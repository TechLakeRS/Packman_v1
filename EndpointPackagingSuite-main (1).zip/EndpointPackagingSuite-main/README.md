# Endpoint Packaging Suite

A Windows desktop application for creating, signing, and deploying application packages to Microsoft Intune.

## Prerequisites

### System
- Windows 10/11 (x64)
- [.NET 9.0 SDK](https://dotnet.microsoft.com/download/dotnet/9.0)
- PowerShell 7.5+

### Azure AD App Registration
- Register an application in Entra ID (Azure AD) with the following Microsoft Graph API permissions:
  - `DeviceManagementApps.ReadWrite.All` — Intune app management
  - `DeviceManagementManagedDevices.Read.All` — device queries and reports
  - `Group.ReadWrite.All` — assignment group management
- Configure authentication: interactive (browser) or certificate-based
- Note your **Tenant ID** and **Client ID** for `appsettings.json`

### Azure Key Vault
- Create a Key Vault and grant the app registration `Key Vault Certificate User` and `Key Vault Secrets User` roles
- Store the code signing certificate as a Base64-encoded PFX (with private key)
- Store per-user GitLab PATs as secrets named `PAT-{username}`

### Code Signing
- An Authenticode code signing certificate, either:
  - Stored in Azure Key Vault (recommended), or
  - Installed in the local Windows certificate store (`CurrentUser\My` or `LocalMachine\My`)
- Timestamp server (defaults to `http://timestamp.digicert.com`)

### GitLab
- A GitLab instance with a project for storing package configurations
- A Personal Access Token (PAT) with `api`, `read_repository`, and `write_repository` scopes
- PAT stored in Azure Key Vault (see above)

### Microsoft Intune
- An Intune-licensed tenant with app management enabled
- Network access to the Microsoft Graph API

## Creating a Package

The package creation wizard guides you through three steps.

### Step 1 — Application Details

Fill in the basic metadata for your application:

| Field | Required | Notes |
|-------|----------|-------|
| Application Name | Yes | Display name shown in Intune |
| Publisher | Yes | Manufacturer name |
| Version | Yes | Defaults to "1" |
| Description | No | Shown in the Intune Company Portal |
| Application Icon | No | PNG or ICO, max 1 MB |

If you select an MSI installer as your source, the product code, version, and upgrade code are extracted automatically.

### Step 2 — Detection Rules

Configure at least one detection rule so Intune can determine whether the app is installed. Three types are available:

- **File detection** — specify a file path and name; optionally check the file version
- **Registry detection** — specify a registry path and value name; choose between Exists, Does not exist, or Equals
- **MSI detection** — specify a product code; optionally check the version with an operator

### Step 3 — Review & Upload

A read-only summary of your application details, deployment configuration, and detection rules. From here you can proceed to upload or go back and edit.

### What Gets Generated

The tool creates a PSADT v4 folder structure at your configured Intune applications path:

```
Manufacturer_AppName/
  Version/
    Application/          ← PSADT v4 toolkit + install scripts
      Files/              ← Your source installer
    Icon/                 ← Application icon
    Intune/               ← Generated .intunewin file (after upload)
    NBB_Info/             ← Detection rules and metadata
    Project Files/
```

### PSADT Configuration (Optional)

Before uploading, you can open the **Configure PSADT Options** dialog to inject PSADT functions into six script phases:

- Pre-Installation, Installation, Post-Installation
- Pre-Uninstallation, Uninstallation, Post-Uninstallation

Functions are searchable and categorized. Selected functions are previewed in real time before being injected into the script.

---

## Upgrading a Package

Toggle to **Upgrade Mode** on the main dashboard to create a new version of an existing package.

### Inputs

| Field | Description |
|-------|-------------|
| Existing Package Path | Browse to the folder of the package you want to upgrade |
| New Version | The version string for the upgrade (e.g. "2.0.0") |
| New Source File | The new MSI or EXE installer |

### What Happens

1. A new version folder is created alongside the old one (e.g. `Vendor_AppName/2.0.0/`). The old package is not modified.
2. The existing PSADT scripts, custom modifications, icon, and detection rules are copied into the new version folder.
3. The old source files are replaced with the new installer in `Application/Files/`.
4. Script metadata (version, date, source file references) is updated automatically. MSI product codes are re-extracted if upgrading to a new MSI.
5. If the old package uses PSADT v3, the upgrade automatically migrates the scripts to v4 format.

After upgrading, the workflow continues to the optional remote test and upload steps.

---

## Uploading to Intune

The upload process runs automatically after you confirm the review step. It performs 12 sequential operations:

1. **Authenticate** — obtains a Microsoft Graph access token
2. **Sign scripts** — code signs the PSADT script (SHA-256 + RFC 3161 timestamp)
3. **Package** — runs IntuneWinAppUtil.exe to create the encrypted `.intunewin` file
4. **Verify** — locates the generated `.intunewin` file
5. **Extract metadata** — reads encryption keys and file digest from the package
6. **Register app** — creates the Win32LobApp in Intune via Graph API
7. **Create content version** — initializes a new version for the app
8. **Create file entry** — registers the file for upload with size metadata
9. **Request Azure URI** — polls for an Azure Storage SAS URI (up to 20 minutes)
10. **Upload** — uploads the encrypted package in 4–6 MB chunks
11. **Commit** — submits encryption metadata to finalize the upload
12. **Publish** — marks the app as available in Intune

### What You See

- A progress bar with percentage and real-time status text (e.g. "Uploading chunk 45/120")
- Step icons that turn into checkmarks as each operation completes
- SAS tokens are renewed automatically every 7 minutes for large uploads

### Assignments

After a successful upload, assignment groups are created automatically:

- System Install, User Install, System Uninstall, User Uninstall

The app is initially assigned to the **Test** category.

### Failure Handling

- Chunk uploads retry up to 5 times with exponential backoff
- Network errors and throttling (429) are retried automatically
- If the upload fails partway through, the app may still exist in Intune — check the admin center

---

## Remote Test Deployment

Test a package on a remote machine before uploading to Intune.

### How to Use

1. Enter a **computer name** (recent targets are saved in a dropdown, up to 10)
2. Click **Check Status** to verify the machine is online (ping with 2-second timeout)
3. Select a **deployment type**: Install, Uninstall, or Repair
4. Optionally enable **Interactive Mode** to show PSADT UI dialogs to the logged-in user
5. Click **Deploy**

### What Happens

1. A temp directory is created on the remote machine at `C:\Temp\AppDeploy` via PsExec
2. The entire package is copied over SMB (`\\ComputerName\C$\Temp\AppDeploy`)
3. The PSADT script is executed remotely via PsExec under SYSTEM context
4. The temp directory is cleaned up automatically after deployment

### Output

- Real-time console output with timestamps streams to the dialog
- File copy progress and package size are displayed
- Exit codes are interpreted: 0 = success, 3010/1641 = success with reboot needed
- After a successful install, detection rules are auto-discovered from the remote machine
- You can export the log to a `.txt` or `.log` file

**Protocols used:** Ping (connectivity check), SMB (file copy), PsExec (remote execution). No explicit credentials required — runs under your current Windows identity.

---

## Code Signing

Sign files using your Authenticode certificate from Azure Key Vault.

### Supported File Types

| Category | Extensions |
|----------|------------|
| Executables | `.exe`, `.dll`, `.sys`, `.ocx`, `.scr`, `.cpl`, `.drv`, `.efi`, `.mui`, `.winmd`, `.ax` |
| Installers | `.msi`, `.msp`, `.msm` |
| Catalogs | `.cat` |
| PowerShell | `.ps1`, `.psm1`, `.psd1`, `.ps1xml` |

### How to Use

1. Open the **Sign** view
2. Add files individually, in bulk, or by scanning a folder (with recursive option)
3. Files appear in a grid with a Pending status
4. Click **Sign** — files are signed sequentially with a progress bar

The certificate is loaded from Azure Key Vault at startup. A status indicator at the top of the view shows "Certificate ready" or "Certificate not loaded — check Key Vault."

### Technical Details

- Uses native Windows Authenticode signing via `SignerSignEx2` (Mssign32.dll) — no external tools or PFX files on disk
- SHA-256 hashing with RFC 3161 timestamps (default: `http://timestamp.digicert.com`)
- The certificate never leaves memory — all cryptographic operations happen in-process
- Timestamps ensure signatures remain valid after certificate expiration

---

## WDAC (Windows Defender Application Control)

Generate and verify security catalogs for application whitelisting.

### Generate a Catalog

1. Select an application path
2. Click **Generate Catalog** — the task is added to a queue
3. Tasks execute sequentially in the background via a Hyper-V host
4. Status updates in the queue grid: Queued → Running → Complete (or Failed)
5. Completed catalogs are automatically signed

The catalog generation uses PsExec to run PowerShell on a configured Hyper-V host, which restores a VM snapshot, generates file hashes, and produces the `.cat` file.

### Verify Catalogs

1. Click **Verify Catalogs** and select one or more `.cat` files
2. The verification window shows:
   - Signature validity
   - Catalog members (file/hash pairs)
   - Structural integrity (via `Test-FileCatalog` with certutil fallback)

---

## Logs & Diagnostics

### Log Viewer

The Logs view has three tabs:

- **Intune Logs** — Intune Management Extension logs from `ProgramData\Microsoft\IntuneManagementExtension\Logs`
- **System App Logs** — NBB system installation logs from `C:\NBB\Logs\Software_Installations`
- **All Logs** — combined view with a source column

Each entry shows the file name, size, and last modified date. Click **View** to open a log in CMTrace (falls back to Notepad if CMTrace is unavailable). For remote machines, logs are copied to a local temp folder first.

### Detection Rule Discovery

After deploying an app (locally or remotely), the tool can auto-discover detection rules by scanning the target machine:

- Searches the registry uninstall keys (both 32-bit and 64-bit) via WMI
- Scans Program Files directories for matching executables
- Uses installer metadata (product name, company, version) to refine matches
- Outputs detection methods prioritized as: MSI > Registry > File
