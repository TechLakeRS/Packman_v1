using Endpoint_Packaging_Suite.Constants;
using Endpoint_Packaging_Suite.Helpers;
using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite.Services;
using Endpoint_Packaging_Suite.Dialogs;
using Endpoint_Packaging_Suite.ViewModels;
using Endpoint_Packaging_Suite.Views;
using Microsoft.Extensions.DependencyInjection;
using Serilog;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Endpoint_Packaging_Suite
{
    public partial class MainWindow
    {
        private void ClearSearch_Click(object sender, RoutedEventArgs e)
        {
            SearchTextBox.Clear();
            SearchTextBox.Focus();
        }

        // Mouse wheel scrolling is now handled by outer ScrollViewer
        private void ApplicationsList_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
        {
            if (!e.Handled)
            {
                e.Handled = true;
                var eventArg = new MouseWheelEventArgs(e.MouseDevice, e.Timestamp, e.Delta);
                eventArg.RoutedEvent = UIElement.MouseWheelEvent;
                eventArg.Source = sender;
                var parent = ((Control)sender).Parent as UIElement;
                parent?.RaiseEvent(eventArg);
            }
        }

        private void ApplicationsList_ScrollChanged(object sender, ScrollChangedEventArgs e)
        {
            // No-op: Pagination buttons are used instead
        }

        private async void ApplicationsList_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (ApplicationsList.SelectedItem != null)
            {
                var selectedApp = ApplicationsList.SelectedItem as IntuneApplication;
                if (selectedApp != null)
                {
                    try
                    {
                        StatusText.Text = $"Loading details for {selectedApp.DisplayName} from Microsoft Intune...";
                        ProgressBar.Visibility = Visibility.Visible;
                        ProgressBar.IsIndeterminate = true;

                        if (_intuneService == null)
                        {
                            ModernMessageBox.Show("Intune service is not initialized", "Error",
                                MessageBoxButton.OK, MessageBoxIcon.Error);
                            return;
                        }

                        // Get data on background thread
                        var appDetail = await _intuneService.GetApplicationDetailAsync(selectedApp.Id)
                            .ConfigureAwait(false);

                        // ALL UI updates must go through Dispatcher after ConfigureAwait(false)
                        await Dispatcher.InvokeAsync(() =>
                        {
                            ProgressBar.Visibility = Visibility.Collapsed;

                            if (appDetail != null)
                            {
                                ApplicationsListPanel.Visibility = Visibility.Collapsed;
                                ApplicationDetailView.Visibility = Visibility.Visible;
                                ApplicationDetailView.LoadApplicationDetail(appDetail);
                                ApplicationDetailView.ResetScrollPosition();

                                // Hide MainWindow header - ApplicationDetailView has its own header
                                PageHeader.Visibility = Visibility.Collapsed;
                                StatusText.Text = $"Loaded live details for {selectedApp.DisplayName} from Intune";
                            }
                        });
                    }
                    catch (Exception ex)
                    {
                        // Even error handling needs Dispatcher after ConfigureAwait(false)
                        await Dispatcher.InvokeAsync(() =>
                        {
                            ProgressBar.Visibility = Visibility.Collapsed;
                            StatusText.Text = "Error loading application details";
                            ModernMessageBox.Show($"Error loading application details from Intune:\n\n{ex.Message}",
                                "Intune API Error", MessageBoxButton.OK, MessageBoxIcon.Error);
                        });
                    }
                }
            }
        }

        private void ApplicationDetailView_BackToListRequested(object? sender, EventArgs e)
        {
            ApplicationDetailView.Visibility = Visibility.Collapsed;
            ApplicationsListPanel.Visibility = Visibility.Visible;

            // Show MainWindow header again
            PageHeader.Visibility = Visibility.Visible;
            PageTitle.Text = "Microsoft Intune Applications";
            PageSubtitle.Text = "Browse and manage your application packages";
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            // VM.SearchFilter is updated by the TwoWay binding (UpdateSourceTrigger=PropertyChanged).
            // We just (re)start the debounce timer here.
            _searchTimer?.Stop();
            _searchTimer?.Start();
        }

        private async void SearchTimer_Tick(object? sender, EventArgs e)
        {
            _searchTimer?.Stop();

            if (_applicationListViewModel != null)
            {
                if (!_applicationListViewModel.ApplicationsLoaded)
                {
                    await _applicationListViewModel.LoadAllApplicationsAsync();
                }
                else
                {
                    _applicationListViewModel.ApplyFiltersAndPagination();
                }
            }
        }

        private async void CategoryFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // VM.CategoryFilter is updated by the SelectedItem binding.
            if (_applicationListViewModel != null)
            {
                if (!_applicationListViewModel.ApplicationsLoaded)
                {
                    await _applicationListViewModel.LoadAllApplicationsAsync();
                }
                else
                {
                    _applicationListViewModel.ApplyFiltersAndPagination();
                }
            }
        }

        private async void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            if (_applicationListViewModel != null)
            {
                await _applicationListViewModel.RefreshApplicationsAsync();
            }
        }

        private void NextPage_Click(object sender, RoutedEventArgs e)
        {
            _applicationListViewModel?.NextPage();
        }

        private void PreviousPage_Click(object sender, RoutedEventArgs e)
        {
            _applicationListViewModel?.PreviousPage();
        }

        private void PageSize_Changed(object sender, SelectionChangedEventArgs e)
        {
            if (_applicationListViewModel != null &&
                PageSizeCombo.SelectedItem is ComboBoxItem item &&
                int.TryParse(item.Tag.ToString(), out int newPageSize))
            {
                _applicationListViewModel.SetPageSize(newPageSize);
                if (_applicationListViewModel.ApplicationsLoaded)
                {
                    _applicationListViewModel.ApplyFiltersAndPagination();
                }
            }
        }

        private void PopulateCategoryDropdown()
        {
            CategoryFilter.Items.Clear();
            CategoryFilter.Items.Add(AppConstants.Defaults.AllCategoriesFilter);
            CategoryFilter.Items.Add("Business");
            CategoryFilter.Items.Add("Hidden");
            CategoryFilter.Items.Add("OSD");
            CategoryFilter.Items.Add("Retired");
            CategoryFilter.Items.Add("Retired, Hidden");
            CategoryFilter.Items.Add("Technical");
            CategoryFilter.Items.Add("Test");
            CategoryFilter.Items.Add("Test, Business");
            CategoryFilter.Items.Add("Uncategorized");

            CategoryFilter.SelectedIndex = 0;
        }

        private void OnApplicationListVmPropertyChanged(object? sender, PropertyChangedEventArgs e)
        {
            if (_applicationListViewModel == null) return;

            switch (e.PropertyName)
            {
                case nameof(ApplicationListViewModel.StatusText):
                    StatusText.Text = _applicationListViewModel.StatusText;
                    break;
                case nameof(ApplicationListViewModel.ProgressBarVisibility):
                    ProgressBar.Visibility = _applicationListViewModel.ProgressBarVisibility;
                    if (ProgressBar.Visibility == Visibility.Visible)
                    {
                        ProgressBar.IsIndeterminate = true;
                    }
                    break;
                case nameof(ApplicationListViewModel.LastSyncDisplayText):
                    LastSyncText.Text = _applicationListViewModel.LastSyncDisplayText;
                    break;
            }
        }
    }
}
