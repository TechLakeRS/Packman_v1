using Endpoint_Packaging_Suite.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Endpoint_Packaging_Suite.Services
{
    /// <summary>
    /// Result of package creation validation
    /// </summary>
    public class PackageValidationResult
    {
        public bool PackageExists { get; set; }
        public string ExistingPath { get; set; } = string.Empty;
        public string ProposedPath { get; set; } = string.Empty;
        public string AppFolderName { get; set; } = string.Empty;
        public string Version { get; set; } = string.Empty;
    }

    /// <summary>
    /// Defines where in the PSADT script a function call should be placed.
    /// Covers Install and Uninstall deployment types (Repair excluded by design).
    /// </summary>
    public enum ScriptPhase
    {
        PreInstallation,
        Installation,
        PostInstallation,
        PreUninstallation,
        Uninstallation,
        PostUninstallation
    }

    /// <summary>
    /// PSADT configuration options using function-based selections per phase.
    /// Each phase holds an ordered list of PSADT function calls (as code strings).
    /// </summary>
    public class PSADTOptions
    {
        /// <summary>
        /// Function entries keyed by ScriptPhase. Each entry is an ordered list of function calls.
        /// </summary>
        public Dictionary<ScriptPhase, List<PSADTFunctionEntry>> PhaseEntries { get; set; } = new()
        {
            { ScriptPhase.PreInstallation, new() },
            { ScriptPhase.Installation, new() },
            { ScriptPhase.PostInstallation, new() },
            { ScriptPhase.PreUninstallation, new() },
            { ScriptPhase.Uninstallation, new() },
            { ScriptPhase.PostUninstallation, new() },
        };

        // Package Info
        public string PackageType { get; set; } = string.Empty;

        /// <summary>
        /// Returns the total count of function entries across all phases.
        /// </summary>
        public int GetEnabledOptionsCount()
        {
            return PhaseEntries.Values.Sum(entries => entries.Count);
        }

        /// <summary>
        /// Gets a flat list of all function names added across all phases (for tag display).
        /// </summary>
        public List<string> GetAllFunctionNames()
        {
            return PhaseEntries.Values
                .SelectMany(entries => entries)
                .Select(e => e.FunctionName)
                .ToList();
        }

        /// <summary>
        /// Gets the code for a specific phase, joined with newlines.
        /// </summary>
        public string GetPhaseCode(ScriptPhase phase)
        {
            if (!PhaseEntries.TryGetValue(phase, out var entries) || entries.Count == 0)
                return string.Empty;

            return string.Join("\n", entries.Select(e => e.GeneratedCode));
        }
    }
}
