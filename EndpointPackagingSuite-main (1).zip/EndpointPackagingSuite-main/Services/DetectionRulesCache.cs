﻿using Endpoint_Packaging_Suite.Models;
using System.IO;

using System.Text.Json;


namespace Endpoint_Packaging_Suite.Services

{

    /// <summary>

    /// Cache for detection rules discovered during remote deployment testing.

    /// Persists rules to package metadata for later use in Intune upload wizard.

    /// </summary>

    public static class DetectionRulesCache

    {

        private const string MetadataFolder = "nbb_info";

        private const string DetectionRulesFile = "detection_rules.json";



        private class DetectionMetadata

        {

            public List<DetectionRule> Rules { get; set; } = new List<DetectionRule>();

            public string PackagePath { get; set; } = "";

            public string DiscoveredDate { get; set; } = "";

            public string ComputerName { get; set; } = "";

        }



        /// <summary>

        /// Store discovered detection rules to package metadata

        /// </summary>

        public static void SetDiscoveredRules(List<DetectionRule> rules, string packagePath = "", string computerName = "")

        {

            if (string.IsNullOrEmpty(packagePath) || !Directory.Exists(packagePath))

            {

                return;

            }



            try

            {

                // Create nbb_info metadata folder in package root

                var metadataDir = Path.Combine(packagePath, MetadataFolder);

                Directory.CreateDirectory(metadataDir);



                // Save detection rules to JSON

                var metadata = new DetectionMetadata

                {

                    Rules = rules,

                    PackagePath = packagePath,

                    DiscoveredDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),

                    ComputerName = computerName

                };



                var metadataFile = Path.Combine(metadataDir, DetectionRulesFile);

                var json = JsonSerializer.Serialize(metadata, new JsonSerializerOptions

                {

                    WriteIndented = true

                });



                File.WriteAllText(metadataFile, json);

            }

            catch (Exception ex)

            {

                System.Diagnostics.Debug.WriteLine($"Error saving detection rules to metadata: {ex.Message}");

            }

        }



        /// <summary>

        /// Get detection rules from package metadata (does not clear)

        /// </summary>

        public static List<DetectionRule>? GetRulesFromPackage(string packagePath, out string computerName)

        {

            computerName = "";



            if (string.IsNullOrEmpty(packagePath) || !Directory.Exists(packagePath))

            {

                return null;

            }



            try

            {

                var metadataFile = Path.Combine(packagePath, MetadataFolder, DetectionRulesFile);



                if (!File.Exists(metadataFile))

                {

                    return null;

                }



                var json = File.ReadAllText(metadataFile);

                var metadata = JsonSerializer.Deserialize<DetectionMetadata>(json);



                if (metadata != null && metadata.Rules != null && metadata.Rules.Count > 0)

                {

                    computerName = metadata.ComputerName;

                    return metadata.Rules;

                }

            }

            catch (Exception ex)

            {

                System.Diagnostics.Debug.WriteLine($"Error loading detection rules from metadata: {ex.Message}");

            }



            return null;

        }



        /// <summary>

        /// Check if package has cached detection rules

        /// </summary>

        public static bool HasCachedRules(string packagePath)

        {

            if (string.IsNullOrEmpty(packagePath))

                return false;



            var metadataFile = Path.Combine(packagePath, MetadataFolder, DetectionRulesFile);

            return File.Exists(metadataFile);

        }



    }

}