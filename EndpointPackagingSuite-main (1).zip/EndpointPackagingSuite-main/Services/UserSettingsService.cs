﻿// Services/UserSettingsService.cs
using Endpoint_Packaging_Suite.Models;
using System;
using System.IO;
using System.Text.Json;

namespace Endpoint_Packaging_Suite.Services
{
    /// <summary>
    /// Manages user-specific settings stored in AppData\Local\Endpoint_Packaging_Suite\settings.json
    /// These settings are per-user and not shared across the application installation.
    /// </summary>
    public class UserSettingsService
    {
        private readonly string _settingsDirectory;
        private readonly string _settingsFilePath;
        private UserSettings? _settings;

        /// <summary>
        /// Constructor for dependency injection
        /// </summary>
        public UserSettingsService()
        {
            // Store settings in %LOCALAPPDATA%\Endpoint_Packaging_Suite\settings.json
            _settingsDirectory = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Endpoint_Packaging_Suite"
            );
            _settingsFilePath = Path.Combine(_settingsDirectory, "settings.json");
        }

        /// <summary>
        /// Gets the current user settings, loading from disk if necessary
        /// </summary>
        public UserSettings Settings
        {
            get
            {
                if (_settings == null)
                {
                    LoadSettings();
                }
                return _settings!;
            }
        }

        /// <summary>
        /// Load user settings from the settings file
        /// </summary>
        public void LoadSettings()
        {
            try
            {
                // Ensure directory exists
                if (!Directory.Exists(_settingsDirectory))
                {
                    Directory.CreateDirectory(_settingsDirectory);
                    System.Diagnostics.Debug.WriteLine($"Created user settings directory: {_settingsDirectory}");
                }

                if (File.Exists(_settingsFilePath))
                {
                    var json = File.ReadAllText(_settingsFilePath);
                    var options = new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true,
                        ReadCommentHandling = JsonCommentHandling.Skip,
                        AllowTrailingCommas = true
                    };

                    _settings = JsonSerializer.Deserialize<UserSettings>(json, options);

                    if (_settings == null)
                    {
                        System.Diagnostics.Debug.WriteLine("Failed to deserialize user settings, using defaults");
                        _settings = new UserSettings();
                    }
                    else
                    {
                        System.Diagnostics.Debug.WriteLine($"Loaded user settings from: {_settingsFilePath}");
                    }
                }
                else
                {
                    // Create default settings
                    _settings = new UserSettings();
                    System.Diagnostics.Debug.WriteLine("User settings file not found, using defaults");

                    // Save defaults to create the file
                    SaveSettings();
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error loading user settings: {ex.Message}");
                _settings = new UserSettings();
            }
        }

        /// <summary>
        /// Save current user settings to disk
        /// </summary>
        public void SaveSettings()
        {
            try
            {
                // Ensure directory exists
                if (!Directory.Exists(_settingsDirectory))
                {
                    Directory.CreateDirectory(_settingsDirectory);
                }

                var options = new JsonSerializerOptions
                {
                    WriteIndented = true
                };

                var json = JsonSerializer.Serialize(_settings, options);
                File.WriteAllText(_settingsFilePath, json);

                System.Diagnostics.Debug.WriteLine($"Saved user settings to: {_settingsFilePath}");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Failed to save user settings: {ex.Message}");
                throw;
            }
        }

    }
}