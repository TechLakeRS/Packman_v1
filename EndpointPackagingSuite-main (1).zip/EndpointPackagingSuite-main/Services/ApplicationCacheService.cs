using Endpoint_Packaging_Suite.Models;
using Serilog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;

namespace Endpoint_Packaging_Suite.Services
{
    /// <summary>
    /// Disk-based cache for the Intune application list.
    /// Persists between sessions so the next launch can compare against API count
    /// and only pull deltas.
    /// </summary>
    public class ApplicationCacheService
    {
        private readonly ILogger _logger = Log.ForContext<ApplicationCacheService>();
        private readonly string _cacheFilePath;
        private readonly SemaphoreSlim _ioLock = new(1, 1);
        private List<IntuneApplication>? _inMemoryCache;

        private static readonly JsonSerializerOptions _jsonOptions = new()
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        };

        public ApplicationCacheService()
        {
            var cacheDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Endpoint_Packaging_Suite",
                "AppListCache");

            Directory.CreateDirectory(cacheDir);
            _cacheFilePath = Path.Combine(cacheDir, "applications.json");
        }

        /// <summary>
        /// Loads the cached application list from disk. Returns null if no cache exists.
        /// </summary>
        public async Task<List<IntuneApplication>?> LoadAsync()
        {
            await _ioLock.WaitAsync();
            try
            {
                if (_inMemoryCache != null)
                    return new List<IntuneApplication>(_inMemoryCache);

                if (!File.Exists(_cacheFilePath))
                {
                    _logger.Debug("No application cache file at {Path}", _cacheFilePath);
                    return null;
                }

                var json = await File.ReadAllTextAsync(_cacheFilePath);
                var apps = JsonSerializer.Deserialize<List<IntuneApplication>>(json, _jsonOptions);
                if (apps == null)
                    return null;

                _inMemoryCache = apps;
                _logger.Information("Loaded {Count} applications from disk cache", apps.Count);
                return new List<IntuneApplication>(apps);
            }
            catch (Exception ex)
            {
                _logger.Warning(ex, "Failed to load application cache; treating as empty");
                return null;
            }
            finally
            {
                _ioLock.Release();
            }
        }

        /// <summary>
        /// Replaces the entire cache with the supplied applications.
        /// </summary>
        public async Task SaveAsync(List<IntuneApplication> applications)
        {
            await _ioLock.WaitAsync();
            try
            {
                _inMemoryCache = new List<IntuneApplication>(applications);
                var json = JsonSerializer.Serialize(applications, _jsonOptions);
                await File.WriteAllTextAsync(_cacheFilePath, json);
                _logger.Information("Saved {Count} applications to disk cache", applications.Count);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Failed to save application cache");
            }
            finally
            {
                _ioLock.Release();
            }
        }

        /// <summary>
        /// Removes a single application from the cache by ID.
        /// Used after an upload/update so the next load detects the discrepancy
        /// and re-fetches the updated entry.
        /// </summary>
        public async Task RemoveAsync(string appId)
        {
            if (string.IsNullOrEmpty(appId))
                return;

            await _ioLock.WaitAsync();
            try
            {
                if (_inMemoryCache == null && !File.Exists(_cacheFilePath))
                    return;

                if (_inMemoryCache == null)
                {
                    var json = await File.ReadAllTextAsync(_cacheFilePath);
                    _inMemoryCache = JsonSerializer.Deserialize<List<IntuneApplication>>(json, _jsonOptions);
                }

                if (_inMemoryCache == null) return;

                int removed = _inMemoryCache.RemoveAll(a => a.Id == appId);
                if (removed > 0)
                {
                    var updatedJson = JsonSerializer.Serialize(_inMemoryCache, _jsonOptions);
                    await File.WriteAllTextAsync(_cacheFilePath, updatedJson);
                    _logger.Debug("Removed app {AppId} from cache", appId);
                }
            }
            catch (Exception ex)
            {
                _logger.Warning(ex, "Failed to remove app {AppId} from cache", appId);
            }
            finally
            {
                _ioLock.Release();
            }
        }

        /// <summary>
        /// Clears the entire cache (memory and disk).
        /// </summary>
        public async Task ClearAsync()
        {
            await _ioLock.WaitAsync();
            try
            {
                _inMemoryCache = null;
                if (File.Exists(_cacheFilePath))
                    File.Delete(_cacheFilePath);
                _logger.Information("Application cache cleared");
            }
            catch (Exception ex)
            {
                _logger.Warning(ex, "Failed to clear application cache");
            }
            finally
            {
                _ioLock.Release();
            }
        }
    }
}
