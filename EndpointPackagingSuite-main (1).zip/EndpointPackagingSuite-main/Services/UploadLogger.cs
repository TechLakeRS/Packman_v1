﻿using System;
using System.Diagnostics;
using System.IO;
using System.Text;

namespace Endpoint_Packaging_Suite.Services
{
    /// <summary>
    /// Log operation type for organizing logs into subfolders
    /// </summary>
    public enum LogOperationType
    {
        Upload,
        Update
    }

    /// <summary>
    /// Dedicated logger for upload/update operations - creates per-package log files
    /// </summary>
    public class UploadLogger : IDisposable
    {
        private readonly string _logFilePath;
        private readonly object _lockObject = new object();
        private StreamWriter? _logWriter;
        private bool _disposed = false;
        private readonly LogOperationType _operationType;

        /// <summary>
        /// Create a new upload logger for a specific application (defaults to Upload operation)
        /// </summary>
        /// <param name="applicationName">Name of the application being uploaded</param>
        public UploadLogger(string applicationName) : this(applicationName, LogOperationType.Upload)
        {
        }

        /// <summary>
        /// Create a new logger for a specific application and operation type
        /// </summary>
        /// <param name="applicationName">Name of the application</param>
        /// <param name="operationType">Type of operation (Upload or Update)</param>
        public UploadLogger(string applicationName, LogOperationType operationType)
        {
            _operationType = operationType;

            // Create log directory structure: %LocalAppData%\Endpoint_Packaging_Suite\Logs\{Upload|Update}
            var logDirectory = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Endpoint_Packaging_Suite",
                "Logs",
                operationType.ToString()
            );

            // Ensure directory exists
            if (!Directory.Exists(logDirectory))
            {
                Directory.CreateDirectory(logDirectory);
            }

            // Sanitize application name for filename (remove invalid characters)
            var safeAppName = string.Join("_", applicationName.Split(Path.GetInvalidFileNameChars()));

            // Create filename: AppName-Date.log (e.g., "MyApp-2025-11-13.log")
            var dateString = DateTime.Now.ToString("yyyy-MM-dd");
            var fileName = $"{safeAppName}-{dateString}.log";
            _logFilePath = Path.Combine(logDirectory, fileName);

            // Initialize log file
            InitializeLogFile();
        }

        private void InitializeLogFile()
        {
            try
            {
                // Open file in append mode (allows multiple uploads on same day)
                _logWriter = new StreamWriter(_logFilePath, append: true, Encoding.UTF8)
                {
                    AutoFlush = true // Ensure immediate writes
                };

                // Write session header
                LogSessionStart();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"⚠️ UploadLogger: Failed to initialize log file: {ex.Message}");
            }
        }

        private void LogSessionStart()
        {
            var separator = new string('=', 80);
            WriteToLog(separator);
            WriteToLog($"{_operationType} Session Started: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
            WriteToLog(separator);
            WriteToLog("");
        }

        /// <summary>
        /// Log an informational message
        /// </summary>
        public void Info(string message)
        {
            WriteToLog($"[INFO ] {DateTime.Now:HH:mm:ss} - {message}");
        }

        /// <summary>
        /// Log a success message
        /// </summary>
        public void Success(string message)
        {
            WriteToLog($"[✓    ] {DateTime.Now:HH:mm:ss} - {message}");
        }

        /// <summary>
        /// Log a warning message
        /// </summary>
        public void Warning(string message)
        {
            WriteToLog($"[WARN ] {DateTime.Now:HH:mm:ss} - {message}");
        }

        /// <summary>
        /// Log an error message
        /// </summary>
        public void Error(string message)
        {
            WriteToLog($"[ERROR] {DateTime.Now:HH:mm:ss} - {message}");
        }

        /// <summary>
        /// Log an error with exception details
        /// </summary>
        public void Error(string message, Exception ex)
        {
            WriteToLog($"[ERROR] {DateTime.Now:HH:mm:ss} - {message}");
            WriteToLog($"        Exception: {ex.GetType().Name}");
            WriteToLog($"        Message: {ex.Message}");
            if (ex.InnerException != null)
            {
                WriteToLog($"        Inner Exception: {ex.InnerException.Message}");
            }
            WriteToLog($"        Stack Trace:");
            WriteToLog($"        {ex.StackTrace?.Replace(Environment.NewLine, Environment.NewLine + "        ")}");
        }

        /// <summary>
        /// Log a progress update
        /// </summary>
        public void Progress(int percentage, string message)
        {
            WriteToLog($"[{percentage,3}%] {DateTime.Now:HH:mm:ss} - {message}");
        }

        /// <summary>
        /// Log upload metadata (app info, package path, etc.)
        /// </summary>
        public void LogMetadata(string key, string value)
        {
            WriteToLog($"  {key}: {value}");
        }

        /// <summary>
        /// Write a section header
        /// </summary>
        public void Section(string sectionName)
        {
            WriteToLog("");
            WriteToLog($"--- {sectionName} ---");
        }

        private void WriteToLog(string message)
        {
            if (_disposed || _logWriter == null)
                return;

            lock (_lockObject)
            {
                try
                {
                    _logWriter.WriteLine(message);
                    // Also write to Debug output for immediate visibility
                    Debug.WriteLine(message);
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"⚠️ UploadLogger: Failed to write to log: {ex.Message}");
                }
            }
        }

        private void LogSessionEnd()
        {
            WriteToLog("");
            WriteToLog($"{_operationType} Session Ended: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
            WriteToLog(new string('=', 80));
            WriteToLog("");
        }

        public void Dispose()
        {
            if (_disposed)
                return;

            lock (_lockObject)
            {
                if (_logWriter != null)
                {
                    LogSessionEnd();
                    _logWriter.Flush();
                    _logWriter.Dispose();
                    _logWriter = null;
                }

                _disposed = true;
            }

            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Get the full path to the log file
        /// </summary>
        public string LogFilePath => _logFilePath;
    }
}