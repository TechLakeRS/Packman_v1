using Endpoint_Packaging_Suite.Models;
using Serilog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Endpoint_Packaging_Suite.Services
{
    /// <summary>
    /// PSADT v4 package generator.
    /// Uses modern cmdlet syntax. User install mode is handled via script parameters,
    /// no XML configuration modification is needed.
    /// </summary>
    public class PSADTGenerator
    {
        private readonly string _baseOutputPath = Paths.IntuneApplications;
        private readonly string _templatePath = Paths.PSADTTemplate;
        private readonly Serilog.ILogger _logger;

        public string BaseOutputPath => _baseOutputPath;
        public string TemplatePath => _templatePath;

        public PSADTGenerator()
        {
            _logger = Log.ForContext<PSADTGenerator>();
        }

        /// <summary>
        /// Validates if a package can be created and returns information about existing packages
        /// </summary>
        public PackageValidationResult ValidatePackageCreation(ApplicationInfo appInfo)
        {
            var cleanManufacturer = appInfo.Manufacturer.Replace(" ", "_");
            var cleanAppName = appInfo.Name.Replace(" ", "_");
            var appFolderName = $"{cleanManufacturer}_{cleanAppName}";
            var appBasePath = Path.Combine(_baseOutputPath, appFolderName);
            var packagePath = Path.Combine(appBasePath, appInfo.Version);

            return new PackageValidationResult
            {
                PackageExists = Directory.Exists(packagePath),
                ExistingPath = packagePath,
                ProposedPath = packagePath,
                AppFolderName = appFolderName,
                Version = appInfo.Version
            };
        }

        /// <summary>
        /// Creates a package. If package exists and overwrite is false, throws InvalidOperationException.
        /// </summary>
        public async Task<string> CreatePackageAsync(ApplicationInfo appInfo, PSADTOptions? psadtOptions = null, bool overwriteExisting = false, CancellationToken cancellationToken = default)
        {
            try
            {
                var cleanManufacturer = appInfo.Manufacturer.Replace(" ", "_");
                var cleanAppName = appInfo.Name.Replace(" ", "_");
                var appFolderName = $"{cleanManufacturer}_{cleanAppName}";
                var appBasePath = Path.Combine(_baseOutputPath, appFolderName);
                var packagePath = Path.Combine(appBasePath, appInfo.Version);

                _logger.Information("Creating PSADT v4 package at: {PackagePath}", packagePath);

                // Check if version folder already exists
                if (Directory.Exists(packagePath))
                {
                    if (!overwriteExisting)
                    {
                        _logger.Warning("Package already exists and overwrite not requested: {PackagePath}", packagePath);
                        throw new InvalidOperationException($"Package version {appInfo.Version} already exists for {appFolderName}. Use overwriteExisting=true to replace it.");
                    }

                    _logger.Information("Removing existing package for overwrite: {PackagePath}", packagePath);
                    Directory.Delete(packagePath, true);
                    await Task.Delay(500);
                }

                // Create the app base folder if it doesn't exist
                Directory.CreateDirectory(appBasePath);

                // Copy entire template folder structure (includes Application, Intune, Icon, NBB_Info, Project Files)
                await CopyTemplateFolderAsync(packagePath);
                _logger.Debug("Copied PSADT v4 template folder structure to: {PackagePath}", packagePath);

                // Copy source files to Application\Files if provided
                if (!string.IsNullOrWhiteSpace(appInfo.SourcesPath))
                {
                    bool hasValidSource = false;

                    if (appInfo.SourcesPath.Contains(";"))
                    {
                        var filePaths = appInfo.SourcesPath.Split(';', StringSplitOptions.RemoveEmptyEntries);
                        hasValidSource = filePaths.Any(path => File.Exists(path.Trim()));
                    }
                    else
                    {
                        hasValidSource = File.Exists(appInfo.SourcesPath) || Directory.Exists(appInfo.SourcesPath);
                    }

                    if (hasValidSource)
                    {
                        await CopySourceFilesToApplicationAsync(appInfo.SourcesPath, packagePath);
                    }
                    else
                    {
                        _logger.Warning("Source path not found or invalid: {SourcesPath}", appInfo.SourcesPath);
                    }
                }

                // Modify the PSADT v4 script with metadata AND functions
                await ModifyPSADTScriptAsync(packagePath, appInfo, psadtOptions);

                // PSADT v4: User install is handled via RequireAdmin property in $adtSession, NOT XML config modification
                // No need to call ModifyAppDeployToolkitConfigAsync for user install

                _logger.Information("PSADT v4 package created successfully at: {PackagePath}", packagePath);
                return packagePath;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error creating PSADT v4 package: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// For PSADT v4, user install mode is handled via RequireAdmin in $adtSession, not config modification.
        /// This method is a no-op for v4 but exists for interface compatibility.
        /// Engineers can set RequireAdmin = $false in the $adtSession hashtable for user install.
        /// </summary>
        public Task ModifyConfigForUserInstallAsync(string packagePath, bool userInstall, CancellationToken cancellationToken = default)
        {
            // PSADT v4: Set RequireAdmin = $false in $adtSession for user install
            // Set RequireAdmin = $true in $adtSession for system install (default)
            // This is NOT manipulated programmatically - engineers handle it themselves
            _logger.Debug("PSADT v4: User install mode is controlled via $adtSession.RequireAdmin property. No programmatic modification needed.");
            return Task.CompletedTask;
        }

        /// <summary>
        /// Resolves the root template directory (the folder containing Application, Icon, Intune, etc.).
        /// Handles multiple scenarios for PSADTTemplate setting:
        /// 1. Points to the Application subfolder itself (contains Invoke-AppDeployToolkit.ps1) → use parent
        /// 2. Points to a version folder (e.g., 20260101) that contains Application/ → use as-is
        /// 3. Points to a parent with version subfolders → pick latest version
        /// 4. Empty/missing → fall back to Tools\IntunePackagingTool
        /// </summary>
        private string ResolveTemplatePath()
        {
            var pathsToTry = new List<string>();

            // Primary: configured template path
            if (!string.IsNullOrWhiteSpace(_templatePath))
            {
                pathsToTry.Add(_templatePath);
            }

            // Fallback: try Tools path directly (may itself be IntunePackagingTool)
            // and also Tools\IntunePackagingTool in case Tools points to a parent
            var toolsPath = Paths.Tools;
            if (!string.IsNullOrWhiteSpace(toolsPath))
            {
                pathsToTry.Add(toolsPath);
                pathsToTry.Add(Path.Combine(toolsPath, "IntunePackagingTool"));
            }

            foreach (var basePath in pathsToTry)
            {
                if (!Directory.Exists(basePath))
                    continue;

                var resolved = TryResolveFromPath(basePath);
                if (resolved != null)
                    return resolved;
            }

            var triedPaths = string.Join(", ", pathsToTry.Select(p => $"'{p}'"));
            throw new DirectoryNotFoundException(
                $"PSADT v4 template not found. Searched: {triedPaths}. " +
                "Please set the PSADTTemplate path in appsettings.json to the folder containing " +
                "Application, Icon, Intune, NBB_Info, and Project Files subfolders.");
        }

        /// <summary>
        /// Tries to resolve the template root from a given path.
        /// </summary>
        private string? TryResolveFromPath(string basePath)
        {
            // Case 1: Path IS the Application folder (contains Invoke-AppDeployToolkit.ps1)
            // → use the parent directory which has the full folder structure
            if (File.Exists(Path.Combine(basePath, "Invoke-AppDeployToolkit.ps1")))
            {
                var parent = Directory.GetParent(basePath)?.FullName;
                if (parent != null && Directory.Exists(Path.Combine(parent, "Application")))
                {
                    _logger.Information("PSADTTemplate points to Application folder, using parent: {Parent}", parent);
                    return parent;
                }
            }

            // Case 2: Path directly contains Application subfolder (this is the version folder)
            if (Directory.Exists(Path.Combine(basePath, "Application")))
            {
                _logger.Information("Resolved PSADT v4 template path: {TemplatePath}", basePath);
                return basePath;
            }

            // Case 3: Path contains version subfolders — pick the latest one
            var subDirs = Directory.GetDirectories(basePath)
                .OrderByDescending(d => Path.GetFileName(d))
                .ToList();

            foreach (var subDir in subDirs)
            {
                if (Directory.Exists(Path.Combine(subDir, "Application")))
                {
                    _logger.Information("Resolved PSADT v4 template to version subfolder: {SubDir}", subDir);
                    return subDir;
                }
            }

            return null;
        }

        /// <summary>
        /// Creates the package folder structure and copies template files in parallel.
        /// Creates empty folders (Icon, Intune, NBB_Info, Project Files) directly and
        /// only copies Application from the template (contains PSADT toolkit files).
        /// </summary>
        private async Task CopyTemplateFolderAsync(string packagePath)
        {
            try
            {
                var resolvedTemplatePath = ResolveTemplatePath();
                _logger.Information("Using PSADT v4 template from: {TemplatePath}", resolvedTemplatePath);

                await Task.Run(() =>
                {
                    // Create the package root
                    Directory.CreateDirectory(packagePath);

                    // Create empty scaffold folders directly (no files to copy)
                    var emptyFolders = new[] { "Icon", "Intune", "NBB_Info", "Project Files" };
                    foreach (var folder in emptyFolders)
                    {
                        var templateFolder = Path.Combine(resolvedTemplatePath, folder);
                        var destFolder = Path.Combine(packagePath, folder);

                        if (Directory.Exists(templateFolder))
                        {
                            CopyDirectory(templateFolder, destFolder);
                        }
                        else
                        {
                            Directory.CreateDirectory(destFolder);
                        }
                    }

                    // Copy the Application folder (contains the actual PSADT toolkit)
                    var templateAppFolder = Path.Combine(resolvedTemplatePath, "Application");
                    var destAppFolder = Path.Combine(packagePath, "Application");

                    if (Directory.Exists(templateAppFolder))
                    {
                        CopyDirectory(templateAppFolder, destAppFolder);
                    }
                    else
                    {
                        throw new DirectoryNotFoundException($"Application folder not found in template: {resolvedTemplatePath}");
                    }
                });
            }
            catch (Exception ex)
            {
                throw new Exception($"Error copying PSADT v4 template folder: {ex.Message}", ex);
            }
        }

        private void CopyDirectory(string sourceDir, string destDir)
        {
            Directory.CreateDirectory(destDir);

            foreach (var file in Directory.GetFiles(sourceDir))
            {
                File.Copy(file, Path.Combine(destDir, Path.GetFileName(file)), true);
            }

            foreach (var dir in Directory.GetDirectories(sourceDir))
            {
                CopyDirectory(dir, Path.Combine(destDir, Path.GetFileName(dir)));
            }
        }

        private async Task CopySourceFilesToApplicationAsync(string sourcesPath, string packagePath)
        {
            var filesDestination = Path.Combine(packagePath, "Application", "Files");
            Directory.CreateDirectory(filesDestination);

            await Task.Run(() =>
            {
                if (sourcesPath.Contains(";"))
                {
                    // Multiple files separated by semicolons
                    var filePaths = sourcesPath.Split(';', StringSplitOptions.RemoveEmptyEntries);
                    foreach (var filePath in filePaths)
                    {
                        var trimmedPath = filePath.Trim();
                        if (File.Exists(trimmedPath))
                        {
                            File.Copy(trimmedPath, Path.Combine(filesDestination, Path.GetFileName(trimmedPath)), true);
                        }
                    }
                }
                else if (File.Exists(sourcesPath))
                {
                    // Single file
                    File.Copy(sourcesPath, Path.Combine(filesDestination, Path.GetFileName(sourcesPath)), true);
                }
                else if (Directory.Exists(sourcesPath))
                {
                    // Directory - copy contents
                    CopyDirectory(sourcesPath, filesDestination);
                }
            });
        }

        private async Task ModifyPSADTScriptAsync(string packagePath, ApplicationInfo appInfo, PSADTOptions? psadtOptions)
        {
            try
            {
                // PSADT v4 uses Invoke-AppDeployToolkit.ps1 as the main script
                var scriptPath = Path.Combine(packagePath, "Application", "Invoke-AppDeployToolkit.ps1");

                if (!File.Exists(scriptPath))
                {
                    throw new FileNotFoundException($"Invoke-AppDeployToolkit.ps1 not found in: {packagePath}");
                }

                var scriptContent = await File.ReadAllTextAsync(scriptPath);

                // Update the metadata variables in the script
                scriptContent = UpdateScriptMetadata(scriptContent, appInfo);

                // Always inject install/uninstall commands based on package type
                scriptContent = InjectInstallCommands(scriptContent, appInfo);

                // If PSADT options are provided, inject functions
                if (psadtOptions != null)
                {
                    _logger.Debug("Injecting PSADT v4 functions for {OptionsCount} entries", psadtOptions.GetEnabledOptionsCount());
                    scriptContent = InjectPSADTv4Functions(scriptContent, appInfo, psadtOptions);
                }

                await File.WriteAllTextAsync(scriptPath, scriptContent);
                _logger.Debug("Modified PSADT v4 script successfully");
            }
            catch (Exception ex)
            {
                throw new Exception($"Error modifying PSADT v4 script: {ex.Message}", ex);
            }
        }

        private string UpdateScriptMetadata(string scriptContent, ApplicationInfo appInfo)
        {
            string currentUser = Environment.UserName;
            var lines = scriptContent.Split('\n').ToList();

            for (int i = 0; i < lines.Count; i++)
            {
                var line = lines[i].Trim();

                // PSADT v4 uses $adtSession hashtable format:
                // $adtSession = @{
                //     AppVendor = 'Vendor'
                //     AppName = 'Name'
                //     ...
                // }

                // Match hashtable property assignments (with or without quotes)
                if (line.StartsWith("AppVendor") && line.Contains("="))
                {
                    lines[i] = $"    AppVendor = '{appInfo.Manufacturer}'";
                }
                else if (line.StartsWith("AppName") && line.Contains("=") && !line.Contains("AppNameWithVersion"))
                {
                    lines[i] = $"    AppName = '{appInfo.Name}'";
                }
                else if (line.StartsWith("AppVersion") && line.Contains("="))
                {
                    lines[i] = $"    AppVersion = '{appInfo.Version}'";
                }
                else if (line.StartsWith("AppArch") && line.Contains("="))
                {
                    lines[i] = $"    AppArch = 'x64'";
                }
                else if (line.StartsWith("AppScriptDate") && line.Contains("="))
                {
                    lines[i] = $"    AppScriptDate = '{DateTime.Now:MM/dd/yyyy}'";
                }
                else if (line.StartsWith("AppScriptAuthor") && line.Contains("="))
                {
                    lines[i] = $"    AppScriptAuthor = '{currentUser}'";
                }
                // Also handle processes to close if configured
                else if (line.StartsWith("AppProcessesToClose") && line.Contains("="))
                {
                    var processName = appInfo.Name.Replace(" ", "").ToLower();
                    lines[i] = $"    AppProcessesToClose = @('{processName}')";
                }
            }

            return string.Join('\n', lines);
        }

        private string InjectInstallCommands(string scriptContent, ApplicationInfo appInfo)
        {
            var lines = scriptContent.Split('\n').ToList();
            var sourceFileName = !string.IsNullOrEmpty(appInfo.SourcesPath)
                ? Path.GetFileName(appInfo.SourcesPath)
                : null;

            // Inject install command
            int installIndex = FindSectionIndex(lines, "Installation");
            if (installIndex > 0)
            {
                if (appInfo.PackageType == "MSI")
                {
                    var msiFileName = sourceFileName ?? $"{appInfo.Name}.msi";
                    var code = $"\n## MSI Installation\nStart-ADTMsiProcess -Action 'Install' -FilePath \"$($adtSession.DirFiles)\\{msiFileName}\"";
                    InsertCodeBlock(lines, installIndex, code);
                }
                else
                {
                    var exeFileName = sourceFileName ?? "setup.exe";
                    var code = $"\n## EXE Installation\nStart-ADTProcess -FilePath \"$($adtSession.DirFiles)\\{exeFileName}\" -ArgumentList '<silent flags>'";
                    InsertCodeBlock(lines, installIndex, code);
                }
            }

            // Inject uninstall command
            int uninstallIndex = FindSectionIndex(lines, "Uninstallation");
            if (uninstallIndex > 0)
            {
                if (appInfo.PackageType == "MSI")
                {
                    var productCode = !string.IsNullOrEmpty(appInfo.MsiProductCode) ? appInfo.MsiProductCode : "{ProductCode}";
                    var code = $"\n## Uninstall MSI application by Product Code\nStart-ADTMsiProcess -Action 'Uninstall' -FilePath '{productCode}'";
                    InsertCodeBlock(lines, uninstallIndex, code);
                }
                else
                {
                    var exeFileName = sourceFileName ?? "setup.exe";
                    var code = $"\n## Uninstall EXE application\nStart-ADTProcess -FilePath \"$($adtSession.DirFiles)\\{exeFileName}\" -ArgumentList '<uninstall flags>'";
                    InsertCodeBlock(lines, uninstallIndex, code);
                }
            }

            return string.Join('\n', lines);
        }

        private string InjectPSADTv4Functions(string scriptContent, ApplicationInfo appInfo, PSADTOptions options)
        {
            var lines = scriptContent.Split('\n').ToList();
            int functionsInjected = 0;

            // Map ScriptPhase to template section marker names
            var phaseMarkerMap = new Dictionary<ScriptPhase, string>
            {
                { ScriptPhase.PreInstallation, "Pre-Installation" },
                { ScriptPhase.Installation, "Installation" },
                { ScriptPhase.PostInstallation, "Post-Installation" },
                { ScriptPhase.PreUninstallation, "Pre-Uninstallation" },
                { ScriptPhase.Uninstallation, "Uninstallation" },
                { ScriptPhase.PostUninstallation, "Post-Uninstallation" },
            };

            // Process phases in reverse order so line index adjustments don't affect earlier phases
            var phasesInOrder = new[]
            {
                ScriptPhase.PostUninstallation,
                ScriptPhase.Uninstallation,
                ScriptPhase.PreUninstallation,
                ScriptPhase.PostInstallation,
                ScriptPhase.Installation,
                ScriptPhase.PreInstallation,
            };

            foreach (var phase in phasesInOrder)
            {
                var code = options.GetPhaseCode(phase);
                if (string.IsNullOrWhiteSpace(code)) continue;

                var markerName = phaseMarkerMap[phase];
                int sectionIndex = FindSectionIndex(lines, markerName);

                if (sectionIndex > 0)
                {
                    InsertCodeBlock(lines, sectionIndex, code);
                    functionsInjected++;
                }
                else
                {
                    _logger.Warning("Could not find section marker for {Phase}", markerName);
                }
            }

            _logger.Debug("Injected {FunctionsInjected} PSADT v4 sections", functionsInjected);
            return string.Join('\n', lines);
        }

        private int FindSectionIndex(List<string> lines, string sectionName)
        {
            // PSADT v4 uses markers like:
            // ## <Perform Pre-Installation tasks here>
            // ## <Perform Installation tasks here>
            // ## <Perform Post-Installation tasks here>
            // ## <Perform Pre-Uninstallation tasks here>
            // ## <Perform Uninstallation tasks here>
            // ## <Perform Post-Uninstallation tasks here>

            for (int i = 0; i < lines.Count; i++)
            {
                var line = lines[i];

                // v4-style marker: ## <Perform {sectionName} tasks here>
                if (line.Contains($"<Perform {sectionName} tasks here>"))
                {
                    return i + 1;
                }

                // Alternative: Just look for section name with ## prefix
                if (line.Contains($"## {sectionName}") || line.Contains($"## <{sectionName}>"))
                {
                    return i + 1;
                }
            }
            return -1;
        }

        private void InsertCodeBlock(List<string> lines, int index, string codeBlock)
        {
            var codeLines = codeBlock.Split('\n');
            for (int i = 0; i < codeLines.Length; i++)
            {
                lines.Insert(index + i, codeLines[i]);
            }
        }
    }
}
