using Endpoint_Packaging_Suite.Controls;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;


namespace Endpoint_Packaging_Suite.Services
{
    public class NotificationService
    {
        private readonly ILogger<NotificationService> _logger;
        private Panel? _toastContainer;
        private readonly List<ToastNotification> _activeToasts = new();
        private readonly List<NotificationHistoryItem> _history = new();
        private readonly HashSet<string> _shownNotificationIds = new(); // Track which notifications have been shown
        private const int MAX_VISIBLE_TOASTS = 3;
        private const int TOAST_SPACING = 10;
        private bool _isInitialized;

        public event EventHandler<NotificationHistoryItem>? NotificationAdded;
        public event EventHandler<NotificationHistoryItem>? NotificationUpdated;
        public event EventHandler<string>? NotificationClicked;
        public event EventHandler<string>? NotificationRemoved;

        public IReadOnlyList<NotificationHistoryItem> History => _history.AsReadOnly();
        public bool IsInitialized => _isInitialized;

        /// <summary>
        /// Constructor for dependency injection
        /// </summary>
        public NotificationService(ILogger<NotificationService> logger)
        {
            _logger = logger;
        }

        public void Initialize(Panel toastContainer)
        {
            if (toastContainer == null)
            {
                _logger.LogError("Initialize called with null toastContainer");
                return;
            }

            _toastContainer = toastContainer;
            _isInitialized = true;
            _logger.LogInformation("NotificationService initialized with container: {ContainerType}", toastContainer.GetType().Name);
        }

        public string ShowSuccess(string title, string message = "", int autoCloseDuration = 5000)
        {
            return ShowToast(ToastType.Success, title, message, autoCloseDuration);
        }

        public string ShowError(string title, string message = "", int autoCloseDuration = 0) // Errors don't auto-close
        {
            return ShowToast(ToastType.Error, title, message, autoCloseDuration);
        }

        public string ShowInProgress(string title, string message = "", int progress = -1)
        {
            return ShowToast(ToastType.InProgress, title, message, 0, progress); // Stays open until completed
        }

        public void CloseToast(string notificationId)
        {
            var toast = _activeToasts.FirstOrDefault(t => t.NotificationId == notificationId);
            toast?.Close();
        }

        public void UpdateProgress(string notificationId, int progress, string? message = null)
        {
            Application.Current.Dispatcher.BeginInvoke(() =>
            {
                // Only update toast if it's still active (it auto-dismisses after 7 seconds)
                var toast = _activeToasts.FirstOrDefault(t => t.NotificationId == notificationId);
                toast?.UpdateProgress(progress, message);

                // Always update history - this is what shows in the sidebar
                var historyItem = _history.FirstOrDefault(h => h.Id == notificationId);
                if (historyItem != null)
                {
                    historyItem.Progress = progress;
                    if (!string.IsNullOrEmpty(message))
                    {
                        historyItem.Message = message;
                    }

                    // Raise event so sidebar can refresh its display
                    NotificationUpdated?.Invoke(this, historyItem);
                }
            });
        }

        /// <summary>
        /// Complete an existing notification with success/error status without showing a new toast
        /// </summary>
        public void CompleteNotification(string notificationId, bool success, string? message = null)
        {
            Application.Current.Dispatcher.BeginInvoke(() =>
            {
                // Transition the toast to success/error state with 20s auto-close
                var toast = _activeToasts.FirstOrDefault(t => t.NotificationId == notificationId);
                if (toast != null)
                {
                    toast.Complete(success, message, 20000);
                }

                // Update history item
                var historyItem = _history.FirstOrDefault(h => h.Id == notificationId);
                if (historyItem != null)
                {
                    historyItem.Type = success ? ToastType.Success : ToastType.Error;
                    historyItem.Progress = success ? 100 : -1;
                    historyItem.CompletedAt = DateTime.Now;
                    if (!string.IsNullOrEmpty(message))
                    {
                        historyItem.Message = message;
                    }
                }
            });
        }

        /// <summary>
        /// Remove a notification from history by ID
        /// </summary>
        public void RemoveNotification(string notificationId)
        {
            Application.Current.Dispatcher.BeginInvoke(() =>
            {
                var historyItem = _history.FirstOrDefault(h => h.Id == notificationId);
                if (historyItem != null)
                {
                    _history.Remove(historyItem);
                    NotificationRemoved?.Invoke(this, notificationId);
                }
            });
        }

        /// <summary>
        /// Clear all notifications from history
        /// </summary>
        public void ClearAllNotifications()
        {
            Application.Current.Dispatcher.BeginInvoke(() =>
            {
                _history.Clear();
                NotificationRemoved?.Invoke(this, "");
            });
        }

        private string ShowToast(ToastType type, string title, string message, int autoCloseDuration, int progress = -1)
        {
            if (!_isInitialized || _toastContainer == null)
            {
                _logger.LogWarning("NotificationService not initialized. Toast not shown: {Title} - {Message}", title, message);

                // Still create a notification ID and add to history so it can be tracked
                var fallbackId = Guid.NewGuid().ToString();
                var historyItem = new NotificationHistoryItem
                {
                    Id = fallbackId,
                    Type = type,
                    Title = title,
                    Message = message,
                    Timestamp = DateTime.Now,
                    Progress = progress
                };
                _history.Insert(0, historyItem);
                NotificationAdded?.Invoke(this, historyItem);
                return fallbackId;
            }

            string notificationId = Guid.NewGuid().ToString();

            try
            {
                Application.Current.Dispatcher.BeginInvoke(() =>
                {
                    var toast = new ToastNotification();
                    toast.NotificationId = notificationId;

                    // Add to history
                    var historyItem = new NotificationHistoryItem
                    {
                        Id = notificationId,
                        Type = type,
                        Title = title,
                        Message = message,
                        Timestamp = DateTime.Now,
                        Progress = progress
                    };
                    _history.Insert(0, historyItem); // Add to beginning
                    NotificationAdded?.Invoke(this, historyItem);

                    // Handle events
                    toast.Clicked += (s, e) =>
                    {
                        NotificationClicked?.Invoke(this, notificationId);
                    };

                    toast.Closed += (s, e) =>
                    {
                        RemoveToast(toast);
                    };

                    // Show toast
                    toast.Show(type, title, message, autoCloseDuration, progress);

                    // Add to container
                    _toastContainer.Children.Add(toast);
                    _activeToasts.Add(toast);

                    // Force the toast to measure and arrange itself so it has a size
                    toast.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
                    toast.Arrange(new Rect(toast.DesiredSize));

                    // Position toasts
                    RepositionToasts();

                    // Remove oldest if we have too many
                    while (_activeToasts.Count > MAX_VISIBLE_TOASTS)
                    {
                        var oldestToast = _activeToasts.First();
                        oldestToast.Close();
                    }

                    _logger.LogDebug("Toast shown: {Type} - {Title}", type, title);
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to show toast notification: {Title} - {Message}", title, message);

                // Return the notification ID even if display failed - the history item was still created
                if (string.IsNullOrEmpty(notificationId))
                {
                    notificationId = Guid.NewGuid().ToString();
                }
            }

            return notificationId;
        }

        private void RemoveToast(ToastNotification toast)
        {
            Application.Current.Dispatcher.BeginInvoke(() =>
            {
                _activeToasts.Remove(toast);
                _toastContainer?.Children.Remove(toast);
                RepositionToasts();
            });
        }

        private void RepositionToasts()
        {
            double yOffset = 0;
            for (int i = _activeToasts.Count - 1; i >= 0; i--)
            {
                var toast = _activeToasts[i];
                Canvas.SetBottom(toast, yOffset);
                Canvas.SetRight(toast, 20);

                // Use DesiredSize.Height if ActualHeight is 0 (during initial layout)
                double height = toast.ActualHeight > 0 ? toast.ActualHeight :
                               toast.DesiredSize.Height > 0 ? toast.DesiredSize.Height : 80;

                yOffset += height + TOAST_SPACING;
            }
        }

    }

    public class NotificationHistoryItem
    {
        public string Id { get; set; } = "";
        public ToastType Type { get; set; }
        public string Title { get; set; } = "";
        public string Message { get; set; } = "";
        public DateTime Timestamp { get; set; }
        public DateTime? CompletedAt { get; set; }
        public int Progress { get; set; } = -1;

        public string TypeIcon => Type switch
        {
            ToastType.Success => "\uE73E", // Checkmark circle - Segoe MDL2 Assets
            ToastType.Error => "\uE711", // Error/Cancel - Segoe MDL2 Assets
            ToastType.Warning => "\uE7BA", // Warning - Segoe MDL2 Assets
            ToastType.InProgress => "\uE9F3", // Sync/Progress - Segoe MDL2 Assets
            _ => "\uE946" // Info - Segoe MDL2 Assets
        };

        public Visibility HasMessage => string.IsNullOrEmpty(Message)
            ? Visibility.Collapsed
            : Visibility.Visible;

        public string TimeAgo
        {
            get
            {
                var timeSpan = DateTime.Now - Timestamp;
                if (timeSpan.TotalMinutes < 1) return "Just now";
                if (timeSpan.TotalMinutes < 60) return $"{(int)timeSpan.TotalMinutes} min ago";
                if (timeSpan.TotalHours < 24) return $"{(int)timeSpan.TotalHours} hour(s) ago";
                return $"{(int)timeSpan.TotalDays} day(s) ago";
            }
        }

        public string Duration
        {
            get
            {
                if (CompletedAt.HasValue)
                {
                    var duration = CompletedAt.Value - Timestamp;
                    if (duration.TotalSeconds < 60) return $"{(int)duration.TotalSeconds}s";
                    if (duration.TotalMinutes < 60) return $"{(int)duration.TotalMinutes}m {duration.Seconds}s";
                    return $"{(int)duration.TotalHours}h {duration.Minutes}m";
                }

                // Show progress percentage for in-progress items
                if (Type == ToastType.InProgress && Progress >= 0)
                {
                    return $"In progress... {Progress}%";
                }

                return Type == ToastType.InProgress ? "In progress..." : "";
            }
        }
    }

    /// <summary>
    /// Adapter class that implements IUploadProgress and updates toast notifications
    /// </summary>
    public class ToastProgressAdapter : IUploadProgress
    {
        private readonly string _notificationId;
        private readonly NotificationService _notificationService;

        public ToastProgressAdapter(string notificationId, NotificationService? notificationService = null)
        {
            _notificationId = notificationId;
            // Allow both constructor injection and fallback to service locator
            _notificationService = notificationService ?? App.Services.GetRequiredService<NotificationService>();
        }

        public void UpdateProgress(int percentage, string message)
        {
            _notificationService.UpdateProgress(_notificationId, percentage, message);
        }
    }
}