﻿using Endpoint_Packaging_Suite.Helpers;
using Endpoint_Packaging_Suite.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Endpoint_Packaging_Suite.Services
{
    /// <summary>
    /// Service for upgrading existing PSADT packages to new versions.
    /// Supports upgrading from both v3 and v4 packages, always producing v4 output.
    /// </summary>
    public class PackageUpgradeService
    {
        private readonly string _baseOutputPath = Paths.IntuneApplications;

        /// <summary>
        /// Upgrades an existing package to a new version with new source files.
        /// If the existing package is PSADT v3, it migrates to v4 using the v4 template.
        /// </summary>
        public async Task<string> UpgradePackageAsync(
            string existingPackagePath,
            string newVersion,
            string newSourcesPath,
            CancellationToken cancellationToken = default)
        {
            try
            {
                Debug.WriteLine($"=== Starting Package Upgrade ===");
                Debug.WriteLine($"Existing Package: {existingPackagePath}");
                Debug.WriteLine($"New Version: {newVersion}");
                Debug.WriteLine($"New Sources: {newSourcesPath}");

                // 1. Find existing PSADT script (v3 or v4)
                var applicationFolder = Path.Combine(existingPackagePath, "Application");
                var existingScriptPath = FolderBrowserHelper.GetPSADTScriptPath(applicationFolder)
                    ?? FolderBrowserHelper.GetPSADTScriptPath(existingPackagePath);

                if (string.IsNullOrEmpty(existingScriptPath) || !File.Exists(existingScriptPath))
                {
                    throw new FileNotFoundException("PSADT script not found in existing package (Invoke-AppDeployToolkit.ps1 or Deploy-Application.ps1)");
                }

                bool isV3 = FolderBrowserHelper.IsPSADTv3Script(existingScriptPath);
                Debug.WriteLine($"Found PSADT {(isV3 ? "v3" : "v4")} script: {existingScriptPath}");

                // 2. Extract metadata from existing script
                var metadata = MetadataExtractor.ExtractMetadataFromScript(existingScriptPath);
                var manufacturer = metadata.GetValueOrDefault("Vendor", "");
                var appName = metadata.GetValueOrDefault("AppName", "");

                Debug.WriteLine($"Package Info: {manufacturer} {appName}");

                // 3. Create new version folder structure
                var cleanManufacturer = manufacturer.Replace(" ", "_");
                var cleanAppName = appName.Replace(" ", "_");
                var appFolderName = $"{cleanManufacturer}_{cleanAppName}";
                var appBasePath = Path.Combine(_baseOutputPath, appFolderName);
                var newPackagePath = Path.Combine(appBasePath, newVersion);

                Debug.WriteLine($"New Package Path: {newPackagePath}");

                if (Directory.Exists(newPackagePath))
                {
                    throw new InvalidOperationException($"Version {newVersion} already exists for {appFolderName}. Please delete it first or choose a different version.");
                }

                Directory.CreateDirectory(newPackagePath);

                if (isV3)
                {
                    // === V3 → V4 MIGRATION ===
                    Debug.WriteLine("Migrating from PSADT v3 to v4...");

                    // Use the v4 template for the new package structure
                    var generator = new PSADTGenerator();
                    var appInfo = new ApplicationInfo
                    {
                        Name = appName,
                        Manufacturer = manufacturer,
                        Version = newVersion,
                        SourcesPath = newSourcesPath
                    };

                    // Create package from v4 template (creates folder structure + copies PSADT v4 toolkit)
                    var templatePackagePath = await generator.CreatePackageAsync(appInfo, null, true);

                    // If CreatePackageAsync created in a different path, move contents
                    if (!templatePackagePath.Equals(newPackagePath, StringComparison.OrdinalIgnoreCase))
                    {
                        if (Directory.Exists(newPackagePath))
                            Directory.Delete(newPackagePath, true);
                        Directory.Move(templatePackagePath, newPackagePath);
                    }

                    // Extract install/uninstall logic from v3 script and inject into v4 script
                    var v3ScriptContent = await File.ReadAllTextAsync(existingScriptPath);
                    await MigrateV3LogicToV4Async(newPackagePath, v3ScriptContent, appName);

                    Debug.WriteLine("Migrated v3 install/uninstall logic to v4 format");
                }
                else
                {
                    // === V4 → V4 UPGRADE ===
                    var folders = new[] { "Application", "Icon", "Intune", "NBB_Info", "Project Files" };
                    foreach (var folder in folders)
                    {
                        Directory.CreateDirectory(Path.Combine(newPackagePath, folder));
                    }

                    // Copy Application folder from old v4 package (preserves customizations)
                    await CopyApplicationFolderAsync(existingPackagePath, newPackagePath);
                    Debug.WriteLine("Copied Application folder from old v4 package");
                }

                // Copy new source file to Application\Files
                var newSourceFileName = await CopyNewSourceFilesAsync(newSourcesPath, newPackagePath);
                Debug.WriteLine($"Copied new source file: {newSourceFileName}");

                // Copy Icon folder from old package if it exists
                await CopyIconFolderAsync(existingPackagePath, newPackagePath);

                // Copy NBB_Info folder from old package if it exists
                await CopyNBBInfoFolderAsync(existingPackagePath, newPackagePath);

                // Extract MSI product code if new source is MSI
                string newMsiProductCode = "";
                if (Path.GetExtension(newSourcesPath).Equals(".msi", StringComparison.OrdinalIgnoreCase))
                {
                    try
                    {
                        var msiInfo = MsiInfoService.ExtractMsiInfo(newSourcesPath);
                        if (msiInfo.IsValid && !string.IsNullOrEmpty(msiInfo.ProductCode))
                        {
                            newMsiProductCode = msiInfo.ProductCode;
                            Debug.WriteLine($"Extracted MSI Product Code: {newMsiProductCode}");
                        }
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"Could not extract MSI product code: {ex.Message}");
                    }
                }

                // Update v4 script with new version and source paths
                await UpdateScriptForUpgradeAsync(
                    newPackagePath,
                    manufacturer,
                    appName,
                    newVersion,
                    newSourceFileName,
                    newMsiProductCode);

                Debug.WriteLine($"Updated Invoke-AppDeployToolkit.ps1 with new version and paths");
                Debug.WriteLine($"Package upgrade completed successfully: {newPackagePath}");
                return newPackagePath;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error upgrading package: {ex.Message}");
                throw new Exception($"Error upgrading package: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Extracts install/uninstall code blocks from a PSADT v3 script and injects them
        /// into the new v4 script at the appropriate section markers.
        /// </summary>
        private async Task MigrateV3LogicToV4Async(string newPackagePath, string v3Content, string appName)
        {
            var v4ScriptPath = Path.Combine(newPackagePath, "Application", "Invoke-AppDeployToolkit.ps1");
            if (!File.Exists(v4ScriptPath))
            {
                Debug.WriteLine("Warning: v4 script not found after template creation, skipping logic migration");
                return;
            }

            var v4Content = await File.ReadAllTextAsync(v4ScriptPath);

            // Extract code blocks from v3 sections and convert cmdlets
            var preInstallCode = ExtractV3SectionCode(v3Content, "PRE-INSTALLATION");
            var installCode = ExtractV3SectionCode(v3Content, "INSTALLATION");
            var postInstallCode = ExtractV3SectionCode(v3Content, "POST-INSTALLATION");
            var uninstallCode = ExtractV3SectionCode(v3Content, "UNINSTALLATION");
            var repairCode = ExtractV3SectionCode(v3Content, "REPAIR");

            // Convert v3 cmdlets, parameters, and variables to v4 equivalents
            preInstallCode = ConvertV3CmdletsToV4(preInstallCode);
            installCode = ConvertV3CmdletsToV4(installCode);
            postInstallCode = ConvertV3CmdletsToV4(postInstallCode);
            uninstallCode = ConvertV3CmdletsToV4(uninstallCode);
            repairCode = ConvertV3CmdletsToV4(repairCode);

            Debug.WriteLine($"Extracted sections - Pre: {preInstallCode.Length}c, Install: {installCode.Length}c, Post: {postInstallCode.Length}c, Uninstall: {uninstallCode.Length}c, Repair: {repairCode.Length}c");

            // Inject into v4 script
            var lines = v4Content.Split('\n').ToList();

            // Find v4 section markers and inject (process in reverse order to preserve indices)
            InjectMigratedCode(lines, "Repair", repairCode);
            InjectMigratedCode(lines, "Uninstallation", uninstallCode);
            InjectMigratedCode(lines, "Post-Installation", postInstallCode);
            InjectMigratedCode(lines, "Installation", installCode);
            InjectMigratedCode(lines, "Pre-Installation", preInstallCode);

            await File.WriteAllTextAsync(v4ScriptPath, string.Join('\n', lines));
            Debug.WriteLine("Migrated v3 logic sections to v4 script");
        }

        /// <summary>
        /// Extracts code from a PSADT v3 section (between section markers).
        /// v3 uses: ##*===============================================
        ///          ##* {SECTION-NAME}
        ///          ##*===============================================
        /// </summary>
        /// <summary>
        /// Extracts code from a PSADT v3 section (between section markers).
        /// v3 uses: ##*===============================================
        ///          ##* {SECTION-NAME}
        ///          ##*===============================================
        /// Also handles the ElseIf blocks for Uninstall/Repair sections.
        /// </summary>
        private string ExtractV3SectionCode(string scriptContent, string sectionName)
        {
            var lines = scriptContent.Split('\n');
            var sectionCode = new StringBuilder();
            bool inSection = false;
            bool foundMarker = false;

            for (int i = 0; i < lines.Length; i++)
            {
                var trimmed = lines[i].Trim();

                // Look for v3 section header: ##* PRE-INSTALLATION / INSTALLATION / POST-INSTALLATION / UNINSTALLATION / REPAIR
                if (!inSection)
                {
                    var sectionUpper = sectionName.ToUpper();
                    if (trimmed.StartsWith("##*") && trimmed.ToUpper().Contains(sectionUpper))
                    {
                        // Skip past the closing ##*=== line
                        foundMarker = true;
                        continue;
                    }
                    if (foundMarker && trimmed.StartsWith("##*===="))
                    {
                        inSection = true;
                        foundMarker = false;
                        continue;
                    }
                    continue;
                }

                // End of section: next ##*=== block, ElseIf, or end of script body
                if (trimmed.StartsWith("##*====") || (trimmed.StartsWith("##*") && trimmed.Length > 5 && !trimmed.StartsWith("##*-")))
                    break;
                if (Regex.IsMatch(trimmed, @"^(ElseIf|Else)\s*", RegexOptions.IgnoreCase) && trimmed.Contains("$deploymentType"))
                    break;
                if (trimmed.StartsWith("##* END SCRIPT BODY", StringComparison.OrdinalIgnoreCase))
                    break;

                // Skip v3 structural lines (phase assignments, deployment type checks, Fabrice's custom variables)
                if (Regex.IsMatch(trimmed, @"^\[string\]\$installPhase\s*=", RegexOptions.IgnoreCase))
                    continue;
                if (Regex.IsMatch(trimmed, @"^\$deploymentTypeName\s*=", RegexOptions.IgnoreCase))
                    continue;

                // Skip comment-only lines and blank lines at the start
                if (sectionCode.Length == 0 && (string.IsNullOrWhiteSpace(trimmed) || trimmed.StartsWith("##")))
                    continue;

                sectionCode.AppendLine(lines[i]);
            }

            return sectionCode.ToString().TrimEnd();
        }

        /// <summary>
        /// Converts PSADT v3 cmdlet names to v4 equivalents.
        /// </summary>
        private string ConvertV3CmdletsToV4(string code)
        {
            if (string.IsNullOrWhiteSpace(code))
                return code;

            // v3 → v4 cmdlet mapping (comprehensive)
            var cmdletMap = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                // Process & MSI execution
                { "Execute-MSI", "Start-ADTMsiProcess" },
                { "Execute-Process", "Start-ADTProcess" },

                // UI dialogs
                { "Show-InstallationWelcome", "Show-ADTInstallationWelcome" },
                { "Show-InstallationProgress", "Show-ADTInstallationProgress" },
                { "Show-InstallationPrompt", "Show-ADTInstallationPrompt" },
                { "Show-InstallationRestartPrompt", "Show-ADTInstallationRestartPrompt" },
                { "Close-InstallationProgress", "Close-ADTInstallationProgress" },
                { "Show-DialogBox", "Show-ADTDialogBox" },
                { "Show-BalloonTip", "Show-ADTBalloonTip" },

                // Application detection
                { "Get-InstalledApplication", "Get-ADTApplication" },
                { "Remove-MSIApplications", "Remove-ADTMsiApplications" },

                // File operations
                { "Copy-File", "Copy-ADTFile" },
                { "Remove-File", "Remove-ADTFile" },
                { "New-Folder", "New-ADTFolder" },
                { "Remove-Folder", "Remove-ADTFolder" },
                { "Copy-FileToUserProfiles", "Copy-ADTFileToUserProfiles" },

                // Registry operations
                { "Get-RegistryKey", "Get-ADTRegistryKey" },
                { "Set-RegistryKey", "Set-ADTRegistryKey" },
                { "Remove-RegistryKey", "Remove-ADTRegistryKey" },

                // Shortcuts
                { "New-Shortcut", "New-ADTShortcut" },
                { "Remove-Shortcut", "Remove-ADTShortcut" },

                // System utilities
                { "Set-ActiveSetup", "Set-ADTActiveSetup" },
                { "Get-FileVersion", "Get-ADTFileVersion" },
                { "Test-Battery", "Test-ADTBattery" },
                { "Test-NetworkConnection", "Test-ADTNetworkConnection" },
                { "Get-LoggedOnUser", "Get-ADTLoggedOnUser" },
                { "Test-ServiceExists", "Test-ADTServiceExists" },
                { "Get-FreeDiskSpace", "Get-ADTFreeDiskSpace" },
                { "Get-MsiTableProperty", "Get-ADTMsiTableProperty" },
                { "Set-MsiProperty", "Set-ADTMsiProperty" },
                { "Get-IniValue", "Get-ADTIniValue" },
                { "Set-IniValue", "Set-ADTIniValue" },

                // SCCM/ConfigMgr
                { "Invoke-SCCMTask", "Invoke-ADTSCCMTask" },
                { "Install-SCCMSoftwareUpdates", "Install-ADTSCCMSoftwareUpdates" },

                // App execution
                { "Block-AppExecution", "Block-ADTAppExecution" },
                { "Unblock-AppExecution", "Unblock-ADTAppExecution" },

                // System state
                { "Get-PendingReboot", "Get-ADTPendingReboot" },
                { "Set-ItemPermission", "Set-ADTItemPermission" },
                { "Get-UserProfiles", "Get-ADTUserProfiles" },

                // DLL registration
                { "Register-DLL", "Register-ADTDll" },
                { "Unregister-DLL", "Unregister-ADTDll" },

                // Logging & script lifecycle
                { "Write-Log", "Write-ADTLogEntry" },
                { "Exit-Script", "Close-ADTSession" },
                { "Resolve-Error", "Resolve-ADTErrorRecord" },

                // Service management
                { "Get-ServiceStartMode", "Get-ADTServiceStartMode" },
                { "Set-ServiceStartMode", "Set-ADTServiceStartMode" },

                // Miscellaneous
                { "Get-DeferHistory", "Get-ADTDeferHistory" },
                { "Set-DeferHistory", "Set-ADTDeferHistory" },
                { "Get-UniversalDate", "Get-ADTUniversalDate" },
                { "Send-Keys", "Send-ADTKeys" },
                { "Test-PowerPoint", "Test-ADTPowerPoint" },
                { "Update-Desktop", "Update-ADTDesktop" },
                { "Update-SessionEnvironmentVariables", "Update-ADTEnvironmentPsProvider" },
                { "Invoke-RegisterOrUnregisterDLL", "Invoke-ADTRegSvr32" },
            };

            // v3 → v4 parameter name mapping (applied after cmdlet conversion)
            var parameterMap = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                // Execute-Process -Parameters → Start-ADTProcess -ArgumentList
                { "-Parameters ", "-ArgumentList " },
                // Execute-MSI -AddParameters → Start-ADTMsiProcess -ArgumentList
                { "-AddParameters ", "-ArgumentList " },
                // Show-InstallationWelcome -CloseApps → -CloseProcesses
                { "-CloseApps ", "-CloseProcesses " },
                // -ContinueOnError $true → -ErrorAction SilentlyContinue (common pattern)
                { "-Source $deployAppScriptFriendlyName", "" },
            };

            // v3 → v4 variable mapping (case-insensitive replacements)
            // Note: $envCommonDesktop, $envCommonStartMenuPrograms etc. work as-is in v4 — no conversion needed
            var variableMap = new List<(string v3Pattern, string v4Replacement)>
            {
                // File path variables — v3 uses $dirFiles/$DirFiles, v4 uses $adtSession.DirFiles
                (@"\$[Dd]ir[Ff]iles", "$($adtSession.DirFiles)"),
                (@"\$[Dd]ir[Ss]upport[Ff]iles", "$($adtSession.DirSupportFiles)"),

                // Script lifecycle variables
                (@"\$installPhase", "$($adtSession.InstallPhase)"),
                (@"\$deploymentTypeName", "$($adtSession.DeploymentType)"),
                (@"\$installName", "$($adtSession.InstallName)"),
                (@"\$installTitle", "$($adtSession.InstallTitle)"),

                // App metadata variables (when used in string expressions, not declarations)
                (@"(?<!\[string\]\s*)\$appVendor(?!\s*=)", "$($adtSession.AppVendor)"),
                (@"(?<!\[string\]\s*)\$appName(?!\s*=)", "$($adtSession.AppName)"),
                (@"(?<!\[string\]\s*)\$appVersion(?!\s*=)", "$($adtSession.AppVersion)"),
                (@"(?<!\[string\]\s*)\$appArch(?!\s*=)", "$($adtSession.AppArch)"),
                (@"(?<!\[string\]\s*)\$appLang(?!\s*=)", "$($adtSession.AppLang)"),
                (@"(?<!\[string\]\s*)\$appRevision(?!\s*=)", "$($adtSession.AppRevision)"),

                // Script directory
                (@"\$scriptDirectory", "$PSScriptRoot"),

                // Exit code — v4 uses -ExitCode parameter on Close-ADTSession
                (@"\$mainExitCode", "0"),
            };

            var result = code;

            // 1. Convert cmdlet names (word boundary aware)
            foreach (var (v3, v4) in cmdletMap)
            {
                result = Regex.Replace(result, @"\b" + Regex.Escape(v3) + @"\b", v4, RegexOptions.IgnoreCase);
            }

            // 2. Convert parameter names
            foreach (var (v3Param, v4Param) in parameterMap)
            {
                result = Regex.Replace(result, Regex.Escape(v3Param), v4Param, RegexOptions.IgnoreCase);
            }

            // 3. Convert variable references (regex-based for case-insensitive matching)
            foreach (var (v3Pattern, v4Replacement) in variableMap)
            {
                result = Regex.Replace(result, v3Pattern, v4Replacement);
            }

            // 4. Strip v3 structural patterns that don't exist in v4
            result = StripV3StructuralWrappers(result);

            // 5. Add migration warnings for patterns we couldn't auto-convert
            result = AddMigrationWarnings(result);

            return result;
        }

        /// <summary>
        /// Strips v3-specific structural wrappers that are handled differently in v4.
        /// v3 wraps install logic in If ($deploymentType -ine 'Uninstall') blocks — v4 uses separate functions.
        /// Also removes v3 variable declarations and phase assignments that v4 handles via $adtSession.
        /// </summary>
        private string StripV3StructuralWrappers(string code)
        {
            if (string.IsNullOrWhiteSpace(code))
                return code;

            var lines = code.Split('\n').ToList();
            var result = new List<string>();

            foreach (var line in lines)
            {
                var trimmed = line.Trim();

                // Skip v3 deployment type conditionals — v4 uses separate functions
                if (Regex.IsMatch(trimmed, @"^If\s*\(\s*\$deploymentType\s+-i(eq|ne)", RegexOptions.IgnoreCase))
                    continue;
                if (Regex.IsMatch(trimmed, @"^ElseIf\s*\(\s*\$deploymentType\s+-i(eq|ne)", RegexOptions.IgnoreCase))
                    continue;

                // Skip v3 installPhase assignments — v4 handles this via $adtSession.InstallPhase
                if (Regex.IsMatch(trimmed, @"^\[string\]\$installPhase\s*=", RegexOptions.IgnoreCase))
                    continue;

                // Skip v3 variable declarations that are now in $adtSession hashtable
                if (Regex.IsMatch(trimmed, @"^\[string\]\$(appVendor|appName|appVersion|appArch|appLang|appRevision|appScriptVersion|appScriptDate|appScriptAuthor|installName|installTitle)\s*=", RegexOptions.IgnoreCase))
                    continue;

                // Skip v3 deployAppScript variables — not used in v4
                if (Regex.IsMatch(trimmed, @"^\[(string|version|hashtable|int32)\]\$(deployAppScript|mainExitCode)", RegexOptions.IgnoreCase))
                    continue;

                // Skip v3 custom deployment type name variable
                if (Regex.IsMatch(trimmed, @"^\$deploymentTypeName\s*=", RegexOptions.IgnoreCase))
                    continue;

                // Skip standalone closing braces that were part of stripped If/ElseIf blocks
                // (we keep other braces as they may be part of user logic)

                // Skip v3 section markers — v4 uses different format
                if (Regex.IsMatch(trimmed, @"^##\*={10,}"))
                    continue;
                if (Regex.IsMatch(trimmed, @"^##\*\s*(PRE-INSTALLATION|INSTALLATION|POST-INSTALLATION|UNINSTALLATION|REPAIR|END VARIABLE DECLARATION|VARIABLE DECLARATION)", RegexOptions.IgnoreCase))
                    continue;

                result.Add(line);
            }

            return string.Join('\n', result);
        }

        /// <summary>
        /// Adds warning comments for v3 patterns that couldn't be automatically converted.
        /// This helps packagers identify what needs manual review.
        /// </summary>
        private string AddMigrationWarnings(string code)
        {
            if (string.IsNullOrWhiteSpace(code))
                return code;

            var warnings = new List<string>();

            // Check for remaining v3-style cmdlets that weren't in our map
            var v3CmdletPattern = @"\b(Execute|Show|Close|Get|Set|Remove|New|Copy|Test|Invoke|Block|Unblock|Write|Install|Register|Unregister)-(MSI|Process|InstallationWelcome|InstallationProgress|InstallationPrompt|DialogBox|BalloonTip|InstalledApplication|File|Folder|RegistryKey|Shortcut|ActiveSetup|FileVersion|Battery|NetworkConnection|LoggedOnUser|ServiceExists|Log|FreeDiskSpace|MsiTableProperty|MsiProperty|SCCMTask|SCCMSoftwareUpdates|AppExecution|PendingReboot|ItemPermission|UserProfiles|DLL|Error)\b";
            if (Regex.IsMatch(code, v3CmdletPattern, RegexOptions.IgnoreCase))
            {
                var matches = Regex.Matches(code, v3CmdletPattern, RegexOptions.IgnoreCase);
                var uniqueCmdlets = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (Match m in matches) uniqueCmdlets.Add(m.Value);
                if (uniqueCmdlets.Count > 0)
                {
                    warnings.Add($"\t\t## WARNING [V3 MIGRATION]: Possible unconverted v3 cmdlets detected: {string.Join(", ", uniqueCmdlets)}");
                }
            }

            // Check for remaining v3-style variable references
            if (Regex.IsMatch(code, @"\$dirFiles|\$dirSupportFiles", RegexOptions.IgnoreCase))
            {
                warnings.Add("\t\t## WARNING [V3 MIGRATION]: Possible unconverted $dirFiles/$dirSupportFiles references — should use $($adtSession.DirFiles)");
            }

            // Check for $mainExitCode usage (common in v3)
            if (code.Contains("$mainExitCode"))
            {
                warnings.Add("\t\t## WARNING [V3 MIGRATION]: $mainExitCode reference found — v4 uses Close-ADTSession -ExitCode instead");
            }

            if (warnings.Count > 0)
            {
                return string.Join('\n', warnings) + "\n\n" + code;
            }

            return code;
        }

        /// <summary>
        /// Injects migrated code at the appropriate v4 section marker.
        /// </summary>
        private void InjectMigratedCode(List<string> lines, string sectionName, string code)
        {
            if (string.IsNullOrWhiteSpace(code))
                return;

            for (int i = 0; i < lines.Count; i++)
            {
                if (lines[i].Contains($"<Perform {sectionName} tasks here>"))
                {
                    var codeLines = code.Split('\n');
                    // Insert a comment noting v3 migration
                    lines.Insert(i + 1, $"\t\t## Migrated from PSADT v3");
                    for (int j = 0; j < codeLines.Length; j++)
                    {
                        lines.Insert(i + 2 + j, codeLines[j]);
                    }
                    Debug.WriteLine($"Injected migrated {sectionName} code ({codeLines.Length} lines)");
                    return;
                }
            }

            Debug.WriteLine($"Warning: Could not find v4 section marker for {sectionName}");
        }

        /// <summary>
        /// Copies the entire Application folder from old package, excluding Files folder
        /// </summary>
        private async Task CopyApplicationFolderAsync(string existingPackagePath, string newPackagePath)
        {
            var sourceAppFolder = Path.Combine(existingPackagePath, "Application");
            var destAppFolder = Path.Combine(newPackagePath, "Application");

            if (!Directory.Exists(sourceAppFolder))
            {
                throw new DirectoryNotFoundException($"Source Application folder not found: {sourceAppFolder}");
            }

            await Task.Run(() =>
            {
                // Copy entire Application folder but exclude Files folder (contains old large source)
                var excludeFolders = new[] { "Files" };
                CopyDirectorySelective(sourceAppFolder, destAppFolder, true, excludeFolders);
                Debug.WriteLine($"✅ Copied Application folder (excluded Files) - all customizations preserved");
            });
        }


        /// <summary>
        /// Copies Icon folder from old package if it exists
        /// </summary>
        private async Task CopyIconFolderAsync(string existingPackagePath, string newPackagePath)
        {
            try
            {
                var sourceIconFolder = Path.Combine(existingPackagePath, "Icon");
                var destIconFolder = Path.Combine(newPackagePath, "Icon");

                if (!Directory.Exists(sourceIconFolder))
                {
                    Debug.WriteLine("Icon folder not found in old package - skipping");
                    return;
                }

                await Task.Run(() =>
                {
                    CopyDirectory(sourceIconFolder, destIconFolder, true);
                    Debug.WriteLine("✅ Copied Icon folder from old package");
                });
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Warning: Could not copy Icon folder: {ex.Message}");
                // Don't throw - this is optional
            }
        }

        /// <summary>
        /// Copies NBB_Info folder from old package if it exists (detection rules)
        /// </summary>
        private async Task CopyNBBInfoFolderAsync(string existingPackagePath, string newPackagePath)
        {
            try
            {
                var sourceNBBInfoFolder = Path.Combine(existingPackagePath, "NBB_Info");
                var destNBBInfoFolder = Path.Combine(newPackagePath, "NBB_Info");

                if (!Directory.Exists(sourceNBBInfoFolder))
                {
                    Debug.WriteLine("NBB_Info folder not found in old package - skipping");
                    return;
                }

                await Task.Run(() =>
                {
                    CopyDirectory(sourceNBBInfoFolder, destNBBInfoFolder, true);
                    Debug.WriteLine("✅ Copied NBB_Info folder - detection rules preserved");
                });
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Warning: Could not copy NBB_Info folder: {ex.Message}");
                // Don't throw - this is optional
            }
        }

        /// <summary>
        /// Updates source file paths throughout the entire PSADT v4 script.
        /// Uses $adtSession.DirFiles pattern.
        /// </summary>
        private string UpdateSourceFilePaths(string scriptContent, string newSourceFileName)
        {
            if (string.IsNullOrWhiteSpace(scriptContent))
                return scriptContent;

            var patterns = new List<(string pattern, string replacement)>
            {
                // PSADT v4 patterns - uses $adtSession.DirFiles
                // $adtSession.DirFiles\oldfile.exe or "$adtSession.DirFiles\oldfile.exe"
                (@"(\$adtSession\.DirFiles\\|""\$adtSession\.DirFiles\\)([^""'\s\\]+\.(exe|msi|bat|cmd))", $"$1{newSourceFileName}"),
                // '$adtSession.DirFiles\oldfile.msi'
                (@"('\$adtSession\.DirFiles\\)([^""'\s\\]+\.msi)", $"$1{newSourceFileName}")
            };

            var result = scriptContent;
            foreach (var (pattern, replacement) in patterns)
            {
                var beforeCount = Regex.Matches(result, pattern, RegexOptions.IgnoreCase).Count;
                result = Regex.Replace(result, pattern, replacement, RegexOptions.IgnoreCase);
                if (beforeCount > 0)
                {
                    Debug.WriteLine($"Replaced {beforeCount} source file path(s) with: {newSourceFileName}");
                }
            }

            return result;
        }

        /// <summary>
        /// Updates MSI product codes throughout the script with the new product code
        /// </summary>
        private string UpdateMsiProductCodes(string scriptContent, string newProductCode)
        {
            if (string.IsNullOrWhiteSpace(scriptContent) || string.IsNullOrWhiteSpace(newProductCode))
                return scriptContent;

            // Pattern to find MSI product codes in msiexec commands
            // Format: {XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX}
            var productCodePattern = @"\{[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\}";

            var matches = Regex.Matches(scriptContent, productCodePattern);
            if (matches.Count > 0)
            {
                Debug.WriteLine($"Found {matches.Count} MSI product code(s) to replace");
                scriptContent = Regex.Replace(scriptContent, productCodePattern, newProductCode);
                Debug.WriteLine($"Replaced all product codes with: {newProductCode}");
            }

            return scriptContent;
        }

        /// <summary>
        /// Replaces MSI product codes with placeholder when upgrading from MSI to EXE
        /// </summary>
        private string ReplaceMsiProductCodesWithPlaceholder(string scriptContent)
        {
            if (string.IsNullOrWhiteSpace(scriptContent))
                return scriptContent;

            // Pattern to find MSI product codes in msiexec commands
            var productCodePattern = @"\{[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\}";

            var matches = Regex.Matches(scriptContent, productCodePattern);
            if (matches.Count > 0)
            {
                Debug.WriteLine($"Found {matches.Count} MSI product code(s), replacing with placeholder");
                scriptContent = Regex.Replace(scriptContent, productCodePattern, "{PRODUCT-CODE-PLACEHOLDER}");
                Debug.WriteLine("Replaced product codes with {PRODUCT-CODE-PLACEHOLDER} - Update manually if needed");
            }

            return scriptContent;
        }


        private async Task<string> CopyNewSourceFilesAsync(string sourcePath, string packagePath)
        {
            try
            {
                var applicationFilesPath = Path.Combine(packagePath, "Application", "Files");
                Directory.CreateDirectory(applicationFilesPath);

                string sourceFileName = "";

                await Task.Run(() =>
                {
                    if (File.Exists(sourcePath))
                    {
                        sourceFileName = Path.GetFileName(sourcePath);
                        var destinationFile = Path.Combine(applicationFilesPath, sourceFileName);
                        File.Copy(sourcePath, destinationFile, true);
                        Debug.WriteLine($"Copied new source: {sourceFileName}");
                    }
                    else
                    {
                        throw new FileNotFoundException($"Source file not found: {sourcePath}");
                    }
                });

                return sourceFileName;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error copying new source files: {ex.Message}", ex);
            }
        }


        private void CopyDirectory(string sourceDir, string destinationDir, bool recursive)
        {
            var dir = new DirectoryInfo(sourceDir);
            if (!dir.Exists)
                throw new DirectoryNotFoundException($"Source directory not found: {dir.FullName}");

            DirectoryInfo[] dirs = dir.GetDirectories();
            Directory.CreateDirectory(destinationDir);

            foreach (FileInfo file in dir.GetFiles())
            {
                string targetFilePath = Path.Combine(destinationDir, file.Name);
                file.CopyTo(targetFilePath, true);
            }

            if (recursive)
            {
                foreach (DirectoryInfo subDir in dirs)
                {
                    string newDestinationDir = Path.Combine(destinationDir, subDir.Name);
                    CopyDirectory(subDir.FullName, newDestinationDir, true);
                }
            }
        }

        /// <summary>
        /// Copies a directory recursively, excluding specified folders
        /// </summary>
        private void CopyDirectorySelective(string sourceDir, string destinationDir, bool recursive, string[] excludeFolders)
        {
            var dir = new DirectoryInfo(sourceDir);
            if (!dir.Exists)
                throw new DirectoryNotFoundException($"Source directory not found: {dir.FullName}");

            DirectoryInfo[] dirs = dir.GetDirectories();
            Directory.CreateDirectory(destinationDir);

            // Copy all files
            foreach (FileInfo file in dir.GetFiles())
            {
                string targetFilePath = Path.Combine(destinationDir, file.Name);
                file.CopyTo(targetFilePath, true);
            }

            // Copy subdirectories recursively, excluding specified folders
            if (recursive)
            {
                foreach (DirectoryInfo subDir in dirs)
                {
                    // Skip excluded folders
                    if (excludeFolders.Contains(subDir.Name, StringComparer.OrdinalIgnoreCase))
                    {
                        Debug.WriteLine($"Skipped folder: {subDir.Name} (excluded from copy)");
                        continue;
                    }

                    string newDestinationDir = Path.Combine(destinationDir, subDir.Name);
                    CopyDirectorySelective(subDir.FullName, newDestinationDir, true, excludeFolders);
                }
            }
        }

        /// <summary>
        /// Updates the copied PSADT v4 script with new version, source paths, and MSI product codes.
        /// </summary>
        private async Task UpdateScriptForUpgradeAsync(
            string packagePath,
            string manufacturer,
            string appName,
            string version,
            string newSourceFileName,
            string newMsiProductCode)
        {
            try
            {
                var scriptName = "Invoke-AppDeployToolkit.ps1";
                var scriptPath = Path.Combine(packagePath, "Application", scriptName);

                if (!File.Exists(scriptPath))
                {
                    throw new FileNotFoundException($"{scriptName} not found: {scriptPath}");
                }

                // Read the copied script
                var scriptContent = await File.ReadAllTextAsync(scriptPath);

                // 1. Update metadata (version, author, date) - PSADT v4 format
                scriptContent = UpdateScriptMetadataV4(scriptContent, manufacturer, appName, version);

                // 2. Update source file paths (v4 uses $adtSession.DirFiles)
                scriptContent = UpdateSourceFilePaths(scriptContent, newSourceFileName);

                // 3. Update MSI product codes if applicable
                if (!string.IsNullOrEmpty(newMsiProductCode))
                {
                    scriptContent = UpdateMsiProductCodes(scriptContent, newMsiProductCode);
                }
                else if (!Path.GetExtension(newSourceFileName).Equals(".msi", StringComparison.OrdinalIgnoreCase))
                {
                    // If new source is EXE (not MSI), replace MSI product codes with placeholder
                    scriptContent = ReplaceMsiProductCodesWithPlaceholder(scriptContent);
                }

                // Write the modified script back
                await File.WriteAllTextAsync(scriptPath, scriptContent);

                Debug.WriteLine($"✅ Updated {scriptName} for version {version}");
            }
            catch (Exception ex)
            {
                throw new Exception($"Error updating script for upgrade: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Updates PSADT v4 script metadata (hashtable format: AppVendor = 'value' inside $adtSession)
        /// </summary>
        private string UpdateScriptMetadataV4(string scriptContent, string manufacturer, string appName, string version)
        {
            string currentUser = Environment.UserName;
            var lines = scriptContent.Split('\n').ToList();

            for (int i = 0; i < lines.Count; i++)
            {
                var line = lines[i].Trim();

                // PSADT v4 uses $adtSession hashtable format:
                // AppVendor = 'Vendor'
                // AppName = 'Name'
                // etc.

                if (line.StartsWith("AppVendor") && line.Contains("="))
                {
                    lines[i] = $"    AppVendor = '{manufacturer}'";
                }
                else if (line.StartsWith("AppName") && line.Contains("=") && !line.Contains("AppNameWithVersion"))
                {
                    lines[i] = $"    AppName = '{appName}'";
                }
                else if (line.StartsWith("AppVersion") && line.Contains("="))
                {
                    lines[i] = $"    AppVersion = '{version}'";
                }
                else if (line.StartsWith("AppArch") && line.Contains("="))
                {
                    lines[i] = $"    AppArch = 'x64'";
                }
                else if (line.StartsWith("AppScriptDate") && line.Contains("="))
                {
                    lines[i] = $"    AppScriptDate = '{DateTime.Now:yyyy-MM-dd}'";
                }
                else if (line.StartsWith("AppScriptAuthor") && line.Contains("="))
                {
                    lines[i] = $"    AppScriptAuthor = '{currentUser}'";
                }
            }

            return string.Join('\n', lines);
        }

    }
}