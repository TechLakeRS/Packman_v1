using System.Diagnostics;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite.Helpers;

namespace Endpoint_Packaging_Suite.Services
{
    public partial class IntuneService
    {
        public async Task<GroupDevice> FindDeviceByNameAsync(string deviceName)
        {
            try
            {
                Debug.WriteLine($"[FindDeviceByNameAsync] Searching for device: {deviceName}");

                var requestUrl = $"https://graph.microsoft.com/v1.0/devices?$filter=displayName eq '{deviceName}'";
                Debug.WriteLine($"[FindDeviceByNameAsync] Request URL: {requestUrl}");

                using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Get, requestUrl);
                var response = await _sharedHttpClient.SendAsync(request);
                Debug.WriteLine($"[FindDeviceByNameAsync] Response status: {response.StatusCode}");

                if (response.IsSuccessStatusCode)
                {
                    var responseText = await response.Content.ReadAsStringAsync();
                    var jsonDoc = JsonDocument.Parse(responseText);

                    if (jsonDoc.RootElement.TryGetProperty("value", out var valueArray) &&
                        valueArray.GetArrayLength() > 0)
                    {
                        var deviceElement = valueArray[0];
                        var device = new GroupDevice
                        {
                            Id = GetStringValue(deviceElement, "id"),
                            DeviceName = GetStringValue(deviceElement, "displayName"),
                            OperatingSystem = GetStringValue(deviceElement, "operatingSystem"),
                        };
                        Debug.WriteLine($"[FindDeviceByNameAsync] Found device: {device.DeviceName} (ID: {device.Id})");
                        return device;
                    }
                }

                Debug.WriteLine("[FindDeviceByNameAsync] Device not found");
                return null;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[FindDeviceByNameAsync] EXCEPTION: {ex.Message}");
                throw;
            }
        }

        public async Task<bool> IsDeviceInGroupAsync(string deviceId, string groupId)
        {
            try
            {
                await GetAccessTokenAsync();

                var requestUrl = $"https://graph.microsoft.com/beta/groups/{groupId}/members/{deviceId}";

                using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Get, requestUrl);
                var response = await _sharedHttpClient.SendAsync(request);
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error checking device membership: {ex.Message}");
                return false;
            }
        }

        public async Task AddDeviceToGroupAsync(string deviceId, string groupId)
        {
            try
            {
                Debug.WriteLine($"[AddDeviceToGroupAsync] Starting - DeviceId: {deviceId}, GroupId: {groupId}");

                await GetAccessTokenAsync();
                Debug.WriteLine("[AddDeviceToGroupAsync] Access token obtained");

                var requestUrl = $"https://graph.microsoft.com/v1.0/groups/{groupId}/members/$ref";
                Debug.WriteLine($"[AddDeviceToGroupAsync] Request URL: {requestUrl}");

                var odataId = $"https://graph.microsoft.com/v1.0/directoryObjects/{deviceId}";
                Debug.WriteLine($"[AddDeviceToGroupAsync] OData.id value: {odataId}");

                var jsonPayload = $"{{\"@odata.id\":\"{odataId}\"}}";
                Debug.WriteLine($"[AddDeviceToGroupAsync] JSON Payload: {jsonPayload}");

                var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

                Debug.WriteLine($"[AddDeviceToGroupAsync] Sending POST request...");
                using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Post, requestUrl);
                request.Content = content;
                var response = await _sharedHttpClient.SendAsync(request);

                Debug.WriteLine($"[AddDeviceToGroupAsync] Response Status Code: {(int)response.StatusCode} ({response.StatusCode})");

                if (!response.IsSuccessStatusCode)
                {
                    var error = await response.Content.ReadAsStringAsync();
                    Debug.WriteLine($"[AddDeviceToGroupAsync] ERROR Response Body: {error}");
                    throw new Exception($"Failed to add device to group. Status: {response.StatusCode}, Error: {error}");
                }

                Debug.WriteLine("[AddDeviceToGroupAsync] Device successfully added to group");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[AddDeviceToGroupAsync] EXCEPTION: {ex.GetType().Name}");
                Debug.WriteLine($"[AddDeviceToGroupAsync] Message: {ex.Message}");
                Debug.WriteLine($"[AddDeviceToGroupAsync] StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        public async Task RemoveDeviceFromGroupAsync(string groupId, string deviceId)
        {
            try
            {
                await GetAccessTokenAsync();

                var requestUrl = $"https://graph.microsoft.com/beta/groups/{groupId}/members/{deviceId}/$ref";

                using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Delete, requestUrl);
                var response = await _sharedHttpClient.SendAsync(request);

                if (!response.IsSuccessStatusCode)
                {
                    var error = await response.Content.ReadAsStringAsync();
                    throw new Exception($"Failed to remove device from group: {error}");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error removing device from group: {ex.Message}");
                throw;
            }
        }

        public async Task RemoveDevicesFromGroupAsync(string groupId, List<string> deviceIds)
        {
            var tasks = new List<Task>();
            const int batchSize = 5;

            for (int i = 0; i < deviceIds.Count; i += batchSize)
            {
                var batch = deviceIds.Skip(i).Take(batchSize);

                foreach (var deviceId in batch)
                {
                    tasks.Add(RemoveDeviceFromGroupAsync(groupId, deviceId));
                }

                await Task.WhenAll(tasks);
                tasks.Clear();

                if (i + batchSize < deviceIds.Count)
                {
                    await Task.Delay(500);
                }
            }
        }

        public async Task<List<GroupDevice>> GetGroupMembersAsync(string groupId)
        {
            try
            {
                await GetAccessTokenAsync();
                var members = new List<GroupDevice>();

                Debug.WriteLine($"Fetching members for group: {groupId}");

                var requestUrl = $"https://graph.microsoft.com/v1.0/groups/{groupId}/members";

                while (!string.IsNullOrEmpty(requestUrl))
                {
                    using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Get, requestUrl);
                    var response = await _sharedHttpClient.SendAsync(request);

                    if (response.IsSuccessStatusCode)
                    {
                        var responseText = await response.Content.ReadAsStringAsync();
                        Debug.WriteLine($"Members response: {responseText.Substring(0, Math.Min(500, responseText.Length))}");

                        var jsonDoc = JsonDocument.Parse(responseText);

                        if (jsonDoc.RootElement.TryGetProperty("value", out var valueArray))
                        {
                            foreach (var member in valueArray.EnumerateArray())
                            {
                                var memberType = GetStringValue(member, "@odata.type");

                                if (memberType == "#microsoft.graph.device")
                                {
                                    var device = new GroupDevice
                                    {
                                        Id = GetStringValue(member, "id"),
                                        DeviceName = GetStringValue(member, "displayName"),
                                        AzureDeviceId = GetStringValue(member, "deviceId"),
                                        OperatingSystem = GetStringValue(member, "operatingSystem"),
                                        IsCompliant = member.GetSafeBoolean("isCompliant"),
                                        LastSyncDateTime = member.GetSafeDateTime("approximateLastSignInDateTime"),
                                        CreatedDateTime = member.GetSafeDateTime("createdDateTime"),
                                        AccountEnabled = member.GetSafeBoolean("accountEnabled")
                                    };

                                    if (member.TryGetProperty("deviceVersion", out var versionProp))
                                    {
                                        device.OSVersion = versionProp.ValueKind == JsonValueKind.Number
                                            ? versionProp.GetInt32().ToString()
                                            : GetStringValue(member, "deviceVersion");
                                    }

                                    Debug.WriteLine($"Added device: {device.DeviceName} (ID: {device.Id})");
                                    members.Add(device);
                                }
                            }
                        }

                        if (jsonDoc.RootElement.TryGetProperty("@odata.nextLink", out var nextLinkProp))
                        {
                            requestUrl = nextLinkProp.GetString();
                        }
                        else
                        {
                            requestUrl = null;
                        }
                    }
                    else
                    {
                        throw new Exception($"Failed to get group members: {response.StatusCode}");
                    }
                }

                Debug.WriteLine($"Total devices found: {members.Count}");
                return members;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error getting group members: {ex.Message}");
                throw;
            }
        }

        public async Task<List<GroupDevice>> GetAllManagedDevicesAsync()
        {
            try
            {
                await GetAccessTokenAsync();

                var devices = new List<GroupDevice>();
                var requestUrl = "https://graph.microsoft.com/beta/deviceManagement/managedDevices";

                while (!string.IsNullOrEmpty(requestUrl))
                {
                    using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Get, requestUrl);
                    var response = await _sharedHttpClient.SendAsync(request);

                    if (response.IsSuccessStatusCode)
                    {
                        var responseText = await response.Content.ReadAsStringAsync();
                        var jsonDoc = JsonDocument.Parse(responseText);

                        if (jsonDoc.RootElement.TryGetProperty("value", out var valueArray))
                        {
                            foreach (var deviceElement in valueArray.EnumerateArray())
                            {
                                var device = new GroupDevice
                                {
                                    Id = GetStringValue(deviceElement, "id"),
                                    DeviceName = GetStringValue(deviceElement, "deviceName"),
                                    UserPrincipalName = GetStringValue(deviceElement, "userPrincipalName"),
                                    OperatingSystem = GetStringValue(deviceElement, "operatingSystem"),
                                    IsCompliant = deviceElement.TryGetProperty("complianceState", out var complianceProp)
                                        && complianceProp.GetString() == "compliant",
                                    LastSyncDateTime = deviceElement.GetSafeDateTime("lastSyncDateTime")
                                };

                                devices.Add(device);
                            }
                        }

                        if (jsonDoc.RootElement.TryGetProperty("@odata.nextLink", out var nextLinkProp))
                        {
                            requestUrl = nextLinkProp.GetString();
                        }
                        else
                        {
                            requestUrl = null;
                        }
                    }
                    else
                    {
                        throw new Exception($"Failed to get managed devices: {response.StatusCode}");
                    }
                }

                return devices;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error getting all managed devices: {ex.Message}");
                throw;
            }
        }

        public async Task<List<DeviceGroupInfo>> GetDeviceGroupsAsync(string deviceId)
        {
            var groups = new List<DeviceGroupInfo>();
            var requestUrl = $"https://graph.microsoft.com/v1.0/devices/{deviceId}/memberOf?$select=id,displayName,description";

            while (!string.IsNullOrEmpty(requestUrl))
            {
                using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Get, requestUrl);
                var response = await _sharedHttpClient.SendAsync(request);

                if (!response.IsSuccessStatusCode)
                {
                    var error = await response.Content.ReadAsStringAsync();
                    throw new Exception($"Failed to get device groups: {response.StatusCode} - {error}");
                }

                var responseText = await response.Content.ReadAsStringAsync();
                var jsonDoc = JsonDocument.Parse(responseText);

                if (jsonDoc.RootElement.TryGetProperty("value", out var valueArray))
                {
                    foreach (var item in valueArray.EnumerateArray())
                    {
                        if (GetStringValue(item, "@odata.type") != "#microsoft.graph.group") continue;

                        groups.Add(new DeviceGroupInfo
                        {
                            Id = GetStringValue(item, "id"),
                            DisplayName = GetStringValue(item, "displayName"),
                            Description = GetStringValue(item, "description")
                        });
                    }
                }

                requestUrl = jsonDoc.RootElement.TryGetProperty("@odata.nextLink", out var nextLink)
                    ? nextLink.GetString()
                    : null;
            }

            return groups.OrderBy(g => g.DisplayName).ToList();
        }
    }

    public class DeviceGroupInfo
    {
        public string Id { get; set; } = "";
        public string DisplayName { get; set; } = "";
        public string Description { get; set; } = "";
        public string Detail => string.IsNullOrWhiteSpace(Description) ? $"Group ID: {Id}" : Description;
    }
}
