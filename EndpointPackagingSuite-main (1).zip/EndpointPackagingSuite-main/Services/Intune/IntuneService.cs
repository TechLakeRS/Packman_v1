using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using System.Diagnostics;
using System.Net.Http;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using Endpoint_Packaging_Suite.Helpers;

namespace Endpoint_Packaging_Suite.Services
{
    public partial class IntuneService
    {
        private static readonly Lazy<HttpClient> _SharedHttpClient = new Lazy<HttpClient>(() =>
        new HttpClient { Timeout = TimeSpan.FromMinutes(2) });

        private static HttpClient _sharedHttpClient => _SharedHttpClient.Value;

        private readonly IMemoryCache _cache;
        private readonly ApplicationCacheService _appListCache;
        private readonly ILogger<IntuneService> _logger;
        private readonly KeyVaultService _keyVaultService;
        private readonly DetectionRuleParser _detectionRuleParser = new DetectionRuleParser();
        private static readonly JsonSerializerOptions _camelCaseOptions = new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase };
        private string? _accessToken;
        private DateTime _tokenExpiry = DateTime.MinValue;
        private bool _disposed = false;

        // Authentication credentials
        private readonly string _clientId;
        private readonly string _tenantId;

        public string ClientId => _clientId;
        public string TenantId => _tenantId;

        public IntuneService(
            string tenantId,
            string clientId,
            KeyVaultService keyVaultService,
            IMemoryCache cache,
            ApplicationCacheService appListCache,
            ILogger<IntuneService> logger)
        {
            _tenantId = tenantId;
            _clientId = clientId;
            _keyVaultService = keyVaultService ?? throw new ArgumentNullException(nameof(keyVaultService));
            _cache = cache ?? throw new ArgumentNullException(nameof(cache));
            _appListCache = appListCache ?? throw new ArgumentNullException(nameof(appListCache));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));

            _logger.LogInformation("IntuneService initialized (TenantId: {TenantId}, ClientId: {ClientId})",
                _tenantId, _clientId);
        }

        public async Task<string> GetAccessTokenAsync()
        {
            if (!string.IsNullOrEmpty(_accessToken) && DateTime.UtcNow < _tokenExpiry.AddMinutes(-5))
            {
                return _accessToken;
            }

            var certificate = LoadCertificate();
            var assertion = CreateJwtAssertion(certificate);

            var content = new FormUrlEncodedContent(new[]
            {
                new KeyValuePair<string, string>("client_id", _clientId),
                new KeyValuePair<string, string>("client_assertion_type", "urn:ietf:params:oauth:client-assertion-type:jwt-bearer"),
                new KeyValuePair<string, string>("client_assertion", assertion),
                new KeyValuePair<string, string>("scope", "https://graph.microsoft.com/.default"),
                new KeyValuePair<string, string>("grant_type", "client_credentials")
            });

            var tokenUrl = $"https://login.microsoftonline.com/{_tenantId}/oauth2/v2.0/token";
            var response = await _sharedHttpClient!.PostAsync(tokenUrl, content);
            var responseText = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"Failed to get access token. Status: {response.StatusCode}, Response: {responseText}");
            }

            var tokenResponse = JsonSerializer.Deserialize<TokenResponse>(responseText);
            if (tokenResponse == null || string.IsNullOrEmpty(tokenResponse.AccessToken))
            {
                throw new Exception("Access token is missing in response");
            }

            _accessToken = tokenResponse.AccessToken;
            _tokenExpiry = DateTime.UtcNow.AddSeconds(tokenResponse.ExpiresIn);

            return _accessToken;
        }

        private async Task<HttpRequestMessage> CreateAuthenticatedRequestAsync(HttpMethod method, string url)
        {
            var token = await GetAccessTokenAsync();
            var request = new HttpRequestMessage(method, url);
            request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
            return request;
        }

        private X509Certificate2 LoadCertificate()
        {
            var cert = _keyVaultService.GetAppRegistrationCertificate()
                ?? throw new Exception(
                    "App-registration certificate not loaded. " +
                    "Call KeyVaultService.LoadAppRegistrationCertificateAsync() during startup.");

            Debug.WriteLine($"✓ Using app-registration certificate from Key Vault: Subject={cert.Subject}, Thumbprint={cert.Thumbprint}");
            return cert;
        }

        private string CreateJwtAssertion(X509Certificate2 certificate)
        {
            var now = DateTimeOffset.UtcNow;
            var x5t = Base64UrlEncode(certificate.GetCertHash());

            var header = new
            {
                alg = "RS256",
                typ = "JWT",
                x5t
            };

            var payload = new
            {
                aud = $"https://login.microsoftonline.com/{_tenantId}/oauth2/v2.0/token",
                exp = now.AddMinutes(10).ToUnixTimeSeconds(),
                iss = _clientId,
                jti = Guid.NewGuid().ToString(),
                nbf = now.ToUnixTimeSeconds(),
                sub = _clientId
            };

            var headerJson = JsonSerializer.Serialize(header);
            var payloadJson = JsonSerializer.Serialize(payload);

            var headerEncoded = Base64UrlEncode(Encoding.UTF8.GetBytes(headerJson));
            var payloadEncoded = Base64UrlEncode(Encoding.UTF8.GetBytes(payloadJson));

            var message = $"{headerEncoded}.{payloadEncoded}";
            var messageBytes = Encoding.UTF8.GetBytes(message);

            using var rsa = certificate.GetRSAPrivateKey();
            if (rsa == null)
            {
                throw new InvalidOperationException(
                    "Certificate does not contain a private key. " +
                    "Please ensure you're using a certificate with a private key for authentication.");
            }
            var signature = rsa.SignData(messageBytes, System.Security.Cryptography.HashAlgorithmName.SHA256, System.Security.Cryptography.RSASignaturePadding.Pkcs1);
            var signatureEncoded = Base64UrlEncode(signature);

            return $"{message}.{signatureEncoded}";
        }

        private static string Base64UrlEncode(byte[] input)
        {
            return Convert.ToBase64String(input)
                .Replace("+", "-")
                .Replace("/", "_")
                .Replace("=", "");
        }

        private string GetStringValue(JsonElement element, string propertyName)
        {
            if (element.TryGetProperty(propertyName, out var prop) && prop.ValueKind == JsonValueKind.String)
            {
                return prop.GetString() ?? "";
            }
            return "";
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    // Don't dispose the static HttpClient
                    _accessToken = null;
                }
                _disposed = true;
            }
        }
    }

    public class GraphResponse<T>
    {
        [JsonPropertyName("@odata.context")]
        public string? ODataContext { get; set; }

        [JsonPropertyName("@odata.nextLink")]
        public string? ODataNextLink { get; set; }

        [JsonPropertyName("value")]
        public List<T>? Value { get; set; }
    }

    public class TokenResponse
    {
        [JsonPropertyName("access_token")]
        public string AccessToken { get; set; } = "";

        [JsonPropertyName("token_type")]
        public string TokenType { get; set; } = "";

        [JsonPropertyName("expires_in")]
        public int ExpiresIn { get; set; }

        [JsonPropertyName("scope")]
        public string Scope { get; set; } = "";
    }
}
