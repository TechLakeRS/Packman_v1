using System.Diagnostics;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite.Constants;
using Endpoint_Packaging_Suite.Helpers;

namespace Endpoint_Packaging_Suite.Services
{
    public partial class IntuneService
    {
        public async Task<InstallationStatistics> GetInstallationStatisticsAsync(string appId)
        {
            try
            {
                var reportUrl = "https://graph.microsoft.com/beta/deviceManagement/reports/getAppStatusOverviewReport";

                var requestBody = new
                {
                    filter = $"(ApplicationId eq '{appId}')"
                };

                var content = new StringContent(
                    JsonSerializer.Serialize(requestBody),
                    Encoding.UTF8,
                    "application/json");

                using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Post, reportUrl);
                request.Content = content;
                var response = await _sharedHttpClient.SendAsync(request);

                if (!response.IsSuccessStatusCode)
                {
                    Debug.WriteLine($"Failed to get report: {response.StatusCode}");
                    return new InstallationStatistics();
                }

                var reportContent = await response.Content.ReadAsStringAsync();
                Debug.WriteLine($"Statistics Response: {reportContent}");

                var data = JsonDocument.Parse(reportContent);

                if (data.RootElement.TryGetProperty("Values", out var values))
                {
                    foreach (var row in values.EnumerateArray())
                    {
                        var rowData = row.EnumerateArray().ToList();

                        // Schema:
                        // [0] ApplicationId
                        // [1] FailedDeviceCount
                        // [2] PendingInstallDeviceCount
                        // [3] InstalledDeviceCount
                        // [4] NotInstalledDeviceCount
                        // [5] NotApplicableDeviceCount

                        if (rowData.Count >= 6)
                        {
                            var stats = new InstallationStatistics
                            {
                                FailedInstalls = rowData[1].GetSafeInt(),
                                PendingInstalls = rowData[2].GetSafeInt(),
                                SuccessfulInstalls = rowData[3].GetSafeInt(),
                                NotInstalled = rowData[4].GetSafeInt(),
                                NotApplicable = rowData[5].GetSafeInt(),
                            };

                            stats.TotalDevices = stats.SuccessfulInstalls + stats.FailedInstalls +
                                                stats.PendingInstalls + stats.NotInstalled + stats.NotApplicable;

                            Debug.WriteLine($"Found stats for {appId}:");
                            Debug.WriteLine($"  Installed: {stats.SuccessfulInstalls}");
                            Debug.WriteLine($"  Failed: {stats.FailedInstalls}");
                            Debug.WriteLine($"  Pending: {stats.PendingInstalls}");
                            Debug.WriteLine($"  NotInstalled: {stats.NotInstalled}");
                            Debug.WriteLine($"  NotApplicable: {stats.NotApplicable}");
                            Debug.WriteLine($"  Total: {stats.TotalDevices}");

                            return stats;
                        }
                    }
                }

                Debug.WriteLine($"No statistics found for app {appId}");
                return new InstallationStatistics();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error getting statistics: {ex.Message}");
                return new InstallationStatistics();
            }
        }

        public async Task<List<DeviceInstallStatus>> GetApplicationInstallStatusAsync(string appId)
        {
            try
            {
                var allStatuses = new List<DeviceInstallStatus>();
                var reportUrl = "https://graph.microsoft.com/beta/deviceManagement/reports/retrieveDeviceAppInstallationStatusReport";

                var requestBody = new
                {
                    filter = $"(ApplicationId eq '{appId}')"
                };

                var content = new StringContent(
                    JsonSerializer.Serialize(requestBody),
                    Encoding.UTF8,
                    "application/json");

                using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Post, reportUrl);
                request.Content = content;
                var response = await _sharedHttpClient.SendAsync(request);

                if (!response.IsSuccessStatusCode)
                {
                    Debug.WriteLine($"Failed to get device report: {response.StatusCode}");
                    return allStatuses;
                }

                var reportContent = await response.Content.ReadAsStringAsync();
                var data = JsonDocument.Parse(reportContent);

                if (data.RootElement.TryGetProperty("Values", out var values))
                {
                    foreach (var row in values.EnumerateArray())
                    {
                        var rowData = row.EnumerateArray().ToList();

                        if (rowData.Count >= 18)
                        {
                            var status = new DeviceInstallStatus
                            {
                                DeviceId = GetStringValue(rowData[0]),
                                DeviceName = GetStringValue(rowData[3]),
                                UserPrincipalName = GetStringValue(rowData[4]),
                                UserName = GetStringValue(rowData[5]),
                                Platform = GetStringValue(rowData[6]),
                                ErrorCode = rowData[8].ValueKind == JsonValueKind.Number ? rowData[8].GetInt32() : null,
                                InstallState = GetInstallStateString(rowData[15]),
                                InstallStateDetail = GetStringValue(rowData[16]),
                            };

                            if (status.ErrorCode.HasValue && status.ErrorCode != 0)
                            {
                                status.HexErrorCode = $"0x{status.ErrorCode.Value:X8}";
                            }

                            if (rowData[11].ValueKind == JsonValueKind.String)
                            {
                                if (DateTime.TryParse(rowData[11].GetString(), out var dt))
                                {
                                    status.LastSyncDateTime = dt;
                                }
                            }

                            allStatuses.Add(status);
                        }
                    }
                }

                var deduplicatedStatuses = allStatuses
              .GroupBy(s => s.DeviceName)
              .Select(group => group
                  .OrderByDescending(s => s.LastSyncDateTime)
                  .ThenBy(s => string.IsNullOrEmpty(s.UserPrincipalName) ? 0 : 1)
                  .First())
              .ToList();

                Debug.WriteLine($"Deduplicated from {allStatuses.Count} to {deduplicatedStatuses.Count} records");

                return deduplicatedStatuses;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error fetching device status: {ex.Message}");
                return new List<DeviceInstallStatus>();
            }
        }

        private string GetStringValue(JsonElement element)
        {
            return element.ValueKind == JsonValueKind.String ? element.GetString() ?? "" : "";
        }

        private string GetInstallStateString(JsonElement element)
        {
            if (element.ValueKind == JsonValueKind.String)
            {
                var stringValue = element.GetString()?.ToLower() ?? "";

                return stringValue switch
                {
                    "installed" => "Installed",
                    "failed" => "Failed",
                    "pending" => "Pending",
                    "notinstalled" => "NotInstalled",
                    "notapplicable" => "NotApplicable",
                    "uninstallfailed" => "UninstallFailed",
                    _ => stringValue
                };
            }

            if (element.ValueKind == JsonValueKind.Number)
            {
                var stateValue = element.GetInt32();
                return stateValue switch
                {
                    AppConstants.InstallState.NotApplicable => "NotApplicable",
                    AppConstants.InstallState.Installed => "Installed",
                    AppConstants.InstallState.Failed => "Failed",
                    AppConstants.InstallState.Pending => "Pending",
                    AppConstants.InstallState.NotInstalled => "NotInstalled",
                    AppConstants.InstallState.UninstallFailed => "UninstallFailed",
                    _ => $"Unknown ({stateValue})"
                };
            }

            return "Unknown";
        }
    }
}
