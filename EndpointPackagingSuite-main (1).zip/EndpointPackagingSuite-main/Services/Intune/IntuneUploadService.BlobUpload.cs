using Endpoint_Packaging_Suite.Models;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Text.Json;

namespace Endpoint_Packaging_Suite.Services
{
    public partial class IntuneUploadService
    {
        private async Task<string> CreateContentVersionAsync(string appId)
        {
            var url = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/{appId}/microsoft.graph.win32LobApp/contentVersions";
            using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Post, url);
            request.Content = new StringContent("{}", Encoding.UTF8, "application/json");
            var response = await sharedHttpClient!.SendAsync(request);
            var responseText = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"Failed to create content version. Status: {response.StatusCode}, Response: {responseText}");
            }

            var contentVersion = JsonSerializer.Deserialize<JsonElement>(responseText);
            var contentVersionId = contentVersion.GetProperty("id").GetString();

            Debug.WriteLine($"✓ Created content version. ID: {contentVersionId}");
            return contentVersionId ?? throw new Exception("Content version ID not returned");
        }

        private async Task<string> CreateFileEntryAsync(string appId, string contentVersionId, IntuneWinInfo intuneWinInfo)
        {
            var encryptedSize = new FileInfo(intuneWinInfo.EncryptedFilePath).Length;

            var fileBody = new Dictionary<string, object?>
            {
                ["@odata.type"] = "#microsoft.graph.mobileAppContentFile",
                ["name"] = intuneWinInfo.FileName,
                ["size"] = intuneWinInfo.UnencryptedContentSize,
                ["sizeEncrypted"] = encryptedSize,
                ["manifest"] = null,
                ["isDependency"] = false
            };

            var url = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/{appId}/microsoft.graph.win32LobApp/contentVersions/{contentVersionId}/files";
            var json = JsonSerializer.Serialize(fileBody, new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase });

            using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Post, url);
            request.Content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await sharedHttpClient!.SendAsync(request);
            var responseText = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"Failed to create file entry. Status: {response.StatusCode}, Response: {responseText}");
            }

            var fileEntry = JsonSerializer.Deserialize<JsonElement>(responseText);
            var fileId = fileEntry.GetProperty("id").GetString();

            return fileId ?? throw new Exception("File ID not returned");
        }

        private async Task<AzureStorageInfo> WaitForAzureStorageUriAsync(string appId, string contentVersionId, string fileId)
        {
            var url = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/{appId}/microsoft.graph.win32LobApp/contentVersions/{contentVersionId}/files/{fileId}";

            for (int attempts = 0; attempts < 120; attempts++) // 20 minutes total
            {
                try
                {
                    using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Get, url);
                    var response = await sharedHttpClient!.SendAsync(request);
                    var responseText = await response.Content.ReadAsStringAsync();

                    if (!response.IsSuccessStatusCode)
                    {
                        Debug.WriteLine($"❌ HTTP Error {response.StatusCode}: {responseText}");
                        throw new Exception($"Failed to get file info. Status: {response.StatusCode}, Response: {responseText}");
                    }

                    var fileInfo = JsonSerializer.Deserialize<JsonElement>(responseText);

                    Debug.WriteLine($"Attempt {attempts + 1}: Response = {responseText}");

                    if (!fileInfo.TryGetProperty("uploadState", out var uploadStateProp))
                    {
                        Debug.WriteLine($"⚠ No uploadState property found in response");
                        await Task.Delay(10000);
                        continue;
                    }

                    var uploadState = uploadStateProp.GetString() ?? "";
                    Debug.WriteLine($"Attempt {attempts + 1}: Upload state = '{uploadState}'");

                    if (uploadState.Equals("AzureStorageUriRequestSuccess", StringComparison.OrdinalIgnoreCase) ||
                        uploadState.Equals("azureStorageUriRequestSuccess", StringComparison.OrdinalIgnoreCase))
                    {
                        if (fileInfo.TryGetProperty("azureStorageUri", out var azureStorageUriProp))
                        {
                            var azureStorageUri = azureStorageUriProp.GetString();
                            Debug.WriteLine($"✅ Got Azure Storage URI after {attempts + 1} attempts");
                            Debug.WriteLine($"URI length: {azureStorageUri?.Length ?? 0}");
                            return new AzureStorageInfo { SasUri = azureStorageUri ?? throw new Exception("Azure Storage URI is null") };
                        }
                        else
                        {
                            Debug.WriteLine($"❌ Success state but no azureStorageUri property found");
                            throw new Exception("Upload state is success but azureStorageUri is missing");
                        }
                    }

                    if (uploadState.Equals("AzureStorageUriRequestPending", StringComparison.OrdinalIgnoreCase) ||
                        uploadState.Equals("azureStorageUriRequestPending", StringComparison.OrdinalIgnoreCase))
                    {
                        Debug.WriteLine($"⏳ Still pending... (attempt {attempts + 1}/120) - waiting 10 seconds");
                        await Task.Delay(10000);
                        continue;
                    }

                    if (uploadState.Equals("AzureStorageUriRequestFailed", StringComparison.OrdinalIgnoreCase) ||
                        uploadState.Equals("azureStorageUriRequestFailed", StringComparison.OrdinalIgnoreCase))
                    {
                        Debug.WriteLine($"❌ Azure Storage URI request failed");
                        throw new Exception("Azure Storage URI request failed");
                    }

                    if (uploadState.Equals("AzureStorageUriRequestTimedOut", StringComparison.OrdinalIgnoreCase) ||
                        uploadState.Equals("azureStorageUriRequestTimedOut", StringComparison.OrdinalIgnoreCase))
                    {
                        Debug.WriteLine($"❌ Azure Storage URI request timed out");
                        throw new Exception("Azure Storage URI request timed out");
                    }

                    Debug.WriteLine($"❓ Unknown upload state: '{uploadState}' - will wait and retry");

                    if (attempts < 115)
                    {
                        await Task.Delay(15000);
                        continue;
                    }
                    else
                    {
                        Debug.WriteLine($"❌ Giving up after {attempts + 1} attempts with unknown state: '{uploadState}'");
                        throw new Exception($"Unknown upload state after many attempts: '{uploadState}'. Check Intune admin center for app status.");
                    }
                }
                catch (Exception ex) when (!(ex.Message.Contains("upload state") || ex.Message.Contains("Failed to get file info")))
                {
                    Debug.WriteLine($"⚠ Network exception on attempt {attempts + 1}: {ex.Message}");

                    if (attempts < 115)
                    {
                        await Task.Delay(10000);
                        continue;
                    }
                    throw;
                }
            }

            Debug.WriteLine($"❌ Timeout after 120 attempts (20 minutes)");
            throw new Exception("Timeout waiting for Azure Storage URI after 20 minutes. The application was created in Intune but file upload preparation timed out. Check the Intune admin center - the app may still be processing.");
        }

        private async Task UploadFileToAzureStorageAsync(string sasUri, string filePath, IUploadProgress? progress = null)
        {
            var fileInfo = new FileInfo(filePath);
            var totalSize = fileInfo.Length;

            int chunkSize;
            if (totalSize > 5L * 1024 * 1024 * 1024) // > 5GB
                chunkSize = 4 * 1024 * 1024;
            else
                chunkSize = 6 * 1024 * 1024;

            var totalChunks = (int)Math.Ceiling((double)totalSize / chunkSize);

            Debug.WriteLine($"=== AZURE STORAGE UPLOAD ===");
            Debug.WriteLine($"File: {Path.GetFileName(filePath)} ({FormatBytes(totalSize)})");
            Debug.WriteLine($"Using chunk size: {FormatBytes(chunkSize)}");
            Debug.WriteLine($"Total chunks: {totalChunks}");

            progress?.UpdateProgress(65, $"Preparing upload ({FormatBytes(totalSize)})...");

            using var azureHttpClient = new HttpClient();
            azureHttpClient.Timeout = TimeSpan.FromMinutes(10);

            using var fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
            var blockIds = new List<string>();
            var sasRenewalTimer = Stopwatch.StartNew();
            var currentSasUri = sasUri;

            for (int chunkIndex = 0; chunkIndex < totalChunks; chunkIndex++)
            {
                var blockId = Convert.ToBase64String(Encoding.ASCII.GetBytes(chunkIndex.ToString("0000")));
                blockIds.Add(blockId);

                long startPosition = (long)chunkIndex * chunkSize;
                int bytesToRead = (int)Math.Min(chunkSize, totalSize - startPosition);

                var buffer = new byte[bytesToRead];
                var totalBytesRead = 0;

                fileStream.Position = startPosition;

                while (totalBytesRead < buffer.Length)
                {
                    var bytesRead = await fileStream.ReadAsync(buffer, totalBytesRead, buffer.Length - totalBytesRead);
                    if (bytesRead == 0)
                    {
                        Debug.WriteLine($"WARNING: End of file at chunk {chunkIndex + 1}, read {totalBytesRead} of {buffer.Length} bytes");
                        break;
                    }
                    totalBytesRead += bytesRead;
                }

                if (totalBytesRead != buffer.Length)
                {
                    Debug.WriteLine($"❌ Chunk {chunkIndex + 1}: Expected {buffer.Length} bytes, got {totalBytesRead} bytes");
                    Array.Resize(ref buffer, totalBytesRead);
                }

                var percentComplete = (int)((long)chunkIndex * 100 / totalChunks);
                var progressPercentage = 65 + (int)((chunkIndex + 1.0) / totalChunks * 15);
                progress?.UpdateProgress(progressPercentage,
                    $"Uploading chunk {chunkIndex + 1}/{totalChunks} ({percentComplete}%)");

                // SAS renewal every 7 minutes
                if (chunkIndex < totalChunks - 1 && sasRenewalTimer.ElapsedMilliseconds >= 420000)
                {
                    progress?.UpdateProgress(progressPercentage, "Renewing SAS token...");
                    try
                    {
                        currentSasUri = await RenewSasUriAsync();
                        sasRenewalTimer.Restart();
                        Debug.WriteLine("✅ SAS token renewed successfully");
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"⚠️ SAS renewal failed, continuing with current token: {ex.Message}");
                    }
                }

                var chunkUri = $"{currentSasUri}&comp=block&blockid={blockId}";
                await UploadChunkWithRetryAsync(azureHttpClient, chunkUri, buffer, chunkIndex, totalChunks);

                Debug.WriteLine($"✅ Uploaded chunk {chunkIndex + 1}/{totalChunks}");
            }

            progress?.UpdateProgress(82, "Finalizing Azure upload...");
            await CommitBlockListWithRetryAsync(azureHttpClient, currentSasUri, blockIds);

            progress?.UpdateProgress(84, "Package uploaded to Azure");
            Debug.WriteLine($"✅ Successfully uploaded file to Azure Storage");
        }

        private async Task UploadChunkWithRetryAsync(HttpClient client, string chunkUri, byte[] buffer,
            int chunkIndex, int totalChunks)
        {
            const int maxRetries = 5;

            for (int attempt = 1; attempt <= maxRetries; attempt++)
            {
                try
                {
                    using var request = new HttpRequestMessage(HttpMethod.Put, chunkUri);
                    request.Content = new ByteArrayContent(buffer);
                    request.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("text/plain")
                    {
                        CharSet = "iso-8859-1"
                    };
                    request.Headers.Add("x-ms-blob-type", "BlockBlob");

                    var timeout = chunkIndex == totalChunks - 1 ?
                        TimeSpan.FromMinutes(15) :
                        TimeSpan.FromMinutes(5 + attempt);

                    using var cts = new CancellationTokenSource(timeout);

                    var response = await client.SendAsync(request, cts.Token);

                    if (response.IsSuccessStatusCode)
                    {
                        if (attempt > 1)
                            Debug.WriteLine($"✓ Chunk {chunkIndex + 1} succeeded on attempt {attempt}");
                        return;
                    }

                    var errorText = await response.Content.ReadAsStringAsync();
                    Debug.WriteLine($"⚠ Chunk {chunkIndex + 1} failed (attempt {attempt}/{maxRetries}): {response.StatusCode}");
                    Debug.WriteLine($"  Error details: {errorText}");

                    // Don't retry client errors (4xx) except 408 (timeout) and 429 (throttled)
                    if ((int)response.StatusCode >= 400 && (int)response.StatusCode < 500
                        && response.StatusCode != System.Net.HttpStatusCode.RequestTimeout
                        && (int)response.StatusCode != 429)
                    {
                        throw new Exception($"Client error: {response.StatusCode} - {errorText}");
                    }
                }
                catch (TaskCanceledException)
                {
                    Debug.WriteLine($"⚠ Chunk {chunkIndex + 1} timed out (attempt {attempt}/{maxRetries})");
                }
                catch (HttpRequestException ex)
                {
                    Debug.WriteLine($"⚠ Network error on chunk {chunkIndex + 1} (attempt {attempt}/{maxRetries}): {ex.Message}");
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"❌ Unexpected error on chunk {chunkIndex + 1} (attempt {attempt}/{maxRetries}): {ex.Message}");
                    if (attempt == maxRetries)
                        throw;
                }

                if (attempt < maxRetries)
                {
                    var baseDelay = Math.Pow(2, attempt);
                    var jitter = new Random().NextDouble();
                    var delay = TimeSpan.FromSeconds(baseDelay + baseDelay * jitter);

                    Debug.WriteLine($"⏳ Waiting {delay.TotalSeconds:F1}s before retry...");
                    await Task.Delay(delay);
                }
                else
                {
                    throw new Exception($"Failed to upload chunk {chunkIndex + 1} after {maxRetries} attempts");
                }
            }
        }

        private async Task CommitBlockListWithRetryAsync(HttpClient client, string sasUri, List<string> blockIds)
        {
            var blockListXml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><BlockList>";
            foreach (var blockId in blockIds)
            {
                blockListXml += $"<Latest>{blockId}</Latest>";
            }
            blockListXml += "</BlockList>";

            const int maxRetries = 5;

            for (int attempt = 1; attempt <= maxRetries; attempt++)
            {
                try
                {
                    var finalizeUri = $"{sasUri}&comp=blocklist";
                    using var request = new HttpRequestMessage(HttpMethod.Put, finalizeUri);
                    request.Content = new StringContent(blockListXml, Encoding.UTF8);
                    request.Content.Headers.ContentType = null; // No Content-Type for block list

                    using var cts = new CancellationTokenSource(TimeSpan.FromMinutes(10));
                    var response = await client.SendAsync(request, cts.Token);

                    if (response.IsSuccessStatusCode)
                    {
                        Debug.WriteLine($"✅ Block list committed successfully (attempt {attempt})");
                        return;
                    }

                    var errorText = await response.Content.ReadAsStringAsync();
                    Debug.WriteLine($"⚠ Block list commit failed (attempt {attempt}/{maxRetries}): {response.StatusCode}");
                    Debug.WriteLine($"  Error: {errorText}");
                }
                catch (TaskCanceledException)
                {
                    Debug.WriteLine($"⚠ Block list commit timed out (attempt {attempt}/{maxRetries})");
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"❌ Error committing block list (attempt {attempt}/{maxRetries}): {ex.Message}");
                }

                if (attempt < maxRetries)
                {
                    var delay = TimeSpan.FromSeconds(Math.Pow(2, attempt) * 2);
                    Debug.WriteLine($"⏳ Waiting {delay.TotalSeconds}s before retry...");
                    await Task.Delay(delay);
                }
                else
                {
                    throw new Exception($"Failed to commit block list after {maxRetries} attempts");
                }
            }
        }

        private string FormatBytes(long bytes)
        {
            if (bytes >= 1073741824)
                return $"{bytes / 1073741824.0:F2} GB";
            if (bytes >= 1048576)
                return $"{bytes / 1048576.0:F2} MB";
            if (bytes >= 1024)
                return $"{bytes / 1024.0:F2} KB";
            return $"{bytes} bytes";
        }

        private async Task CommitFileAsync(string appId, string contentVersionId, string fileId, EncryptionInfo encryptionInfo)
        {
            var issues = new List<string>();
            if (string.IsNullOrWhiteSpace(encryptionInfo.EncryptionKey)) issues.Add("EncryptionKey is empty");
            if (string.IsNullOrWhiteSpace(encryptionInfo.MacKey)) issues.Add("MacKey is empty");
            if (string.IsNullOrWhiteSpace(encryptionInfo.InitializationVector)) issues.Add("InitializationVector is empty");
            if (string.IsNullOrWhiteSpace(encryptionInfo.Mac)) issues.Add("Mac is empty");
            if (string.IsNullOrWhiteSpace(encryptionInfo.FileDigest)) issues.Add("FileDigest is empty");

            if (issues.Any())
            {
                Console.WriteLine("❌ ENCRYPTION ISSUES FOUND:");
                foreach (var issue in issues)
                {
                    Console.WriteLine($"   - {issue}");
                }
            }
            else
            {
                Console.WriteLine("✅ All encryption fields appear populated");
            }

            var commitBody = new Dictionary<string, object>
            {
                ["fileEncryptionInfo"] = new Dictionary<string, object>
                {
                    ["encryptionKey"] = encryptionInfo.EncryptionKey ?? "",
                    ["macKey"] = encryptionInfo.MacKey ?? "",
                    ["initializationVector"] = encryptionInfo.InitializationVector ?? "",
                    ["mac"] = encryptionInfo.Mac ?? "",
                    ["profileIdentifier"] = encryptionInfo.ProfileIdentifier ?? "ProfileVersion1",
                    ["fileDigest"] = encryptionInfo.FileDigest ?? "",
                    ["fileDigestAlgorithm"] = encryptionInfo.FileDigestAlgorithm ?? "SHA256"
                }
            };

            var url = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/{appId}/microsoft.graph.win32LobApp/contentVersions/{contentVersionId}/files/{fileId}/commit";
            var json = JsonSerializer.Serialize(commitBody, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                WriteIndented = true
            });

            try
            {
                using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Post, url);
                request.Content = new StringContent(json, Encoding.UTF8, "application/json");
                var response = await sharedHttpClient!.SendAsync(request);
                var responseText = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception($"Failed to commit file. Status: {response.StatusCode}, Response: {responseText}");
                }

                Console.WriteLine($"✅ File committed successfully");
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to upload application to Intune: {ex.Message}", ex);
            }
        }

        private async Task WaitForFileProcessingAsync(string appId, string contentVersionId, string fileId, string stage)
        {
            var url = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/{appId}/microsoft.graph.win32LobApp/contentVersions/{contentVersionId}/files/{fileId}";
            var successState = $"{stage}Success";
            var pendingState = $"{stage}Pending";

            Debug.WriteLine($"=== WAITING FOR FILE PROCESSING: {stage} ===");
            Debug.WriteLine($"Expected success state: {successState}");
            Debug.WriteLine($"Expected pending state: {pendingState}");

            for (int attempts = 0; attempts < 120; attempts++)
            {
                using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Get, url);
                var response = await sharedHttpClient!.SendAsync(request);
                var responseText = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception($"Failed to get file processing status. Status: {response.StatusCode}, Response: {responseText}");
                }

                var fileInfo = JsonSerializer.Deserialize<JsonElement>(responseText);

                if (!fileInfo.TryGetProperty("uploadState", out var uploadStateProp))
                {
                    Debug.WriteLine($"⚠ No uploadState property found, attempt {attempts + 1}");
                    await Task.Delay(5000);
                    continue;
                }

                var uploadState = uploadStateProp.GetString() ?? "";
                Debug.WriteLine($"Attempt {attempts + 1}: Upload state = '{uploadState}'");

                if (uploadState.Equals(successState, StringComparison.OrdinalIgnoreCase))
                {
                    Debug.WriteLine($"✓ File processing completed for stage: {stage}");
                    return;
                }

                if (uploadState.Equals(pendingState, StringComparison.OrdinalIgnoreCase))
                {
                    Debug.WriteLine($"⏳ Still processing... (attempt {attempts + 1}/120) - waiting 5 seconds");
                    await Task.Delay(5000);
                    continue;
                }

                if (uploadState.Equals($"{stage}Failed", StringComparison.OrdinalIgnoreCase))
                {
                    Debug.WriteLine($"❌ File processing failed for stage: {stage}");
                    throw new Exception($"File processing failed for stage: {stage}. State: {uploadState}");
                }

                if (uploadState.Equals($"{stage}TimedOut", StringComparison.OrdinalIgnoreCase))
                {
                    Debug.WriteLine($"❌ File processing timed out for stage: {stage}");
                    throw new Exception($"File processing timed out for stage: {stage}. State: {uploadState}");
                }

                Debug.WriteLine($"❓ Unknown upload state: '{uploadState}' - will wait and retry");

                if (attempts < 115)
                {
                    await Task.Delay(10000);
                    continue;
                }
                else
                {
                    Debug.WriteLine($"❌ Giving up after {attempts + 1} attempts with unknown state: '{uploadState}'");
                    throw new Exception($"Unknown file processing state after many attempts: '{uploadState}'. Check Intune admin center.");
                }
            }

            throw new Exception($"Timeout waiting for file processing stage: {stage} after 10 minutes");
        }

        private async Task CommitAppAsync(string appId, string contentVersionId)
        {
            var commitBody = new Dictionary<string, object>
            {
                ["@odata.type"] = "#microsoft.graph.win32LobApp",
                ["committedContentVersion"] = contentVersionId
            };

            var url = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/{appId}";
            var json = JsonSerializer.Serialize(commitBody, new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase });
            using var request = await CreateAuthenticatedRequestAsync(new HttpMethod("PATCH"), url);
            request.Content = new StringContent(json, Encoding.UTF8, "application/json");
            var sw = Stopwatch.StartNew();
            var response = await sharedHttpClient!.SendAsync(request);
            sw.Stop();

            if (response.IsSuccessStatusCode)
            {
                Debug.WriteLine($"✓ App committed successfully (took {sw.Elapsed.TotalSeconds:F1}s)");
                return;
            }

            var responseText = await response.Content.ReadAsStringAsync();
            await LogGraphFailureDiagnosticsAsync("CommitApp (PATCH)", request, response, sw, responseText);

            // 5xx from the gateway often means the backend processing exceeded the
            // sync timeout but completed anyway. Confirm by reading back the app's
            // actual committedContentVersion.
            if ((int)response.StatusCode >= 500 && (int)response.StatusCode < 600)
            {
                Debug.WriteLine($"  Verifying server-side state after gateway 5xx (waiting 30s)...");
                await Task.Delay(TimeSpan.FromSeconds(30));

                var actual = await TryGetCommittedVersionAsync(appId);
                if (actual.GetCommitted == contentVersionId)
                {
                    Debug.WriteLine($"  ✓ App actually committed to version {contentVersionId} despite gateway 5xx — treating as success");
                    return;
                }
                if (actual.VerifyFailed)
                    Debug.WriteLine($"  ? Verify GET failed ({actual.FailureReason}) — cannot tell whether commit took. Treating as failure.");
                else
                    Debug.WriteLine($"  ✗ App's committedContentVersion is '{actual.GetCommitted ?? "(null)"}' — commit did not take");
            }

            throw new Exception($"Failed to commit app. Status: {response.StatusCode}, Response: {responseText}");
        }

        private readonly record struct VerifyResult(string? GetCommitted, bool VerifyFailed, string? FailureReason);

        private async Task<VerifyResult> TryGetCommittedVersionAsync(string appId)
        {
            try
            {
                // No $select — `committedContentVersion` lives on the derived
                // win32LobApp type and $select against the polymorphic mobileApps
                // resource returns 400. Payload is small without it.
                var url = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/{appId}";
                using var req = await CreateAuthenticatedRequestAsync(HttpMethod.Get, url);
                var resp = await sharedHttpClient!.SendAsync(req);
                var body = await resp.Content.ReadAsStringAsync();

                if (!resp.IsSuccessStatusCode)
                {
                    Debug.WriteLine($"  ⚠ Verify GET returned {(int)resp.StatusCode}; body: {body}");
                    return new VerifyResult(null, true, $"HTTP {(int)resp.StatusCode}");
                }

                using var doc = JsonDocument.Parse(body);
                if (doc.RootElement.TryGetProperty("committedContentVersion", out var v))
                    return new VerifyResult(v.ValueKind == JsonValueKind.String ? v.GetString() : null, false, null);
                return new VerifyResult(null, false, null);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"  ⚠ Verify GET threw {ex.GetType().Name}: {ex.Message}");
                return new VerifyResult(null, true, $"{ex.GetType().Name}: {ex.Message}");
            }
        }

        private static async Task LogGraphFailureDiagnosticsAsync(
            string operation,
            HttpRequestMessage request,
            HttpResponseMessage response,
            Stopwatch stopwatch,
            string responseBody)
        {
            Debug.WriteLine($"=== GRAPH FAILURE: {operation} ===");
            Debug.WriteLine($"  Method/URL: {request.Method} {request.RequestUri}");
            Debug.WriteLine($"  Status: {(int)response.StatusCode} {response.StatusCode}");
            Debug.WriteLine($"  Duration: {stopwatch.Elapsed.TotalSeconds:F1}s");

            foreach (var name in new[] { "request-id", "client-request-id", "x-ms-ags-diagnostic", "Retry-After", "Date" })
            {
                if (response.Headers.TryGetValues(name, out var values))
                    Debug.WriteLine($"  {name}: {string.Join(", ", values)}");
            }

            try
            {
                using var doc = JsonDocument.Parse(responseBody);
                if (doc.RootElement.TryGetProperty("error", out var error))
                {
                    if (error.TryGetProperty("code", out var code))
                        Debug.WriteLine($"  error.code: {code.GetString()}");
                    if (error.TryGetProperty("innerError", out var inner))
                    {
                        if (inner.TryGetProperty("request-id", out var reqId))
                            Debug.WriteLine($"  Activity-ID: {reqId.GetString()}");
                        if (inner.TryGetProperty("date", out var date))
                            Debug.WriteLine($"  Server timestamp: {date.GetString()}");
                    }
                }
            }
            catch { /* response wasn't JSON we can parse — body is logged below */ }

            Debug.WriteLine($"  Body: {responseBody}");
            Debug.WriteLine($"=== END FAILURE DIAGNOSTICS ===");
            await Task.CompletedTask;
        }

        private void CleanupTempFiles(IntuneWinInfo intuneWinInfo)
        {
            try
            {
                if (Directory.Exists(intuneWinInfo.TempDirectory))
                {
                    Directory.Delete(intuneWinInfo.TempDirectory, true);
                    Debug.WriteLine($"✓ Cleaned up temp files: {intuneWinInfo.TempDirectory}");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"⚠ Failed to cleanup temp files: {ex.Message}");
            }
        }

        private async Task<string> RenewSasUriAsync()
        {
            var renewUrl = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/{_currentAppId}/microsoft.graph.win32LobApp/contentVersions/{_currentContentVersionId}/files/{_currentFileId}/renewUpload";

            using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Post, renewUrl);
            request.Content = new StringContent("{}", Encoding.UTF8, "application/json");
            var response = await sharedHttpClient!.SendAsync(request);

            if (!response.IsSuccessStatusCode)
            {
                var responseText = await response.Content.ReadAsStringAsync();
                throw new Exception($"Failed to renew SAS URI. Status: {response.StatusCode}, Response: {responseText}");
            }

            return await WaitForNewSasUriAfterRenewal();
        }

        private async Task<string> WaitForNewSasUriAfterRenewal()
        {
            var url = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/{_currentAppId}/microsoft.graph.win32LobApp/contentVersions/{_currentContentVersionId}/files/{_currentFileId}";

            for (int attempts = 0; attempts < 30; attempts++) // 5 minutes max
            {
                using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Get, url);
                var response = await sharedHttpClient!.SendAsync(request);
                var responseText = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception($"Failed to get renewed SAS URI. Status: {response.StatusCode}, Response: {responseText}");
                }

                var fileInfo = JsonSerializer.Deserialize<JsonElement>(responseText);

                if (fileInfo.TryGetProperty("uploadState", out var uploadStateProp))
                {
                    var uploadState = uploadStateProp.GetString() ?? "";

                    if (uploadState.Equals("AzureStorageUriRenewalSuccess", StringComparison.OrdinalIgnoreCase))
                    {
                        if (fileInfo.TryGetProperty("azureStorageUri", out var azureStorageUriProp))
                        {
                            var newSasUri = azureStorageUriProp.GetString();
                            if (!string.IsNullOrEmpty(newSasUri))
                            {
                                Debug.WriteLine("✓ Successfully renewed SAS URI");
                                return newSasUri;
                            }
                        }
                    }
                }

                await Task.Delay(10000);
            }

            throw new Exception("Timeout waiting for SAS URI renewal");
        }

        private async Task UpdateCommittedContentVersionAsync(string appId, string contentVersionId)
        {
            try
            {
                Debug.WriteLine($"Fetching existing app metadata for {appId}...");
                var getUrl = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/{appId}";
                using var getRequest = await CreateAuthenticatedRequestAsync(HttpMethod.Get, getUrl);
                var getResponse = await sharedHttpClient!.SendAsync(getRequest);

                if (!getResponse.IsSuccessStatusCode)
                {
                    throw new Exception($"Failed to fetch existing app: {getResponse.StatusCode}");
                }

                var existingAppJson = await getResponse.Content.ReadAsStringAsync();
                var existingApp = JsonSerializer.Deserialize<JsonElement>(existingAppJson);

                var updateBody = new Dictionary<string, object>
                {
                    ["@odata.type"] = "#microsoft.graph.win32LobApp",
                    ["committedContentVersion"] = contentVersionId
                };

                if (existingApp.TryGetProperty("largeIcon", out var iconProp) &&
                    iconProp.ValueKind != JsonValueKind.Null)
                {
                    var iconDict = new Dictionary<string, object>();

                    if (iconProp.TryGetProperty("type", out var typeProp))
                        iconDict["type"] = typeProp.GetString() ?? "";

                    if (iconProp.TryGetProperty("value", out var valueProp))
                        iconDict["value"] = valueProp.GetString() ?? "";

                    updateBody["largeIcon"] = iconDict;
                    Debug.WriteLine("✅ Preserved existing icon in update");
                }
                else
                {
                    Debug.WriteLine("⚠️ No icon found in existing app");
                }

                var url = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/{appId}";
                var json = JsonSerializer.Serialize(updateBody, new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                });

                Debug.WriteLine($"Updating app with preserved metadata...");

                using var request = await CreateAuthenticatedRequestAsync(new HttpMethod("PATCH"), url);
                request.Content = new StringContent(json, Encoding.UTF8, "application/json");
                var response = await sharedHttpClient!.SendAsync(request);

                if (!response.IsSuccessStatusCode)
                {
                    var responseText = await response.Content.ReadAsStringAsync();
                    Debug.WriteLine($"❌ Update failed: {responseText}");
                    throw new Exception($"Failed to update content version. Status: {response.StatusCode}, Response: {responseText}");
                }

                Debug.WriteLine($"✅ Successfully updated committedContentVersion to {contentVersionId} with preserved icon");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"❌ Error in UpdateCommittedContentVersionAsync: {ex.Message}");
                throw;
            }
        }
    }
}
