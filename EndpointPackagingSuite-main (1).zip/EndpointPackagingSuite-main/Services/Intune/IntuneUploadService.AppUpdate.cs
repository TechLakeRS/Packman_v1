using System.Diagnostics;
using System.IO;

namespace Endpoint_Packaging_Suite.Services
{
    public partial class IntuneUploadService
    {
        public async Task<bool> UpdateExistingApplicationAsync(
           string existingAppId,
           string packagePath,
           IUploadProgress? progress = null,
           string? applicationName = null,
           string? gitLabCommitMessage = null)
        {
            var appName = Path.GetFileName(packagePath) ?? "Unknown";
            using var uploadLogger = new UploadLogger(appName, LogOperationType.Update);

            try
            {
                uploadLogger.Section("UPDATE METADATA");
                uploadLogger.LogMetadata("Existing App ID", existingAppId);
                uploadLogger.LogMetadata("Package Path", packagePath);
                uploadLogger.Info($"Update log file: {uploadLogger.LogFilePath}");

                uploadLogger.Section("UPDATE PROCESS");

                progress?.UpdateProgress(5, "Authenticating with Microsoft Graph...");
                uploadLogger.Progress(5, "Authenticating with Microsoft Graph...");
                EnsureHttpClient();
                uploadLogger.Success("Authentication successful");

                // Step 1: Sign the PSADT script
                progress?.UpdateProgress(8, "Signing application files...");
                uploadLogger.Progress(8, "Signing application files...");
                await SignApplicationFilesAsync(packagePath, progress, uploadLogger);

                // Step 2: GitLab version control push (after signing, before packaging)
                if (!string.IsNullOrEmpty(gitLabCommitMessage) && !string.IsNullOrEmpty(applicationName))
                {
                    uploadLogger.Section("GITLAB VERSION CONTROL");
                    try
                    {
                        if (!_gitLabService.IsConfigured)
                        {
                            var configError = _gitLabService.GetConfigurationErrors();
                            uploadLogger.Warning($"GitLab not fully configured: {configError}");
                        }
                        else
                        {
                            uploadLogger.Info($"Commit message: {gitLabCommitMessage}");
                            uploadLogger.Info("Pushing script to GitLab...");
                            progress?.UpdateProgress(12, "Pushing to GitLab...");

                            var gitLabProgress = new Progress<string>(status => uploadLogger.Info(status));

                            var (gitLabSuccess, gitLabError) = await _gitLabService.PushScriptToGitLabAsync(
                                applicationName,
                                packagePath,
                                gitLabCommitMessage,
                                gitLabProgress);

                            if (gitLabSuccess)
                            {
                                uploadLogger.Success("Script pushed to GitLab successfully");
                            }
                            else
                            {
                                uploadLogger.Error($"GitLab push failed: {gitLabError}");
                            }
                        }
                    }
                    catch (Exception gitEx)
                    {
                        uploadLogger.Error("GitLab push error", gitEx);
                    }

                    uploadLogger.Section("INTUNE UPLOAD");
                }

                // Step 3: Create the .intunewin file
                progress?.UpdateProgress(20, "Packaging application files...");
                uploadLogger.Progress(20, "Packaging application files...");
                await CreateIntuneWinFileAsync(packagePath);
                uploadLogger.Success("Package created successfully");

                // Step 4: Find the created .intunewin file
                progress?.UpdateProgress(25, "Verifying package creation...");
                uploadLogger.Progress(25, "Verifying package creation...");
                var intuneFolder = Path.Combine(packagePath, "Intune");
                var intuneWinFiles = Directory.GetFiles(intuneFolder, "*.intunewin");
                if (intuneWinFiles.Length == 0)
                {
                    throw new Exception("No .intunewin file found after conversion.");
                }

                var intuneWinFile = intuneWinFiles[0];
                Debug.WriteLine($"✓ Found .intunewin file: {Path.GetFileName(intuneWinFile)}");
                uploadLogger.Success($"Found .intunewin file: {Path.GetFileName(intuneWinFile)}");

                // Step 5: Extract .intunewin metadata
                progress?.UpdateProgress(30, "Reading package metadata...");
                uploadLogger.Progress(30, "Reading package metadata...");
                var intuneWinInfo = ExtractIntuneWinInfo(intuneWinFile);
                uploadLogger.Success($"Package metadata extracted - Size: {intuneWinInfo.UnencryptedContentSize:N0} bytes");

                // Step 6: Create NEW content version for EXISTING app
                progress?.UpdateProgress(35, "Preparing new version...");
                uploadLogger.Progress(35, "Preparing new version...");
                var contentVersionId = await CreateContentVersionAsync(existingAppId);
                _currentAppId = existingAppId;
                _currentContentVersionId = contentVersionId;
                uploadLogger.Success($"Content version created: {contentVersionId}");

                // Step 7: Create file entry
                progress?.UpdateProgress(45, "Initializing file upload...");
                uploadLogger.Progress(45, "Initializing file upload...");
                var fileId = await CreateFileEntryAsync(existingAppId, contentVersionId, intuneWinInfo);
                _currentFileId = fileId;
                uploadLogger.Success($"File entry created: {fileId}");

                // Step 8: Wait for Azure Storage URI
                progress?.UpdateProgress(55, "Requesting Azure upload URL...");
                uploadLogger.Progress(55, "Requesting Azure upload URL...");
                var azureStorageInfo = await WaitForAzureStorageUriAsync(existingAppId, contentVersionId, fileId);
                uploadLogger.Success($"Azure Storage URI obtained");

                // Step 9: Upload file to Azure Storage
                progress?.UpdateProgress(65, "Uploading package to Azure...");
                uploadLogger.Progress(65, "Uploading package to Azure...");
                await UploadFileToAzureStorageAsync(azureStorageInfo.SasUri, intuneWinInfo.EncryptedFilePath, progress);
                uploadLogger.Success("Package uploaded to Azure Storage successfully");

                // Step 10: Commit the file
                progress?.UpdateProgress(85, "Finalizing package upload...");
                uploadLogger.Progress(85, "Finalizing package upload...");
                await CommitFileAsync(existingAppId, contentVersionId, fileId, intuneWinInfo.EncryptionInfo);
                uploadLogger.Success("File committed successfully");

                // Step 11: Wait for file processing
                progress?.UpdateProgress(90, "Processing uploaded package...");
                uploadLogger.Progress(90, "Processing uploaded package...");
                await WaitForFileProcessingAsync(existingAppId, contentVersionId, fileId, "CommitFile");
                uploadLogger.Success("File processing completed");

                // Step 12: Commit the app with new content version
                progress?.UpdateProgress(95, "Publishing updated version...");
                uploadLogger.Progress(95, "Publishing updated version...");
                await UpdateCommittedContentVersionAsync(existingAppId, contentVersionId);
                uploadLogger.Success("Application published successfully");

                // Step 13: Cleanup temp files
                CleanupTempFiles(intuneWinInfo);
                uploadLogger.Info("Temporary files cleaned up");

                progress?.UpdateProgress(100, "✓ Update complete!");
                uploadLogger.Section("UPDATE COMPLETE");
                uploadLogger.Success($"Application '{appName}' updated successfully!");
                uploadLogger.Info($"Application ID: {existingAppId}");

                return true;
            }
            catch (Exception ex)
            {
                uploadLogger.Section("UPDATE FAILED");
                uploadLogger.Error("Update process failed", ex);
                Debug.WriteLine($"❌ Failed to update application: {ex.Message}");
                progress?.UpdateProgress(0, $"Update failed: {ex.Message}");
                throw new Exception($"Failed to update application in Intune: {ex.Message}", ex);
            }
        }

        public async Task<bool> UpdateApplicationWithNewCommandsAsync(
           string existingAppId,
           string packagePath,
           string installCommand,
           string uninstallCommand,
           IUploadProgress? progress = null)
        {
            try
            {
                progress?.UpdateProgress(5, "Updating application package...");
                var packageSuccess = await UpdateExistingApplicationAsync(existingAppId, packagePath, progress);

                if (!packageSuccess)
                {
                    return false;
                }

                progress?.UpdateProgress(95, "Updating install commands...");
                var commandsSuccess = await _intuneService.UpdateApplicationCommandsAsync(
                    existingAppId,
                    installCommand,
                    uninstallCommand);

                if (!commandsSuccess)
                {
                    Debug.WriteLine("⚠️ Package updated but failed to update commands");
                    progress?.UpdateProgress(100, "Package updated (command update failed)");
                    return false;
                }

                progress?.UpdateProgress(100, "✓ Update complete with new commands!");
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"❌ Failed to update application with new commands: {ex.Message}");
                progress?.UpdateProgress(0, $"Update failed: {ex.Message}");
                throw new Exception($"Failed to update application with new commands: {ex.Message}", ex);
            }
        }
    }
}
