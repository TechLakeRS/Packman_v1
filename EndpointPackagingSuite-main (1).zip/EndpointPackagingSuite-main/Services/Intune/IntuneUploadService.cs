using Endpoint_Packaging_Suite.Helpers;
using Endpoint_Packaging_Suite.Models;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Text;

namespace Endpoint_Packaging_Suite.Services
{
    public interface IUploadProgress
    {
        void UpdateProgress(int percentage, string message);
    }

    public partial class IntuneUploadService : IDisposable
    {
        private HttpClient? sharedHttpClient;
        private readonly IntuneService _intuneService;
        private readonly NativeCodeSigner _signer;
        private readonly GitLabService _gitLabService;
        private string _currentAppId = "";
        private string _currentContentVersionId = "";
        private string _currentFileId = "";
        public string ConverterPath => Paths.IntuneWinAppUtil;

        public IntuneUploadService(IntuneService intuneService, NativeCodeSigner signer, GitLabService gitLabService)
        {
            _intuneService = intuneService;
            _signer = signer ?? throw new ArgumentNullException(nameof(signer));
            _gitLabService = gitLabService ?? throw new ArgumentNullException(nameof(gitLabService));
        }

        private void EnsureHttpClient()
        {
            if (sharedHttpClient == null)
            {
                sharedHttpClient = new HttpClient();
                sharedHttpClient.Timeout = TimeSpan.FromMinutes(30);
            }
        }

        private async Task<HttpRequestMessage> CreateAuthenticatedRequestAsync(HttpMethod method, string url)
        {
            var token = await _intuneService.GetAccessTokenAsync();
            var request = new HttpRequestMessage(method, url);
            request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
            return request;
        }

        public async Task<string> UploadWin32ApplicationAsync(
            ApplicationInfo appInfo,
            string packagePath,
            List<DetectionRule> detectionRules,
            string installCommand,
            string uninstallCommand,
            string description,
            string installContext,
            string? iconPath = null,
            IUploadProgress? progress = null,
            string? predecessorAppId = null)
        {
            using var uploadLogger = new UploadLogger(appInfo.Name);

            try
            {
                uploadLogger.Section("UPLOAD METADATA");
                uploadLogger.LogMetadata("Application Name", appInfo.Name);
                uploadLogger.LogMetadata("Manufacturer", appInfo.Manufacturer);
                uploadLogger.LogMetadata("Version", appInfo.Version);
                uploadLogger.LogMetadata("Package Path", packagePath);
                uploadLogger.LogMetadata("Install Command", installCommand);
                uploadLogger.LogMetadata("Uninstall Command", uninstallCommand);
                uploadLogger.LogMetadata("Install Context", installContext);
                uploadLogger.LogMetadata("Description", description);
                uploadLogger.LogMetadata("Icon Path", iconPath ?? "None");
                uploadLogger.LogMetadata("Detection Rules", $"{detectionRules.Count} rule(s)");
                uploadLogger.Info($"Upload log file: {uploadLogger.LogFilePath}");

                uploadLogger.Section("UPLOAD PROCESS");

                progress?.UpdateProgress(5, "Authenticating with Microsoft Graph...");
                uploadLogger.Progress(5, "Authenticating with Microsoft Graph...");
                var token = await _intuneService.GetAccessTokenAsync();
                uploadLogger.Success("Authentication successful");
                EnsureHttpClient();

                // Step 0 - Sign files before conversion
                progress?.UpdateProgress(10, "Signing application files...");
                uploadLogger.Progress(10, "Signing application files...");
                await SignApplicationFilesAsync(packagePath, progress, uploadLogger);

                // Step 1: Create the .intunewin file
                progress?.UpdateProgress(20, "Packaging application files...");
                uploadLogger.Progress(20, "Packaging application files...");
                await CreateIntuneWinFileAsync(packagePath);
                uploadLogger.Success("Package created successfully");

                // Step 2: Find the created .intunewin file
                progress?.UpdateProgress(25, "Verifying package creation...");
                uploadLogger.Progress(25, "Verifying package creation...");
                var intuneFolder = Path.Combine(packagePath, "Intune");
                var intuneWinFiles = Directory.GetFiles(intuneFolder, "*.intunewin");
                if (intuneWinFiles.Length == 0)
                {
                    throw new Exception("No .intunewin file found after conversion.");
                }

                var intuneWinFile = intuneWinFiles[0];
                Debug.WriteLine($"✓ Found .intunewin file: {Path.GetFileName(intuneWinFile)}");
                uploadLogger.Success($"Found .intunewin file: {Path.GetFileName(intuneWinFile)}");

                // Step 3: Extract .intunewin metadata
                progress?.UpdateProgress(30, "Reading package metadata...");
                uploadLogger.Progress(30, "Reading package metadata...");
                var intuneWinInfo = ExtractIntuneWinInfo(intuneWinFile);
                uploadLogger.Success($"Package metadata extracted - Size: {intuneWinInfo.UnencryptedContentSize:N0} bytes");

                // Step 4: Create Win32LobApp
                progress?.UpdateProgress(35, "Registering application in Intune...");
                uploadLogger.Progress(35, "Registering application in Intune...");
                var appId = await CreateWin32LobAppAsync(appInfo, installCommand, uninstallCommand, description, detectionRules, installContext, intuneWinInfo, iconPath);
                uploadLogger.Success($"Application registered with ID: {appId}");

                // Step 5: Create content version
                progress?.UpdateProgress(45, "Preparing content storage...");
                uploadLogger.Progress(45, "Preparing content storage...");
                var contentVersionId = await CreateContentVersionAsync(appId);
                _currentAppId = appId;
                _currentContentVersionId = contentVersionId;
                uploadLogger.Success($"Content version created: {contentVersionId}");

                // Step 6: Create file entry
                progress?.UpdateProgress(55, "Initializing file upload...");
                uploadLogger.Progress(55, "Initializing file upload...");
                var fileId = await CreateFileEntryAsync(appId, contentVersionId, intuneWinInfo);
                _currentFileId = fileId;
                uploadLogger.Success($"File entry created: {fileId}");

                // Step 7: Wait for Azure Storage URI
                progress?.UpdateProgress(65, "Requesting Azure upload URL...");
                uploadLogger.Progress(65, "Requesting Azure upload URL...");
                var azureStorageInfo = await WaitForAzureStorageUriAsync(appId, contentVersionId, fileId);
                uploadLogger.Success($"Azure Storage URI obtained (length: {azureStorageInfo.SasUri.Length} chars)");

                // Step 8: Upload file to Azure Storage
                progress?.UpdateProgress(75, "Uploading package to Azure...");
                uploadLogger.Progress(75, "Uploading package to Azure...");
                await UploadFileToAzureStorageAsync(azureStorageInfo.SasUri, intuneWinInfo.EncryptedFilePath, progress);
                uploadLogger.Success("Package uploaded to Azure Storage successfully");

                // Step 9: Commit the file
                progress?.UpdateProgress(85, "Finalizing package upload...");
                uploadLogger.Progress(85, "Finalizing package upload...");
                await CommitFileAsync(appId, contentVersionId, fileId, intuneWinInfo.EncryptionInfo);
                uploadLogger.Success("File committed successfully");

                // Step 10: Wait for file processing
                progress?.UpdateProgress(90, "Processing uploaded package...");
                uploadLogger.Progress(90, "Processing uploaded package...");
                await WaitForFileProcessingAsync(appId, contentVersionId, fileId, "CommitFile");
                uploadLogger.Success("File processing completed");

                // Step 11: Commit the app
                progress?.UpdateProgress(95, "Publishing application...");
                uploadLogger.Progress(95, "Publishing application...");
                await CommitAppAsync(appId, contentVersionId);
                uploadLogger.Success("Application published successfully");

                // Step 12: Cleanup temp files
                CleanupTempFiles(intuneWinInfo);
                uploadLogger.Info("Temporary files cleaned up");

                progress?.UpdateProgress(100, "✓ Upload complete!");
                uploadLogger.Section("UPLOAD COMPLETE");
                uploadLogger.Success($"Application '{appInfo.Name}' uploaded successfully!");
                uploadLogger.Info($"Application ID: {appId}");

                // Record an app-id marker so the package folder can be found by id later
                NetworkShareHelper.SaveMarker(packagePath, appId, appInfo.Name, appInfo.Version);

                if (!string.IsNullOrEmpty(predecessorAppId))
                {
                    await WriteSupersedenceAsync(appId, predecessorAppId, uploadLogger);
                }

                return appId;
            }
            catch (Exception ex)
            {
                uploadLogger.Section("UPLOAD FAILED");
                uploadLogger.Error("Upload process failed", ex);
                throw new Exception($"Failed to upload application to Intune: {ex.Message}", ex);
            }
        }

        public void Dispose()
        {
            // Don't dispose HttpClient - it's designed to be long-lived and reused.
        }

        private async Task WriteSupersedenceAsync(string newAppId, string predecessorAppId, UploadLogger uploadLogger)
        {
            try
            {
                EnsureHttpClient();
                var url = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/{newAppId}/updateRelationships";
                var json = $$"""
                {
                  "relationships": [
                    {
                      "@odata.type": "#microsoft.graph.mobileAppSupersedence",
                      "targetId": "{{predecessorAppId}}",
                      "targetType": "child",
                      "supersedenceType": "update"
                    }
                  ]
                }
                """;
                using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Post, url);
                request.Content = new StringContent(json, Encoding.UTF8, "application/json");
                var response = await sharedHttpClient!.SendAsync(request);
                if (response.IsSuccessStatusCode)
                {
                    uploadLogger.Success($"Marked previous app {predecessorAppId} as superseded");
                }
                else
                {
                    var body = await response.Content.ReadAsStringAsync();
                    uploadLogger.Warning($"Could not write supersedence (HTTP {(int)response.StatusCode}): {body}");
                }
            }
            catch (Exception ex)
            {
                uploadLogger.Warning($"Could not write supersedence: {ex.Message}");
            }
        }
    }

    public class IntuneWinInfo
    {
        public string FileName { get; set; } = "";
        public long UnencryptedContentSize { get; set; }
        public string EncryptedFilePath { get; set; } = "";
        public string TempDirectory { get; set; } = "";
        public EncryptionInfo EncryptionInfo { get; set; } = new();
    }

    public class EncryptionInfo
    {
        public string EncryptionKey { get; set; } = "";
        public string MacKey { get; set; } = "";
        public string InitializationVector { get; set; } = "";
        public string Mac { get; set; } = "";
        public string ProfileIdentifier { get; set; } = "";
        public string FileDigest { get; set; } = "";
        public string FileDigestAlgorithm { get; set; } = "";
    }

    public class AzureStorageInfo
    {
        public string SasUri { get; set; } = "";
    }
}
