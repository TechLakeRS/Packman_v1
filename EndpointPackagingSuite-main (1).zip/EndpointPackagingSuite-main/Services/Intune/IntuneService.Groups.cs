using Microsoft.Extensions.DependencyInjection;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using Endpoint_Packaging_Suite.Models;

namespace Endpoint_Packaging_Suite.Services
{
    public partial class IntuneService
    {
        public const string AllPackagersGroupId = "781ac246-7d58-4796-863f-81fce3e9f5da";
        public const string AllPackagersGroupName = "SY_AZNBB_WKS_AllPackagersDevices";


        public async Task<string> CreateOrGetGroupAsync(string displayName, string description, List<string> ownerObjectIds)
        {
            try
            {
                var token = await GetAccessTokenAsync();

                var checkUrl = $"https://graph.microsoft.com/beta/groups?$filter=displayName eq '{Uri.EscapeDataString(displayName)}'";
                using var checkRequest = await CreateAuthenticatedRequestAsync(HttpMethod.Get, checkUrl);
                var checkResponse = await _sharedHttpClient.SendAsync(checkRequest);

                if (checkResponse.IsSuccessStatusCode)
                {
                    var checkContent = await checkResponse.Content.ReadAsStringAsync();
                    var checkJson = JsonSerializer.Deserialize<JsonElement>(checkContent);

                    if (checkJson.TryGetProperty("value", out var groups) &&
                        groups.GetArrayLength() > 0)
                    {
                        var existingGroupId = groups[0].GetProperty("id").GetString();
                        if (existingGroupId == null)
                        {
                            throw new InvalidOperationException($"Group '{displayName}' exists but has no ID");
                        }

                        return existingGroupId;
                    }
                }

                var ownerBindings = ownerObjectIds
                    .Select(id => $"https://graph.microsoft.com/v1.0/users/{id}")
                    .ToArray();

                var groupPayload = new Dictionary<string, object>
                {
                    ["displayName"] = displayName,
                    ["description"] = description,
                    ["mailEnabled"] = false,
                    ["mailNickname"] = Guid.NewGuid().ToString("N").Substring(0, 10),
                    ["securityEnabled"] = true,
                    ["groupTypes"] = new string[] { },
                    ["owners@odata.bind"] = ownerBindings
                };

                var createUrl = "https://graph.microsoft.com/beta/groups";
                var content = new StringContent(JsonSerializer.Serialize(groupPayload),
                    Encoding.UTF8, "application/json");

                using var createRequest = await CreateAuthenticatedRequestAsync(HttpMethod.Post, createUrl);
                createRequest.Content = content;
                var createResponse = await _sharedHttpClient.SendAsync(createRequest);
                var responseContent = await createResponse.Content.ReadAsStringAsync();

                if (!createResponse.IsSuccessStatusCode)
                {
                    throw new Exception($"Failed to create group: {createResponse.StatusCode} - {responseContent}");
                }

                var responseJson = JsonSerializer.Deserialize<JsonElement>(responseContent);
                var groupId = responseJson.GetProperty("id").GetString();

                if (groupId == null)
                {
                    throw new InvalidOperationException($"Created group '{displayName}' but response contained no ID. Response: {responseContent}");
                }

                return groupId;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error creating/getting group: {ex.Message}");
                throw;
            }
        }

        public async Task<(string Id, string DisplayName)?> FindGroupByNameAsync(string displayName)
        {
            var checkUrl = $"https://graph.microsoft.com/beta/groups?$filter=displayName eq '{Uri.EscapeDataString(displayName)}'&$select=id,displayName";
            using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Get, checkUrl);
            var response = await _sharedHttpClient.SendAsync(request);

            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync();
                throw new Exception($"Failed to look up group '{displayName}': {response.StatusCode} - {error}");
            }

            var content = await response.Content.ReadAsStringAsync();
            var json = JsonSerializer.Deserialize<JsonElement>(content);

            if (json.TryGetProperty("value", out var groups) && groups.GetArrayLength() > 0)
            {
                var first = groups[0];
                var id = first.GetProperty("id").GetString();
                var name = first.TryGetProperty("displayName", out var nameProp) ? nameProp.GetString() : displayName;
                if (!string.IsNullOrEmpty(id))
                {
                    return (id, name ?? displayName);
                }
            }

            return null;
        }

        public async Task AssignGroupsToApplicationAsync(string appId, GroupAssignmentIds groupIds)
        {
            try
            {
                var token = await GetAccessTokenAsync();

                var settingsService = App.Services.GetRequiredService<SettingsService>();
                var ownerIds = settingsService.Settings.GroupAssignment.OwnerIds;

                if (!string.IsNullOrEmpty(groupIds.SystemInstallId))
                {
                    await CreateAssignment(appId, groupIds.SystemInstallId, "required");
                }
                else
                {
                    groupIds.SystemInstallId = await CreateOrGetGroupAsync(
                        "System Install Group",
                        "Group for system-level installations",
                        ownerIds
                    );
                    await CreateAssignment(appId, groupIds.SystemInstallId, "required");
                }

                if (!string.IsNullOrEmpty(groupIds.UserInstallId))
                {
                    await CreateAssignment(appId, groupIds.UserInstallId, "required");
                }
                else
                {
                    groupIds.UserInstallId = await CreateOrGetGroupAsync(
                        "User Install Group",
                        "Group for user-level installations",
                        ownerIds
                    );
                    await CreateAssignment(appId, groupIds.UserInstallId, "required");
                }

                if (!string.IsNullOrEmpty(groupIds.SystemUninstallId))
                {
                    await CreateAssignment(appId, groupIds.SystemUninstallId, "uninstall");
                }
                else
                {
                    groupIds.SystemUninstallId = await CreateOrGetGroupAsync(
                        "System Uninstall Group",
                        "Group for system-level uninstallations",
                        ownerIds
                    );
                    await CreateAssignment(appId, groupIds.SystemUninstallId, "uninstall");
                }

                if (!string.IsNullOrEmpty(groupIds.UserUninstallId))
                {
                    await CreateAssignment(appId, groupIds.UserUninstallId, "uninstall");
                }
                else
                {
                    groupIds.UserUninstallId = await CreateOrGetGroupAsync(
                        "User Uninstall Group",
                        "Group for user-level uninstallations",
                        ownerIds
                    );
                    await CreateAssignment(appId, groupIds.UserUninstallId, "uninstall");
                }

                try
                {
                    await CreateAssignment(appId, AllPackagersGroupId, "available");
                    Debug.WriteLine($"✓ Automatically assigned {AllPackagersGroupName} as available");
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"⚠️ Failed to assign {AllPackagersGroupName}: {ex.Message}");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error assigning groups: {ex.Message}");
                throw;
            }
        }

        private async Task CreateAssignment(string appId, string groupId, string intent)
        {
            var assignmentPayload = new Dictionary<string, object?>
            {
                ["@odata.type"] = "#microsoft.graph.mobileAppAssignment",
                ["intent"] = intent,
                ["target"] = new Dictionary<string, object>
                {
                    ["@odata.type"] = "#microsoft.graph.groupAssignmentTarget",
                    ["groupId"] = groupId
                },
                ["settings"] = null
            };

            var url = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/{appId}/assignments";
            var content = new StringContent(JsonSerializer.Serialize(assignmentPayload),
                Encoding.UTF8, "application/json");

            using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Post, url);
            request.Content = content;
            var response = await _sharedHttpClient.SendAsync(request);

            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync();
                Debug.WriteLine($"Warning: Failed to create {intent} assignment for group {groupId}: {error}");
            }
            else
            {
                Debug.WriteLine($"Created {intent} assignment for group {groupId}");
            }
        }

        private async Task<List<AssignedGroup>> GetAssignedGroupsAsync(string appId)
        {
            var groups = new List<AssignedGroup>();

            try
            {
                var assignmentsUrl = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/{appId}/assignments";
                using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Get, assignmentsUrl);
                var response = await _sharedHttpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseText = await response.Content.ReadAsStringAsync();
                    var json = JsonSerializer.Deserialize<JsonElement>(responseText);

                    if (json.TryGetProperty("value", out var assignmentsArray) && assignmentsArray.ValueKind == JsonValueKind.Array)
                    {
                        var groupsNeedingNames = new List<(AssignedGroup group, string groupId)>();

                        foreach (var assignment in assignmentsArray.EnumerateArray())
                        {
                            var intent = assignment.TryGetProperty("intent", out var intentProp) ? intentProp.GetString() : "Unknown";
                            var groupId = "";

                            if (assignment.TryGetProperty("target", out var targetObj))
                            {
                                var targetType = targetObj.TryGetProperty("@odata.type", out var targetTypeProp) ? targetTypeProp.GetString() : "";

                                switch (targetType)
                                {
                                    case "#microsoft.graph.groupAssignmentTarget":
                                        if (targetObj.TryGetProperty("groupId", out var groupIdProp))
                                        {
                                            groupId = groupIdProp.GetString();
                                            if (!string.IsNullOrEmpty(groupId))
                                            {
                                                var group = new AssignedGroup
                                                {
                                                    GroupId = groupId,
                                                    GroupName = $"Group ID: {groupId}",
                                                    AssignmentType = intent ?? "Unknown"
                                                };
                                                groups.Add(group);
                                                groupsNeedingNames.Add((group, groupId));
                                            }
                                        }
                                        break;

                                    case "#microsoft.graph.allLicensedUsersAssignmentTarget":
                                        groups.Add(new AssignedGroup
                                        {
                                            GroupId = "",
                                            GroupName = "All Licensed Users",
                                            AssignmentType = intent ?? "Unknown"
                                        });
                                        break;

                                    case "#microsoft.graph.allDevicesAssignmentTarget":
                                        groups.Add(new AssignedGroup
                                        {
                                            GroupId = "",
                                            GroupName = "All Devices",
                                            AssignmentType = intent ?? "Unknown"
                                        });
                                        break;

                                    default:
                                        groups.Add(new AssignedGroup
                                        {
                                            GroupId = "",
                                            GroupName = targetType?.Replace("#microsoft.graph.", "") ?? "Unknown Target",
                                            AssignmentType = intent ?? "Unknown"
                                        });
                                        break;
                                }
                            }
                        }

                        if (groupsNeedingNames.Any())
                        {
                            var nameTasks = groupsNeedingNames.Select(async item =>
                            {
                                try
                                {
                                    var name = await GetGroupNameAsync(item.groupId).ConfigureAwait(false);
                                    if (!string.IsNullOrEmpty(name))
                                    {
                                        item.group.GroupName = name;
                                    }
                                }
                                catch (Exception ex)
                                {
                                    Debug.WriteLine($"Failed to get name for group {item.groupId}: {ex.Message}");
                                }
                            });

                            await Task.WhenAll(nameTasks).ConfigureAwait(false);
                        }
                    }
                }

                if (groups.Count == 0)
                {
                    groups.Add(new AssignedGroup
                    {
                        GroupId = "",
                        GroupName = "No Assignments",
                        AssignmentType = "Not assigned to any groups"
                    });
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error getting assigned groups: {ex.Message}");
                groups.Add(new AssignedGroup
                {
                    GroupId = "",
                    GroupName = "Error Loading Groups",
                    AssignmentType = "Could not load assignments"
                });
            }

            return groups;
        }

        private async Task<string?> GetGroupNameAsync(string groupId)
        {
            try
            {
                var groupUrl = $"https://graph.microsoft.com/beta/groups/{groupId}?$select=displayName";
                using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Get, groupUrl);
                var response = await _sharedHttpClient!.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseText = await response.Content.ReadAsStringAsync();
                    var json = JsonSerializer.Deserialize<JsonElement>(responseText);
                    return json.TryGetProperty("displayName", out var nameProp) ? nameProp.GetString() : null;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error getting group name for {groupId}: {ex.Message}");
            }

            return null;
        }

        public async Task<List<AppGroupAssignment>> GetApplicationsAssignedToGroupAsync(
            string groupId,
            IProgress<(int current, int total)>? progress = null,
            CancellationToken cancellationToken = default)
        {
            var apps = await GetApplicationsAsync(forceRefresh: false, cancellationToken);
            var results = new ConcurrentBag<AppGroupAssignment>();

            int processed = 0;
            using var semaphore = new SemaphoreSlim(8);

            var tasks = apps.Select(async app =>
            {
                await semaphore.WaitAsync(cancellationToken);
                try
                {
                    var match = await FindGroupAssignmentAsync(app.Id, groupId, cancellationToken);
                    if (match != null)
                    {
                        results.Add(new AppGroupAssignment
                        {
                            AppId = app.Id,
                            AppName = app.DisplayName,
                            Version = app.Version,
                            AssignmentId = match.Value.assignmentId,
                            Intent = match.Value.intent
                        });
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"Error checking assignments for app {app.Id}: {ex.Message}");
                }
                finally
                {
                    var done = Interlocked.Increment(ref processed);
                    progress?.Report((done, apps.Count));
                    semaphore.Release();
                }
            });

            await Task.WhenAll(tasks);

            return results.OrderBy(r => r.AppName).ToList();
        }

        private async Task<(string assignmentId, string intent)?> FindGroupAssignmentAsync(
            string appId, string groupId, CancellationToken cancellationToken)
        {
            var url = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/{appId}/assignments";
            using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Get, url);
            var response = await _sharedHttpClient.SendAsync(request, cancellationToken);

            if (!response.IsSuccessStatusCode) return null;

            var text = await response.Content.ReadAsStringAsync(cancellationToken);
            var json = JsonSerializer.Deserialize<JsonElement>(text);

            if (!json.TryGetProperty("value", out var assignments) || assignments.ValueKind != JsonValueKind.Array)
                return null;

            foreach (var assignment in assignments.EnumerateArray())
            {
                if (!assignment.TryGetProperty("target", out var target)) continue;
                if (!target.TryGetProperty("@odata.type", out var t)
                    || t.GetString() != "#microsoft.graph.groupAssignmentTarget") continue;
                if (!target.TryGetProperty("groupId", out var g) || g.GetString() != groupId) continue;

                var assignmentId = assignment.TryGetProperty("id", out var idProp) ? idProp.GetString() : null;
                var intent = assignment.TryGetProperty("intent", out var i) ? i.GetString() ?? "" : "";
                if (!string.IsNullOrEmpty(assignmentId))
                    return (assignmentId, intent);
            }

            return null;
        }

        public async Task RemoveAssignmentAsync(string appId, string assignmentId)
        {
            var url = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/{appId}/assignments/{assignmentId}";
            using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Delete, url);
            var response = await _sharedHttpClient.SendAsync(request);

            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync();
                throw new Exception($"Failed to remove assignment ({response.StatusCode}): {error}");
            }

            InvalidateApplicationCache(appId);
        }
    }

    public class AppGroupAssignment
    {
        public string AppId { get; set; } = "";
        public string AppName { get; set; } = "";
        public string Version { get; set; } = "";
        public string AssignmentId { get; set; } = "";
        public string Intent { get; set; } = "";
    }
}
