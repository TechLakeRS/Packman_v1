using Endpoint_Packaging_Suite.Models;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Xml.Linq;

namespace Endpoint_Packaging_Suite.Services
{
    public partial class IntuneUploadService
    {
        private async Task SignApplicationFilesAsync(string packagePath, IUploadProgress? progress, UploadLogger uploadLogger)
        {
            try
            {
                uploadLogger.Section("FILE SIGNING");

                if (!_signer.IsCertificateAvailable())
                {
                    progress?.UpdateProgress(10, "Certificate not available - skipping file signing");
                    uploadLogger.Warning("Certificate not available - skipping file signing");
                    return;
                }

                var scriptPath = FindPSADTScript(packagePath);
                if (scriptPath == null)
                {
                    progress?.UpdateProgress(15, "PSADT script not found - skipping signing");
                    uploadLogger.Warning("No PSADT script found (Invoke-AppDeployToolkit.ps1 or Deploy-Application.ps1) - skipping signing");
                    return;
                }

                var scriptName = Path.GetFileName(scriptPath);
                progress?.UpdateProgress(10, $"Signing {scriptName}...");
                uploadLogger.Info($"Signing {scriptName} (SHA-256 + RFC 3161)");

                var result = await _signer.SignFileAsync(scriptPath);

                if (result.Success)
                {
                    progress?.UpdateProgress(15, $"{scriptName} signed successfully");
                    uploadLogger.Success($"{scriptName} signed successfully");
                }
                else
                {
                    uploadLogger.Warning($"Failed to sign {scriptName}: {result.ErrorMessage}");
                }
            }
            catch (Exception ex)
            {
                uploadLogger.Error("File signing failed", ex);
                progress?.UpdateProgress(15, "File signing failed - continuing with upload");
            }
        }

        private static string FindPSADTExecutable(string packagePath)
        {
            var appFolder = Path.Combine(packagePath, "Application");

            if (File.Exists(Path.Combine(appFolder, "Invoke-AppDeployToolkit.exe")))
                return "Invoke-AppDeployToolkit.exe";
            if (File.Exists(Path.Combine(appFolder, "Deploy-Application.exe")))
                return "Deploy-Application.exe";
            if (File.Exists(Path.Combine(appFolder, "Deploy-Application.ps1")))
                return "Deploy-Application.ps1";

            return "Invoke-AppDeployToolkit.exe";
        }

        private static string? FindPSADTScript(string packagePath)
        {
            // v4: Invoke-AppDeployToolkit.ps1
            var path = Path.Combine(packagePath, "Application", "Invoke-AppDeployToolkit.ps1");
            if (File.Exists(path)) return path;

            path = Path.Combine(packagePath, "Invoke-AppDeployToolkit.ps1");
            if (File.Exists(path)) return path;

            // v3: Deploy-Application.ps1
            path = Path.Combine(packagePath, "Application", "Deploy-Application.ps1");
            if (File.Exists(path)) return path;

            path = Path.Combine(packagePath, "Deploy-Application.ps1");
            if (File.Exists(path)) return path;

            return null;
        }

        private async Task CreateIntuneWinFileAsync(string packagePath)
        {
            var converterPath = @"\\nbb.local\sys\SCCMData\TOOLS\Endpoint_Packaging_Suite\IntuneWinAppUtil.exe";

            if (!File.Exists(converterPath))
            {
                throw new FileNotFoundException($"IntuneWinAppUtil.exe not found at: {converterPath}");
            }

            var applicationFolder = Path.Combine(packagePath, "Application");
            // Support both PSADTv4 (Invoke-AppDeployToolkit.exe) and PSADTv3 (Deploy-Application.exe)
            var setupFile = Path.Combine(applicationFolder, "Invoke-AppDeployToolkit.exe");
            if (!File.Exists(setupFile))
                setupFile = Path.Combine(applicationFolder, "Deploy-Application.exe");
            if (!File.Exists(setupFile))
                setupFile = Path.Combine(applicationFolder, "Deploy-Application.ps1");
            var outputFolder = Path.Combine(packagePath, "Intune");

            if (!Directory.Exists(applicationFolder))
            {
                throw new DirectoryNotFoundException($"Application folder not found: {applicationFolder}");
            }

            if (!File.Exists(setupFile))
            {
                throw new FileNotFoundException($"PSADT executable not found in: {applicationFolder}. Expected Invoke-AppDeployToolkit.exe (v4) or Deploy-Application.exe (v3).");
            }

            Directory.CreateDirectory(outputFolder);

            var arguments = $"-c \"{applicationFolder}\" -s \"{setupFile}\" -o \"{outputFolder}\" -q";

            var processStartInfo = new ProcessStartInfo
            {
                FileName = converterPath,
                Arguments = arguments,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            };

            using var process = new Process { StartInfo = processStartInfo };
            process.Start();

            var output = await process.StandardOutput.ReadToEndAsync();
            var error = await process.StandardError.ReadToEndAsync();
            await process.WaitForExitAsync();

            if (process.ExitCode != 0)
            {
                var errorMessage = string.IsNullOrWhiteSpace(error) ? output : error;
                throw new Exception($"IntuneWinAppUtil failed with exit code {process.ExitCode}: {errorMessage}");
            }

            Debug.WriteLine($"✓ Created .intunewin file using: {converterPath} {arguments}");
        }

        private IntuneWinInfo ExtractIntuneWinInfo(string intuneWinFilePath)
        {
            var tempDir = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString());
            Directory.CreateDirectory(tempDir);

            try
            {
                using (var archive = ZipFile.OpenRead(intuneWinFilePath))
                {
                    foreach (var entry in archive.Entries)
                    {
                        Debug.WriteLine($"  {entry.Name} ({entry.Length:N0} bytes)");
                    }

                    var detectionEntry = archive.Entries.FirstOrDefault(e =>
                        e.Name.Equals("detection.xml", StringComparison.OrdinalIgnoreCase));

                    if (detectionEntry == null)
                    {
                        var availableFiles = string.Join(", ", archive.Entries.Select(e => e.Name));
                        throw new Exception($"detection.xml not found. Available files: {availableFiles}");
                    }

                    var detectionXmlPath = Path.Combine(tempDir, "detection.xml");
                    detectionEntry.ExtractToFile(detectionXmlPath);

                    var xmlContent = File.ReadAllText(detectionXmlPath);

                    var detectionXml = XDocument.Load(detectionXmlPath);
                    var appInfo = detectionXml.Root;

                    if (appInfo == null || !appInfo.Name.LocalName.Equals("ApplicationInfo", StringComparison.OrdinalIgnoreCase))
                    {
                        throw new Exception($"Root element is not ApplicationInfo. Found: {appInfo?.Name}");
                    }

                    var encryptionInfo = appInfo.Elements().FirstOrDefault(e => e.Name.LocalName == "EncryptionInfo");
                    if (encryptionInfo == null)
                    {
                        var availableElements = string.Join(", ", appInfo.Elements().Select(e => e.Name.LocalName));
                        throw new Exception($"EncryptionInfo not found. Available elements: {availableElements}");
                    }

                    Debug.WriteLine("✓ Found ApplicationInfo and EncryptionInfo");

                    ZipArchiveEntry? contentEntry = null;
                    string contentStrategy = "";

                    var commonDatNames = new[] { "Contents.dat", "IntunePackage.dat", "contents.dat", "intunepackage.dat" };
                    foreach (var datName in commonDatNames)
                    {
                        contentEntry = archive.Entries.FirstOrDefault(e => e.Name.Equals(datName, StringComparison.OrdinalIgnoreCase));
                        if (contentEntry != null)
                        {
                            contentStrategy = $"Found by common .dat name: {datName}";
                            break;
                        }
                    }

                    if (contentEntry == null)
                    {
                        contentEntry = archive.Entries.FirstOrDefault(e =>
                            e.Name.EndsWith(".intunewin", StringComparison.OrdinalIgnoreCase) &&
                            e.Length > 1000);

                        if (contentEntry != null)
                        {
                            contentStrategy = $"Found .intunewin content file: {contentEntry.Name}";
                        }
                    }

                    if (contentEntry == null)
                    {
                        contentEntry = archive.Entries.FirstOrDefault(e => e.Name.EndsWith(".dat", StringComparison.OrdinalIgnoreCase));
                        if (contentEntry != null)
                        {
                            contentStrategy = $"Found .dat file: {contentEntry.Name}";
                        }
                    }

                    if (contentEntry == null)
                    {
                        contentEntry = archive.Entries
                            .Where(e => !e.Name.EndsWith(".xml", StringComparison.OrdinalIgnoreCase))
                            .OrderByDescending(e => e.Length)
                            .FirstOrDefault();

                        if (contentEntry != null)
                        {
                            contentStrategy = $"Found largest non-XML file: {contentEntry.Name}";
                        }
                    }

                    if (contentEntry == null)
                    {
                        var fileNameFromXml = GetElementValue(appInfo, "FileName");
                        if (!string.IsNullOrEmpty(fileNameFromXml))
                        {
                            var possibleNames = new[]
                            {
                                fileNameFromXml,
                                Path.GetFileNameWithoutExtension(fileNameFromXml) + ".dat",
                                Path.GetFileNameWithoutExtension(fileNameFromXml),
                            };

                            foreach (var possibleName in possibleNames)
                            {
                                contentEntry = archive.Entries.FirstOrDefault(e => e.Name.Equals(possibleName, StringComparison.OrdinalIgnoreCase));
                                if (contentEntry != null)
                                {
                                    contentStrategy = $"Found by FileName reference: {possibleName}";
                                    break;
                                }
                            }
                        }
                    }

                    if (contentEntry == null)
                    {
                        var fileList = string.Join("\n  ", archive.Entries.Select(e => $"{e.Name} ({e.Length:N0} bytes)"));
                        throw new Exception($"Could not find encrypted content file in archive.\n\nAvailable files:\n  {fileList}");
                    }

                    Debug.WriteLine($"✓ {contentStrategy}");

                    var encryptedFilePath = Path.Combine(tempDir, contentEntry.Name);
                    contentEntry.ExtractToFile(encryptedFilePath);
                    Debug.WriteLine($"✓ Extracted content file: {contentEntry.Name} ({contentEntry.Length:N0} bytes)");

                    string GetElementValue(XElement parent, string localName)
                    {
                        var element = parent.Elements().FirstOrDefault(e => e.Name.LocalName.Equals(localName, StringComparison.OrdinalIgnoreCase));
                        var value = element?.Value?.Trim();

                        if (string.IsNullOrWhiteSpace(value))
                        {
                            Debug.WriteLine($"⚠ Element '{localName}' is empty or missing");
                            return "";
                        }

                        Debug.WriteLine($"✓ Element '{localName}': {value}");
                        return value;
                    }

                    var fileName = GetElementValue(appInfo, "FileName");
                    if (string.IsNullOrEmpty(fileName))
                    {
                        fileName = Path.GetFileName(intuneWinFilePath);
                        Debug.WriteLine($"Using fallback filename: {fileName}");
                    }

                    var unencryptedSizeStr = GetElementValue(appInfo, "UnencryptedContentSize");
                    if (!long.TryParse(unencryptedSizeStr, out var unencryptedSize))
                    {
                        Debug.WriteLine($"⚠ Could not parse UnencryptedContentSize: '{unencryptedSizeStr}', using actual content file size");
                        unencryptedSize = contentEntry.Length;
                    }

                    var result = new IntuneWinInfo
                    {
                        FileName = fileName,
                        UnencryptedContentSize = unencryptedSize,
                        EncryptedFilePath = encryptedFilePath,
                        TempDirectory = tempDir,
                        EncryptionInfo = new EncryptionInfo
                        {
                            EncryptionKey = GetElementValue(encryptionInfo, "EncryptionKey"),
                            MacKey = GetElementValue(encryptionInfo, "MacKey") ?? GetElementValue(encryptionInfo, "macKey"),
                            InitializationVector = GetElementValue(encryptionInfo, "InitializationVector") ?? GetElementValue(encryptionInfo, "initializationVector"),
                            Mac = GetElementValue(encryptionInfo, "Mac") ?? GetElementValue(encryptionInfo, "mac"),
                            ProfileIdentifier = GetElementValue(encryptionInfo, "ProfileIdentifier") ?? "ProfileVersion1",
                            FileDigest = GetElementValue(encryptionInfo, "FileDigest") ?? GetElementValue(encryptionInfo, "fileDigest"),
                            FileDigestAlgorithm = GetElementValue(encryptionInfo, "FileDigestAlgorithm") ?? GetElementValue(encryptionInfo, "fileDigestAlgorithm") ?? "SHA256"
                        }
                    };

                    if (string.IsNullOrEmpty(result.EncryptionInfo.EncryptionKey))
                    {
                        throw new Exception("EncryptionKey is missing from detection.xml");
                    }

                    if (!File.Exists(result.EncryptedFilePath))
                    {
                        throw new Exception($"Encrypted content file was not extracted properly: {result.EncryptedFilePath}");
                    }

                    return result;
                }
            }
            catch
            {
                if (Directory.Exists(tempDir))
                {
                    try
                    {
                        Directory.Delete(tempDir, true);
                    }
                    catch { }
                }
                throw;
            }
        }

        private async Task<string> CreateWin32LobAppAsync(
            ApplicationInfo appInfo,
            string installCommand,
            string uninstallCommand,
            string description,
            List<DetectionRule> detectionRules,
            string installContext,
            IntuneWinInfo intuneWinInfo,
            string? iconPath = null)
        {
            var formattedDetectionRules = new List<Dictionary<string, object>>();

            foreach (var rule in detectionRules)
            {
                var formattedRule = ConvertDetectionRuleForBetaAPI(rule);
                if (formattedRule != null)
                {
                    formattedDetectionRules.Add(formattedRule);
                }
            }

            if (formattedDetectionRules.Count == 0)
            {
                formattedDetectionRules.Add(new Dictionary<string, object>
                {
                    ["@odata.type"] = "#microsoft.graph.win32LobAppFileSystemDetection",
                    ["path"] = "%ProgramFiles%",
                    ["fileOrFolderName"] = $"{appInfo.Name}.exe",
                    ["check32BitOn64System"] = true,
                    ["detectionType"] = "exists"
                });
            }

            var createAppPayload = new Dictionary<string, object>
            {
                ["@odata.type"] = "#microsoft.graph.win32LobApp",
                ["displayName"] = $"{appInfo.Manufacturer} {appInfo.Name} {appInfo.Version}",
                ["description"] = description,
                ["publisher"] = appInfo.Manufacturer,
                ["displayVersion"] = appInfo.Version,
                ["installCommandLine"] = installCommand,
                ["uninstallCommandLine"] = uninstallCommand,
                ["applicableArchitectures"] = "x86,x64,arm64",
                ["fileName"] = intuneWinInfo.FileName,
                ["setupFilePath"] = "Invoke-AppDeployToolkit.exe",
                ["informationUrl"] = "https://servicemanagement.nbb.be/nbb_portal",
                ["privacyInformationUrl"] = "https://servicemanagement.nbb.be/nbb_portal",
                ["installExperience"] = new Dictionary<string, object>
                {
                    ["runAsAccount"] = installContext,
                    ["deviceRestartBehavior"] = "allow"
                },

                ["detectionRules"] = formattedDetectionRules.ToArray(),
                ["returnCodes"] = new[]
                {
                    new Dictionary<string, object> { ["returnCode"] = 0, ["type"] = "success" },
                    new Dictionary<string, object> { ["returnCode"] = 3010, ["type"] = "softReboot" },
                    new Dictionary<string, object> { ["returnCode"] = 1641, ["type"] = "hardReboot" },
                    new Dictionary<string, object> { ["returnCode"] = 1618, ["type"] = "retry" }
                }
            };

            if (!string.IsNullOrEmpty(iconPath) && File.Exists(iconPath))
            {
                try
                {
                    var fileInfo = new FileInfo(iconPath);
                    Debug.WriteLine($"Icon file exists: true");
                    Debug.WriteLine($"Icon file size: {fileInfo.Length} bytes");

                    var iconData = ConvertIconToBase64(iconPath);
                    if (iconData != null)
                    {
                        createAppPayload["largeIcon"] = iconData;
                        Debug.WriteLine($"✓ Added icon to payload");

                        var iconJson = JsonSerializer.Serialize(iconData);
                        Debug.WriteLine($"Icon structure: {iconJson}");
                    }
                    else
                    {
                        Debug.WriteLine("❌ ConvertIconToBase64 returned null");
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"⚠ Failed to add icon: {ex.Message}");
                }
            }
            else
            {
                if (string.IsNullOrEmpty(iconPath))
                {
                    Debug.WriteLine("⚠ No icon path provided");
                }
                else
                {
                    Debug.WriteLine($"❌ Icon file not found: {iconPath}");
                }
            }

            var json = JsonSerializer.Serialize(createAppPayload, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                WriteIndented = true
            });

            if (json.Contains("\"largeIcon\""))
            {
                var iconIndex = json.IndexOf("\"largeIcon\"");
                if (iconIndex > 0)
                {
                    var iconSection = json.Substring(iconIndex, Math.Min(500, json.Length - iconIndex));
                }
            }
            using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Post, "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps");
            request.Content = new StringContent(json, Encoding.UTF8, "application/json");
            var sw = Stopwatch.StartNew();
            var response = await sharedHttpClient!.SendAsync(request);
            var responseText = await response.Content.ReadAsStringAsync();
            sw.Stop();

            if (!response.IsSuccessStatusCode)
            {
                await LogGraphFailureDiagnosticsAsync("CreateWin32LobApp (POST)", request, response, sw, responseText);
                throw new Exception($"Failed to create Win32 app. Status: {response.StatusCode}, Response: {responseText}");
            }

            Debug.WriteLine($"  ✓ Win32 app created (took {sw.Elapsed.TotalSeconds:F1}s)");

            var createdApp = JsonSerializer.Deserialize<JsonElement>(responseText);
            var appId = createdApp.GetProperty("id").GetString();

            try
            {
                await _intuneService.AssignTestCategoryToAppAsync(appId!);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"⚠ Failed to assign Test category: {ex.Message}");
            }

            return appId ?? throw new Exception("App ID not returned from creation");
        }

        private Dictionary<string, object>? ConvertIconToBase64(string iconPath)
        {
            try
            {
                Debug.WriteLine($"=== CONVERTING ICON ===");
                Debug.WriteLine($"Icon path: {iconPath}");

                var iconBytes = File.ReadAllBytes(iconPath);
                Debug.WriteLine($"Icon size: {iconBytes.Length} bytes");

                if (iconBytes.Length > 500 * 1024)
                {
                    Debug.WriteLine($"⚠ Icon is large ({iconBytes.Length} bytes), may fail to upload");
                }

                var base64String = Convert.ToBase64String(iconBytes);
                Debug.WriteLine($"Base64 length: {base64String.Length} characters");

                var extension = Path.GetExtension(iconPath).ToLower();
                var mimeType = extension switch
                {
                    ".png" => "image/png",
                    ".jpg" or ".jpeg" => "image/jpeg",
                    ".ico" => "image/x-icon",
                    _ => "image/png"
                };

                Debug.WriteLine($"MIME type: {mimeType}");

                var iconData = new Dictionary<string, object>
                {
                    ["type"] = mimeType,
                    ["value"] = base64String
                };

                Debug.WriteLine("✓ Icon converted successfully");
                return iconData;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"❌ Error converting icon to base64: {ex.Message}");
                Debug.WriteLine($"Stack trace: {ex.StackTrace}");
                return null;
            }
        }
    }
}
