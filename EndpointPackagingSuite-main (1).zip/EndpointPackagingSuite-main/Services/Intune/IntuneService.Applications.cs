using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite.Helpers;
using Endpoint_Packaging_Suite.Constants;

namespace Endpoint_Packaging_Suite.Services
{
    public partial class IntuneService
    {
        public async Task<List<IntuneApplication>> GetApplicationsAsync(bool forceRefresh = false, CancellationToken cancellationToken = default, IProgress<(int fetchedCount, int totalCount)>? progress = null)
        {
            // Force refresh: bypass cache entirely, fetch all, and replace cache
            if (forceRefresh)
            {
                _logger.LogInformation("Force refresh requested - fetching all applications from Intune");
                var allApps = await GetAllApplicationsFromGraphAsync(cancellationToken, progress);
                await _appListCache.SaveAsync(allApps);
                return allApps;
            }

            var cached = await _appListCache.LoadAsync();

            // No cache yet - first run, pull everything
            if (cached == null || cached.Count == 0)
            {
                _logger.LogInformation("No application cache found - fetching all from Intune");
                var allApps = await GetAllApplicationsFromGraphAsync(cancellationToken, progress);
                await _appListCache.SaveAsync(allApps);
                return allApps;
            }

            // Cache exists - reconcile against the live ID set from the API
            _logger.LogInformation("Cache has {Count} apps - checking API for delta", cached.Count);
            progress?.Report((0, cached.Count));

            List<string> apiIds;
            try
            {
                apiIds = await GetApplicationIdsAsync(cancellationToken);
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to fetch application IDs for delta check; falling back to cached list");
                return cached.OrderBy(a => a.DisplayName).ToList();
            }

            var apiIdSet = new HashSet<string>(apiIds);
            var cachedIdSet = new HashSet<string>(cached.Select(a => a.Id));
            var newIds = apiIds.Where(id => !cachedIdSet.Contains(id)).ToList();
            var deletedIds = cachedIdSet.Where(id => !apiIdSet.Contains(id)).ToHashSet();

            if (newIds.Count == 0 && deletedIds.Count == 0)
            {
                _logger.LogInformation("Cache in sync with API ({Count} apps); using cache", cached.Count);
                return cached.OrderBy(a => a.DisplayName).ToList();
            }

            _logger.LogInformation("Cache delta: +{New} new, -{Deleted} deleted (cache: {Cached}, API: {Api})",
                newIds.Count, deletedIds.Count, cached.Count, apiIds.Count);

            var reconciled = deletedIds.Count > 0
                ? cached.Where(a => !deletedIds.Contains(a.Id)).ToList()
                : cached;

            int processed = 0;
            foreach (var id in newIds)
            {
                cancellationToken.ThrowIfCancellationRequested();
                try
                {
                    var app = await GetApplicationListItemByIdAsync(id, cancellationToken);
                    if (app != null)
                    {
                        reconciled.Add(app);
                    }
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Failed to fetch new application {Id}", id);
                }

                processed++;
                progress?.Report((processed, reconciled.Count));
            }

            await _appListCache.SaveAsync(reconciled);

            return reconciled.OrderBy(a => a.DisplayName).ToList();
        }

        private async Task<List<string>> GetApplicationIdsAsync(CancellationToken cancellationToken = default)
        {
            var ids = new List<string>();
            var requestUrl = "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps" +
                             "?$filter=isof('microsoft.graph.win32LobApp')" +
                             "&$select=id" +
                             "&$top=999";

            while (!string.IsNullOrEmpty(requestUrl))
            {
                cancellationToken.ThrowIfCancellationRequested();

                var (response, responseText) = await RetryHelper.ExecuteWithRetryAsync(async () =>
                {
                    using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Get, requestUrl);
                    var resp = await _sharedHttpClient.SendAsync(request, cancellationToken);
                    var text = await resp.Content.ReadAsStringAsync(cancellationToken);
                    return (resp, text);
                }, maxRetries: 3, initialDelayMs: 1000, cancellationToken);

                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception($"Failed to fetch application IDs: {response.StatusCode}");
                }

                var graphResponse = JsonSerializer.Deserialize<GraphResponse<JsonElement>>(responseText, _camelCaseOptions);
                if (graphResponse?.Value != null)
                {
                    foreach (var app in graphResponse.Value)
                    {
                        if (app.TryGetProperty("id", out var idProp))
                        {
                            var id = idProp.GetString();
                            if (!string.IsNullOrEmpty(id))
                                ids.Add(id);
                        }
                    }
                }

                requestUrl = graphResponse?.ODataNextLink ?? "";
            }

            return ids;
        }

        private async Task<IntuneApplication?> GetApplicationListItemByIdAsync(string id, CancellationToken cancellationToken)
        {
            var requestUrl = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/{id}?$expand=categories";
            using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Get, requestUrl);
            var response = await _sharedHttpClient.SendAsync(request, cancellationToken);
            var responseText = await response.Content.ReadAsStringAsync(cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogWarning("Failed to fetch app {Id}: {Status}", id, response.StatusCode);
                return null;
            }

            var appJson = JsonSerializer.Deserialize<JsonElement>(responseText);
            return ParseIntuneApplication(appJson);
        }

        private async Task<List<IntuneApplication>> GetAllApplicationsFromGraphAsync(CancellationToken cancellationToken = default, IProgress<(int fetchedCount, int totalCount)>? progress = null)
        {
            try
            {
                Debug.WriteLine("=== FETCHING ALL APPLICATIONS FROM GRAPH ===");

                var apps = new List<IntuneApplication>();
                _logger.LogDebug("Using HTTP client to fetch applications");

                var token = await GetAccessTokenAsync();
                var requestUrl = "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps" +
                                "?$filter=isof('microsoft.graph.win32LobApp')" +
                                "&$expand=categories" +
                                "&$top=100" +
                                "&$orderby=displayName";

                int batchCount = 0;
                while (!string.IsNullOrEmpty(requestUrl))
                {
                    cancellationToken.ThrowIfCancellationRequested();

                    batchCount++;
                    Debug.WriteLine($"Fetching batch #{batchCount} from: {requestUrl}");

                    var (response, responseText) = await RetryHelper.ExecuteWithRetryAsync(async () =>
                    {
                        using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Get, requestUrl);
                        var resp = await _sharedHttpClient.SendAsync(request, cancellationToken);
                        var text = await resp.Content.ReadAsStringAsync(cancellationToken);
                        return (resp, text);
                    }, maxRetries: 3, initialDelayMs: 1000, cancellationToken);

                    if (!response.IsSuccessStatusCode)
                    {
                        requestUrl = requestUrl.Replace("&$expand=categories", "");

                        var (retryResponse, retryResponseText) = await RetryHelper.ExecuteWithRetryAsync(async () =>
                        {
                            using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Get, requestUrl);
                            var resp = await _sharedHttpClient.SendAsync(request, cancellationToken);
                            var text = await resp.Content.ReadAsStringAsync(cancellationToken);
                            return (resp, text);
                        }, maxRetries: 3, initialDelayMs: 1000, cancellationToken);

                        response = retryResponse;
                        responseText = retryResponseText;

                        if (!response.IsSuccessStatusCode)
                        {
                            Debug.WriteLine($"Failed to fetch applications: {response.StatusCode}");
                            throw new Exception($"Failed to fetch applications: {response.StatusCode}");
                        }
                    }

                    var graphResponse = JsonSerializer.Deserialize<GraphResponse<JsonElement>>(responseText, _camelCaseOptions);

                    if (graphResponse?.Value != null)
                    {
                        int fetchedInBatch = 0;
                        foreach (var app in graphResponse.Value)
                        {
                            apps.Add(ParseIntuneApplication(app));
                            fetchedInBatch++;
                        }

                        Debug.WriteLine($"Fetched {fetchedInBatch} apps in batch #{batchCount}, total so far: {apps.Count}");

                        progress?.Report((fetchedInBatch, apps.Count));
                    }

                    requestUrl = graphResponse?.ODataNextLink ?? "";
                }

                Debug.WriteLine($"✓ Successfully fetched {apps.Count} total applications using HTTP");
                return apps.OrderBy(a => a.DisplayName).ToList();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error fetching all applications: {ex.Message}");
                throw;
            }
        }

        public async Task<ApplicationDetail> GetApplicationDetailAsync(string intuneAppId, bool forceRefresh = false)
        {
            var cacheKey = $"app_detail_{intuneAppId}";

            if (forceRefresh)
            {
                _cache.Remove(cacheKey);
            }

            return await _cache.GetOrCreateAsync(cacheKey, async entry =>
            {
                entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(15);
                entry.SetPriority(CacheItemPriority.High);
                entry.SetSize(1);
                return await GetApplicationDetailFromGraphAsync(intuneAppId);
            }) ?? throw new InvalidOperationException($"Failed to retrieve application detail for {intuneAppId}");
        }

        public async Task<ApplicationDetail> GetApplicationDetailFromGraphAsync(string intuneAppId, CancellationToken cancellationToken = default)
        {
            try
            {
                Debug.WriteLine($"=== FETCHING APP DETAILS FOR: {intuneAppId} ===");

                _logger.LogDebug("Using HTTP client to fetch app details");

                var token = await GetAccessTokenAsync();
                var appUrl = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/{intuneAppId}";
                Debug.WriteLine($"Getting complete app details from: {appUrl}");

                using var appRequest = await CreateAuthenticatedRequestAsync(HttpMethod.Get, appUrl);
                var appResponse = await _sharedHttpClient.SendAsync(appRequest);
                var appResponseText = await appResponse.Content.ReadAsStringAsync();

                if (!appResponse.IsSuccessStatusCode)
                {
                    throw new Exception($"Failed to get app details: {appResponse.StatusCode} - {appResponseText}");
                }

                var appJson = JsonSerializer.Deserialize<JsonElement>(appResponseText);

                ApplicationDetail appDetail;
                try
                {
                    appDetail = new ApplicationDetail
                    {
                        Id = appJson.GetProperty("id").GetString() ?? "",
                        DisplayName = appJson.TryGetProperty("displayName", out var displayNameProp) ? displayNameProp.GetString() ?? "Unknown" : "Unknown",
                        Version = appJson.TryGetProperty("displayVersion", out var versionProp) ? versionProp.GetString() ?? "1.0.0" : "1.0.0",
                        Publisher = appJson.TryGetProperty("publisher", out var publisherProp) ? publisherProp.GetString() ?? "Unknown" : "Unknown",
                        Description = appJson.TryGetProperty("description", out var descProp) ? descProp.GetString() ?? "" : "",
                        InstallCommand = appJson.TryGetProperty("installCommandLine", out var installProp) ? installProp.GetString() ?? "Invoke-AppDeployToolkit.exe Install" : "Invoke-AppDeployToolkit.exe Install",
                        UninstallCommand = appJson.TryGetProperty("uninstallCommandLine", out var uninstallProp) ? uninstallProp.GetString() ?? "Invoke-AppDeployToolkit.exe Uninstall" : "Invoke-AppDeployToolkit.exe Uninstall",
                        InstallContext = "System",

                        Owner = appJson.TryGetProperty("owner", out var ownerProp) ? ownerProp.GetString() ?? "" : "",
                        Developer = appJson.TryGetProperty("developer", out var devProp) ? devProp.GetString() ?? "" : "",
                        Notes = appJson.TryGetProperty("notes", out var notesProp) ? notesProp.GetString() ?? "" : "",
                        FileName = appJson.TryGetProperty("fileName", out var fileNameProp) ? fileNameProp.GetString() ?? "" : "",
                        Size = appJson.GetSafeLong("size"),
                        MinimumFreeDiskSpaceInMB = appJson.GetSafeInt("minimumFreeDiskSpaceInMB"),
                        MinimumMemoryInMB = appJson.GetSafeInt("minimumMemoryInMB"),
                        MinimumNumberOfProcessors = appJson.GetSafeInt("minimumNumberOfProcessors"),
                        MinimumCpuSpeedInMHz = appJson.GetSafeInt("minimumCpuSpeedInMHz"),

                        PrivacyInformationUrl = appJson.TryGetProperty("privacyInformationUrl", out var privacyProp) ? privacyProp.GetString() ?? "" : "",
                        InformationUrl = appJson.TryGetProperty("informationUrl", out var infoProp) ? infoProp.GetString() ?? "" : "",
                        UploadState = appJson.TryGetProperty("uploadState", out var uploadProp)
                    ? uploadProp.ValueKind == JsonValueKind.Number
                    ? uploadProp.GetInt32().ToString()
                     : uploadProp.GetString() ?? ""
                     : "",
                        PublishingState = appJson.TryGetProperty("publishingState", out var publishProp)
                            ? publishProp.ValueKind == JsonValueKind.Number ? publishProp.GetInt32().ToString() : publishProp.GetString() ?? ""
                            : "",
                        ApplicableArchitectures = appJson.TryGetProperty("applicableArchitectures", out var appArchProp)
                            ? appArchProp.ValueKind == JsonValueKind.Number ? appArchProp.GetInt32().ToString() : appArchProp.GetString() ?? ""
                            : "",
                        AllowedArchitectures = appJson.TryGetProperty("allowedArchitectures", out var allowArchProp)
                            ? allowArchProp.ValueKind == JsonValueKind.Number ? allowArchProp.GetInt32().ToString() : allowArchProp.GetString() ?? ""
                            : "",
                        SetupFilePath = appJson.TryGetProperty("setupFilePath", out var setupProp)
                            ? setupProp.ValueKind == JsonValueKind.Number ? setupProp.GetInt32().ToString() : setupProp.GetString() ?? ""
                            : "",
                        MinimumSupportedWindowsRelease = appJson.TryGetProperty("minimumSupportedWindowsRelease", out var winProp)
                            ? winProp.ValueKind == JsonValueKind.Number ? winProp.GetInt32().ToString() : winProp.GetString() ?? ""
                            : "",

                        CreatedDateTime = appJson.GetSafeDateTime("createdDateTime"),
                        LastModifiedDateTime = appJson.GetSafeDateTime("lastModifiedDateTime"),

                        Category = "Loading..."
                    };
                    if (appJson.TryGetProperty("installExperience", out var installExpProp) && installExpProp.ValueKind != JsonValueKind.Null)
                    {
                        if (installExpProp.TryGetProperty("runAsAccount", out var runAsAccountProp))
                        {
                            var runAsAccount = runAsAccountProp.ValueKind == JsonValueKind.Number
                                ? runAsAccountProp.GetInt32().ToString()
                                : runAsAccountProp.GetString();
                            appDetail.InstallContext = runAsAccount?.Equals("user", StringComparison.OrdinalIgnoreCase) == true ? "User" : "System";
                            Debug.WriteLine($"✓ Install context: {appDetail.InstallContext} (from runAsAccount: {runAsAccount})");
                        }

                        if (installExpProp.TryGetProperty("deviceRestartBehavior", out var restartProp))
                        {
                            var restartBehavior = restartProp.ValueKind == JsonValueKind.Number
                                ? restartProp.GetInt32().ToString()
                                : restartProp.GetString();
                            appDetail.DeviceRestartBehavior = restartBehavior ?? "";
                            Debug.WriteLine($"Device restart behavior: {restartBehavior}");
                        }

                        if (installExpProp.TryGetProperty("maxRunTimeInMinutes", out var maxTimeProp))
                        {
                            appDetail.MaxInstallTimeInMinutes = maxTimeProp.ValueKind == JsonValueKind.Number
                                ? maxTimeProp.GetInt32()
                                : null;
                        }
                    }
                }
                catch (InvalidOperationException ex)
                {
                    Debug.WriteLine($"❌ JSON parsing failed for app ID: {intuneAppId}");
                    Debug.WriteLine($"❌ Error: {ex.Message}");
                    Debug.WriteLine($"❌ Stack trace: {ex.StackTrace}");

                    var debugFileName = $"debug_app_{intuneAppId}_{DateTime.Now:yyyyMMdd_HHmmss}.json";
                    File.WriteAllText(debugFileName, appJson.GetRawText());
                    Debug.WriteLine($"🔍 Raw JSON saved to: {debugFileName}");

                    throw;
                }

                if (appJson.TryGetProperty("largeIcon", out var iconProp) && iconProp.ValueKind != JsonValueKind.Null)
                {
                    var iconType = iconProp.TryGetProperty("type", out var typeProp) ? typeProp.GetString() ?? "" : "";
                    var iconValue = iconProp.TryGetProperty("value", out var valueProp) ? valueProp.GetString() ?? "" : "";

                    if (!string.IsNullOrEmpty(iconValue))
                    {
                        try
                        {
                            appDetail.IconType = iconType;
                            appDetail.IconData = Convert.FromBase64String(iconValue);
                            Debug.WriteLine($"Icon data set: {appDetail.IconData.Length} bytes");
                        }
                        catch (Exception ex)
                        {
                            Debug.WriteLine($"Failed to parse icon: {ex.Message}");
                        }
                    }
                }

                if (appJson.TryGetProperty("roleScopeTagIds", out var roleTagsProp) && roleTagsProp.ValueKind == JsonValueKind.Array)
                {
                    foreach (var tag in roleTagsProp.EnumerateArray())
                    {
                        var tagValue = tag.ValueKind == JsonValueKind.Number
                            ? tag.GetInt32().ToString()
                            : tag.GetString();
                        if (!string.IsNullOrEmpty(tagValue))
                            appDetail.RoleScopeTagIds.Add(tagValue);
                    }
                }

                if (appJson.TryGetProperty("returnCodes", out var returnCodesProp) && returnCodesProp.ValueKind == JsonValueKind.Array)
                {
                    foreach (var returnCode in returnCodesProp.EnumerateArray())
                    {
                        var code = returnCode.GetSafeInt("returnCode");
                        var type = returnCode.TryGetProperty("type", out var typeProp)
                            ? typeProp.ValueKind == JsonValueKind.Number ? typeProp.GetInt32().ToString() : typeProp.GetString() ?? "Unknown"
                            : "Unknown";

                        appDetail.ReturnCodes.Add(new ReturnCode
                        {
                            Code = code,
                            Type = type
                        });
                    }
                }

                Debug.WriteLine($"✓ Basic app info loaded: {appDetail.DisplayName}");

                appDetail.DetectionRules = ParseDetectionRulesFromResponse(appJson);

                if (appJson.TryGetProperty("requirementRules", out var reqRulesProp) && reqRulesProp.ValueKind == JsonValueKind.Array)
                {
                    Debug.WriteLine($"Found requirementRules array with {reqRulesProp.GetArrayLength()} items");
                    foreach (var rule in reqRulesProp.EnumerateArray())
                    {
                        if (rule.TryGetProperty("@odata.type", out var typeProp))
                        {
                            var ruleType = typeProp.GetString() ?? "";
                            Debug.WriteLine($"  Requirement rule type: {ruleType}");

                            var description = rule.TryGetProperty("displayName", out var dispProp)
                                ? dispProp.GetString() ?? ""
                                : "";
                            if (string.IsNullOrEmpty(description) && rule.TryGetProperty("description", out var descProp))
                            {
                                description = descProp.GetString() ?? "";
                            }

                            if (!string.IsNullOrEmpty(description))
                            {
                                appDetail.RequirementRules.Add(new RequirementRule
                                {
                                    Type = ruleType,
                                    Description = description
                                });
                            }
                        }
                    }
                }

                var assignmentsTask = GetAssignedGroupsAsync(intuneAppId);
                var categoriesTask = GetAppCategoriesAsync(intuneAppId);

                await Task.WhenAll(assignmentsTask, categoriesTask).ConfigureAwait(false);

                appDetail.AssignedGroups = await assignmentsTask;
                appDetail.Category = await categoriesTask;

                Debug.WriteLine($"=== SYSTEM REQUIREMENTS DEBUG ===");
                Debug.WriteLine($"  Disk Space: {appDetail.MinimumFreeDiskSpaceInMB?.ToString() ?? "null"} MB");
                Debug.WriteLine($"  Memory: {appDetail.MinimumMemoryInMB?.ToString() ?? "null"} MB");
                Debug.WriteLine($"  Processors: {appDetail.MinimumNumberOfProcessors?.ToString() ?? "null"}");
                Debug.WriteLine($"  CPU Speed: {appDetail.MinimumCpuSpeedInMHz?.ToString() ?? "null"} MHz");
                Debug.WriteLine($"  Architectures: {appDetail.ApplicableArchitectures}");
                Debug.WriteLine($"  Min Windows Release: {appDetail.MinimumSupportedWindowsRelease}");

                if (appJson.TryGetProperty("minimumSupportedOperatingSystem", out var minOsProp) && minOsProp.ValueKind != JsonValueKind.Null)
                {
                    Debug.WriteLine($"  Found minimumSupportedOperatingSystem object:");
                    string minOsVersion = ParseMinimumOperatingSystem(minOsProp);
                    if (!string.IsNullOrEmpty(minOsVersion))
                    {
                        appDetail.MinimumSupportedWindowsRelease = minOsVersion;
                        Debug.WriteLine($"  Parsed OS Version: {minOsVersion}");
                    }
                }
                Debug.WriteLine($"=================================");

                Debug.WriteLine($"✓ Complete app details loaded for: {appDetail.DisplayName}");
                return appDetail;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"✗ Error getting app details: {ex.Message}");
                throw new Exception($"Failed to get application details from Intune: {ex.Message}", ex);
            }
        }

        private IntuneApplication ParseIntuneApplication(JsonElement app)
        {
            var id = app.GetProperty("id").GetString() ?? "";
            var displayName = app.TryGetProperty("displayName", out var dnProp) ? dnProp.GetString() ?? "Unknown" : "Unknown";
            var version = app.TryGetProperty("displayVersion", out var verProp) ? verProp.GetString() ?? "1.0.0" : "1.0.0";
            var publisher = app.TryGetProperty("publisher", out var pubProp) ? pubProp.GetString() ?? "Unknown" : "Unknown";

            var category = "Uncategorized";
            if (app.TryGetProperty("categories", out var categoriesProp) && categoriesProp.ValueKind == JsonValueKind.Array)
            {
                var categoryNames = new List<string>();
                foreach (var cat in categoriesProp.EnumerateArray())
                {
                    if (cat.TryGetProperty("displayName", out var catName))
                    {
                        var catNameStr = catName.GetString();
                        if (!string.IsNullOrWhiteSpace(catNameStr))
                            categoryNames.Add(catNameStr);
                    }
                }
                if (categoryNames.Count > 0)
                    category = string.Join(", ", categoryNames);
            }

            return new IntuneApplication
            {
                Id = id,
                DisplayName = displayName,
                Version = version,
                Publisher = publisher,
                Category = category,
                LastModified = DateTime.Now
            };
        }

        public void InvalidateApplicationCache(string appId)
        {
            _cache.Remove($"app_detail_{appId}");

            // Drop the entry from the persistent app-list cache so the next load
            // sees a count discrepancy and re-fetches the (now updated) app.
            _ = _appListCache.RemoveAsync(appId);
        }

        private List<DetectionRule> ParseDetectionRulesFromResponse(JsonElement appJson)
        {
            return _detectionRuleParser.ParseFromJson(appJson);
        }

        private string ParseMinimumOperatingSystem(JsonElement minOsElement)
        {
            var osVersions = new Dictionary<string, string>
            {
                ["v8_0"] = "Windows 8.0",
                ["v8_1"] = "Windows 8.1",
                ["v10_0"] = "Windows 10",
                ["v10_1507"] = "Windows 10 1507",
                ["v10_1511"] = "Windows 10 1511",
                ["v10_1607"] = "Windows 10 1607",
                ["v10_1703"] = "Windows 10 1703",
                ["v10_1709"] = "Windows 10 1709",
                ["v10_1803"] = "Windows 10 1803",
                ["v10_1809"] = "Windows 10 1809",
                ["v10_1903"] = "Windows 10 1903",
                ["v10_1909"] = "Windows 10 1909",
                ["v10_2004"] = "Windows 10 2004",
                ["v10_2H20"] = "Windows 10 20H2",
                ["v10_21H1"] = "Windows 10 21H1",
                ["v10_21H2"] = "Windows 10 21H2",
                ["v10_22H2"] = "Windows 10 22H2",
                ["v11_21H2"] = "Windows 11 21H2",
                ["v11_22H2"] = "Windows 11 22H2",
                ["v11_23H2"] = "Windows 11 23H2"
            };

            string? highestVersion = null;

            foreach (var kvp in osVersions.Reverse())
            {
                if (minOsElement.TryGetProperty(kvp.Key, out var versionProp) &&
                    versionProp.ValueKind == JsonValueKind.True)
                {
                    highestVersion = kvp.Value;
                    Debug.WriteLine($"    {kvp.Key}: true -> {kvp.Value}");
                    break;
                }
            }

            return highestVersion ?? "";
        }

        public async Task<bool> AssignTestCategoryToAppAsync(string appId)
        {
            try
            {
                var token = await GetAccessTokenAsync();

                var categoriesUrl = "https://graph.microsoft.com/beta/deviceAppManagement/mobileAppCategories";
                using var getCatRequest = await CreateAuthenticatedRequestAsync(HttpMethod.Get, categoriesUrl);
                var response = await _sharedHttpClient.SendAsync(getCatRequest);

                if (!response.IsSuccessStatusCode)
                {
                    Debug.WriteLine("Failed to get categories");
                    return false;
                }

                var responseText = await response.Content.ReadAsStringAsync();
                var json = JsonSerializer.Deserialize<JsonElement>(responseText);

                string? testCategoryId = null;
                if (json.TryGetProperty("value", out var categories))
                {
                    foreach (var category in categories.EnumerateArray())
                    {
                        if (category.TryGetProperty("displayName", out var name) &&
                            name.GetString() == "Test")
                        {
                            testCategoryId = category.GetProperty("id").GetString();
                            Debug.WriteLine($"Found Test category with ID: {testCategoryId}");
                            break;
                        }
                    }
                }

                if (string.IsNullOrEmpty(testCategoryId))
                {
                    Debug.WriteLine("Test category not found in Intune");
                    return false;
                }

                var assignUrl = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/{appId}/categories/$ref";
                var assignPayload = new Dictionary<string, object>
                {
                    ["@odata.id"] = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileAppCategories/{testCategoryId}"
                };

                var assignContent = new StringContent(
                    JsonSerializer.Serialize(assignPayload),
                    Encoding.UTF8,
                    "application/json");

                using var postRequest = await CreateAuthenticatedRequestAsync(HttpMethod.Post, assignUrl);
                postRequest.Content = assignContent;
                var assignResponse = await _sharedHttpClient.SendAsync(postRequest);

                if (assignResponse.IsSuccessStatusCode)
                {
                    Debug.WriteLine("✓ Successfully assigned Test category to app");
                    return true;
                }
                else
                {
                    var errorText = await assignResponse.Content.ReadAsStringAsync();
                    Debug.WriteLine($"Failed to assign category: {errorText}");
                    return false;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error assigning Test category: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Replaces the app's category with <paramref name="newCategoryName"/> and appends a dated note
        /// to the description in the form "dd-MM-yyyy - Category change to: {category}".
        /// Passing "Uncategorized" removes any existing categories without assigning a new one.
        /// </summary>
        public async Task<(bool success, string newDescription)> SetAppCategoryAsync(
            string appId,
            string newCategoryName,
            string currentDescription)
        {
            try
            {
                var allCategoriesUrl = "https://graph.microsoft.com/beta/deviceAppManagement/mobileAppCategories";
                using var listRequest = await CreateAuthenticatedRequestAsync(HttpMethod.Get, allCategoriesUrl);
                var listResponse = await _sharedHttpClient.SendAsync(listRequest);
                if (!listResponse.IsSuccessStatusCode)
                {
                    Debug.WriteLine($"Failed to list mobileAppCategories: {listResponse.StatusCode}");
                    return (false, currentDescription);
                }

                var listJson = JsonSerializer.Deserialize<JsonElement>(await listResponse.Content.ReadAsStringAsync());
                string? newCategoryId = null;
                if (!string.Equals(newCategoryName, AppConstants.Categories.Uncategorized, StringComparison.OrdinalIgnoreCase)
                    && listJson.TryGetProperty("value", out var allCats))
                {
                    foreach (var cat in allCats.EnumerateArray())
                    {
                        if (cat.TryGetProperty("displayName", out var dn) &&
                            string.Equals(dn.GetString(), newCategoryName, StringComparison.OrdinalIgnoreCase))
                        {
                            newCategoryId = cat.GetProperty("id").GetString();
                            break;
                        }
                    }

                    if (string.IsNullOrEmpty(newCategoryId))
                    {
                        Debug.WriteLine($"Category '{newCategoryName}' not found in Intune");
                        return (false, currentDescription);
                    }
                }

                var existingUrl = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/{appId}/categories";
                using var existingRequest = await CreateAuthenticatedRequestAsync(HttpMethod.Get, existingUrl);
                var existingResponse = await _sharedHttpClient.SendAsync(existingRequest);
                if (existingResponse.IsSuccessStatusCode)
                {
                    var existingJson = JsonSerializer.Deserialize<JsonElement>(await existingResponse.Content.ReadAsStringAsync());
                    if (existingJson.TryGetProperty("value", out var existingCats))
                    {
                        foreach (var cat in existingCats.EnumerateArray())
                        {
                            if (cat.TryGetProperty("id", out var idProp))
                            {
                                var existingId = idProp.GetString();
                                if (string.IsNullOrEmpty(existingId)) continue;
                                var deleteUrl = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/{appId}/categories/{existingId}/$ref";
                                using var deleteRequest = await CreateAuthenticatedRequestAsync(HttpMethod.Delete, deleteUrl);
                                var deleteResponse = await _sharedHttpClient.SendAsync(deleteRequest);
                                if (!deleteResponse.IsSuccessStatusCode)
                                {
                                    var err = await deleteResponse.Content.ReadAsStringAsync();
                                    Debug.WriteLine($"Failed to remove category {existingId}: {err}");
                                }
                            }
                        }
                    }
                }

                if (!string.IsNullOrEmpty(newCategoryId))
                {
                    var assignUrl = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/{appId}/categories/$ref";
                    var assignPayload = new Dictionary<string, object>
                    {
                        ["@odata.id"] = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileAppCategories/{newCategoryId}"
                    };
                    using var assignRequest = await CreateAuthenticatedRequestAsync(HttpMethod.Post, assignUrl);
                    assignRequest.Content = new StringContent(JsonSerializer.Serialize(assignPayload), Encoding.UTF8, "application/json");
                    var assignResponse = await _sharedHttpClient.SendAsync(assignRequest);
                    if (!assignResponse.IsSuccessStatusCode)
                    {
                        var err = await assignResponse.Content.ReadAsStringAsync();
                        Debug.WriteLine($"Failed to assign category '{newCategoryName}': {err}");
                        return (false, currentDescription);
                    }
                }

                var note = $"{DateTime.Now:dd-MM-yyyy} - Category change to: {newCategoryName}";
                var amendedDescription = string.IsNullOrWhiteSpace(currentDescription)
                    ? note
                    : currentDescription.TrimEnd() + Environment.NewLine + note;

                var patchUrl = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/{appId}";
                var patchPayload = new Dictionary<string, object>
                {
                    ["@odata.type"] = "#microsoft.graph.win32LobApp",
                    ["description"] = amendedDescription
                };
                using var patchRequest = await CreateAuthenticatedRequestAsync(new HttpMethod("PATCH"), patchUrl);
                patchRequest.Content = new StringContent(JsonSerializer.Serialize(patchPayload, _camelCaseOptions), Encoding.UTF8, "application/json");
                var patchResponse = await _sharedHttpClient.SendAsync(patchRequest);
                if (!patchResponse.IsSuccessStatusCode)
                {
                    var err = await patchResponse.Content.ReadAsStringAsync();
                    Debug.WriteLine($"Category was updated but description PATCH failed: {err}");
                    return (false, currentDescription);
                }

                InvalidateApplicationCache(appId);
                return (true, amendedDescription);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error in SetAppCategoryAsync: {ex.Message}");
                return (false, currentDescription);
            }
        }

        public async Task<bool> UpdateApplicationCommandsAsync(string appId, string installCommand, string uninstallCommand)
        {
            try
            {
                var token = await GetAccessTokenAsync();

                var updatePayload = new Dictionary<string, object>
                {
                    ["@odata.type"] = "#microsoft.graph.win32LobApp",
                    ["installCommandLine"] = installCommand,
                    ["uninstallCommandLine"] = uninstallCommand
                };

                var updateUrl = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/{appId}";

                var json = JsonSerializer.Serialize(updatePayload, _camelCaseOptions);

                var content = new StringContent(json, Encoding.UTF8, "application/json");

                using var request = await CreateAuthenticatedRequestAsync(new HttpMethod("PATCH"), updateUrl);
                request.Content = content;

                var response = await _sharedHttpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    Debug.WriteLine($"✓ Successfully updated commands for app {appId}");
                    Debug.WriteLine($"  Install: {installCommand}");
                    Debug.WriteLine($"  Uninstall: {uninstallCommand}");
                    return true;
                }
                else
                {
                    var errorText = await response.Content.ReadAsStringAsync();
                    Debug.WriteLine($"Failed to update commands: {response.StatusCode}");
                    Debug.WriteLine($"Error: {errorText}");
                    return false;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error updating application commands: {ex.Message}");
                return false;
            }
        }

        private async Task<string> GetAppCategoriesAsync(string appId)
        {
            try
            {
                var categoriesUrl = $"https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/{appId}/categories";
                Debug.WriteLine($"Fetching categories from: {categoriesUrl}");

                using var request = await CreateAuthenticatedRequestAsync(HttpMethod.Get, categoriesUrl);
                var response = await _sharedHttpClient!.SendAsync(request);

                Debug.WriteLine($"Category response status: {response.StatusCode}");

                if (response.IsSuccessStatusCode)
                {
                    var responseText = await response.Content.ReadAsStringAsync();
                    Debug.WriteLine($"Category response: {responseText}");

                    var json = JsonSerializer.Deserialize<JsonElement>(responseText);

                    if (json.TryGetProperty("value", out var categoriesArray) && categoriesArray.ValueKind == JsonValueKind.Array)
                    {
                        var categoryNames = new List<string>();
                        var categoryCount = categoriesArray.GetArrayLength();
                        Debug.WriteLine($"Found {categoryCount} categories for app {appId}");

                        foreach (var category in categoriesArray.EnumerateArray())
                        {
                            if (category.TryGetProperty("displayName", out var catNameProp))
                            {
                                var catName = catNameProp.GetString();
                                if (!string.IsNullOrWhiteSpace(catName))
                                {
                                    Debug.WriteLine($"  - Category: {catName}");
                                    categoryNames.Add(catName);
                                }
                            }
                        }

                        var result = categoryNames.Count > 0 ? string.Join(", ", categoryNames) : "Uncategorized";
                        Debug.WriteLine($"✓ Final category result: {result}");
                        return result;
                    }
                    else
                    {
                        Debug.WriteLine($"⚠️ No 'value' property or not an array in category response");
                    }
                }
                else
                {
                    var errorText = await response.Content.ReadAsStringAsync();
                    Debug.WriteLine($"❌ Category fetch failed: {response.StatusCode} - {errorText}");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"❌ Error getting categories for {appId}: {ex.Message}");
                Debug.WriteLine($"   Stack trace: {ex.StackTrace}");
            }

            Debug.WriteLine($"Returning 'Uncategorized' for app {appId}");
            return "Uncategorized";
        }
    }
}
