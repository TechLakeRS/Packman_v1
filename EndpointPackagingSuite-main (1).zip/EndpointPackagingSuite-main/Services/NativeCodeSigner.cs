// Services/NativeCodeSigner.cs
//
// Native Authenticode signer that calls SignerSignEx2 (Mssign32.dll) directly.
// No PowerShell, no temp PFX on disk, no script interpolation.
//
// The cert comes from KeyVaultService as an in-memory X509Certificate2. We add it
// to an ephemeral in-memory cert store and hand the store handle + PCCERT_CONTEXT
// to SignerSignEx2. Windows' SIP (Subject Interface Package) dispatch then decides
// how to embed the signature based on file type, so a single code path covers
// PE files (.exe/.dll/.sys/.ocx/.cab/.msi), catalog files (.cat), and PowerShell
// scripts (.ps1/.psm1/.psd1/.ps1xml) — anything with a registered SIP on the host.

using Serilog;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Threading.Tasks;

namespace Endpoint_Packaging_Suite.Services
{
    /// <summary>
    /// In-process Authenticode signer. No PFX ever touches disk, no PowerShell
    /// process is launched, no script is written to a temp file.
    /// </summary>
    public class NativeCodeSigner
    {
        private readonly KeyVaultService _keyVaultService;
        private readonly Serilog.ILogger _logger;
        private readonly string _timestampServer;

        /// <summary>
        /// Default extensions we show in the UI folder scan. SignerSignEx2 will reject
        /// anything the OS has no SIP for, so this is advisory only.
        /// </summary>
        public static readonly IReadOnlyCollection<string> DefaultSignableExtensions =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            {
                // PE family
                ".exe", ".dll", ".sys", ".ocx", ".scr", ".cpl", ".drv", ".efi",
                ".mui", ".winmd", ".ax",
                // Installers
                ".msi", ".msp", ".msm",
                // Cabinet / catalog
                ".cab", ".cat",
                // PowerShell
                ".ps1", ".psm1", ".psd1", ".ps1xml",
            };

        public NativeCodeSigner(
            KeyVaultService keyVaultService,
            SettingsService? settingsService = null,
            string? timestampServer = null)
        {
            _keyVaultService = keyVaultService ?? throw new ArgumentNullException(nameof(keyVaultService));
            _logger = Log.ForContext<NativeCodeSigner>();

            _timestampServer = timestampServer
                ?? settingsService?.Settings?.CodeSigning?.TimestampServer
                ?? "http://timestamp.digicert.com";
        }

        public bool IsCertificateAvailable()
        {
            var cert = _keyVaultService.GetCertificate();
            return cert is { HasPrivateKey: true };
        }

        /// <summary>
        /// Signs a single file with SHA-256 Authenticode and an RFC 3161 timestamp.
        /// Runs on a background thread.
        /// </summary>
        public Task<SigningResult> SignFileAsync(
            string filePath,
            CancellationToken cancellationToken = default)
        {
            return Task.Run(() =>
            {
                cancellationToken.ThrowIfCancellationRequested();

                var cert = _keyVaultService.GetCertificate();
                if (cert is null || !cert.HasPrivateKey)
                {
                    return new SigningResult
                    {
                        FilePath = filePath,
                        Success = false,
                        ErrorMessage = "No signing certificate loaded. Ensure the Key Vault certificate was loaded at startup."
                    };
                }

                return SignOneFile(filePath, cert);
            }, cancellationToken);
        }

        /// <summary>
        /// Signs a batch of files sequentially with SHA-256 Authenticode and RFC 3161 timestamps.
        /// </summary>
        public Task<BatchSigningResult> SignFilesAsync(
            IReadOnlyList<string> filePaths,
            IProgress<BatchSigningProgress>? progress = null,
            CancellationToken cancellationToken = default)
        {
            return Task.Run(() =>
            {
                var result = new BatchSigningResult { TotalFiles = filePaths.Count };

                var cert = _keyVaultService.GetCertificate();
                if (cert is null || !cert.HasPrivateKey)
                {
                    foreach (var f in filePaths)
                    {
                        result.Results.Add(new SigningResult
                        {
                            FilePath = f,
                            Success = false,
                            ErrorMessage = "No signing certificate loaded."
                        });
                    }
                    return result;
                }

                _logger.Information("Starting native batch signing of {Count} files (cert={Subject})",
                    filePaths.Count, cert.Subject);

                for (int i = 0; i < filePaths.Count; i++)
                {
                    cancellationToken.ThrowIfCancellationRequested();

                    var filePath = filePaths[i];
                    progress?.Report(new BatchSigningProgress
                    {
                        CurrentIndex = i,
                        TotalFiles = filePaths.Count,
                        CurrentFile = filePath,
                        Phase = "Signing"
                    });

                    var oneResult = SignOneFile(filePath, cert);
                    result.Results.Add(oneResult);

                    if (oneResult.Success) result.SuccessCount++;
                    else result.FailureCount++;

                    progress?.Report(new BatchSigningProgress
                    {
                        CurrentIndex = i + 1,
                        TotalFiles = filePaths.Count,
                        CurrentFile = filePath,
                        Phase = oneResult.Success ? "Signed" : "Failed",
                        LastResult = oneResult
                    });
                }

                _logger.Information("Native batch signing complete: {Ok}/{Total}",
                    result.SuccessCount, filePaths.Count);
                return result;
            }, cancellationToken);
        }

        // -----------------------------------------------------------------
        // Core: call SignerSignEx2 once for a single file.
        // Every unmanaged allocation is paired with a free in a finally block.
        // -----------------------------------------------------------------
        // SHA-256 Authenticode — the only algorithm we sign with.
        // See: https://learn.microsoft.com/windows/win32/seccrypto/authenticode
        private const uint SHA256_ALG_ID = CALG_SHA_256;
        private const string SHA256_OID  = "2.16.840.1.101.3.4.2.1";

        private SigningResult SignOneFile(
            string filePath,
            X509Certificate2 cert)
        {
            var result = new SigningResult { FilePath = filePath };

            SignDiag($"[SIGN] ----- Begin SignOneFile {filePath} -----");

            if (!File.Exists(filePath))
            {
                result.Success = false;
                result.ErrorMessage = $"File does not exist: {filePath}";
                SignDiag($"[SIGN] File.Exists returned FALSE for {filePath}");
                return result;
            }

            try
            {
                var fi = new FileInfo(filePath);
                SignDiag(
                    $"[SIGN] File {Path.GetFileName(filePath)} — size={fi.Length}, " +
                    $"attrs={fi.Attributes}, readonly={(fi.Attributes & FileAttributes.ReadOnly) != 0}");
            }
            catch (Exception statEx)
            {
                SignDiag($"[SIGN] Could not stat {filePath}: {statEx.Message}");
            }

            SignDiag(
                $"[SIGN] Cert handle=0x{cert.Handle.ToInt64():X}, thumb={cert.Thumbprint}");

            IntPtr hMemStore       = IntPtr.Zero;
            IntPtr pSubjectInfo    = IntPtr.Zero;
            IntPtr pFileInfo       = IntPtr.Zero;
            IntPtr pSignerCert     = IntPtr.Zero;
            IntPtr pCertStoreInfo  = IntPtr.Zero;
            IntPtr pSignatureInfo  = IntPtr.Zero;
            IntPtr pIndex          = IntPtr.Zero;
            IntPtr pSignerContext  = IntPtr.Zero;

            try
            {
                // Open an in-memory cert store and add our cert to it.
                hMemStore = CertOpenStore(
                    lpszStoreProvider: (IntPtr)CERT_STORE_PROV_MEMORY,
                    dwMsgAndCertEncodingType: X509_ASN_ENCODING | PKCS_7_ASN_ENCODING,
                    hCryptProv: IntPtr.Zero,
                    dwFlags: 0,
                    pvPara: IntPtr.Zero);
                if (hMemStore == IntPtr.Zero)
                {
                    var err = Marshal.GetLastWin32Error();
                    SignDiag($"[SIGN] CertOpenStore failed Win32=0x{err:X8}");
                    throw new Win32Exception(err, "CertOpenStore failed");
                }

                if (!CertAddCertificateContextToStore(
                        hMemStore,
                        cert.Handle,
                        CERT_STORE_ADD_ALWAYS,
                        IntPtr.Zero))
                {
                    var err = Marshal.GetLastWin32Error();
                    SignDiag($"[SIGN] CertAddCertificateContextToStore failed Win32=0x{err:X8}");
                    throw new Win32Exception(err, "CertAddCertificateContextToStore failed");
                }

                var fileInfo = new SIGNER_FILE_INFO
                {
                    cbSize = (uint)Marshal.SizeOf<SIGNER_FILE_INFO>(),
                    pwszFileName = filePath,
                    hFile = IntPtr.Zero
                };
                pFileInfo = Marshal.AllocHGlobal((int)fileInfo.cbSize);
                Marshal.StructureToPtr(fileInfo, pFileInfo, fDeleteOld: false);

                pIndex = Marshal.AllocHGlobal(sizeof(uint));
                Marshal.WriteInt32(pIndex, 0);

                var subjectInfo = new SIGNER_SUBJECT_INFO
                {
                    cbSize = (uint)Marshal.SizeOf<SIGNER_SUBJECT_INFO>(),
                    pdwIndex = pIndex,
                    dwSubjectChoice = SIGNER_SUBJECT_FILE,
                    union1 = pFileInfo
                };
                pSubjectInfo = Marshal.AllocHGlobal((int)subjectInfo.cbSize);
                Marshal.StructureToPtr(subjectInfo, pSubjectInfo, fDeleteOld: false);

                var certStoreInfo = new SIGNER_CERT_STORE_INFO
                {
                    cbSize = (uint)Marshal.SizeOf<SIGNER_CERT_STORE_INFO>(),
                    pSigningCert = cert.Handle,
                    dwCertPolicy = SIGNER_CERT_POLICY_CHAIN,
                    hCertStore = hMemStore
                };
                pCertStoreInfo = Marshal.AllocHGlobal((int)certStoreInfo.cbSize);
                Marshal.StructureToPtr(certStoreInfo, pCertStoreInfo, fDeleteOld: false);

                // 5) SIGNER_CERT { cbSize, dwCertChoice=STORE, SIGNER_CERT_STORE_INFO*, hwnd }
                var signerCert = new SIGNER_CERT
                {
                    cbSize = (uint)Marshal.SizeOf<SIGNER_CERT>(),
                    dwCertChoice = SIGNER_CERT_STORE,
                    union1 = pCertStoreInfo,
                    hwnd = IntPtr.Zero
                };
                pSignerCert = Marshal.AllocHGlobal((int)signerCert.cbSize);
                Marshal.StructureToPtr(signerCert, pSignerCert, fDeleteOld: false);

                // 6) SIGNER_SIGNATURE_INFO { cbSize, algidHash, no attrs }
                var sigInfo = new SIGNER_SIGNATURE_INFO
                {
                    cbSize = (uint)Marshal.SizeOf<SIGNER_SIGNATURE_INFO>(),
                    algidHash = SHA256_ALG_ID,
                    dwAttrChoice = SIGNER_NO_ATTR,
                    union1 = IntPtr.Zero,
                    psAuthenticated = IntPtr.Zero,
                    psUnauthenticated = IntPtr.Zero
                };
                pSignatureInfo = Marshal.AllocHGlobal((int)sigInfo.cbSize);
                Marshal.StructureToPtr(sigInfo, pSignatureInfo, fDeleteOld: false);

                // 7) Call SignerSignEx2 — always with an RFC 3161 SHA-256 countersignature.
                //    The timestamp is what keeps the signature trusted after the cert expires.
                if (string.IsNullOrWhiteSpace(_timestampServer))
                {
                    result.Success = false;
                    result.ErrorMessage = "No timestamp server configured (CodeSigning.TimestampServer in appsettings.json).";
                    return result;
                }

                SignDiag(
                    $"[SIGN] Calling SignerSignEx2 file={Path.GetFileName(filePath)} " +
                    $"ts={_timestampServer}");

                int hr = SignerSignEx2(
                    dwFlags: 0,
                    pSubjectInfo: pSubjectInfo,
                    pSignerCert: pSignerCert,
                    pSignatureInfo: pSignatureInfo,
                    pProviderInfo: IntPtr.Zero,
                    dwTimestampFlags: SIGNER_TIMESTAMP_RFC3161,
                    pszTimestampAlgorithmOid: SHA256_OID,
                    pwszHttpTimeStamp: _timestampServer,
                    psRequest: IntPtr.Zero,
                    pSipData: IntPtr.Zero,
                    ppSignerContext: out pSignerContext,
                    pCryptoPolicy: IntPtr.Zero,
                    pReserved: IntPtr.Zero);

                SignDiag(
                    $"[SIGN] SignerSignEx2 returned HRESULT=0x{hr:X8} for {Path.GetFileName(filePath)}");

                if (hr == 0)
                {
                    result.Success = true;
                    _logger.Debug("Signed {File} (SHA-256, RFC 3161 timestamped)",
                        Path.GetFileName(filePath));
                }
                else
                {
                    result.Success = false;
                    result.HResult = hr;
                    result.ErrorMessage = HResultToMessage(hr);
                    SignDiag(
                        $"[SIGN] FAILED {Path.GetFileName(filePath)}: {result.ErrorMessage}");
                    _logger.Warning("SignerSignEx2 failed for {File}: 0x{Hr:X8} {Msg}",
                        Path.GetFileName(filePath), hr, result.ErrorMessage);
                }
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.ErrorMessage = ex.Message;
                SignDiag($"[SIGN] EXCEPTION signing {filePath}: {ex}");
                _logger.Warning(ex, "Exception signing {File}", filePath);
            }
            finally
            {
                if (pSignerContext != IntPtr.Zero) SignerFreeSignerContext(pSignerContext);
                if (pSignatureInfo != IntPtr.Zero) Marshal.FreeHGlobal(pSignatureInfo);
                if (pSignerCert != IntPtr.Zero) Marshal.FreeHGlobal(pSignerCert);
                if (pCertStoreInfo != IntPtr.Zero) Marshal.FreeHGlobal(pCertStoreInfo);
                if (pSubjectInfo != IntPtr.Zero) Marshal.FreeHGlobal(pSubjectInfo);
                if (pFileInfo != IntPtr.Zero)
                {
                    // SIGNER_FILE_INFO contains a string we marshalled; DestroyStructure releases it.
                    Marshal.DestroyStructure<SIGNER_FILE_INFO>(pFileInfo);
                    Marshal.FreeHGlobal(pFileInfo);
                }
                if (pIndex != IntPtr.Zero) Marshal.FreeHGlobal(pIndex);
                if (hMemStore != IntPtr.Zero) CertCloseStore(hMemStore, 0);
            }

            return result;
        }

        // -----------------------------------------------------------------
        // Helpers
        // -----------------------------------------------------------------

        // Mirrors to stdout and the debug stream so the trace is visible regardless
        // of whether a console is attached to the WPF process.
        private static void SignDiag(string message)
        {
            Console.WriteLine(message);
            System.Diagnostics.Debug.WriteLine(message);
        }

        private static string HResultToMessage(int hr)
        {
            try
            {
                // Marshal.GetExceptionForHR builds a Win32Exception-style message.
                var ex = Marshal.GetExceptionForHR(hr);
                if (ex is not null && !string.IsNullOrWhiteSpace(ex.Message))
                    return $"0x{hr:X8}: {ex.Message}";
            }
            catch
            {
                // fall through
            }
            return $"SignerSignEx2 failed with HRESULT 0x{hr:X8}";
        }

        // =================================================================
        // P/Invoke surface
        // =================================================================
        private const uint SIGNER_SUBJECT_FILE        = 0x01;
        private const uint SIGNER_CERT_STORE          = 0x02;
        private const uint SIGNER_CERT_POLICY_CHAIN   = 0x02;
        private const uint SIGNER_NO_ATTR             = 0x00;
        private const uint SIGNER_TIMESTAMP_RFC3161   = 0x02;

        // ALG_ID from wincrypt.h — SHA-256 is the only one we use.
        private const uint CALG_SHA_256 = 0x0000800c;

        // Cert store provider: "Memory" as an integer resource (MAKEINTRESOURCE)
        private const int CERT_STORE_PROV_MEMORY = 2;
        private const uint CERT_STORE_ADD_ALWAYS = 4;
        private const uint X509_ASN_ENCODING     = 0x00000001;
        private const uint PKCS_7_ASN_ENCODING   = 0x00010000;

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct SIGNER_FILE_INFO
        {
            public uint cbSize;
            [MarshalAs(UnmanagedType.LPWStr)]
            public string pwszFileName;
            public IntPtr hFile;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct SIGNER_SUBJECT_INFO
        {
            public uint cbSize;
            public IntPtr pdwIndex;           // DWORD* (must point to 0)
            public uint dwSubjectChoice;      // SIGNER_SUBJECT_FILE
            public IntPtr union1;             // SIGNER_FILE_INFO*
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct SIGNER_CERT_STORE_INFO
        {
            public uint cbSize;
            public IntPtr pSigningCert;       // PCCERT_CONTEXT
            public uint dwCertPolicy;         // SIGNER_CERT_POLICY_CHAIN
            public IntPtr hCertStore;         // HCERTSTORE
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct SIGNER_CERT
        {
            public uint cbSize;
            public uint dwCertChoice;         // SIGNER_CERT_STORE
            public IntPtr union1;             // SIGNER_CERT_STORE_INFO*
            public IntPtr hwnd;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct SIGNER_SIGNATURE_INFO
        {
            public uint cbSize;
            public uint algidHash;            // ALG_ID (CALG_SHA_256, etc.)
            public uint dwAttrChoice;         // SIGNER_NO_ATTR
            public IntPtr union1;             // SIGNER_ATTR_AUTHCODE* (NULL)
            public IntPtr psAuthenticated;    // NULL
            public IntPtr psUnauthenticated;  // NULL
        }

        [DllImport("Mssign32.dll", CharSet = CharSet.Unicode, ExactSpelling = true, SetLastError = false)]
        private static extern int SignerSignEx2(
            uint dwFlags,
            IntPtr pSubjectInfo,
            IntPtr pSignerCert,
            IntPtr pSignatureInfo,
            IntPtr pProviderInfo,
            uint dwTimestampFlags,
            [MarshalAs(UnmanagedType.LPStr)] string? pszTimestampAlgorithmOid,
            [MarshalAs(UnmanagedType.LPWStr)] string? pwszHttpTimeStamp,
            IntPtr psRequest,
            IntPtr pSipData,
            out IntPtr ppSignerContext,
            IntPtr pCryptoPolicy,
            IntPtr pReserved);

        [DllImport("Mssign32.dll", ExactSpelling = true)]
        private static extern int SignerFreeSignerContext(IntPtr pSignerContext);

        [DllImport("Crypt32.dll", CharSet = CharSet.Unicode, ExactSpelling = true, SetLastError = true)]
        private static extern IntPtr CertOpenStore(
            IntPtr lpszStoreProvider,
            uint dwMsgAndCertEncodingType,
            IntPtr hCryptProv,
            uint dwFlags,
            IntPtr pvPara);

        [DllImport("Crypt32.dll", ExactSpelling = true, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool CertAddCertificateContextToStore(
            IntPtr hCertStore,
            IntPtr pCertContext,
            uint dwAddDisposition,
            IntPtr ppStoreContext);

        [DllImport("Crypt32.dll", ExactSpelling = true, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool CertCloseStore(IntPtr hCertStore, uint dwFlags);
    }

    public class SigningResult
    {
        public string FilePath { get; set; } = "";
        public bool Success { get; set; }
        public int HResult { get; set; }
        public string ErrorMessage { get; set; } = "";
    }

    public class BatchSigningProgress
    {
        public int CurrentIndex { get; set; }
        public int TotalFiles { get; set; }
        public string CurrentFile { get; set; } = "";
        public string Phase { get; set; } = "";
        public SigningResult? LastResult { get; set; }
    }

    public class BatchSigningResult
    {
        public int TotalFiles { get; set; }
        public int SuccessCount { get; set; }
        public int FailureCount { get; set; }
        public List<SigningResult> Results { get; set; } = new();
    }
}
