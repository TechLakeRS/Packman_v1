using Endpoint_Packaging_Suite.Models;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Endpoint_Packaging_Suite.Services
{
    public class GitLabService
    {
        private readonly SettingsService _settingsService;
        private readonly UserSettingsService _userSettingsService;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ILogger<GitLabService> _logger;

        public GitLabService(
            SettingsService settingsService,
            UserSettingsService userSettingsService,
            IHttpClientFactory httpClientFactory,
            ILogger<GitLabService> logger)
        {
            _settingsService = settingsService;
            _userSettingsService = userSettingsService;
            _httpClientFactory = httpClientFactory;
            _logger = logger;
        }

        public bool IsConfigured
        {
            get
            {
                var gitlab = _settingsService.Settings.GitLab;
                return !string.IsNullOrWhiteSpace(gitlab.Url)
                    && !string.IsNullOrWhiteSpace(gitlab.PersonalAccessToken)
                    && !string.IsNullOrWhiteSpace(gitlab.ProjectId);
            }
        }

        /// <summary>
        /// Returns true if any GitLab setting has been filled in (even partially).
        /// Used to decide whether to show the commit dialog.
        /// PAT is excluded since it comes from Key Vault, not appsettings.json.
        /// </summary>
        public bool IsPartiallyConfigured
        {
            get
            {
                var gitlab = _settingsService.Settings.GitLab;
                return !string.IsNullOrWhiteSpace(gitlab.Url)
                    || !string.IsNullOrWhiteSpace(gitlab.ProjectId);
            }
        }

        /// <summary>
        /// Returns a human-readable list of missing configuration fields, or null if fully configured.
        /// PAT is loaded from Key Vault (secret: PAT-{username}), not from appsettings.json.
        /// </summary>
        public string? GetConfigurationErrors()
        {
            var gitlab = _settingsService.Settings.GitLab;
            var missing = new List<string>();

            if (string.IsNullOrWhiteSpace(gitlab.Url))
                missing.Add("Url (appsettings.json)");
            if (string.IsNullOrWhiteSpace(gitlab.ProjectId))
                missing.Add("ProjectId (appsettings.json)");
            if (string.IsNullOrWhiteSpace(gitlab.PersonalAccessToken))
            {
                var userName = Environment.UserName;
                if (userName.StartsWith("admin.", StringComparison.OrdinalIgnoreCase))
                    userName = userName.Substring(6);
                missing.Add($"PAT-{userName} (Key Vault)");
            }

            return missing.Count > 0
                ? $"Missing GitLab settings: {string.Join(", ", missing)}"
                : null;
        }

        /// <summary>
        /// Pushes the Invoke-AppDeployToolkit.ps1 script to GitLab under a subfolder named after the application.
        /// Creates a new commit with the provided message.
        /// </summary>
        public async Task<(bool success, string? error)> PushScriptToGitLabAsync(
            string applicationName,
            string packagePath,
            string commitMessage,
            IProgress<string>? progress = null)
        {
            var gitlab = _settingsService.Settings.GitLab;

            if (!IsConfigured)
            {
                _logger.LogWarning("GitLab is not configured. Skipping push.");
                return (false, "GitLab is not configured. Set Url and ProjectId in appsettings.json, and ensure your PAT is stored in Key Vault as 'PAT-{username}'.");
            }

            try
            {
                progress?.Report("Locating script files...");
                _logger.LogInformation("GitLab push started - App: {AppName}, PackagePath: {PackagePath}", applicationName, packagePath);

                // Find the PSADT script (v4: Invoke-AppDeployToolkit.ps1, v3: Deploy-Application.ps1)
                var scriptPath = FindPSADTScript(packagePath);
                _logger.LogInformation("Looking for PSADT script in: {PackagePath}", packagePath);

                if (scriptPath == null)
                {
                    var msg = $"PSADT script not found.\n\nSearched in {packagePath} for:\n  Invoke-AppDeployToolkit.ps1 (v4)\n  Deploy-Application.ps1 (v3)";
                    _logger.LogWarning(msg);
                    return (false, msg);
                }

                _logger.LogInformation("Found script: {ScriptPath}", scriptPath);
                var scriptFileName = Path.GetFileName(scriptPath);

                // Sanitize application name for use as folder name
                var folderName = SanitizeFolderName(applicationName);
                var targetFilePath = $"{folderName}/{scriptFileName}";

                progress?.Report($"Reading script: {Path.GetFileName(scriptPath)}...");
                var scriptContent = await File.ReadAllTextAsync(scriptPath).ConfigureAwait(false);
                _logger.LogInformation("Script read: {Length} chars, target: {TargetPath}", scriptContent.Length, targetFilePath);

                var branch = string.IsNullOrWhiteSpace(gitlab.Branch) ? "main" : gitlab.Branch;

                progress?.Report("Pushing to GitLab...");

                // Check if the file already exists (to decide create vs update)
                var fileExists = await FileExistsInRepoAsync(gitlab, targetFilePath, branch);
                _logger.LogInformation("File exists in repo: {Exists}, action: {Action}", fileExists, fileExists ? "update" : "create");

                var action = fileExists ? "update" : "create";
                var payload = new Dictionary<string, object>
                {
                    ["branch"] = branch,
                    ["commit_message"] = commitMessage,
                    ["actions"] = new[]
                    {
                        new Dictionary<string, string>
                        {
                            ["action"] = action,
                            ["file_path"] = targetFilePath,
                            ["content"] = scriptContent,
                            ["encoding"] = "text"
                        }
                    }
                };

                // Add author and committer info to satisfy pre-receive hook email validation
                // Per-user settings (AppData) take priority over shared appsettings.json
                var userSettings = _userSettingsService.Settings;
                var authorEmail = !string.IsNullOrWhiteSpace(userSettings.GitLabAuthorEmail)
                    ? userSettings.GitLabAuthorEmail
                    : gitlab.AuthorEmail;
                var authorName = !string.IsNullOrWhiteSpace(userSettings.GitLabAuthorName)
                    ? userSettings.GitLabAuthorName
                    : gitlab.AuthorName;

                if (!string.IsNullOrWhiteSpace(authorEmail))
                {
                    payload["author_email"] = authorEmail;
                    payload["committer_email"] = authorEmail;
                    _logger.LogInformation("Using author/committer email: {Email}", authorEmail);
                }
                if (!string.IsNullOrWhiteSpace(authorName))
                {
                    payload["author_name"] = authorName;
                    payload["committer_name"] = authorName;
                }

                var client = CreateHttpClient(gitlab);
                var encodedProjectId = Uri.EscapeDataString(gitlab.ProjectId);
                var url = $"{gitlab.Url.TrimEnd('/')}/api/v4/projects/{encodedProjectId}/repository/commits";
                _logger.LogInformation("POST {Url}", url);

                var json = JsonSerializer.Serialize(payload);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                var response = await client.PostAsync(url, content).ConfigureAwait(false);
                _logger.LogInformation("GitLab response: {StatusCode}", response.StatusCode);

                if (response.IsSuccessStatusCode)
                {
                    _logger.LogInformation("Successfully pushed {FilePath} to GitLab ({Action})", targetFilePath, action);
                    progress?.Report("Successfully pushed to GitLab!");
                    return (true, null);
                }
                else
                {
                    var errorBody = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                    _logger.LogError("GitLab API error {StatusCode}: {Error}", response.StatusCode, errorBody);

                    // Try to extract a readable message from the JSON error response
                    var errorMessage = $"HTTP {(int)response.StatusCode} {response.StatusCode}";
                    try
                    {
                        using var doc = JsonDocument.Parse(errorBody);
                        if (doc.RootElement.TryGetProperty("message", out var msg))
                            errorMessage = msg.ToString();
                        else if (doc.RootElement.TryGetProperty("error", out var err))
                            errorMessage = err.ToString();
                    }
                    catch { /* use default errorMessage */ }

                    progress?.Report($"GitLab push failed: {errorMessage}");
                    return (false, errorMessage);
                }
            }
            catch (HttpRequestException ex)
            {
                var msg = $"Cannot connect to GitLab at {gitlab.Url}: {ex.Message}";
                _logger.LogError(ex, "Failed to connect to GitLab");
                progress?.Report(msg);
                return (false, msg);
            }
            catch (TaskCanceledException)
            {
                var msg = $"GitLab request timed out connecting to {gitlab.Url}";
                _logger.LogError("GitLab request timed out");
                progress?.Report(msg);
                return (false, msg);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to push script to GitLab");
                progress?.Report($"GitLab push error: {ex.Message}");
                return (false, ex.Message);
            }
        }

        private async Task<bool> FileExistsInRepoAsync(AppSettings.GitLabSettings gitlab, string filePath, string branch)
        {
            try
            {
                var client = CreateHttpClient(gitlab);
                var encodedProjectId = Uri.EscapeDataString(gitlab.ProjectId);
                var encodedFilePath = Uri.EscapeDataString(filePath);
                var url = $"{gitlab.Url.TrimEnd('/')}/api/v4/projects/{encodedProjectId}/repository/files/{encodedFilePath}?ref={Uri.EscapeDataString(branch)}";

                var response = await client.GetAsync(url).ConfigureAwait(false);
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }

        private HttpClient CreateHttpClient(AppSettings.GitLabSettings gitlab)
        {
            var client = _httpClientFactory.CreateClient("GitLab");
            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.Add("PRIVATE-TOKEN", gitlab.PersonalAccessToken);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.Timeout = TimeSpan.FromSeconds(30);
            return client;
        }

        /// <summary>
        /// Finds the PSADT script - supports both v4 (Invoke-AppDeployToolkit.ps1) and v3 (Deploy-Application.ps1).
        /// </summary>
        private static string? FindPSADTScript(string packagePath)
        {
            // v4: Invoke-AppDeployToolkit.ps1
            var path = Path.Combine(packagePath, "Application", "Invoke-AppDeployToolkit.ps1");
            if (File.Exists(path)) return path;

            path = Path.Combine(packagePath, "Invoke-AppDeployToolkit.ps1");
            if (File.Exists(path)) return path;

            // v3: Deploy-Application.ps1
            path = Path.Combine(packagePath, "Application", "Deploy-Application.ps1");
            if (File.Exists(path)) return path;

            path = Path.Combine(packagePath, "Deploy-Application.ps1");
            if (File.Exists(path)) return path;

            return null;
        }

        private static string SanitizeFolderName(string name)
        {
            var invalid = Path.GetInvalidFileNameChars();
            var sanitized = new string(name.Select(c => invalid.Contains(c) ? '_' : c).ToArray());
            return sanitized.Trim().TrimEnd('.');
        }

        /// <summary>
        /// Tests the GitLab connection by fetching the project info.
        /// Returns a detailed result with project name on success or error details on failure.
        /// </summary>
        public async Task<(bool success, string message)> TestConnectionAsync()
        {
            var gitlab = _settingsService.Settings.GitLab;

            var configError = GetConfigurationErrors();
            if (configError != null)
                return (false, configError);

            try
            {
                var client = CreateHttpClient(gitlab);
                var encodedProjectId = Uri.EscapeDataString(gitlab.ProjectId);
                var url = $"{gitlab.Url.TrimEnd('/')}/api/v4/projects/{encodedProjectId}";

                var response = await client.GetAsync(url).ConfigureAwait(false);
                var body = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

                if (response.IsSuccessStatusCode)
                {
                    var projectName = "";
                    var webUrl = "";
                    var defaultBranch = "";
                    try
                    {
                        using var doc = JsonDocument.Parse(body);
                        projectName = doc.RootElement.TryGetProperty("name_with_namespace", out var n) ? n.GetString() : "Unknown";
                        webUrl = doc.RootElement.TryGetProperty("web_url", out var w) ? w.GetString() : "";
                        defaultBranch = doc.RootElement.TryGetProperty("default_branch", out var b) ? b.GetString() : "main";
                    }
                    catch { }

                    var branch = string.IsNullOrWhiteSpace(gitlab.Branch) ? "main" : gitlab.Branch;
                    var branchWarning = !string.Equals(branch, defaultBranch, StringComparison.OrdinalIgnoreCase)
                        ? $"\n\nWarning: Configured branch \"{branch}\" differs from project default \"{defaultBranch}\""
                        : "";

                    return (true, $"Connection successful!\n\nProject: {projectName}\nURL: {webUrl}\nDefault branch: {defaultBranch}{branchWarning}");
                }
                else
                {
                    var errorMessage = $"HTTP {(int)response.StatusCode} {response.StatusCode}";
                    try
                    {
                        using var doc = JsonDocument.Parse(body);
                        if (doc.RootElement.TryGetProperty("message", out var msg))
                            errorMessage = msg.ToString();
                        else if (doc.RootElement.TryGetProperty("error", out var err))
                            errorMessage = err.ToString();
                    }
                    catch { }

                    if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                    {
                        var userName = Environment.UserName;
                        if (userName.StartsWith("admin.", StringComparison.OrdinalIgnoreCase))
                            userName = userName.Substring(6);
                        errorMessage += $"\n\nYour GitLab PAT is invalid or expired. Update the 'PAT-{userName}' secret in Key Vault.";
                    }
                    else if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                        errorMessage += $"\n\nProject \"{gitlab.ProjectId}\" not found. Check your ProjectId in appsettings.json.";

                    return (false, errorMessage);
                }
            }
            catch (HttpRequestException ex)
            {
                return (false, $"Cannot connect to GitLab server.\n\nURL: {gitlab.Url}\nError: {ex.Message}\n\nCheck that the Url in appsettings.json is correct (e.g. \"https://gitlab.example.com\").");
            }
            catch (TaskCanceledException)
            {
                return (false, $"Connection timed out.\n\nURL: {gitlab.Url}\n\nThe GitLab server did not respond within 30 seconds.");
            }
            catch (Exception ex)
            {
                return (false, $"Unexpected error: {ex.Message}");
            }
        }
    }
}
