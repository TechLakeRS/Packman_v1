using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Endpoint_Packaging_Suite.Models;

namespace Endpoint_Packaging_Suite.Services
{
    /// <summary>
    /// Discovers detection methods by scanning a remote machine after deployment
    /// </summary>
    public class DetectionMethodDiscoveryService
    {
        public class DiscoveryResult
        {
            public bool Success { get; set; }
            public string ErrorMessage { get; set; } = "";
            public List<DetectionRule> SuggestedRules { get; set; } = new List<DetectionRule>();
            public string AppName { get; set; } = "";
            public string AppVersion { get; set; } = "";
            public string Publisher { get; set; } = "";
            public string InstallLocation { get; set; } = "";
            public List<string> DebugMessages { get; set; } = new List<string>();
        }

        /// <summary>
        /// Discovers detection methods from a remote computer after deployment
        /// </summary>
        public async Task<DiscoveryResult> DiscoverDetectionMethodsAsync(
            string computerName,
            string appName,
            string appVersion,
            string sourceInstallerPath = "")
        {
            var result = new DiscoveryResult();

            try
            {
                // Create discovery PowerShell script
                string scriptPath = Path.Combine(
                    AppDomain.CurrentDomain.BaseDirectory,
                    "Scripts",
                    "DiscoverDetectionMethods.ps1");

                if (!File.Exists(scriptPath))
                {
                    result.ErrorMessage = $"Discovery script not found at {scriptPath}";
                    return result;
                }

                // Execute discovery script on remote machine
                Debug.WriteLine($"Executing discovery script: {scriptPath}");
                Debug.WriteLine($"Parameters: Computer={computerName}, App={appName}, Version={appVersion}, Source={sourceInstallerPath}");

                var discoveryData = await ExecuteDiscoveryScriptAsync(
                    scriptPath,
                    computerName,
                    appName,
                    appVersion,
                    sourceInstallerPath);

                if (string.IsNullOrEmpty(discoveryData))
                {
                    result.ErrorMessage = "No data received from remote machine. The discovery script may have failed or timed out.";
                    Debug.WriteLine($"Discovery returned no data for {appName} on {computerName}");
                    return result;
                }

                Debug.WriteLine($"Received discovery data:\n{discoveryData}");

                // Check if discovery returned an error
                if (discoveryData.Contains("ERROR:"))
                {
                    var errorLine = discoveryData.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                        .FirstOrDefault(l => l.Contains("ERROR:"));
                    if (errorLine != null)
                    {
                        result.ErrorMessage = errorLine.Replace("ERROR:", "").Trim();
                        Debug.WriteLine($"Discovery error: {result.ErrorMessage}");
                        return result;
                    }
                }

                // Parse the discovery data and generate detection rules
                ParseDiscoveryData(discoveryData, result);

                result.Success = result.SuggestedRules.Count > 0;
                if (!result.Success && string.IsNullOrEmpty(result.ErrorMessage))
                {
                    result.ErrorMessage = "No detection methods could be discovered";
                }
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.ErrorMessage = $"Discovery failed: {ex.Message}";
                Debug.WriteLine($"Detection discovery error: {ex}");
            }

            return result;
        }

        private async Task<string> ExecuteDiscoveryScriptAsync(
            string scriptPath,
            string computerName,
            string appName,
            string appVersion,
            string sourceInstallerPath)
        {
            return await Task.Run(() =>
            {
                try
                {
                    Debug.WriteLine($"Starting discovery for: {appName} on {computerName}");
                    Debug.WriteLine($"Using external PowerShell process");

                    // Build arguments
                    var args = $"-NoProfile -ExecutionPolicy Bypass -File \"{scriptPath}\" -ComputerName \"{computerName}\" -AppName \"{appName}\" -AppVersion \"{appVersion}\"";

                    // Add source installer path if provided
                    if (!string.IsNullOrEmpty(sourceInstallerPath) && File.Exists(sourceInstallerPath))
                    {
                        args += $" -SourceInstallerPath \"{sourceInstallerPath}\"";
                        Debug.WriteLine($"Using source installer metadata from: {sourceInstallerPath}");
                    }

                    var processInfo = new ProcessStartInfo
                    {
                        FileName = "powershell.exe",
                        Arguments = args,
                        UseShellExecute = false,
                        RedirectStandardOutput = true,
                        RedirectStandardError = true,
                        CreateNoWindow = true,
                        WorkingDirectory = Path.GetDirectoryName(scriptPath)
                    };

                    Debug.WriteLine($"PowerShell arguments: {processInfo.Arguments}");

                    using (var process = new Process { StartInfo = processInfo })
                    {
                        var outputBuilder = new StringBuilder();
                        var errorBuilder = new StringBuilder();

                        process.OutputDataReceived += (sender, e) =>
                        {
                            if (!string.IsNullOrEmpty(e.Data))
                            {
                                lock (outputBuilder)
                                {
                                    outputBuilder.AppendLine(e.Data);
                                }
                            }
                        };

                        process.ErrorDataReceived += (sender, e) =>
                        {
                            if (!string.IsNullOrEmpty(e.Data))
                            {
                                lock (errorBuilder)
                                {
                                    errorBuilder.AppendLine(e.Data);
                                }
                            }
                        };

                        process.Start();
                        process.BeginOutputReadLine();
                        process.BeginErrorReadLine();

                        // Wait up to 90 seconds for discovery
                        bool exited = process.WaitForExit(90000);

                        if (!exited)
                        {
                            Debug.WriteLine("Discovery process timed out after 90 seconds");
                            try { process.Kill(); } catch { }
                            return "";
                        }

                        // Wait for async handlers to complete
                        process.WaitForExit();

                        string output = outputBuilder.ToString();
                        string errors = errorBuilder.ToString();

                        if (!string.IsNullOrEmpty(errors))
                        {
                            Debug.WriteLine($"PowerShell errors: {errors}");
                        }

                        Debug.WriteLine($"Discovery output length: {output?.Length ?? 0} characters");
                        if (!string.IsNullOrEmpty(output))
                        {
                            Debug.WriteLine($"Discovery output preview: {output.Substring(0, Math.Min(500, output.Length))}");
                        }

                        return output;
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"Error executing discovery script: {ex.Message}");
                    Debug.WriteLine($"Stack trace: {ex.StackTrace}");
                    return "";
                }
            });
        }

        private void ParseDiscoveryData(string data, DiscoveryResult result)
        {
            var lines = data.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);

            foreach (var line in lines)
            {
                var trimmed = line.Trim();

                // Capture DEBUG lines for troubleshooting
                if (trimmed.StartsWith("DEBUG:"))
                {
                    var debugMsg = trimmed.Substring("DEBUG:".Length).Trim();
                    result.DebugMessages.Add(debugMsg);
                    Debug.WriteLine($"Discovery: {debugMsg}");
                    continue;
                }

                // Parse MSI Product Code
                if (trimmed.StartsWith("MSI_PRODUCTCODE:"))
                {
                    var productCode = trimmed.Substring("MSI_PRODUCTCODE:".Length).Trim();
                    if (!string.IsNullOrEmpty(productCode))
                    {
                        result.SuggestedRules.Add(new DetectionRule
                        {
                            Type = DetectionRuleType.MSI,
                            Path = productCode,
                            FileOrFolderName = "",
                            CheckVersion = false
                        });
                    }
                }
                // Parse Registry Key
                else if (trimmed.StartsWith("REGISTRY_KEY:"))
                {
                    var regKey = trimmed.Substring("REGISTRY_KEY:".Length).Trim();
                    if (!string.IsNullOrEmpty(regKey))
                    {
                        result.SuggestedRules.Add(new DetectionRule
                        {
                            Type = DetectionRuleType.Registry,
                            Path = regKey,
                            FileOrFolderName = "",
                            CheckVersion = false
                        });
                    }
                }
                // Parse Registry Value
                else if (trimmed.StartsWith("REGISTRY_VALUE:"))
                {
                    var parts = trimmed.Substring("REGISTRY_VALUE:".Length).Trim().Split('|');
                    if (parts.Length == 2)
                    {
                        result.SuggestedRules.Add(new DetectionRule
                        {
                            Type = DetectionRuleType.Registry,
                            Path = parts[0].Trim(),
                            FileOrFolderName = parts[1].Trim(),
                            CheckVersion = false
                        });
                    }
                }
                // Parse File Detection
                else if (trimmed.StartsWith("FILE_PATH:"))
                {
                    var filePath = trimmed.Substring("FILE_PATH:".Length).Trim();
                    if (!string.IsNullOrEmpty(filePath))
                    {
                        var directory = Path.GetDirectoryName(filePath) ?? "";
                        var fileName = Path.GetFileName(filePath);

                        result.SuggestedRules.Add(new DetectionRule
                        {
                            Type = DetectionRuleType.File,
                            Path = directory,
                            FileOrFolderName = fileName,
                            CheckVersion = false
                        });
                    }
                }
                // Parse File with Version
                else if (trimmed.StartsWith("FILE_WITH_VERSION:"))
                {
                    var parts = trimmed.Substring("FILE_WITH_VERSION:".Length).Trim().Split('|');
                    if (parts.Length >= 1)
                    {
                        var filePath = parts[0].Trim();
                        var directory = Path.GetDirectoryName(filePath) ?? "";
                        var fileName = Path.GetFileName(filePath);

                        result.SuggestedRules.Add(new DetectionRule
                        {
                            Type = DetectionRuleType.File,
                            Path = directory,
                            FileOrFolderName = fileName,
                            CheckVersion = true,
                            Operator = "greaterThanOrEqual"
                        });
                    }
                }
                // Parse App Metadata
                else if (trimmed.StartsWith("APP_NAME:"))
                {
                    result.AppName = trimmed.Substring("APP_NAME:".Length).Trim();
                }
                else if (trimmed.StartsWith("APP_VERSION:"))
                {
                    result.AppVersion = trimmed.Substring("APP_VERSION:".Length).Trim();
                }
                else if (trimmed.StartsWith("PUBLISHER:"))
                {
                    result.Publisher = trimmed.Substring("PUBLISHER:".Length).Trim();
                }
                else if (trimmed.StartsWith("INSTALL_LOCATION:"))
                {
                    result.InstallLocation = trimmed.Substring("INSTALL_LOCATION:".Length).Trim();
                }
            }

            // Deduplicate rules (prioritize MSI, then Registry, then File)
            result.SuggestedRules = result.SuggestedRules
                .GroupBy(r => r.Title)
                .Select(g => g.First())
                .OrderBy(r => r.Type == DetectionRuleType.MSI ? 0 :
                             r.Type == DetectionRuleType.Registry ? 1 : 2)
                .ToList();
        }
    }
}