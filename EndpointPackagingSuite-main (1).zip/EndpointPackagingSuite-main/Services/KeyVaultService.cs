// Services/KeyVaultService.cs
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Threading.Tasks;
using Azure.Identity;
using Azure.Security.KeyVault.Certificates;
using Azure.Security.KeyVault.Secrets;
using Microsoft.Extensions.Caching.Memory;
using Azure.Identity.Broker;
using Serilog;

namespace Endpoint_Packaging_Suite.Services
{
    // Retrieves secrets and certificates from Azure Key Vault. Uses WAM broker auth
    // so there's no local HTTP listener. Secrets are cached in memory only.
    public class KeyVaultService : IDisposable
    {
        private readonly string _keyVaultName;
        private readonly SecretClient _secretClient;
        private readonly CertificateClient _certificateClient;
        private readonly InteractiveBrowserCredential _credential;
        private readonly string? _tenantId;
        private readonly IMemoryCache _cache;
        private readonly ILogger _logger;
        private readonly TimeSpan _cacheDuration;
        // Certificates loaded at startup and kept in memory for the session.
        // The X509Certificate2 owns its underlying CNG key container; disposing
        // it at app shutdown releases the temporary container too.
        private X509Certificate2? _codeSigningCertificate;
        private X509Certificate2? _appRegistrationCertificate;
        private bool _disposed = false;

        public KeyVaultService(string keyVaultName, string? tenantId = null, IMemoryCache? cache = null, ILogger? logger = null, int cacheDurationHours = 24)
        {
            _keyVaultName = keyVaultName;
            _tenantId = tenantId;
            _cache = cache ?? new MemoryCache(new MemoryCacheOptions());
            _logger = logger ?? Log.Logger;
            _cacheDuration = TimeSpan.FromHours(cacheDurationHours);

            _logger.Information("KeyVault: Service starting");
            Debug.WriteLine($"🔐 KeyVault: In-memory cache duration set to {cacheDurationHours} hours");

            [System.Runtime.InteropServices.DllImport("user32.dll")]
            static extern IntPtr GetForegroundWindow();

            var windowHandle = System.Diagnostics.Process.GetCurrentProcess().MainWindowHandle;
            if (windowHandle == IntPtr.Zero)
                windowHandle = GetForegroundWindow();

            var options = new InteractiveBrowserCredentialBrokerOptions(windowHandle)
            {
                RedirectUri = new Uri("http://127.0.0.1"),
                DisableInstanceDiscovery = false,
                UseDefaultBrokerAccount = true,
            };

            // Deliberately NOT setting options.TokenCachePersistenceOptions.
            //
            // The previous configuration persisted the MSAL token cache to
            // %LOCALAPPDATA%\.IdentityService\Endpoint_Packaging_Suite.KeyVault and used
            // UnsafeAllowUnencryptedStorage = true as a fallback when DPAPI is unavailable.
            // The cache holds Azure AD refresh tokens (default 90-day lifetime) — anyone
            // who reads it can silently mint Graph and Key Vault tokens, including pulling
            // the code-signing certificate, with the user's full permission set and no
            // audit trail. The "unsafe" fallback would have written that file as plaintext
            // if DPAPI ever failed.
            //
            // We don't need a persistent MSAL cache at all: WAM (UseDefaultBrokerAccount
            // above) already manages the user's Azure AD session at the OS level and
            // mints tokens silently against the existing Windows logon. On process
            // restart the in-memory MSAL cache is empty, MSAL asks the broker, the
            // broker returns a token without UI. The on-disk MSAL cache duplicated state
            // the broker already owned, so removing it is pure subtraction: zero on-disk
            // token artifact, identical UX in the happy path.
            //
            // Failure mode: if WAM cannot silently obtain a token (broker disabled,
            // account removed from the device, conditional access requires fresh MFA),
            // the user will see an interactive sign-in flow — the same prompt they get
            // on first launch today. No regression for cold start, no plaintext on disk
            // for warm start.

            if (!string.IsNullOrWhiteSpace(tenantId))
            {
                options.TenantId = tenantId;
                Debug.WriteLine($"🔐 KeyVault: Using Tenant ID {tenantId.Substring(0, Math.Min(8, tenantId.Length))}...");
            }
            else
            {
                Debug.WriteLine("🔐 KeyVault: No Tenant ID provided - using multi-tenant authentication");
            }

            _credential = new InteractiveBrowserCredential(options);

            Debug.WriteLine("🔐 KeyVault: InteractiveBrowserCredential created");
            Debug.WriteLine($"🔐 KeyVault: RedirectUri: {options.RedirectUri}");
            Debug.WriteLine($"🔐 KeyVault: TenantId: {options.TenantId ?? "(not set)"}");

            var keyVaultUri = new Uri($"https://{keyVaultName}.vault.azure.net/");
            _secretClient = new SecretClient(keyVaultUri, _credential);
            _certificateClient = new CertificateClient(keyVaultUri, _credential);

            _logger.Information("KeyVault: Service initialized");
            Debug.WriteLine($"🔐 KeyVault service initialized for: {_keyVaultName}");
        }

        public async Task<Dictionary<string, string>> GetSecretsAsync(params string[] secretNames)
        {
            var cacheKey = $"kv_secrets_{string.Join("_", secretNames)}";
            if (_cache.TryGetValue<Dictionary<string, string>>(cacheKey, out var cachedSecrets))
            {
                Debug.WriteLine($"🔐 KeyVault: ✓ Retrieved {cachedSecrets.Count} secret(s) from in-memory cache");
                return cachedSecrets;
            }

            using var cts = new CancellationTokenSource(TimeSpan.FromMinutes(3));

            try
            {
                _logger.Information("KeyVault: Retrieving secrets");
                Debug.WriteLine($"🔐 KeyVault: Retrieving secrets from {_keyVaultName}");
                Debug.WriteLine($"🔐 KeyVault: Requested secrets: {string.Join(", ", secretNames)}");

                var secrets = new Dictionary<string, string>();

                if (!string.IsNullOrWhiteSpace(_tenantId))
                {
                    secrets["TenantId"] = _tenantId;
                    Debug.WriteLine("🔐 KeyVault: Using TenantId from configuration");
                }
                else
                {
                    Debug.WriteLine("🔐 KeyVault: Attempting to authenticate...");

                    var authStartTime = DateTime.UtcNow;
                    var tenantId = await GetTenantIdAsync(cts.Token);
                    var authDuration = DateTime.UtcNow - authStartTime;

                    if (authDuration.TotalSeconds < 2)
                    {
                        Debug.WriteLine($"🔐 KeyVault: ✓ Used cached tokens! (took {authDuration.TotalSeconds:F2}s)");
                    }
                    else
                    {
                        _logger.Information("KeyVault: Interactive authentication required");
                        Debug.WriteLine($"🔐 KeyVault: ⚠ Interactive authentication required (took {authDuration.TotalSeconds:F2}s)");
                    }

                    if (!string.IsNullOrEmpty(tenantId))
                    {
                        secrets["TenantId"] = tenantId;
                        Debug.WriteLine("🔐 KeyVault: Successfully authenticated");
                    }
                }

                foreach (var secretName in secretNames)
                {
                    if (secretName.Equals("TenantId", StringComparison.OrdinalIgnoreCase))
                        continue;

                    try
                    {
                        Debug.WriteLine($"🔐 KeyVault: Retrieving secret: {secretName}");

                        var secretStartTime = DateTime.UtcNow;
                        KeyVaultSecret secret = await _secretClient.GetSecretAsync(secretName, cancellationToken: cts.Token);
                        var secretDuration = DateTime.UtcNow - secretStartTime;

                        if (secret != null && !string.IsNullOrEmpty(secret.Value))
                        {
                            secrets[secretName] = secret.Value;
                            Debug.WriteLine($"🔐 KeyVault: Retrieved {secretName} (took {secretDuration.TotalSeconds:F2}s)");
                        }
                        else
                        {
                            secrets[secretName] = "";
                            Debug.WriteLine($"🔐 KeyVault: ⚠ Secret '{secretName}' is empty");
                        }
                    }
                    catch (OperationCanceledException)
                    {
                        _logger.Error("KeyVault: Timeout while retrieving a secret");
                        throw;
                    }
                    catch (Exception ex)
                    {
                        _logger.Warning("KeyVault: Failed to retrieve a secret");
                        Debug.WriteLine($"🔐 KeyVault: ⚠ Failed to retrieve {secretName}: {ex.Message}");
                        secrets[secretName] = "";
                    }
                }

                if (secrets.Count == 0)
                    throw new Exception("No secrets were retrieved from Key Vault");

                _logger.Information("KeyVault: Retrieved {Count} secret(s)", secrets.Count);
                Debug.WriteLine($"🔐 KeyVault: Successfully retrieved {secrets.Count} secret(s) from Key Vault");

                var cacheEntryOptions = new MemoryCacheEntryOptions()
                    .SetAbsoluteExpiration(_cacheDuration)
                    .SetSize(1);
                _cache.Set(cacheKey, secrets, cacheEntryOptions);

                return secrets;
            }
            catch (OperationCanceledException)
            {
                _logger.Error("KeyVault: Authentication timed out");
                Debug.WriteLine("🔐 KeyVault: ❌ Authentication timed out after 3 minutes");
                throw new Exception("Azure Key Vault authentication timed out. Please complete sign-in within 3 minutes or check network/firewall.");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "KeyVault: Failed to retrieve secrets");
                Debug.WriteLine($"🔐 KeyVault: ❌ Failed to retrieve secrets: {ex.Message}");
                throw new Exception($"Failed to retrieve secrets from Azure Key Vault: {ex.Message}", ex);
            }
        }

        public async Task<string> GetSecretAsync(string secretName)
        {
            var secrets = await GetSecretsAsync(secretName);

            if (secrets.TryGetValue(secretName, out var secretValue))
            {
                return secretValue;
            }

            throw new Exception($"Secret '{secretName}' not found in Key Vault response");
        }

        public async Task<bool> TestConnectionAsync(string testSecretName = "TenantId")
        {
            try
            {
                await GetSecretAsync(testSecretName);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task LoadCertificateAsync(string certificateName)
        {
            if (_codeSigningCertificate != null)
            {
                Debug.WriteLine("🔐 KeyVault: Code-signing certificate already loaded in session");
                return;
            }

            _codeSigningCertificate = await LoadCertificateFromKeyVaultAsync(certificateName);
        }

        public async Task LoadAppRegistrationCertificateAsync(string certificateName)
        {
            if (_appRegistrationCertificate != null)
            {
                Debug.WriteLine("🔐 KeyVault: App-registration certificate already loaded in session");
                return;
            }

            _appRegistrationCertificate = await LoadCertificateFromKeyVaultAsync(certificateName);
        }

        public X509Certificate2? GetCertificate()
        {
            if (_codeSigningCertificate == null)
            {
                _logger.Warning("KeyVault: Code-signing certificate not loaded. Call LoadCertificateAsync() first.");
                Debug.WriteLine("🔐 KeyVault: ⚠ Code-signing certificate not loaded. Call LoadCertificateAsync() first.");
            }

            return _codeSigningCertificate;
        }

        public X509Certificate2? GetAppRegistrationCertificate()
        {
            if (_appRegistrationCertificate == null)
            {
                _logger.Warning("KeyVault: App-registration certificate not loaded. Call LoadAppRegistrationCertificateAsync() first.");
                Debug.WriteLine("🔐 KeyVault: ⚠ App-registration certificate not loaded. Call LoadAppRegistrationCertificateAsync() first.");
            }

            return _appRegistrationCertificate;
        }

        private async Task<X509Certificate2> LoadCertificateFromKeyVaultAsync(string certificateName)
        {
            _logger.Information("KeyVault: Loading certificate");
            Debug.WriteLine($"🔐 KeyVault: Loading certificate '{certificateName}' from {_keyVaultName}");

            using var cts = new CancellationTokenSource(TimeSpan.FromMinutes(3));

            try
            {
                Debug.WriteLine($"🔐 KeyVault: Using Secret API to get PFX bytes (not Certificate API)");

                var startTime = DateTime.UtcNow;

                // Key Vault stores uploaded certificates in both /certificates (non-exportable CNG)
                // and /secrets (raw PFX bytes). We pull via /secrets because /certificates returns
                // a cert whose private key handle Wintrust APIs cannot acquire.
                var secret = await _secretClient.GetSecretAsync(certificateName, cancellationToken: cts.Token);

                if (secret == null || string.IsNullOrEmpty(secret.Value.Value))
                    throw new Exception("Certificate secret not found or empty in Key Vault");

                var pfxBytes = Convert.FromBase64String(secret.Value.Value);
                SignDiag($"[SIGN] KeyVault PFX decoded for '{certificateName}': {pfxBytes.Length} bytes");

                // Default flags: temporary CNG container, cleaned up on Dispose.
                // EphemeralKeySet does not work end-to-end with SignerSignEx2.
                var certificate = new X509Certificate2(pfxBytes, "");

                var duration = DateTime.UtcNow - startTime;

                SignDiag(
                    $"[SIGN] KeyVault cert imported — Subject={certificate.Subject}, " +
                    $"Thumbprint={certificate.Thumbprint}, HasPrivateKey={certificate.HasPrivateKey}, " +
                    $"SigAlg={certificate.SignatureAlgorithm?.FriendlyName ?? "(null)"}, " +
                    $"Handle=0x{certificate.Handle.ToInt64():X}");

                if (!certificate.HasPrivateKey)
                    throw new Exception("Certificate does not have a private key");

                _logger.Information("KeyVault: Certificate '{Name}' loaded (took {Seconds}s)", certificateName, (int)duration.TotalSeconds);

                Debug.WriteLine($"🔐 KeyVault: ✓ Loaded certificate '{certificateName}' from Key Vault (took {duration.TotalSeconds:F2}s)");
                Debug.WriteLine($"🔐 KeyVault: Subject: {certificate.Subject}");
                Debug.WriteLine($"🔐 KeyVault: Thumbprint: {certificate.Thumbprint}");
                Debug.WriteLine($"🔐 KeyVault: Has Private Key: {certificate.HasPrivateKey}");
                Debug.WriteLine($"🔐 KeyVault: Certificate will be kept in memory for session lifetime");

                return certificate;
            }
            catch (OperationCanceledException)
            {
                _logger.Error("KeyVault: Certificate loading timed out");
                Debug.WriteLine("🔐 KeyVault: ❌ Certificate loading timed out");
                throw new Exception("Azure Key Vault certificate loading timed out.");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "KeyVault: Failed to load certificate");
                Debug.WriteLine($"🔐 KeyVault: ❌ Failed to load certificate: {ex.Message}");
                throw new Exception($"Failed to load certificate from Azure Key Vault: {ex.Message}", ex);
            }
        }

        // Mirrors to stdout and the debug stream so the trace is visible regardless
        // of whether a console is attached to the WPF process.
        private static void SignDiag(string message)
        {
            Console.WriteLine(message);
            Debug.WriteLine(message);
        }

        private async Task<string> GetTenantIdAsync(CancellationToken cancellationToken = default)
        {
            try
            {
                var tokenRequestContext = new Azure.Core.TokenRequestContext(
                    new[] { "https://vault.azure.net/.default" });

                var token = await _credential.GetTokenAsync(tokenRequestContext, cancellationToken);

                // JWT format: header.payload.signature — parse payload to get tid
                var tokenParts = System.Text.Encoding.UTF8.GetString(
                    Convert.FromBase64String(PadBase64(token.Token.Split('.')[1])));

                var tokenJson = JsonDocument.Parse(tokenParts);

                if (tokenJson.RootElement.TryGetProperty("tid", out var tidElement))
                {
                    var tenantId = tidElement.GetString() ?? "";
                    Debug.WriteLine($"🔐 KeyVault: Extracted TenantId from token: {tenantId.Substring(0, Math.Min(8, tenantId.Length))}...");
                    return tenantId;
                }

                _logger.Warning("KeyVault: TenantId not found in token");
                return "";
            }
            catch (OperationCanceledException)
            {
                _logger.Error("KeyVault: Authentication cancelled or timed out");
                throw;
            }
            catch (Exception ex)
            {
                _logger.Warning(ex, "KeyVault: Could not extract TenantId from token");
                return "";
            }
        }

        private string PadBase64(string base64)
        {
            var padding = (4 - base64.Length % 4) % 4;
            return base64 + new string('=', padding);
        }

        public void ClearCache()
        {
            if (_cache is MemoryCache memCache)
            {
                memCache.Compact(1.0);
                _logger.Information("KeyVault: In-memory cache cleared");
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (_disposed) return;

            if (disposing)
            {
                if (_codeSigningCertificate != null)
                {
                    _codeSigningCertificate.Dispose();
                    _codeSigningCertificate = null;
                    _logger.Information("KeyVault: Code-signing certificate disposed");
                    Debug.WriteLine("🔐 KeyVault: Code-signing certificate disposed");
                }

                if (_appRegistrationCertificate != null)
                {
                    _appRegistrationCertificate.Dispose();
                    _appRegistrationCertificate = null;
                    _logger.Information("KeyVault: App-registration certificate disposed");
                    Debug.WriteLine("🔐 KeyVault: App-registration certificate disposed");
                }
            }

            _disposed = true;
        }
    }
}