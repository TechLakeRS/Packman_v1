﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Security.Cryptography.Pkcs;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace Endpoint_Packaging_Suite.Services
{
    /// <summary>
    /// Native catalog file verification service using Windows Cryptography API
    /// Similar to PowerShell's Authenticode implementation
    /// </summary>
    public class CatalogVerificationService
    {
        #region P/Invoke Declarations for Wintrust API

        [DllImport("wintrust.dll", ExactSpelling = true, SetLastError = false, CharSet = CharSet.Unicode)]
        private static extern uint WinVerifyTrust(
            nint hwnd,
            [MarshalAs(UnmanagedType.LPStruct)] Guid pgActionID,
            nint pWVTData
        );

        [DllImport("wintrust.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern nint CryptCATOpen(
            string pwszFileName,
            uint fdwOpenFlags,
            nint hProv,
            uint dwPublicVersion,
            uint dwEncodingType
        );

        [DllImport("wintrust.dll", SetLastError = true)]
        private static extern bool CryptCATClose(nint hCatalog);

        [DllImport("wintrust.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern nint CryptCATEnumerateMember(
            nint hCatalog,
            nint pPrevMember
        );

        [DllImport("wintrust.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern nint CryptCATCDFEnumMembersByCDFTagEx(
            nint hCatalog,
            string pwszPrevCDFTag,
            nint pfnParsError,
            ref CRYPTCATMEMBER pPrevMember,
            bool fContinueOnError,
            nint pvReserved
        );

        [DllImport("wintrust.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern nint CryptCATEnumerateAttr(
            nint hCatalog,
            nint pCatMember,
            nint pPrevAttr
        );

        [StructLayout(LayoutKind.Sequential)]
        private struct CRYPTCATMEMBER
        {
            public uint cbStruct;
            public nint pwszReferenceTag;
            public nint pwszFileName;
            public Guid gSubjectType;
            public uint fdwMemberFlags;
            public nint pIndirectData;
            public uint dwCertVersion;
            public uint dwReserved;
            public nint hReserved;
            public CRYPTOAPI_BLOB sEncodedIndirectData;
            public CRYPTOAPI_BLOB sEncodedMemberInfo;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct CRYPTCATATTRIBUTE
        {
            public uint cbStruct;
            public nint pwszReferenceTag;
            public uint dwAttrTypeAndAction;
            public uint cbValue;
            public nint pbValue;
            public uint dwReserved;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct CRYPTOAPI_BLOB
        {
            public uint cbData;
            public nint pbData;
        }

        private const uint INVALID_HANDLE_VALUE = 0xFFFFFFFF;
        private const int ERROR_NOT_FOUND = 1168;

        #endregion

        /// <summary>
        /// Verifies a catalog file's digital signature and extracts its contents
        /// </summary>
        public CatalogVerificationResult VerifyCatalog(string catalogPath)
        {
            var result = new CatalogVerificationResult
            {
                CatalogPath = catalogPath
            };

            try
            {
                if (!File.Exists(catalogPath))
                {
                    result.IsValid = false;
                    result.ErrorMessage = "Catalog file not found";
                    return result;
                }

                // Verify the catalog signature using PKCS7
                VerifySignature(catalogPath, result);

                // Extract catalog contents
                ExtractCatalogContents(catalogPath, result);

                // Overall validity
                result.IsValid = result.SignatureStatus == SignatureStatus.Valid;
            }
            catch (Exception ex)
            {
                result.IsValid = false;
                result.ErrorMessage = $"Verification failed: {ex.Message}";
            }

            return result;
        }

        /// <summary>
        /// Verifies the digital signature on the catalog file using PKCS#7
        /// </summary>
        private void VerifySignature(string catalogPath, CatalogVerificationResult result)
        {
            try
            {
                // Read the catalog file as a PKCS#7 signed message
                var catalogBytes = File.ReadAllBytes(catalogPath);

                // Parse as SignedCms
                var signedCms = new SignedCms();
                signedCms.Decode(catalogBytes);

                // Check if there are any signers
                if (signedCms.SignerInfos.Count == 0)
                {
                    result.SignatureStatus = SignatureStatus.NotSigned;
                    result.ErrorMessage = "Catalog is not signed";
                    return;
                }

                var signerInfo = signedCms.SignerInfos[0];

                // Extract signer information
                result.SignerCertificate = signerInfo.Certificate;

                if (signerInfo.Certificate != null)
                {
                    result.SignerSubject = signerInfo.Certificate.Subject;
                    result.SignerIssuer = signerInfo.Certificate.Issuer;
                    result.SignerThumbprint = signerInfo.Certificate.Thumbprint;
                    result.SignerNotBefore = signerInfo.Certificate.NotBefore;
                    result.SignerNotAfter = signerInfo.Certificate.NotAfter;
                }

                // Extract timestamp information from signed attributes
                foreach (var signedAttr in signerInfo.SignedAttributes)
                {
                    if (signedAttr.Oid.Value == "1.2.840.113549.1.9.5") // Signing time OID
                    {
                        try
                        {
                            foreach (var value in signedAttr.Values)
                            {
                                if (value is Pkcs9SigningTime signingTime)
                                {
                                    result.TimestampTime = signingTime.SigningTime;
                                    break;
                                }
                            }
                        }
                        catch
                        {
                            // Timestamp extraction failed, continue without it
                        }
                    }
                }

                // Verify the signature
                try
                {
                    signedCms.CheckSignature(true); // Verify with certificate chain validation
                    result.SignatureStatus = SignatureStatus.Valid;
                    result.ErrorMessage = "Signature is valid";
                }
                catch (CryptographicException cryptoEx)
                {
                    // Signature verification failed
                    result.SignatureStatus = SignatureStatus.Invalid;
                    result.ErrorMessage = $"Invalid signature: {cryptoEx.Message}";
                }
            }
            catch (CryptographicException cryptoEx)
            {
                // Not a valid PKCS#7 file or unsigned
                result.SignatureStatus = SignatureStatus.NotSigned;
                result.ErrorMessage = $"Not a signed catalog: {cryptoEx.Message}";
            }
            catch (Exception ex)
            {
                result.SignatureStatus = SignatureStatus.Unknown;
                result.ErrorMessage = $"Signature verification error: {ex.Message}";
            }
        }

        /// <summary>
        /// Extracts file entries from the catalog using Wintrust API
        /// </summary>
        private void ExtractCatalogContents(string catalogPath, CatalogVerificationResult result)
        {
            nint hCatalog = nint.Zero;

            try
            {
                // Open the catalog file
                hCatalog = CryptCATOpen(catalogPath, 0, nint.Zero, 0, 0);

                if (hCatalog == nint.Zero || hCatalog.ToInt64() == -1)
                {
                    var error = Marshal.GetLastWin32Error();
                    result.ErrorMessage += $" | Failed to open catalog (Error: {error})";
                    return;
                }

                // Enumerate members (files) in the catalog
                nint pMember = nint.Zero;
                int memberCount = 0;

                while (true)
                {
                    pMember = CryptCATEnumerateMember(hCatalog, pMember);

                    if (pMember == nint.Zero)
                    {
                        var error = Marshal.GetLastWin32Error();
                        if (error == ERROR_NOT_FOUND)
                        {
                            // No more members
                            break;
                        }
                        else
                        {
                            // Error occurred
                            break;
                        }
                    }

                    try
                    {
                        // Marshal the member structure
                        var member = Marshal.PtrToStructure<CRYPTCATMEMBER>(pMember);

                        // Extract file reference tag (hash or identifier)
                        string referenceTag = string.Empty;
                        if (member.pwszReferenceTag != nint.Zero)
                        {
                            referenceTag = Marshal.PtrToStringUni(member.pwszReferenceTag) ?? string.Empty;
                        }

                        // Extract filename - try multiple sources
                        string fileName = string.Empty;

                        // First, try pwszFileName
                        if (member.pwszFileName != nint.Zero)
                        {
                            fileName = Marshal.PtrToStringUni(member.pwszFileName) ?? string.Empty;
                        }

                        // If no filename, try to extract from catalog attributes
                        if (string.IsNullOrEmpty(fileName))
                        {
                            fileName = ExtractFilePathFromAttributes(hCatalog, pMember);
                        }

                        // In Windows catalog files:
                        // - ReferenceTag IS the file content hash (SHA1=40 chars, SHA256=64 chars)
                        // - EncodedIndirectData contains SIP verification data (not a separate hash)
                        // So we use the referenceTag as the hash value to display

                        string displayName;
                        string displayHash = referenceTag; // The reference tag IS the file hash

                        if (!string.IsNullOrEmpty(fileName))
                        {
                            // We have an actual filename - use it
                            displayName = fileName;
                        }
                        else if (!string.IsNullOrEmpty(referenceTag))
                        {
                            // Create a friendly identifier based on entry number and hash type
                            string hashType = referenceTag.Length == 40 ? "SHA1" :
                                            referenceTag.Length == 64 ? "SHA256" : "HASH";
                            displayName = $"File {memberCount + 1} ({hashType})";
                        }
                        else
                        {
                            // No filename or reference tag
                            displayName = $"File {memberCount + 1}";
                            displayHash = string.Empty;
                        }

                        result.CatalogEntries.Add(new CatalogEntry
                        {
                            FileName = displayName,
                            Hash = displayHash,
                            ReferenceTag = referenceTag
                        });

                        memberCount++;
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"Failed to parse member {memberCount + 1}: {ex.Message}");
                        // Failed to parse member, continue
                    }
                }

                result.FileCount = memberCount;
            }
            catch (Exception ex)
            {
                result.ErrorMessage += $" | Catalog enumeration error: {ex.Message}";
            }
            finally
            {
                // Close the catalog
                if (hCatalog != nint.Zero && hCatalog.ToInt64() != -1)
                {
                    CryptCATClose(hCatalog);
                }
            }
        }

        /// <summary>
        /// Extracts the file path from catalog member attributes
        /// </summary>
        private string ExtractFilePathFromAttributes(nint hCatalog, nint pMember)
        {
            try
            {
                nint pAttr = nint.Zero;

                // Enumerate through all attributes of this member
                while (true)
                {
                    pAttr = CryptCATEnumerateAttr(hCatalog, pMember, pAttr);

                    if (pAttr == nint.Zero)
                    {
                        // No more attributes
                        break;
                    }

                    try
                    {
                        var attr = Marshal.PtrToStructure<CRYPTCATATTRIBUTE>(pAttr);

                        // Get the attribute name (reference tag)
                        string attrName = string.Empty;
                        if (attr.pwszReferenceTag != nint.Zero)
                        {
                            attrName = Marshal.PtrToStringUni(attr.pwszReferenceTag) ?? string.Empty;
                        }

                        // Look for FilePath attribute
                        if (attrName.Equals("FilePath", StringComparison.OrdinalIgnoreCase))
                        {
                            // Extract the value
                            if (attr.pbValue != nint.Zero && attr.cbValue > 0)
                            {
                                // The value might be a Unicode string
                                try
                                {
                                    string filePath = Marshal.PtrToStringUni(attr.pbValue);
                                    if (!string.IsNullOrEmpty(filePath))
                                    {
                                        return filePath;
                                    }
                                }
                                catch
                                {
                                    // Try as UTF-8 or byte array
                                    try
                                    {
                                        byte[] bytes = new byte[attr.cbValue];
                                        Marshal.Copy(attr.pbValue, bytes, 0, (int)attr.cbValue);

                                        // Try Unicode
                                        string filePath = Encoding.Unicode.GetString(bytes).TrimEnd('\0');
                                        if (!string.IsNullOrEmpty(filePath))
                                        {
                                            return filePath;
                                        }
                                    }
                                    catch
                                    {
                                        // Unable to decode
                                    }
                                }
                            }
                        }
                    }
                    catch
                    {
                        // Failed to parse attribute, continue to next
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error extracting file path from attributes: {ex.Message}");
            }

            return string.Empty;
        }

        /// <summary>
        /// Extracts the hash value from a catalog member by parsing ASN.1 encoded data
        /// </summary>
        private string ExtractHashFromMember(CRYPTCATMEMBER member)
        {
            try
            {
                if (member.sEncodedIndirectData.cbData == 0 || member.sEncodedIndirectData.pbData == nint.Zero)
                {
                    return string.Empty;
                }

                // Read the encoded data (ASN.1/DER format)
                byte[] encodedData = new byte[member.sEncodedIndirectData.cbData];
                Marshal.Copy(member.sEncodedIndirectData.pbData, encodedData, 0, (int)member.sEncodedIndirectData.cbData);

                // The encoded indirect data contains a SIP_INDIRECT_DATA structure in ASN.1/DER format
                // We need to find the OCTET STRING that contains the hash
                // Common hash sizes: SHA1=20, SHA256=32, SHA384=48, SHA512=64

                // Search for OCTET STRING tag (0x04) followed by length and hash bytes
                for (int i = 0; i < encodedData.Length - 2; i++)
                {
                    if (encodedData[i] == 0x04) // OCTET STRING tag
                    {
                        int hashLength = encodedData[i + 1];

                        // Check for valid hash lengths
                        if ((hashLength == 20 || hashLength == 32 || hashLength == 48 || hashLength == 64) &&
                            i + 2 + hashLength <= encodedData.Length)
                        {
                            byte[] hash = new byte[hashLength];
                            Array.Copy(encodedData, i + 2, hash, 0, hashLength);
                            return BitConverter.ToString(hash).Replace("-", "");
                        }
                    }
                }

                // Fallback: If ASN.1 parsing fails, try to extract common hash from end
                if (encodedData.Length >= 32)
                {
                    // Look for SHA256 pattern
                    var hash = encodedData.Skip(encodedData.Length - 32).Take(32).ToArray();
                    // Verify it's not all zeros or all FFs (likely not a valid hash)
                    if (hash.Any(b => b != 0) && hash.Any(b => b != 0xFF))
                    {
                        return BitConverter.ToString(hash).Replace("-", "");
                    }
                }
            }
            catch
            {
                // Hash extraction failed
            }

            return string.Empty;
        }

        /// <summary>
        /// Verifies a file against a catalog entry
        /// </summary>
        public bool VerifyFileAgainstCatalog(string filePath, CatalogEntry catalogEntry, HashAlgorithmName hashAlgorithm = default)
        {
            try
            {
                if (!File.Exists(filePath))
                {
                    return false;
                }

                // Use SHA256 by default
                if (hashAlgorithm == default)
                {
                    hashAlgorithm = HashAlgorithmName.SHA256;
                }

                // Compute file hash
                using var stream = File.OpenRead(filePath);
                using HashAlgorithm hashAlg = hashAlgorithm.Name switch
                {
                    "SHA256" => SHA256.Create(),
                    "SHA1" => SHA1.Create(),
                    _ => SHA256.Create()
                };

                var fileHash = hashAlg.ComputeHash(stream);
                var fileHashString = BitConverter.ToString(fileHash).Replace("-", "");

                // Compare with catalog hash
                return string.Equals(fileHashString, catalogEntry.Hash, StringComparison.OrdinalIgnoreCase);
            }
            catch
            {
                return false;
            }
        }
    }

    #region Result Models

    public class CatalogVerificationResult
    {
        public string CatalogPath { get; set; } = string.Empty;
        public bool IsValid { get; set; }
        public SignatureStatus SignatureStatus { get; set; }
        public string ErrorMessage { get; set; } = string.Empty;

        // Signer Information
        public string SignerSubject { get; set; } = string.Empty;
        public string SignerIssuer { get; set; } = string.Empty;
        public string SignerThumbprint { get; set; } = string.Empty;
        public DateTime? SignerNotBefore { get; set; }
        public DateTime? SignerNotAfter { get; set; }
        public DateTime? TimestampTime { get; set; }
        public X509Certificate2? SignerCertificate { get; set; }

        // Catalog Contents
        public int FileCount { get; set; }
        public List<CatalogEntry> CatalogEntries { get; set; } = new List<CatalogEntry>();
    }

    public class CatalogEntry
    {
        public string FileName { get; set; } = string.Empty;
        public string Hash { get; set; } = string.Empty;
        public string ReferenceTag { get; set; } = string.Empty;
    }

    public enum SignatureStatus
    {
        Unknown,
        NotSigned,
        Valid,
        Invalid
    }

    #endregion
}