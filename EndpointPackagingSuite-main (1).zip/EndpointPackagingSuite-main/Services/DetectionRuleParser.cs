using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.Json;
using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite.Helpers;

namespace Endpoint_Packaging_Suite.Services
{
    public class DetectionRuleParser
    {
        public List<DetectionRule> ParseFromJson(JsonElement appJson)
        {
            var rules = new List<DetectionRule>();
            try
            {
                ParseDetectionRulesArray(appJson, rules);
                ParseMsiInformationSection(appJson, rules);
                if (rules.Count == 0)
                {
                    rules.Add(CreateNoRulesPlaceholder());
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error parsing detection rules: {ex.Message}");
                rules.Add(CreateErrorPlaceholder(ex));
            }
            return rules;
        }
        private void ParseDetectionRulesArray(JsonElement appJson, List<DetectionRule> rules)
        {
            if (!appJson.TryGetProperty("detectionRules", out var rulesArray) ||
                rulesArray.ValueKind != JsonValueKind.Array)
                return;
            foreach (var rule in rulesArray.EnumerateArray())
            {
                var ruleType = rule.TryGetProperty("@odata.type", out var typeProp)
                    ? typeProp.GetString()
                    : "";
                var parsedRule = ruleType switch
                {
                    "#microsoft.graph.win32LobAppFileSystemDetection" => ParseFileSystemDetection(rule),
                    "#microsoft.graph.win32LobAppRegistryDetection" => ParseRegistryDetection(rule),
                    "#microsoft.graph.win32LobAppProductCodeDetection" => ParseProductCodeDetection(rule),
                    "#microsoft.graph.win32LobAppMsiInformation" => ParseMsiInformationRule(rule),
                    _ => CreateUnknownRulePlaceholder(ruleType)
                };
                rules.Add(parsedRule);
            }
        }
        private DetectionRule ParseFileSystemDetection(JsonElement rule)
        {
            return new DetectionRule
            {
                Type = DetectionRuleType.File,
                Path = rule.TryGetProperty("path", out var pathProp) ? pathProp.GetString() ?? "" : "",
                FileOrFolderName = rule.TryGetProperty("fileOrFolderName", out var fileProp) ? fileProp.GetString() ?? "" : "",
                CheckVersion = rule.GetSafeBoolean("check32BitOn64System")
            };
        }
        private DetectionRule ParseRegistryDetection(JsonElement rule)
        {
            return new DetectionRule
            {
                Type = DetectionRuleType.Registry,
                Path = rule.TryGetProperty("keyPath", out var keyProp) ? keyProp.GetString() ?? "" : "",
                FileOrFolderName = rule.TryGetProperty("valueName", out var valueProp) ? valueProp.GetString() ?? "" : ""
            };
        }
        private DetectionRule ParseProductCodeDetection(JsonElement rule)
        {
            var productCode = rule.TryGetProperty("productCode", out var codeProp) ? codeProp.GetString() ?? "" : "";
            var productVersion = rule.TryGetProperty("productVersion", out var versionProp) ? versionProp.GetString() ?? "" : "";
            var productVersionOperator = rule.TryGetProperty("productVersionOperator", out var operatorProp) ? operatorProp.GetString() ?? "" : "";
            return new DetectionRule
            {
                Type = DetectionRuleType.MSI,
                Path = productCode,
                FileOrFolderName = productVersion,
                CheckVersion = !string.IsNullOrEmpty(productVersion) && productVersionOperator != "notConfigured"
            };
        }
        private DetectionRule ParseMsiInformationRule(JsonElement rule)
        {
            var msiCode = rule.TryGetProperty("productCode", out var msiCodeProp) ? msiCodeProp.GetString() ?? "" : "";
            var msiVersion = rule.TryGetProperty("productVersion", out var msiVersionProp) ? msiVersionProp.GetString() ?? "" : "";
            return new DetectionRule
            {
                Type = DetectionRuleType.MSI,
                Path = msiCode,
                FileOrFolderName = msiVersion,
                CheckVersion = !string.IsNullOrEmpty(msiVersion)
            };
        }
        private void ParseMsiInformationSection(JsonElement appJson, List<DetectionRule> rules)
        {
            if (!appJson.TryGetProperty("msiInformation", out var msiInfo) ||
                msiInfo.ValueKind == JsonValueKind.Null)
                return;
            var productCode = msiInfo.TryGetProperty("productCode", out var msiCodeProp) ? msiCodeProp.GetString() ?? "" : "";
            var productVersion = msiInfo.TryGetProperty("productVersion", out var msiVersionProp) ? msiVersionProp.GetString() ?? "" : "";
            if (!string.IsNullOrEmpty(productCode))
            {
                rules.Add(new DetectionRule
                {
                    Type = DetectionRuleType.MSI,
                    Path = productCode,
                    FileOrFolderName = productVersion,
                    CheckVersion = !string.IsNullOrEmpty(productVersion)
                });
            }
        }
        private DetectionRule CreateUnknownRulePlaceholder(string ruleType)
        {
            return new DetectionRule
            {
                Type = DetectionRuleType.File,
                Path = "Unknown detection rule type",
                FileOrFolderName = ruleType?.Replace("#microsoft.graph.", "") ?? "Unknown"
            };
        }
        private DetectionRule CreateNoRulesPlaceholder()
        {
            return new DetectionRule
            {
                Type = DetectionRuleType.File,
                Path = "No detection rules configured",
                FileOrFolderName = "for this application"
            };
        }
        private DetectionRule CreateErrorPlaceholder(Exception ex)
        {
            return new DetectionRule
            {
                Type = DetectionRuleType.File,
                Path = "Error loading detection rules",
                FileOrFolderName = ex.Message
            };
        }
    }
}
