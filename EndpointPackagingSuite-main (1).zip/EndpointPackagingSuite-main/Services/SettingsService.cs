﻿// Services/SettingsService.cs
using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite;
using Microsoft.Extensions.DependencyInjection;
using System.IO;
using System.Text.Json;
namespace Endpoint_Packaging_Suite.Services
{
    public class SettingsService
    {
        private readonly string _appSettingsFile;
        private AppSettings? _settings;
        private bool _useKeyVault = false;
        private string? _keyVaultName;

        /// <summary>
        /// Constructor for dependency injection
        /// </summary>
        public SettingsService()
        {
            _appSettingsFile = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "appsettings.json");
        }
        public void LoadSettings()
        {
            try
            {
                // Load from appsettings.json (single source of truth)
                if (File.Exists(_appSettingsFile))
                {
                    var json = File.ReadAllText(_appSettingsFile);
                    var options = new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true,
                        ReadCommentHandling = JsonCommentHandling.Skip,
                        AllowTrailingCommas = true
                    };
                    _settings = JsonSerializer.Deserialize<AppSettings>(json, options);
                    if (_settings == null)
                    {
                        throw new Exception("Failed to deserialize appsettings.json");
                    }
                    // Ensure Authentication is not null
                    if (_settings.Authentication == null)
                    {
                        System.Diagnostics.Debug.WriteLine("WARNING: Authentication settings is null, creating default");
                        _settings.Authentication = new AppSettings.AuthenticationSettings();
                    }
                    ResolveKeyVaultForCurrentUser();

                    _keyVaultName = _settings.KeyVaultName;
                    _useKeyVault = !string.IsNullOrWhiteSpace(_keyVaultName);
                    // Debug: Log what was loaded
                    System.Diagnostics.Debug.WriteLine($"Loaded appsettings.json from: {_appSettingsFile}");
                    System.Diagnostics.Debug.WriteLine($"  Key Vault Enabled: {_useKeyVault}");
                    if (_useKeyVault)
                    {
                        System.Diagnostics.Debug.WriteLine($"  Key Vault Name: {_keyVaultName}");
                    }
                    System.Diagnostics.Debug.WriteLine($"  TenantId: {_settings.Authentication?.TenantId ?? "(null)"}");
                    System.Diagnostics.Debug.WriteLine($"  ClientId: {_settings.Authentication?.ClientId ?? "(null)"}");
                    System.Diagnostics.Debug.WriteLine($"  CertificateName: {_settings.Authentication?.CertificateName ?? "(null)"}");
                }
                else
                {
                    throw new FileNotFoundException($"appsettings.json not found at: {_appSettingsFile}");
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to load application settings: {ex.Message}", ex);
            }
        }
        /// <summary>
        /// Load settings from appsettings.json and optionally override sensitive values from Key Vault
        /// </summary>
        public async Task LoadSettingsWithKeyVaultAsync()
        {
            // First load base settings from appsettings.json (only if not already loaded)
            if (_settings == null)
            {
                LoadSettings();
            }
            // If Key Vault is configured, load sensitive settings from there
            if (_useKeyVault && !string.IsNullOrWhiteSpace(_keyVaultName) && _settings != null)
            {
                try
                {
                    System.Diagnostics.Debug.WriteLine($"🔐 Loading sensitive settings from Key Vault: {_keyVaultName}");
                    var kvService = App.Services.GetRequiredService<KeyVaultService>();

                    // Build the per-user GitLab PAT secret name
                    // Environment.UserName may return "admin.username" — strip the "admin." prefix
                    var userName = Environment.UserName;
                    System.Diagnostics.Debug.WriteLine($"  Environment.UserName: {userName}");
                    if (userName.StartsWith("admin.", StringComparison.OrdinalIgnoreCase))
                    {
                        userName = userName.Substring(6);
                    }
                    var gitLabPatSecretName = $"PAT-{userName}";
                    System.Diagnostics.Debug.WriteLine($"  GitLab PAT secret name: {gitLabPatSecretName}");

                    // Retrieve all secrets in a single Key Vault call
                    var secrets = await kvService.GetSecretsAsync(
                        "ClientId",
                        gitLabPatSecretName
                    );

                    // Apply GitLab PAT if found
                    if (secrets.ContainsKey(gitLabPatSecretName) && !string.IsNullOrWhiteSpace(secrets[gitLabPatSecretName]))
                    {
                        _settings.GitLab.PersonalAccessToken = secrets[gitLabPatSecretName];
                        System.Diagnostics.Debug.WriteLine($"  ✓ Loaded GitLab PAT from Key Vault ({gitLabPatSecretName})");
                    }
                    else
                    {
                        System.Diagnostics.Debug.WriteLine($"  ⚠ GitLab PAT not found in Key Vault for '{gitLabPatSecretName}'");
                    }
                    // TenantId is retrieved from Azure session context if not already in appsettings
                    if (secrets.ContainsKey("TenantId") && !string.IsNullOrWhiteSpace(secrets["TenantId"]))
                    {
                        if (string.IsNullOrWhiteSpace(_settings.Authentication.TenantId))
                        {
                            _settings.Authentication.TenantId = secrets["TenantId"];
                            System.Diagnostics.Debug.WriteLine("  ✓ Loaded TenantId from Azure session");
                        }
                        else
                        {
                            System.Diagnostics.Debug.WriteLine("  ✓ Using TenantId from appsettings.json");
                        }
                    }
                    if (secrets.ContainsKey("ClientId") && !string.IsNullOrWhiteSpace(secrets["ClientId"]))
                    {
                        _settings.Authentication.ClientId = secrets["ClientId"];
                        System.Diagnostics.Debug.WriteLine("  ✓ Loaded ClientId from Key Vault");
                    }
                    System.Diagnostics.Debug.WriteLine("✅ Successfully loaded sensitive settings from Key Vault");
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"⚠️ Failed to load settings from Key Vault: {ex.Message}");
                    System.Diagnostics.Debug.WriteLine("   Falling back to appsettings.json values");
                    // Continue with values from appsettings.json
                }
            }
        }
        public void SaveSettings()
        {
            try
            {
                var json = JsonSerializer.Serialize(_settings, new JsonSerializerOptions
                {
                    WriteIndented = true
                });
                File.WriteAllText(_appSettingsFile, json);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Failed to save settings: {ex.Message}");
                throw;
            }
        }
        public AppSettings Settings
        {
            get
            {
                if (_settings == null)
                {
                    LoadSettings();
                }
                return _settings!;
            }
        }

        private void ResolveKeyVaultForCurrentUser()
        {
            var mapPath = _settings?.UserVaultMapPath;
            if (string.IsNullOrWhiteSpace(mapPath)) return;

            if (!File.Exists(mapPath))
            {
                System.Diagnostics.Debug.WriteLine(
                    $"  ⚠ UserVaultMapPath '{mapPath}' not reachable; running without Key Vault");
                return;
            }

            Dictionary<string, List<string>>? map;
            try
            {
                var json = File.ReadAllText(mapPath);
                map = JsonSerializer.Deserialize<Dictionary<string, List<string>>>(json, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true,
                    ReadCommentHandling = JsonCommentHandling.Skip,
                    AllowTrailingCommas = true,
                });
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"  ⚠ Could not read UserVaultMapPath ({ex.GetType().Name}: {ex.Message}); running without Key Vault");
                return;
            }

            if (map == null || map.Count == 0) return;

            var userName = Environment.UserName;

            foreach (var kvp in map)
            {
                if (string.IsNullOrWhiteSpace(kvp.Key) || kvp.Value == null) continue;

                if (kvp.Value.Any(u => string.Equals(u, userName, StringComparison.OrdinalIgnoreCase)))
                {
                    System.Diagnostics.Debug.WriteLine(
                        $"  ✓ Mapped user '{userName}' to Key Vault '{kvp.Key}'");
                    _settings!.KeyVaultName = kvp.Key;
                    return;
                }
            }

            System.Diagnostics.Debug.WriteLine(
                $"  User '{userName}' has no entry in '{mapPath}'; running without Key Vault");
        }
    }
}