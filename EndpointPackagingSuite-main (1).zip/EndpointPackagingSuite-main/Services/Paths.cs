// Services/Paths.cs
using Endpoint_Packaging_Suite.Models;
using Microsoft.Extensions.DependencyInjection;

namespace Endpoint_Packaging_Suite.Services
{
    public static class Paths
    {
        private static AppSettings Settings =>
            App.Services.GetRequiredService<SettingsService>().Settings;

        // Network paths
        public static string NetworkRoot => Settings.NetworkPaths.NetworkRoot;
        public static string IntuneApplications => Settings.NetworkPaths.IntuneApplications;
        public static string Tools => Settings.NetworkPaths.Tools;
        public static string Scripts => Settings.NetworkPaths.Scripts;
        public static string CatTS => Settings.NetworkPaths.CatTS;
        public static string IntuneWinAppUtil => Settings.NetworkPaths.IntuneWinAppUtil;
        public static string PSADTTemplate => Settings.NetworkPaths.PSADTTemplate;

        public static string HyperVScript => Settings.NetworkPaths.HyperVScript;
        public static string VMScript => Settings.NetworkPaths.VMScript;

        // WDAC Hyper-V Configuration from settings
        public static class WDACHyperV
        {
            public static string Host => Settings.WDACHyperV.Host;
            public static string VMName => Settings.WDACHyperV.VMName;
            public static string SnapshotName => Settings.WDACHyperV.SnapshotName;
            public static string PsExecPath => Settings.WDACHyperV.PsExecPath;
        }
    }
}
