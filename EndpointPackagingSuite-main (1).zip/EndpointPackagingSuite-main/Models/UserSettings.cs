﻿// Models/UserSettings.cs
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Endpoint_Packaging_Suite.Models
{
    /// <summary>
    /// User-specific settings stored in AppData\Local\Endpoint_Packaging_Suite\settings.json
    /// These settings are per-user and not shared across users.
    /// </summary>
    public class UserSettings : INotifyPropertyChanged
    {
        private bool _confirmBeforeUpload = true;
        private bool _rememberWindowSize = true;
        private int _windowWidth = 1200;
        private int _windowHeight = 800;
        private string _language = "en-US";
        private int _defaultPageSize = 50;
        private int _searchDebounceMilliseconds = 500;
        private int _notificationDisplaySeconds = 5;
        private string _gitLabAuthorName = "";
        private string _gitLabAuthorEmail = "";

        /// <summary>
        /// Whether to show confirmation dialog before uploading to Intune
        /// </summary>
        public bool ConfirmBeforeUpload
        {
            get => _confirmBeforeUpload;
            set => SetField(ref _confirmBeforeUpload, value);
        }

        /// <summary>
        /// Whether to remember window size between sessions
        /// </summary>
        public bool RememberWindowSize
        {
            get => _rememberWindowSize;
            set => SetField(ref _rememberWindowSize, value);
        }

        /// <summary>
        /// Window width in pixels
        /// </summary>
        public int WindowWidth
        {
            get => _windowWidth;
            set => SetField(ref _windowWidth, value);
        }

        /// <summary>
        /// Window height in pixels
        /// </summary>
        public int WindowHeight
        {
            get => _windowHeight;
            set => SetField(ref _windowHeight, value);
        }

        /// <summary>
        /// UI language (e.g., "en-US", "nl-NL")
        /// </summary>
        public string Language
        {
            get => _language;
            set => SetField(ref _language, value);
        }

        /// <summary>
        /// Default page size for list views
        /// </summary>
        public int DefaultPageSize
        {
            get => _defaultPageSize;
            set => SetField(ref _defaultPageSize, value);
        }

        /// <summary>
        /// Search debounce time in milliseconds
        /// </summary>
        public int SearchDebounceMilliseconds
        {
            get => _searchDebounceMilliseconds;
            set => SetField(ref _searchDebounceMilliseconds, value);
        }

        /// <summary>
        /// How long to display notifications in seconds
        /// </summary>
        public int NotificationDisplaySeconds
        {
            get => _notificationDisplaySeconds;
            set => SetField(ref _notificationDisplaySeconds, value);
        }

        /// <summary>
        /// Per-user GitLab author name (overrides appsettings.json GitLab.AuthorName)
        /// </summary>
        public string GitLabAuthorName
        {
            get => _gitLabAuthorName;
            set => SetField(ref _gitLabAuthorName, value);
        }

        /// <summary>
        /// Per-user GitLab author email (overrides appsettings.json GitLab.AuthorEmail)
        /// </summary>
        public string GitLabAuthorEmail
        {
            get => _gitLabAuthorEmail;
            set => SetField(ref _gitLabAuthorEmail, value);
        }

        // INotifyPropertyChanged implementation
        public event PropertyChangedEventHandler? PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        protected bool SetField<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
        {
            if (EqualityComparer<T>.Default.Equals(field, value)) return false;
            field = value;
            OnPropertyChanged(propertyName);
            return true;
        }
    }
}