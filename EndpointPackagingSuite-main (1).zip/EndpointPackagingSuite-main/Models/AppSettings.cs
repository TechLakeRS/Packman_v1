﻿// Models/AppSettings.cs
using System;
using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace Endpoint_Packaging_Suite.Models
{
    public class AppSettings : INotifyPropertyChanged
    {
        // === AUTHENTICATION ===
        public class AuthenticationSettings
        {
            public string TenantId { get; set; } = "";
            public string ClientId { get; set; } = "";
            // Name of the app-registration certificate stored in Azure Key Vault.
            public string CertificateName { get; set; } = "";
        }

        // === CODE SIGNING ===
        public class CodeSigningSettings
        {
            public string TimestampServer { get; set; } = "http://timestamp.digicert.com";
        }

        // === NETWORK PATHS ===
        public class NetworkPathSettings
        {
            public string NetworkRoot { get; set; } = "";
            public string IntuneApplications { get; set; } = "";
            public string DefaultPackageBrowsePath { get; set; } = "";
            public string Tools { get; set; } = "";
            public string Scripts { get; set; } = "";
            public string CatTS { get; set; } = "";
            public string IntuneWinAppUtil { get; set; } = "";
            public string PSADTTemplate { get; set; } = "";
            public string HyperVScript { get; set; } = "";
            public string VMScript { get; set; } = "";
        }

        // === WDAC HYPER-V ===
        public class WDACHyperVSettings
        {
            public string Host { get; set; } = "";
            public string VMName { get; set; } = "";
            public string SnapshotName { get; set; } = "";
            public string PsExecPath { get; set; } = @"C:\Windows\System32\PsExec.exe";
        }

        // === GITLAB VERSION CONTROL ===
        public class GitLabSettings
        {
            public string Url { get; set; } = "";
            public string PersonalAccessToken { get; set; } = "";
            public string ProjectId { get; set; } = "";
            public string Branch { get; set; } = "main";
            public string AuthorName { get; set; } = "";
            public string AuthorEmail { get; set; } = "";
        }

        // === GROUP ASSIGNMENT ===
        public class GroupAssignmentSettings
        {
            public List<string> OwnerIds { get; set; } = new();
        }

        // === KEY VAULT ===
        public class KeyVaultSettings
        {
            // Cache duration in hours (default: 24 hours)
            // How long to cache secrets before requiring re-authentication
            public int CacheDurationHours { get; set; } = 24;
        }

        // Properties
        public bool FirstRun { get; set; } = true;
        public string AppVersion { get; set; } = "1.0.0";
        [JsonIgnore]
        public string? KeyVaultName { get; set; } = null;
        public string? UserVaultMapPath { get; set; } = null;
        public AuthenticationSettings Authentication { get; set; } = new();
        public CodeSigningSettings CodeSigning { get; set; } = new();
        public NetworkPathSettings NetworkPaths { get; set; } = new();
        public WDACHyperVSettings WDACHyperV { get; set; } = new();
        public GroupAssignmentSettings GroupAssignment { get; set; } = new();
        public KeyVaultSettings KeyVault { get; set; } = new();
        public GitLabSettings GitLab { get; set; } = new();

        // INotifyPropertyChanged
        public event PropertyChangedEventHandler? PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}