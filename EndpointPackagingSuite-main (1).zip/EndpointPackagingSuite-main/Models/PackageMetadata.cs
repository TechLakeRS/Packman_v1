﻿using System;
using System.Collections.Generic;

namespace Endpoint_Packaging_Suite.Models
{
    /// <summary>
    /// Metadata stored in package folder for auto-filling upload forms
    /// </summary>
    public class PackageMetadata
    {
        public string MetadataVersion { get; set; } = "1.0";

        // Basic package info
        public string Manufacturer { get; set; } = "";
        public string AppName { get; set; } = "";
        public string Version { get; set; } = "";
        public string InstallContext { get; set; } = "System";
        public string Category { get; set; } = ""; // Intune category

        // File info
        public string IconFileName { get; set; } = "";
        public string SourceFileName { get; set; } = "";
        public string PackageType { get; set; } = ""; // "msi" or "exe"
        public string Architecture { get; set; } = ""; // "x64", "x86", or "Both"

        // Commands
        public string InstallCommand { get; set; } = "Invoke-AppDeployToolkit.exe Install";
        public string UninstallCommand { get; set; } = "Invoke-AppDeployToolkit.exe Uninstall";

        // Creation metadata
        public DateTime CreatedDate { get; set; } = DateTime.Now;
        public string CreatedBy { get; set; } = ""; // "create" or "upgrade"
        public string UpgradedFrom { get; set; } = ""; // Previous version if upgrade

        // Detection methods (stored after remote test)
        public List<DetectionMethodMetadata> DetectionMethods { get; set; } = new List<DetectionMethodMetadata>();

        // Upload tracking (optional)
        public bool? UploadedToIntune { get; set; }
        public DateTime? UploadDate { get; set; }
        public string IntuneAppId { get; set; } = "";
    }

    /// <summary>
    /// Detection method metadata for a package
    /// </summary>
    public class DetectionMethodMetadata
    {
        public string Type { get; set; } = ""; // "MSI", "Registry", "File", "Script"
        public string Path { get; set; } = "";
        public string ValueName { get; set; } = "";
        public string ExpectedValue { get; set; } = "";
        public string Operator { get; set; } = "";
        public bool CheckVersion { get; set; }
        public string Description { get; set; } = "";
    }
}