using Endpoint_Packaging_Suite.Helpers;
using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite.Services;
using Serilog;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;

namespace Endpoint_Packaging_Suite.ViewModels
{
    /// <summary>
    /// ViewModel for package creation workflow
    /// Handles package folder selection, metadata extraction, PSADT options, and generation
    /// </summary>
    public class CreatePackageViewModel : ViewModelBase
    {
        private readonly ILogger _logger = Log.ForContext<CreatePackageViewModel>();
        private readonly PSADTGenerator? _psadtGenerator;
        private readonly SettingsService? _settingsService;

        // State
        private string _sourcesPath = "";
        private string _appName = "";
        private string _manufacturer = "";
        private string _version = "";
        private string _extractedIconPath = "";
        private bool _userInstall = false;
        private string _detectedPackageType = "";
        private MsiInfoService.MsiInfo? _currentMsiInfo;
        private PSADTOptions? _currentPSADTOptions;
        private string _currentPackagePath = "";
        private string? _predecessorAppId;

        // UI State
        private string _statusText = "";
        private bool _isGenerating = false;
        private Visibility _progressBarVisibility = Visibility.Collapsed;

        public string SourcesPath
        {
            get => _sourcesPath;
            set => SetProperty(ref _sourcesPath, value);
        }

        public string AppName
        {
            get => _appName;
            set => SetProperty(ref _appName, value);
        }

        public string Manufacturer
        {
            get => _manufacturer;
            set => SetProperty(ref _manufacturer, value);
        }

        public string Version
        {
            get => _version;
            set => SetProperty(ref _version, value);
        }

        public string ExtractedIconPath
        {
            get => _extractedIconPath;
            set => SetProperty(ref _extractedIconPath, value);
        }

        public bool UserInstall
        {
            get => _userInstall;
            set => SetProperty(ref _userInstall, value);
        }

        public string DetectedPackageType
        {
            get => _detectedPackageType;
            set => SetProperty(ref _detectedPackageType, value);
        }

        public MsiInfoService.MsiInfo? CurrentMsiInfo
        {
            get => _currentMsiInfo;
            set => SetProperty(ref _currentMsiInfo, value);
        }

        public PSADTOptions? CurrentPSADTOptions
        {
            get => _currentPSADTOptions;
            set => SetProperty(ref _currentPSADTOptions, value);
        }

        public string CurrentPackagePath
        {
            get => _currentPackagePath;
            set => SetProperty(ref _currentPackagePath, value);
        }

        public string? PredecessorAppId
        {
            get => _predecessorAppId;
            set => SetProperty(ref _predecessorAppId, value);
        }

        public string StatusText
        {
            get => _statusText;
            set => SetProperty(ref _statusText, value);
        }

        public bool IsGenerating
        {
            get => _isGenerating;
            set => SetProperty(ref _isGenerating, value);
        }

        public Visibility ProgressBarVisibility
        {
            get => _progressBarVisibility;
            set => SetProperty(ref _progressBarVisibility, value);
        }

        public CreatePackageViewModel(SettingsService settingsService)
        {
            _psadtGenerator = new PSADTGenerator();
            _settingsService = settingsService;
            _logger.Debug("CreatePackageViewModel created");
        }

        /// <summary>
        /// Detect package type from file extension
        /// </summary>
        public void DetectPackageType(string extension)
        {
            DetectedPackageType = extension switch
            {
                ".msi" => "MSI",
                ".exe" => "EXE",
                _ => "Unknown"
            };
            _logger.Debug("Detected package type: {PackageType}", DetectedPackageType);
        }

        /// <summary>
        /// Extract MSI metadata from the selected MSI file
        /// </summary>
        public void ExtractMsiMetadata(string msiPath)
        {
            try
            {
                var msiInfo = MsiInfoService.ExtractMsiInfo(msiPath);
                if (msiInfo?.IsValid == true)
                {
                    CurrentMsiInfo = msiInfo;
                    Manufacturer = msiInfo.Manufacturer;
                    AppName = msiInfo.ProductName;
                    Version = msiInfo.ProductVersion;
                    _logger.Debug("MSI metadata extracted: {ProductName} v{Version}", msiInfo.ProductName, msiInfo.ProductVersion);
                }
            }
            catch (Exception ex)
            {
                _logger.Warning(ex, "Failed to extract MSI metadata");
            }
        }

        /// <summary>
        /// Create ApplicationInfo from current ViewModel state
        /// </summary>
        public ApplicationInfo? CreateApplicationInfo(string installContext = "System")
        {
            if (!ValidatePackageInputs())
                return null;

            var appInfo = PackageCreationHelper.CreateApplicationInfo(
                AppName,
                Manufacturer,
                Version,
                SourcesPath,
                CurrentMsiInfo,
                installContext
            );

            _logger.Debug("ApplicationInfo created: {AppName} v{Version}", appInfo.Name, appInfo.Version);
            return appInfo;
        }

        /// <summary>
        /// Collect and validate PSADT options
        /// </summary>
        public PSADTOptions? CollectPSADTOptions(string packageType)
        {
            return PackageCreationHelper.CollectPSADTOptions(UserInstall, CurrentPSADTOptions, packageType);
        }

        /// <summary>
        /// Validate package inputs before generation
        /// </summary>
        public bool ValidatePackageInputs()
        {
            return PackageCreationHelper.ValidatePackageInputs(AppName);
        }

        /// <summary>
        /// Set PSADT options from dialog
        /// </summary>
        public void SetPSADTOptions(PSADTOptions options)
        {
            CurrentPSADTOptions = options;
            _logger.Debug("PSADT options set");
        }

        /// <summary>
        /// Set the package path after successful generation
        /// </summary>
        public void SetPackagePath(string packagePath)
        {
            CurrentPackagePath = packagePath;
            PredecessorAppId = null;
        }

        /// <summary>
        /// Show success UI after package creation
        /// </summary>
        public void ShowPackageSuccess(string packagePath, PSADTOptions? psadtOptions)
        {
            CurrentPackagePath = packagePath;
            int enabledFeatures = psadtOptions != null ? PackageCreationHelper.CountEnabledFeatures(psadtOptions) : 0;
            string featuresText = enabledFeatures > 0 ? $" with {enabledFeatures} PSADT cheatsheet functions" : "";
            StatusText = $"Package created successfully{featuresText} • {DateTime.Now:HH:mm:ss}";
            _logger.Information("Package created successfully: {PackagePath}", packagePath);
        }

        /// <summary>
        /// Reset the form to initial state
        /// </summary>
        public void ResetForm()
        {
            SourcesPath = "";
            AppName = "";
            Manufacturer = "";
            Version = "";
            ExtractedIconPath = "";
            UserInstall = false;
            DetectedPackageType = "";
            CurrentMsiInfo = null;
            CurrentPSADTOptions = null;
            CurrentPackagePath = "";
            StatusText = "";
            _logger.Debug("CreatePackageViewModel form reset");
        }
    }
}
