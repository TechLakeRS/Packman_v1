using Endpoint_Packaging_Suite.Helpers;
using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite.Services;
using Serilog;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Input;

namespace Endpoint_Packaging_Suite.ViewModels
{
    /// <summary>
    /// ViewModel for uploading existing packages to Intune
    /// Handles package selection, validation, metadata extraction, and upload workflow
    /// </summary>
    public class UploadPackageViewModel : ViewModelBase
    {
        private readonly ILogger _logger = Log.ForContext<UploadPackageViewModel>();
        private readonly PSADTGenerator? _psadtGenerator;
        private readonly SettingsService? _settingsService;

        // State
        private string _packageFolderPath = "";
        private string _deployExePath = "";
        private string _appName = "";
        private string _manufacturer = "";
        private string _version = "";
        private string _scriptDate = "";
        private string _scriptAuthor = "";
        private string _selectedIconPath = "";
        private bool _userInstall = false;
        private ObservableCollection<DetectionRule> _detectionRules = new();
        private MsiInfoService.MsiInfo? _currentMsiInfo;

        // UI State
        private string _statusText = "";
        private Visibility _validationStatusVisibility = Visibility.Collapsed;
        private string _validationTitle = "";
        private string _validationMessage = "";
        private bool _uploadButtonEnabled = false;

        public string PackageFolderPath
        {
            get => _packageFolderPath;
            set => SetProperty(ref _packageFolderPath, value);
        }

        public string DeployExePath
        {
            get => _deployExePath;
            set => SetProperty(ref _deployExePath, value);
        }

        public string AppName
        {
            get => _appName;
            set => SetProperty(ref _appName, value);
        }

        public string Manufacturer
        {
            get => _manufacturer;
            set => SetProperty(ref _manufacturer, value);
        }

        public string Version
        {
            get => _version;
            set => SetProperty(ref _version, value);
        }

        public string ScriptDate
        {
            get => _scriptDate;
            set => SetProperty(ref _scriptDate, value);
        }

        public string ScriptAuthor
        {
            get => _scriptAuthor;
            set => SetProperty(ref _scriptAuthor, value);
        }

        public string SelectedIconPath
        {
            get => _selectedIconPath;
            set => SetProperty(ref _selectedIconPath, value);
        }

        public bool UserInstall
        {
            get => _userInstall;
            set => SetProperty(ref _userInstall, value);
        }

        public ObservableCollection<DetectionRule> DetectionRules
        {
            get => _detectionRules;
            set => SetProperty(ref _detectionRules, value);
        }

        public MsiInfoService.MsiInfo? CurrentMsiInfo
        {
            get => _currentMsiInfo;
            set => SetProperty(ref _currentMsiInfo, value);
        }

        public string StatusText
        {
            get => _statusText;
            set => SetProperty(ref _statusText, value);
        }

        public Visibility ValidationStatusVisibility
        {
            get => _validationStatusVisibility;
            set => SetProperty(ref _validationStatusVisibility, value);
        }

        public string ValidationTitle
        {
            get => _validationTitle;
            set => SetProperty(ref _validationTitle, value);
        }

        public string ValidationMessage
        {
            get => _validationMessage;
            set => SetProperty(ref _validationMessage, value);
        }

        public bool UploadButtonEnabled
        {
            get => _uploadButtonEnabled;
            set => SetProperty(ref _uploadButtonEnabled, value);
        }

        public UploadPackageViewModel(SettingsService settingsService)
        {
            _psadtGenerator = new PSADTGenerator();
            _settingsService = settingsService;
            _logger.Debug("UploadPackageViewModel created");
        }

        /// <summary>
        /// Process a selected PSADT deploy executable
        /// </summary>
        public void ProcessSelectedDeployExe(string deployExePath)
        {
            try
            {
                var fileName = Path.GetFileName(deployExePath);
                var isV4 = fileName.Equals("Invoke-AppDeployToolkit.exe", StringComparison.OrdinalIgnoreCase);

                if (!isV4)
                {
                    ShowValidationError("Please select a valid PSADT executable (Invoke-AppDeployToolkit.exe)");
                    return;
                }

                var applicationFolder = Path.GetDirectoryName(deployExePath);
                PackageFolderPath = Path.GetDirectoryName(applicationFolder) ?? "";
                DeployExePath = deployExePath;

                var scriptName = "Invoke-AppDeployToolkit.ps1";
                var scriptPath = Path.Combine(applicationFolder ?? "", scriptName);

                if (!File.Exists(scriptPath))
                {
                    ShowValidationError($"{scriptName} not found in the same folder");
                    ResetForm();
                    return;
                }

                ExtractMetadataFromScript(scriptPath);

                var detectedInstallContext = ExtractInstallContextFromConfig(PackageFolderPath);
                UserInstall = detectedInstallContext == "User";

                ShowValidationSuccess();
                CheckForMsiInFiles();
                ValidateUploadButton();

                _logger.Information("Deploy exe processed successfully: {Path}", deployExePath);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error processing deploy exe");
                ShowValidationError($"Error processing file: {ex.Message}");
                ResetForm();
            }
        }

        /// <summary>
        /// Extract metadata from PSADT script
        /// </summary>
        private void ExtractMetadataFromScript(string scriptPath)
        {
            try
            {
                var metadata = MetadataExtractor.ExtractMetadataFromScript(scriptPath);
                Manufacturer = metadata.GetValueOrDefault("Vendor", "");
                AppName = metadata.GetValueOrDefault("AppName", "");
                Version = metadata.GetValueOrDefault("Version", "");
                ScriptDate = metadata.GetValueOrDefault("ScriptDate", "");
                ScriptAuthor = metadata.GetValueOrDefault("ScriptAuthor", "");

                _logger.Debug("Metadata extracted from script");
            }
            catch (Exception ex)
            {
                _logger.Warning(ex, "Error extracting metadata from script");
            }
        }

        /// <summary>
        /// Check for MSI files in the package and auto-add detection rule
        /// </summary>
        private void CheckForMsiInFiles()
        {
            try
            {
                var filesFolder = Path.Combine(PackageFolderPath, "Application", "Files");
                if (Directory.Exists(filesFolder))
                {
                    var msiFiles = Directory.GetFiles(filesFolder, "*.msi", SearchOption.TopDirectoryOnly);
                    if (msiFiles.Length > 0)
                    {
                        var msiInfo = MsiInfoService.ExtractMsiInfo(msiFiles[0]);
                        if (msiInfo?.IsValid == true)
                        {
                            CurrentMsiInfo = msiInfo;
                            DetectionRules.Clear();
                            DetectionRules.Add(new DetectionRule
                            {
                                Type = DetectionRuleType.File,
                                Path = "%ProgramFiles%",
                                FileOrFolderName = $"{AppName}.exe",
                                DetectionType = "version",
                                Operator = "greaterThanOrEqual",
                                DetectionValue = string.IsNullOrEmpty(msiInfo.ProductVersion) ? Version : msiInfo.ProductVersion,
                                CheckVersion = true,
                                Check32BitOn64System = true
                            });

                            _logger.Debug("Auto-added File detection rule from MSI version: {ProductVersion}", msiInfo.ProductVersion);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Warning(ex, "Error checking for MSI in files");
            }
        }

        /// <summary>
        /// Create ApplicationInfo from current state
        /// </summary>
        public ApplicationInfo CreateApplicationInfo(string installContext = "System")
        {
            return new ApplicationInfo
            {
                Name = AppName.Trim(),
                Manufacturer = Manufacturer.Trim(),
                Version = Version.Trim(),
                SourcesPath = PackageFolderPath.Trim(),
                InstallContext = installContext
            };
        }

        /// <summary>
        /// Show validation success UI
        /// </summary>
        public void ShowValidationSuccess()
        {
            ValidationStatusVisibility = Visibility.Visible;
            ValidationTitle = "Valid Package Detected";
            ValidationMessage = "Successfully extracted metadata from PSADT script";
            _logger.Debug("Validation success shown");
        }

        /// <summary>
        /// Show validation error UI
        /// </summary>
        public void ShowValidationError(string message)
        {
            ValidationStatusVisibility = Visibility.Visible;
            ValidationTitle = "Invalid Selection";
            ValidationMessage = message;
            _logger.Warning("Validation error: {Message}", message);
        }

        /// <summary>
        /// Validate upload button should be enabled
        /// </summary>
        public void ValidateUploadButton()
        {
            UploadButtonEnabled = !string.IsNullOrWhiteSpace(AppName) &&
                                  !string.IsNullOrWhiteSpace(Manufacturer) &&
                                  !string.IsNullOrWhiteSpace(Version);
        }

        /// <summary>
        /// Extract install context from AppDeployToolkitConfig.xml
        /// </summary>
        private string ExtractInstallContextFromConfig(string packagePath)
        {
            try
            {
                var configPath = Path.Combine(packagePath, "AppDeployToolkit", "AppDeployToolkitConfig.xml");
                if (File.Exists(configPath))
                {
                    var content = File.ReadAllText(configPath);
                    // Check for RequireAdmin setting
                    var requireAdminMatch = System.Text.RegularExpressions.Regex.Match(content, @"<RequireAdmin>(true|false)</RequireAdmin>", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                    if (requireAdminMatch.Success)
                    {
                        bool requireAdmin = bool.Parse(requireAdminMatch.Groups[1].Value);
                        return requireAdmin ? "System" : "User";
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Warning(ex, "Error extracting install context from config");
            }

            return "System"; // Default
        }

        /// <summary>
        /// Reset form to initial state
        /// </summary>
        public void ResetForm()
        {
            PackageFolderPath = "";
            DeployExePath = "";
            AppName = "";
            Manufacturer = "";
            Version = "";
            ScriptDate = "";
            ScriptAuthor = "";
            SelectedIconPath = "";
            UserInstall = false;
            DetectionRules.Clear();
            CurrentMsiInfo = null;
            ValidationStatusVisibility = Visibility.Collapsed;
            StatusText = "";
            UploadButtonEnabled = false;
            _logger.Debug("UploadPackageViewModel form reset");
        }
    }
}
