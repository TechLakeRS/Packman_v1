using Endpoint_Packaging_Suite.Models;

namespace Endpoint_Packaging_Suite.ViewModels
{
    /// <summary>
    /// ViewModel for the Upgrade Existing Package workflow on the Create Application page.
    /// Holds the selected source package, its loaded metadata, and the user's new-version inputs.
    /// </summary>
    public class UpgradePackageViewModel : ViewModelBase
    {
        private string _packagePath = "";
        private string _newVersion = "";
        private string _newSourcePath = "";
        private PackageMetadata? _loadedMetadata;
        private string _packageDisplayName = "";
        private string _packageDisplayVersion = "";
        private string _packageDisplayContext = "";

        public string PackagePath
        {
            get => _packagePath;
            set => SetProperty(ref _packagePath, value);
        }

        public string NewVersion
        {
            get => _newVersion;
            set => SetProperty(ref _newVersion, value);
        }

        public string NewSourcePath
        {
            get => _newSourcePath;
            set => SetProperty(ref _newSourcePath, value);
        }

        public PackageMetadata? LoadedMetadata
        {
            get => _loadedMetadata;
            set => SetProperty(ref _loadedMetadata, value);
        }

        public string PackageDisplayName
        {
            get => _packageDisplayName;
            set => SetProperty(ref _packageDisplayName, value);
        }

        public string PackageDisplayVersion
        {
            get => _packageDisplayVersion;
            set => SetProperty(ref _packageDisplayVersion, value);
        }

        public string PackageDisplayContext
        {
            get => _packageDisplayContext;
            set => SetProperty(ref _packageDisplayContext, value);
        }

        /// <summary>
        /// Clears the new-version and new-source inputs after a successful upgrade.
        /// Existing package selection and display info are preserved so the user
        /// can quickly run another upgrade against the same source package.
        /// </summary>
        public void ResetNewVersionInputs()
        {
            NewVersion = "";
            NewSourcePath = "";
        }
    }
}
