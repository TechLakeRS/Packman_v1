using Endpoint_Packaging_Suite.Constants;
using Endpoint_Packaging_Suite.Dialogs;
using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite.Services;
using Microsoft.Extensions.DependencyInjection;
using Serilog;
using System.Collections.ObjectModel;
using System.Windows;

namespace Endpoint_Packaging_Suite.ViewModels
{
    /// <summary>
    /// ViewModel for application list management and display
    /// Handles loading, filtering, searching, and pagination of Intune applications
    /// </summary>
    public class ApplicationListViewModel : ViewModelBase
    {
        private readonly ILogger _logger = Log.ForContext<ApplicationListViewModel>();
        private readonly IntuneService? _intuneService;

        // Collections
        private ObservableCollection<IntuneApplication> _applications = new();
        private List<IntuneApplication> _allApplications = new();

        // State
        private string _searchFilter = "";
        private string _categoryFilter = AppConstants.Defaults.AllCategoriesFilter;
        private int _currentPage = 1;
        private int _pageSize = 50;
        private int _totalApplicationCount = 0;
        private bool _applicationsLoaded = false;
        private bool _isLoading = false;

        // UI State
        private string _statusText = "";
        private Visibility _progressBarVisibility = Visibility.Collapsed;
        private DateTime? _lastSyncTime;
        private string _lastSyncDisplayText = "Last sync: Never";
        private string _pageDisplayText = "Page 1 of 1";
        private bool _canGoPreviousPage = false;
        private bool _canGoNextPage = false;
        private Visibility _skeletonVisibility = Visibility.Collapsed;
        private Visibility _applicationsListVisibility = Visibility.Visible;

        private CancellationTokenSource? _loadCancellation;

        public ObservableCollection<IntuneApplication> Applications
        {
            get => _applications;
            set => SetProperty(ref _applications, value);
        }

        /// <summary>Full unfiltered application list (all pages).</summary>
        public IReadOnlyList<IntuneApplication> AllApplications => _allApplications;

        public string SearchFilter
        {
            get => _searchFilter;
            set => SetProperty(ref _searchFilter, value);
        }

        public string CategoryFilter
        {
            get => _categoryFilter;
            set => SetProperty(ref _categoryFilter, value);
        }

        public int CurrentPage
        {
            get => _currentPage;
            set => SetProperty(ref _currentPage, value);
        }

        public int PageSize
        {
            get => _pageSize;
            set => SetProperty(ref _pageSize, value);
        }

        public int TotalApplicationCount
        {
            get => _totalApplicationCount;
            set => SetProperty(ref _totalApplicationCount, value);
        }

        public bool ApplicationsLoaded
        {
            get => _applicationsLoaded;
            set => SetProperty(ref _applicationsLoaded, value);
        }

        public bool IsLoading
        {
            get => _isLoading;
            set => SetProperty(ref _isLoading, value);
        }

        public string StatusText
        {
            get => _statusText;
            set => SetProperty(ref _statusText, value);
        }

        public Visibility ProgressBarVisibility
        {
            get => _progressBarVisibility;
            set => SetProperty(ref _progressBarVisibility, value);
        }

        public DateTime? LastSyncTime
        {
            get => _lastSyncTime;
            set => SetProperty(ref _lastSyncTime, value);
        }

        public string LastSyncDisplayText
        {
            get => _lastSyncDisplayText;
            set => SetProperty(ref _lastSyncDisplayText, value);
        }

        public string PageDisplayText
        {
            get => _pageDisplayText;
            set => SetProperty(ref _pageDisplayText, value);
        }

        public bool CanGoPreviousPage
        {
            get => _canGoPreviousPage;
            set => SetProperty(ref _canGoPreviousPage, value);
        }

        public bool CanGoNextPage
        {
            get => _canGoNextPage;
            set => SetProperty(ref _canGoNextPage, value);
        }

        public Visibility SkeletonVisibility
        {
            get => _skeletonVisibility;
            set => SetProperty(ref _skeletonVisibility, value);
        }

        public Visibility ApplicationsListVisibility
        {
            get => _applicationsListVisibility;
            set => SetProperty(ref _applicationsListVisibility, value);
        }

        public ApplicationListViewModel()
        {
            _intuneService = App.Services?.GetService<IntuneService>();
            _logger.Debug("ApplicationListViewModel created");
        }

        /// <summary>
        /// Loads all applications from Intune
        /// </summary>
        public async Task LoadAllApplicationsAsync()
        {
            // Cancel and dispose any existing load operation before creating new one
            var oldCancellation = _loadCancellation;
            _loadCancellation = null;

            try
            {
                oldCancellation?.Cancel();
            }
            catch { /* Ignore cancellation errors */ }
            finally
            {
                oldCancellation?.Dispose();
            }

            if (_intuneService == null)
            {
                _logger.Warning("Intune service is not initialized");
                return;
            }

            try
            {
                _loadCancellation = new CancellationTokenSource();

                IsLoading = true;
                ProgressBarVisibility = Visibility.Visible;
                ShowSkeleton(true);
                StatusText = "Loading applications from Microsoft Intune...";

                var progress = new Progress<(int fetchedCount, int totalCount)>(update =>
                {
                    var (fetched, total) = update;
                    StatusText = $"Fetched {fetched} apps, total loaded: {total}";
                    UpdateLastSyncDisplay(inProgress: true, totalCount: total);
                });

                _allApplications = await _intuneService.GetApplicationsAsync(
                    forceRefresh: false,
                    cancellationToken: _loadCancellation.Token,
                    progress: progress);

                ApplicationsLoaded = true;
                LastSyncTime = DateTime.Now;

                CurrentPage = 1;
                ApplyFiltersAndPagination();
                UpdateLastSyncDisplay();
            }
            catch (OperationCanceledException)
            {
                _logger.Debug("Application loading was cancelled");
                StatusText = "Loading cancelled";
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error loading applications");
                StatusText = $"Error: {ex.Message}";
                ModernMessageBox.Show($"Failed to load applications:\n\n{ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxIcon.Error);
            }
            finally
            {
                IsLoading = false;
                ProgressBarVisibility = Visibility.Collapsed;
                ShowSkeleton(false);
                _loadCancellation?.Dispose();
                _loadCancellation = null;
            }
        }

        /// <summary>
        /// Refreshes applications from Intune (force refresh)
        /// </summary>
        public async Task RefreshApplicationsAsync()
        {
            if (_intuneService == null)
            {
                _logger.Warning("Intune service is not initialized");
                return;
            }

            try
            {
                IsLoading = true;
                ProgressBarVisibility = Visibility.Visible;
                ShowSkeleton(true);
                StatusText = "Refreshing applications from Microsoft Intune...";

                var progress = new Progress<(int fetchedCount, int totalCount)>(update =>
                {
                    var (fetched, total) = update;
                    StatusText = $"Fetched {fetched} apps, total loaded: {total}";
                    UpdateLastSyncDisplay(inProgress: true, totalCount: total);
                });

                _allApplications = await _intuneService.GetApplicationsAsync(
                    forceRefresh: false,
                    progress: progress);

                ApplicationsLoaded = true;
                LastSyncTime = DateTime.Now;

                CurrentPage = 1;
                ApplyFiltersAndPagination();
                UpdateLastSyncDisplay();

                StatusText = $"Refreshed {_allApplications.Count} applications from Intune";
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error refreshing applications");
                StatusText = $"Error: {ex.Message}";
                ModernMessageBox.Show($"Failed to refresh applications:\n\n{ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxIcon.Error);
            }
            finally
            {
                IsLoading = false;
                ProgressBarVisibility = Visibility.Collapsed;
                ShowSkeleton(false);
            }
        }

        /// <summary>
        /// Apply search and category filters, then paginate
        /// </summary>
        public void ApplyFiltersAndPagination()
        {
            try
            {
                var filtered = _allApplications.AsEnumerable();

                if (!string.IsNullOrEmpty(SearchFilter))
                {
                    filtered = filtered.Where(app =>
                        app.DisplayName.Contains(SearchFilter, StringComparison.OrdinalIgnoreCase) ||
                        app.Publisher.Contains(SearchFilter, StringComparison.OrdinalIgnoreCase));
                }

                if (!string.IsNullOrEmpty(CategoryFilter) && CategoryFilter != AppConstants.Defaults.AllCategoriesFilter)
                {
                    filtered = filtered.Where(app =>
                        app.Category.Contains(CategoryFilter, StringComparison.OrdinalIgnoreCase));
                }

                filtered = filtered.OrderBy(app => app.DisplayName);

                var filteredList = filtered.ToList();
                TotalApplicationCount = filteredList.Count;

                var skip = (CurrentPage - 1) * PageSize;
                var pagedApps = filteredList.Skip(skip).Take(PageSize).ToList();

                Applications.Clear();
                foreach (var app in pagedApps)
                {
                    Applications.Add(app);
                }

                int maxPage = TotalApplicationCount > 0 ? (int)Math.Ceiling((double)TotalApplicationCount / PageSize) : 1;

                PageDisplayText = $"Page {CurrentPage} of {maxPage}";
                CanGoPreviousPage = CurrentPage > 1;
                CanGoNextPage = CurrentPage < maxPage;

                StatusText = $"Showing {pagedApps.Count} of {TotalApplicationCount} applications (Page {CurrentPage} of {maxPage})";

                _logger.Debug("Filter applied: {TotalCount} apps match, showing page {CurrentPage}/{MaxPage}",
                    TotalApplicationCount, CurrentPage, maxPage);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error applying filters");
                StatusText = $"Error applying filters: {ex.Message}";
            }
        }

        public void NextPage()
        {
            int maxPage = TotalApplicationCount > 0 ? (int)Math.Ceiling((double)TotalApplicationCount / PageSize) : 1;
            if (CurrentPage < maxPage)
            {
                CurrentPage++;
                ApplyFiltersAndPagination();
            }
        }

        public void PreviousPage()
        {
            if (CurrentPage > 1)
            {
                CurrentPage--;
                ApplyFiltersAndPagination();
            }
        }

        public void SetPageSize(int pageSize)
        {
            PageSize = pageSize;
            CurrentPage = 1;
        }

        public void CancelPendingOperations()
        {
            _loadCancellation?.Cancel();
            _loadCancellation?.Dispose();
            _loadCancellation = null;
        }

        public async Task<ApplicationDetail?> GetApplicationDetailAsync(string appId)
        {
            if (_intuneService == null)
            {
                _logger.Warning("Intune service is not initialized");
                return null;
            }

            try
            {
                IsLoading = true;
                StatusText = "Loading application details...";
                ProgressBarVisibility = Visibility.Visible;

                var detail = await _intuneService.GetApplicationDetailAsync(appId);
                _logger.Information("Retrieved application detail for {AppId}", appId);
                return detail;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error loading application detail");
                StatusText = "Error loading details";
                return null;
            }
            finally
            {
                IsLoading = false;
                ProgressBarVisibility = Visibility.Collapsed;
            }
        }

        public void Reset()
        {
            SearchFilter = "";
            CategoryFilter = AppConstants.Defaults.AllCategoriesFilter;
            CurrentPage = 1;
            Applications.Clear();
            _allApplications.Clear();
            ApplicationsLoaded = false;
            StatusText = "";
            _logger.Debug("ApplicationListViewModel reset");
        }

        private void ShowSkeleton(bool show)
        {
            SkeletonVisibility = show ? Visibility.Visible : Visibility.Collapsed;
            ApplicationsListVisibility = show ? Visibility.Collapsed : Visibility.Visible;
        }

        private void UpdateLastSyncDisplay(bool inProgress = false, int totalCount = 0)
        {
            if (inProgress)
            {
                var timestamp = DateTime.Now.ToString("HH:mm:ss");
                LastSyncDisplayText = $"Loading: {totalCount} apps loaded at {timestamp}";
                return;
            }

            if (!LastSyncTime.HasValue) return;

            var elapsed = DateTime.Now - LastSyncTime.Value;
            string timeText;
            if (elapsed.TotalMinutes < 1)
            {
                var timestamp = LastSyncTime.Value.ToString("HH:mm:ss");
                timeText = $"at {timestamp}";
            }
            else if (elapsed.TotalMinutes < 60)
                timeText = $"{(int)elapsed.TotalMinutes} minute{((int)elapsed.TotalMinutes > 1 ? "s" : "")} ago";
            else if (elapsed.TotalHours < 24)
                timeText = $"{(int)elapsed.TotalHours} hour{((int)elapsed.TotalHours > 1 ? "s" : "")} ago";
            else
                timeText = $"{(int)elapsed.TotalDays} day{((int)elapsed.TotalDays > 1 ? "s" : "")} ago";

            LastSyncDisplayText = $"Last sync: {timeText}";
        }
    }
}
