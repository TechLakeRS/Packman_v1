using Endpoint_Packaging_Suite.Managers;
using Endpoint_Packaging_Suite.Services;
using Serilog;
using System.Windows.Input;

namespace Endpoint_Packaging_Suite.ViewModels
{
    /// <summary>
    /// Main ViewModel that coordinates navigation and application state
    /// </summary>
    public class MainViewModel : ViewModelBase
    {
        private readonly ILogger _logger = Log.ForContext<MainViewModel>();

        private NavigationManager? _navigationManager;
        private CreatePackageViewModel? _createPackageViewModel;
        private UploadPackageViewModel? _uploadPackageViewModel;
        private ApplicationListViewModel? _applicationListViewModel;

        private string _currentPageName = "";
        private bool _isSidebarCollapsed = false;

        public NavigationManager? NavigationManager
        {
            get => _navigationManager;
            set => SetProperty(ref _navigationManager, value);
        }

        public CreatePackageViewModel? CreatePackageViewModel
        {
            get => _createPackageViewModel;
            set => SetProperty(ref _createPackageViewModel, value);
        }

        public UploadPackageViewModel? UploadPackageViewModel
        {
            get => _uploadPackageViewModel;
            set => SetProperty(ref _uploadPackageViewModel, value);
        }

        public ApplicationListViewModel? ApplicationListViewModel
        {
            get => _applicationListViewModel;
            set => SetProperty(ref _applicationListViewModel, value);
        }

        public string CurrentPageName
        {
            get => _currentPageName;
            set => SetProperty(ref _currentPageName, value);
        }

        public bool IsSidebarCollapsed
        {
            get => _isSidebarCollapsed;
            set => SetProperty(ref _isSidebarCollapsed, value);
        }

        public MainViewModel()
        {
            _logger.Debug("MainViewModel created");
        }

        /// <summary>
        /// Initialize the main view model with managers (done after UI elements are created)
        /// </summary>
        public void Initialize(
            NavigationManager navigationManager,
            CreatePackageViewModel createPackageViewModel,
            UploadPackageViewModel uploadPackageViewModel,
            ApplicationListViewModel applicationListViewModel)
        {
            NavigationManager = navigationManager;
            CreatePackageViewModel = createPackageViewModel;
            UploadPackageViewModel = uploadPackageViewModel;
            ApplicationListViewModel = applicationListViewModel;

            _logger.Information("MainViewModel initialized with managers and viewmodels");
        }

        /// <summary>
        /// Navigate to a specific page
        /// </summary>
        public void NavigateToPage(string pageName)
        {
            CurrentPageName = pageName;
            NavigationManager?.ShowPage(pageName);
            _logger.Debug("Navigated to page: {PageName}", pageName);
        }

        /// <summary>
        /// Set the active navigation button
        /// </summary>
        public void SetActiveNavigationButton(System.Windows.Controls.Button button)
        {
            NavigationManager?.SetActiveNavButton(button);
        }

        /// <summary>
        /// Toggle sidebar collapsed state
        /// </summary>
        public void ToggleSidebarCollapsed()
        {
            IsSidebarCollapsed = !IsSidebarCollapsed;
        }
    }
}
