using Endpoint_Packaging_Suite.Constants;
using Endpoint_Packaging_Suite.Helpers;
using Endpoint_Packaging_Suite.Managers;
using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite.Services;
using Endpoint_Packaging_Suite.Dialogs;
using Endpoint_Packaging_Suite.Views;
using Microsoft.Extensions.DependencyInjection;
using Serilog;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Endpoint_Packaging_Suite
{
    public partial class MainWindow
    {
        private void CreateModeToggle_Click(object sender, RoutedEventArgs e)
        {
            var accent = (System.Windows.Media.Brush)FindResource("AccentBrush");
            var onAccent = (System.Windows.Media.Brush)FindResource("OnAccentBrush");
            var surfaceAlt = (System.Windows.Media.Brush)FindResource("SurfaceAltBrush");
            var borderStrong = (System.Windows.Media.Brush)FindResource("BorderStrongBrush");
            var secondaryText = (System.Windows.Media.Brush)FindResource("TextSecondaryBrush");

            CreateModeToggle.Background = accent;
            CreateModeToggle.BorderBrush = accent;
            UpgradeModeToggle.Background = surfaceAlt;
            UpgradeModeToggle.BorderBrush = borderStrong;

            foreach (var tb in VisualTreeHelpers.FindVisualChildren<TextBlock>(CreateModeToggle))
                tb.Foreground = onAccent;
            foreach (var tb in VisualTreeHelpers.FindVisualChildren<TextBlock>(UpgradeModeToggle))
                tb.Foreground = secondaryText;

            CreateModeForm.Visibility = Visibility.Visible;
            UpgradeModeForm.Visibility = Visibility.Collapsed;

            GeneratePackageSection.Visibility = Visibility.Visible;
            UpgradePackageSection.Visibility = Visibility.Collapsed;

            // Update pipeline step 1 label
            PipelineLabel1.Text = "Generate Package";
            PipelineDesc1.Text = "Create PSADT folder structure";

            ResetPipelineState();
        }

        private void UpgradeModeToggle_Click(object sender, RoutedEventArgs e)
        {
            var accent = (System.Windows.Media.Brush)FindResource("AccentBrush");
            var onAccent = (System.Windows.Media.Brush)FindResource("OnAccentBrush");
            var surfaceAlt = (System.Windows.Media.Brush)FindResource("SurfaceAltBrush");
            var borderStrong = (System.Windows.Media.Brush)FindResource("BorderStrongBrush");
            var secondaryText = (System.Windows.Media.Brush)FindResource("TextSecondaryBrush");

            UpgradeModeToggle.Background = accent;
            UpgradeModeToggle.BorderBrush = accent;
            CreateModeToggle.Background = surfaceAlt;
            CreateModeToggle.BorderBrush = borderStrong;

            foreach (var tb in VisualTreeHelpers.FindVisualChildren<TextBlock>(UpgradeModeToggle))
                tb.Foreground = onAccent;
            foreach (var tb in VisualTreeHelpers.FindVisualChildren<TextBlock>(CreateModeToggle))
                tb.Foreground = secondaryText;

            CreateModeForm.Visibility = Visibility.Collapsed;
            UpgradeModeForm.Visibility = Visibility.Visible;

            GeneratePackageSection.Visibility = Visibility.Collapsed;
            UpgradePackageSection.Visibility = Visibility.Visible;

            // Update pipeline step 1 label
            PipelineLabel1.Text = "Upgrade Package";
            PipelineDesc1.Text = "Create new version with existing logic";

            ResetPipelineState();
        }

        private async void BrowseUpgradePackage_Click(object sender, RoutedEventArgs e)
        {
            // Default to IntuneApplications network path
            var intuneAppsPath = _settingsService?.Settings?.NetworkPaths?.IntuneApplications;

            var folderDialog = new System.Windows.Forms.FolderBrowserDialog
            {
                Description = "Select existing PSADT package folder",
                ShowNewFolderButton = false,
                SelectedPath = !string.IsNullOrEmpty(intuneAppsPath) && Directory.Exists(intuneAppsPath) ? intuneAppsPath : ""
            };

            if (folderDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                var packagePath = folderDialog.SelectedPath;

                // Check if PSADT script exists (v3 or v4)
                var applicationFolder = Path.Combine(packagePath, "Application");
                var scriptInRoot = FolderBrowserHelper.GetPSADTScriptPath(packagePath);
                var scriptInAppFolder = FolderBrowserHelper.GetPSADTScriptPath(applicationFolder);

                if (string.IsNullOrEmpty(scriptInRoot) && string.IsNullOrEmpty(scriptInAppFolder))
                {
                    ModernMessageBox.Show(
                        "This doesn't appear to be a valid PSADT package folder.\n\n" +
                        "Could not find PSADT script (Invoke-AppDeployToolkit.ps1 or Deploy-Application.ps1)",
                        "Invalid Package",
                        MessageBoxButton.OK,
                        MessageBoxIcon.Warning);
                    return;
                }

                if (_upgradePackageViewModel != null)
                {
                    _upgradePackageViewModel.PackagePath = packagePath;
                }

                // Try to load metadata
                await LoadUpgradePackageMetadataAsync(packagePath);
            }
        }

        private async Task LoadUpgradePackageMetadataAsync(string packagePath)
        {
            try
            {
                // Always extract from PSADT script - no metadata.json files needed (supports v3 and v4)
                var applicationFolder = Path.Combine(packagePath, "Application");
                var scriptPath = FolderBrowserHelper.GetPSADTScriptPath(applicationFolder);
                if (string.IsNullOrEmpty(scriptPath) || !File.Exists(scriptPath))
                {
                    if (_upgradePackageViewModel != null)
                    {
                        _upgradePackageViewModel.PackageDisplayName = Path.GetFileName(packagePath);
                        _upgradePackageViewModel.PackageDisplayVersion = "PSADT script not found";
                        _upgradePackageViewModel.PackageDisplayContext = "Cannot load package info";
                    }
                    UpgradePackageInfoPanel.Visibility = Visibility.Visible;

                    ModernMessageBox.Show(
                        "PSADT script not found in this package.\n\nCannot upgrade this package.",
                        "Script Not Found",
                        MessageBoxButton.OK,
                        MessageBoxIcon.Error);
                    return;
                }

                var scriptMetadata = MetadataExtractor.ExtractMetadataFromScript(scriptPath);
                var manufacturer = scriptMetadata.GetValueOrDefault("Vendor", "");
                var appName = scriptMetadata.GetValueOrDefault("AppName", "");
                var version = scriptMetadata.GetValueOrDefault("Version", "");

                // Extract install context from AppDeployToolkitConfig.xml
                var installContext = InstallContextParser.ExtractFromPackage(packagePath);

                if (_upgradePackageViewModel != null)
                {
                    _upgradePackageViewModel.LoadedMetadata = new PackageMetadata
                    {
                        Manufacturer = manufacturer,
                        AppName = appName,
                        Version = version,
                        InstallContext = installContext
                    };
                    _upgradePackageViewModel.PackageDisplayName = $"{manufacturer} {appName}";
                    _upgradePackageViewModel.PackageDisplayVersion = version != "" ? $"Version {version}" : "Version unknown";
                    _upgradePackageViewModel.PackageDisplayContext = $"{installContext} Install";
                }

                // Try to load icon from Icon folder
                await TryLoadUpgradeIconAsync(packagePath);

                UpgradePackageInfoPanel.Visibility = Visibility.Visible;
                Debug.WriteLine($"Extracted metadata from script: {manufacturer} {appName} v{version}, Context: {installContext}");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error loading upgrade package metadata: {ex.Message}");
                ModernMessageBox.Show(
                    $"Error loading package metadata:\n\n{ex.Message}",
                    "Load Error",
                    MessageBoxButton.OK,
                    MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Try to load icon from Icon folder by scanning for image files
        /// </summary>
        private async Task TryLoadUpgradeIconAsync(string packagePath)
        {
            try
            {
                var iconFolder = Path.Combine(packagePath, "Icon");
                if (!Directory.Exists(iconFolder))
                {
                    Debug.WriteLine("Icon folder not found");
                    return;
                }

                // Look for common icon file extensions
                var iconExtensions = new[] { "*.png", "*.ico", "*.jpg", "*.jpeg" };
                string? iconPath = null;

                foreach (var ext in iconExtensions)
                {
                    var files = Directory.GetFiles(iconFolder, ext);
                    if (files.Length > 0)
                    {
                        iconPath = files[0]; // Use first icon found
                        break;
                    }
                }

                if (iconPath != null && File.Exists(iconPath))
                {
                    await Task.Run(() =>
                    {
                        Dispatcher.Invoke(() =>
                        {
                            var bitmap = new System.Windows.Media.Imaging.BitmapImage();
                            bitmap.BeginInit();
                            bitmap.CacheOption = System.Windows.Media.Imaging.BitmapCacheOption.OnLoad;
                            bitmap.UriSource = new Uri(iconPath);
                            bitmap.EndInit();
                            UpgradePackageIcon.Source = bitmap;

                            // Store icon filename for later use
                            if (_upgradePackageViewModel?.LoadedMetadata != null)
                            {
                                _upgradePackageViewModel.LoadedMetadata.IconFileName = Path.GetFileName(iconPath);
                            }
                        });
                    });
                    Debug.WriteLine($"Loaded icon from: {iconPath}");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error loading icon: {ex.Message}");
            }
        }

        private void UpgradeExistingPackage_TextChanged(object sender, TextChangedEventArgs e)
        {
            ValidateUpgradeForm();
        }

        private void UpgradeForm_TextChanged(object sender, TextChangedEventArgs e)
        {
            ValidateUpgradeForm();
        }

        private void BrowseUpgradeSource_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new Microsoft.Win32.OpenFileDialog
            {
                Title = "Select New Source File",
                Filter = "All Supported Files (*.msi;*.exe)|*.msi;*.exe|MSI Files (*.msi)|*.msi|EXE Files (*.exe)|*.exe|All Files (*.*)|*.*",
                FilterIndex = 1
            };

            // Set default browse location from settings if configured
            var defaultBrowsePath = _settingsService?.Settings?.NetworkPaths?.DefaultPackageBrowsePath;
            if (!string.IsNullOrEmpty(defaultBrowsePath) && Directory.Exists(defaultBrowsePath))
            {
                openFileDialog.InitialDirectory = defaultBrowsePath;
            }

            if (openFileDialog.ShowDialog() == true)
            {
                UpgradeNewSourceTextBox.Text = openFileDialog.FileName;
                string fileExtension = Path.GetExtension(openFileDialog.FileName).ToLower();

                // Auto-populate version from source file
                if (fileExtension == ".msi")
                {
                    try
                    {
                        var msiInfo = MsiInfoService.ExtractMsiInfo(openFileDialog.FileName);
                        if (msiInfo.IsValid && !string.IsNullOrEmpty(msiInfo.ProductVersion))
                        {
                            UpgradeNewVersionTextBox.Text = msiInfo.ProductVersion;
                            Debug.WriteLine($"Auto-populated version from MSI: {msiInfo.ProductVersion}");
                        }
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"Error extracting version from MSI: {ex.Message}");
                    }
                }
                else if (fileExtension == ".exe")
                {
                    try
                    {
                        var (productName, companyName, version) = MetadataExtractor.ExtractExeMetadata(openFileDialog.FileName);

                        // Try to extract version from filename if file version seems incomplete
                        // Example: VMware-VMRC-13.0.1.0.24954779.exe should give 13.0.1.0.24954779
                        string fileName = Path.GetFileNameWithoutExtension(openFileDialog.FileName);
                        string filenameVersion = MetadataExtractor.ExtractVersionFromFilename(fileName);

                        // Use filename version if it's longer/more complete than file metadata version
                        if (!string.IsNullOrEmpty(filenameVersion) &&
                            (string.IsNullOrEmpty(version) || filenameVersion.Length > version.Length))
                        {
                            UpgradeNewVersionTextBox.Text = filenameVersion;
                            Debug.WriteLine($"Auto-populated version from filename: {filenameVersion}");
                        }
                        else if (!string.IsNullOrEmpty(version))
                        {
                            UpgradeNewVersionTextBox.Text = version;
                            Debug.WriteLine($"Auto-populated version from EXE metadata: {version}");
                        }
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"Error extracting version from EXE: {ex.Message}");
                    }
                }
            }
        }

        private void ValidateUpgradeForm()
        {
            bool isValid = !string.IsNullOrWhiteSpace(UpgradeExistingPackageTextBox.Text) &&
                           Directory.Exists(UpgradeExistingPackageTextBox.Text) &&
                           !string.IsNullOrWhiteSpace(UpgradeNewVersionTextBox.Text) &&
                           !string.IsNullOrWhiteSpace(UpgradeNewSourceTextBox.Text) &&
                           File.Exists(UpgradeNewSourceTextBox.Text);

            UpgradePackageButton.IsEnabled = isValid;
        }

        private async void UpgradePackageButton_Click(object sender, RoutedEventArgs e)
        {
            string newVersion = UpgradeNewVersionTextBox.Text.Trim();
            string newSourcePath = UpgradeNewSourceTextBox.Text.Trim();
            string existingPackagePath = UpgradeExistingPackageTextBox.Text.Trim();

            // Validate package path
            if (!Directory.Exists(existingPackagePath))
            {
                ModernMessageBox.Show(
                    "Package folder not found.",
                    "Invalid Path",
                    MessageBoxButton.OK,
                    MessageBoxIcon.Error);
                return;
            }

            // Find PSADT script (v3 or v4)
            var applicationFolder = Path.Combine(existingPackagePath, "Application");
            var deployScriptPath = FolderBrowserHelper.GetPSADTScriptPath(applicationFolder)
                ?? FolderBrowserHelper.GetPSADTScriptPath(existingPackagePath);

            if (string.IsNullOrEmpty(deployScriptPath) || !File.Exists(deployScriptPath))
            {
                ModernMessageBox.Show(
                    "PSADT script not found in the package.",
                    "Script Not Found",
                    MessageBoxButton.OK,
                    MessageBoxIcon.Error);
                return;
            }

            // Confirm upgrade
            var loadedMetadata = _upgradePackageViewModel?.LoadedMetadata;
            var result = ModernMessageBox.Show(
                $"This will create a new package version:\n\n" +
                $"Package: {(loadedMetadata != null ? $"{loadedMetadata.Manufacturer} {loadedMetadata.AppName}" : Path.GetFileName(existingPackagePath))}\n" +
                $"From Version: {(loadedMetadata?.Version ?? "Unknown")}\n" +
                $"To Version: {newVersion}\n\n" +
                $"The install/uninstall logic will be copied from the existing package.\n" +
                $"File paths will be updated to use the new sources.\n\n" +
                $"Continue?",
                "Confirm Upgrade",
                MessageBoxButton.YesNo,
                MessageBoxIcon.Question);

            if (result != MessageBoxResult.Yes)
                return;

            try
            {
                // Disable button and show progress
                UpgradePackageButton.IsEnabled = false;
                UpgradePackageButton.Content = "Creating...";

                // Show notification
                var notificationId = _notificationService!.ShowInProgress(
                    "Creating New Version",
                    $"Building v{newVersion} package with existing logic...",
                    0
                );

                // Perform the upgrade
                var upgradeService = new PackageUpgradeService();
                string newPackagePath = await upgradeService.UpgradePackageAsync(
                    existingPackagePath,
                    newVersion,
                    newSourcePath
                );

                // Copy icon if available from metadata
                string savedIconFileName = "";
                if (loadedMetadata != null && !string.IsNullOrEmpty(loadedMetadata.IconFileName))
                {
                    try
                    {
                        var sourceIconPath = Path.Combine(existingPackagePath, "Icon", loadedMetadata.IconFileName);
                        if (File.Exists(sourceIconPath))
                        {
                            var iconFolder = Path.Combine(newPackagePath, "Icon");
                            if (Directory.Exists(iconFolder))
                            {
                                var destinationPath = Path.Combine(iconFolder, loadedMetadata.IconFileName);
                                File.Copy(sourceIconPath, destinationPath, overwrite: true);
                                savedIconFileName = loadedMetadata.IconFileName;

                                // Set the extracted icon path and display it in Create Mode
                                _extractedIconPath = destinationPath;
                                DisplayIcon(CreateModeIconImage, CreateModeIconPreview, _extractedIconPath);

                                Debug.WriteLine($"Icon copied from existing package: {destinationPath}");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"Error copying icon to upgraded package: {ex.Message}");
                    }
                }

                // No metadata.json saving - everything extracted from PSADT script

                // Update notification
                _notificationService!.UpdateProgress(notificationId, 100, "New version created");
                _notificationService!.CloseToast(notificationId);
                _notificationService!.ShowSuccess(
                    "New Version Created",
                    $"Version {newVersion} package created successfully"
                );

                // Show success status
                UpgradeStatusPanel.Visibility = Visibility.Visible;
                UpgradeStatusText.Text = $"New package version {newVersion} created";
                UpgradePathText.Text = newPackagePath;

                // Advance to "Open Script" step
                AdvancePipeline(2);

                // Set package path so Upload to Intune and Open Script buttons work
                _createPackageViewModel?.SetPackagePath(newPackagePath);

                // Carry the source app id so the upload writes a supersedence relationship
                if (_createPackageViewModel != null)
                {
                    _createPackageViewModel.PredecessorAppId =
                        NetworkShareHelper.GetMarkerAppId(existingPackagePath);
                }

                // Populate Create Mode form fields with upgraded package metadata
                // This ensures Upload to Intune has the correct metadata
                if (loadedMetadata != null && _createPackageViewModel != null)
                {
                    _createPackageViewModel.AppName = loadedMetadata.AppName;
                    _createPackageViewModel.Manufacturer = loadedMetadata.Manufacturer;
                    _createPackageViewModel.Version = newVersion;
                    _createPackageViewModel.SourcesPath = newSourcePath;
                    _createPackageViewModel.UserInstall =
                        loadedMetadata.InstallContext?.Equals("User", StringComparison.OrdinalIgnoreCase) == true;

                    // Extract MSI info if the new source is an MSI file
                    if (Path.GetExtension(newSourcePath).Equals(".msi", StringComparison.OrdinalIgnoreCase))
                    {
                        try
                        {
                            _currentMsiInfo = MsiInfoService.ExtractMsiInfo(newSourcePath);
                            Debug.WriteLine($"Extracted MSI info for upgraded package");
                        }
                        catch (Exception ex)
                        {
                            Debug.WriteLine($"Error extracting MSI info for upgraded package: {ex.Message}");
                            _currentMsiInfo = null;
                        }
                    }
                    else
                    {
                        _currentMsiInfo = null;
                    }

                    Debug.WriteLine($"Populated Create Mode fields with upgraded package metadata");
                }

                // Reset button
                UpgradePackageButton.Content = "Upgrade Package";
                UpgradePackageButton.IsEnabled = true;

                // Clear new-version inputs (existing package selection is preserved)
                _upgradePackageViewModel?.ResetNewVersionInputs();
            }
            catch (Exception ex)
            {
                _notificationService!.ShowError(
                    "Upgrade Failed",
                    ex.Message
                );

                ModernMessageBox.Show(
                    $"Error upgrading package:\n\n{ex.Message}",
                    "Upgrade Error",
                    MessageBoxButton.OK,
                    MessageBoxIcon.Error);

                UpgradePackageButton.IsEnabled = true;
                UpgradePackageButton.Content = "Upgrade Package";
            }
        }

        private void OpenUpgradedPackageFolder_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(UpgradePathText.Text) && Directory.Exists(UpgradePathText.Text))
            {
                Process.Start("explorer.exe", UpgradePathText.Text);
            }
        }

    }
}
