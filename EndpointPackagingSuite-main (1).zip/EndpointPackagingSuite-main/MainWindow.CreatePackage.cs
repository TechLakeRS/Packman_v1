using Endpoint_Packaging_Suite.Constants;
using Endpoint_Packaging_Suite.Helpers;
using Endpoint_Packaging_Suite.Managers;
using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite.Services;
using Endpoint_Packaging_Suite.Dialogs;
using Endpoint_Packaging_Suite.Views;
using Microsoft.Extensions.DependencyInjection;
using Serilog;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Endpoint_Packaging_Suite
{
    public partial class MainWindow
    {
        private int _currentPipelineStep = 1;

        private const string SystemInstallHelpText =
            "Installs for all users with elevated privileges (most common for managed apps).";
        private const string UserInstallHelpText =
            "Installs only for the current user, without requiring elevation.";

        private void SyncInstallContextToggles()
        {
            bool isUser = _createPackageViewModel?.UserInstall ?? false;
            SystemInstallToggle.IsChecked = !isUser;
            UserInstallToggle.IsChecked = isUser;
            InstallContextHelp.Text = isUser ? UserInstallHelpText : SystemInstallHelpText;
        }

        private void SystemInstallToggle_Click(object sender, RoutedEventArgs e)
        {
            SystemInstallToggle.IsChecked = true;
            UserInstallToggle.IsChecked = false;
            if (_createPackageViewModel != null)
                _createPackageViewModel.UserInstall = false;
            InstallContextHelp.Text = SystemInstallHelpText;
        }

        private void UserInstallToggle_Click(object sender, RoutedEventArgs e)
        {
            UserInstallToggle.IsChecked = true;
            SystemInstallToggle.IsChecked = false;
            if (_createPackageViewModel != null)
                _createPackageViewModel.UserInstall = true;
            InstallContextHelp.Text = UserInstallHelpText;
        }

        private void BrowseSourcesButton_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new Microsoft.Win32.OpenFileDialog
            {
                Title = "Select Application Source File",
                Filter = "All Supported Files (*.msi;*.exe)|*.msi;*.exe|MSI Files (*.msi)|*.msi|EXE Files (*.exe)|*.exe|All Files (*.*)|*.*",
                FilterIndex = 1
            };

            // Set default browse location from settings if configured
            var defaultBrowsePath = _settingsService?.Settings?.NetworkPaths?.DefaultPackageBrowsePath;
            if (!string.IsNullOrEmpty(defaultBrowsePath) && Directory.Exists(defaultBrowsePath))
            {
                openFileDialog.InitialDirectory = defaultBrowsePath;
            }

            if (openFileDialog.ShowDialog() == true)
            {
                string selectedFile = openFileDialog.FileName;
                string fileName = Path.GetFileName(selectedFile);
                string fileExtension = Path.GetExtension(selectedFile).ToLower();

                SourcesPathTextBox.Text = selectedFile;
                DetectPackageType(fileExtension, fileName);

                // Enhanced metadata extraction with MSI detection
                if (fileExtension == ".msi")
                {
                    ExtractMsiMetadataEnhanced(selectedFile);
                }
                else
                {
                    ExtractFileMetadata(selectedFile);
                }

                // Extract and display icon
                _extractedIconPath = ExtractAndSaveIcon(selectedFile) ?? "";
                DisplayIcon(CreateModeIconImage, CreateModeIconPreview, _extractedIconPath);
            }
        }

        private async void GenerateButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Disable button to prevent double-click
                GenerateButton.IsEnabled = false;
                ProgressBar.Visibility = Visibility.Visible;
                StatusText.Text = "Generating package...";

                // Validate inputs on UI thread (needs to read UI controls)
                if (!ValidatePackageInputs())
                {
                    return;
                }

                // VM input properties are kept in sync via two-way bindings; sync MSI info
                if (_createPackageViewModel != null)
                {
                    _createPackageViewModel.CurrentMsiInfo = _currentMsiInfo;
                }

                string installContext = (UserInstallToggle.IsChecked ?? false) ? "User" : "System";
                var appInfo = _createPackageViewModel?.CreateApplicationInfo(installContext);

                var psadtOptions = _createPackageViewModel?.CollectPSADTOptions(DetectedPackageType);

                // Check if validation failed
                if (psadtOptions == null)
                {
                    StatusText.Text = "Package generation cancelled - fix conflicts";
                    return;
                }

                // Run package creation on background thread
                var generator = new PSADTGenerator();
                string? packagePath = null;

                await Task.Run(async () =>
                {
                    packagePath = await generator.CreatePackageAsync(appInfo, psadtOptions)
                        .ConfigureAwait(false);

                    // Copy extracted icon to package Icon folder
                    string savedIconFileName = "";
                    if (!string.IsNullOrEmpty(packagePath) && !string.IsNullOrEmpty(_extractedIconPath))
                    {
                        bool iconCopied = IconExtractor.CopyIconToPackage(_extractedIconPath, packagePath, appInfo.Name);
                        if (iconCopied)
                        {
                            // Sanitize app name for filename (same logic as IconExtractor)
                            var invalidChars = Path.GetInvalidFileNameChars();
                            var sanitized = string.Join("_", appInfo.Name.Split(invalidChars, StringSplitOptions.RemoveEmptyEntries));
                            savedIconFileName = $"{(string.IsNullOrEmpty(sanitized) ? "app" : sanitized)}_icon.png";
                        }
                    }

                    // No metadata.json saving - everything extracted from PSADT script
                }).ConfigureAwait(false);

                // Store the result on the ViewModel
                _createPackageViewModel?.SetPackagePath(packagePath ?? "");

                // Update UI on UI thread
                await Dispatcher.InvokeAsync(() =>
                {
                    _createPackageViewModel?.SetPSADTOptions(psadtOptions!);
                    PackageCreationHelper.ShowPackageSuccess(
                        PackageStatusPanel,
                        PackageStatusText,
                        StatusText,
                        PackagePathText,
                        OpenPackageFolderButton,
                        ProgressBar,
                        packagePath ?? "",
                        psadtOptions);
                    StatusText.Text = $"Package created successfully • {DateTime.Now:HH:mm:ss}";
                    AdvancePipeline(2);
                });
            }
            catch (Exception ex)
            {
                // Handle errors on UI thread
                await Dispatcher.InvokeAsync(() =>
                {
                    ModernMessageBox.Show($"Error generating package: {ex.Message}", "Error",
                        MessageBoxButton.OK, MessageBoxIcon.Error);
                    StatusText.Text = "Package generation failed";
                });
            }
            finally
            {
                // Ensure UI cleanup happens on UI thread
                await Dispatcher.InvokeAsync(() =>
                {
                    GenerateButton.IsEnabled = true;
                    ProgressBar.Visibility = Visibility.Collapsed;
                });
            }
        }

        private async void UploadButton_Click(object sender, RoutedEventArgs e)

        {

            try

            {

                string? packagePath = _createPackageViewModel?.CurrentPackagePath;



                if (string.IsNullOrEmpty(packagePath))

                {

                    ModernMessageBox.Show("Please generate a package first.", "No Package",

                        MessageBoxButton.OK, MessageBoxIcon.Warning);

                    return;

                }



                // Extract install context from the package's AppDeployToolkitConfig.xml
                var installContext = InstallContextParser.ExtractFromPackage(packagePath);
                Debug.WriteLine($"📋 Extracted install context from package config: '{installContext}'");

                if (_createPackageViewModel != null)
                {
                    _createPackageViewModel.CurrentMsiInfo = _currentMsiInfo;
                }

                var appInfo = _createPackageViewModel?.CreateApplicationInfo(installContext);



                if (appInfo == null) return;



                // Create toast notification BEFORE showing wizard
                var notificationId = _notificationService!.ShowInProgress(
                    $"Uploading {appInfo.Name}",
                    "Starting upload...",
                    0
                );

                var uploadWizard = new IntuneUploadWizard

                {

                    Owner = this,

                    ApplicationInfo = appInfo,

                    PackagePath = packagePath,

                    NotificationId = notificationId,  // Pass notification ID to wizard

                    PredecessorAppId = _createPackageViewModel?.PredecessorAppId

                };



                // Pre-populate detection rules if available from package metadata
                var cachedRules = DetectionRulesCache.GetRulesFromPackage(packagePath, out string computerName);
                if (cachedRules != null && cachedRules.Count > 0)
                {
                    Debug.WriteLine($"Using {cachedRules.Count} cached detection rules from package metadata (discovered on {computerName})");
                    var rulesCollection = new ObservableCollection<DetectionRule>(cachedRules);
                    uploadWizard.UpdateDetectionRules(rulesCollection);
                }

                // If MSI, show a tooltip about auto-detection

                if (appInfo.IsMsiPackage)

                {

                    Debug.WriteLine($"Opening upload wizard with MSI Product Code: {appInfo.MsiProductCode}");

                }



                // Show wizard - it will handle upload and show toast notifications

                // Wizard now closes immediately after starting background upload

                if (uploadWizard.ShowDialog() == true)

                {

                    // Upload wizard completed setup - reset form so user can continue working

                    ResetUploadExistingForm();



                    // Upload is running in background via ReviewUploadStep

                    // Toast notifications are shown automatically

                }


            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error opening upload wizard: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxIcon.Error);
            }
        }

        private void SourcesPath_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (!string.IsNullOrEmpty(SourcesPathTextBox.Text) && File.Exists(SourcesPathTextBox.Text))
            {
                PSADTConfigSection.Visibility = Visibility.Visible;

                var extension = Path.GetExtension(SourcesPathTextBox.Text).ToLower();
                DetectedPackageTypeIcon.Text = extension switch
                {
                    ".msi" => "\uE7B8",  // Package icon
                    ".exe" => "\uE756",  // Executable icon
                    _ => "\uE897"        // Unknown icon
                };

                DetectedPackageTypeText.Text = extension switch
                {
                    ".msi" => "MSI Package",
                    ".exe" => "EXE Installer",
                    _ => "Unknown Package Type"
                };
            }
        }

        private void ConfigurePSADT_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new PSADTConfigDialog();
            dialog.Owner = this;

            // Pass package info including source file name and product code
            var sourceFileName = !string.IsNullOrEmpty(SourcesPathTextBox.Text)
                ? Path.GetFileName(SourcesPathTextBox.Text)
                : "";
            var msiProductCode = _currentMsiInfo?.ProductCode ?? "";

            dialog.SetPackageInfo(
                ManufacturerTextBox.Text,
                AppNameTextBox.Text,
                VersionTextBox.Text,
                DetectedPackageType,
                sourceFileName,
                msiProductCode);

            // Load existing options if any
            var currentOptions = _createPackageViewModel?.CurrentPSADTOptions;
            if (currentOptions != null)
                dialog.LoadOptions(currentOptions);

            if (dialog.ShowDialog() == true)
            {
                _createPackageViewModel?.SetPSADTOptions(dialog.SelectedOptions);
                PackageCreationHelper.UpdatePSADTSummary(
                    dialog.SelectedOptions,
                    PSADTStatusText,
                    SelectedOptionsCount,
                    EstimatedScriptSize,
                    InjectionCount,
                    PSADTSummaryPanel,
                    ConfigurePSADTButton);
                UpdatePSADTOptionTags(dialog.SelectedOptions);
            }
        }

        private void UpdatePSADTOptionTags(PSADTOptions? options)
        {
            PSADTOptionTagsWrap.Children.Clear();

            if (options == null || options.GetEnabledOptionsCount() == 0)
            {
                PSADTOptionsTagsPanel.Visibility = Visibility.Collapsed;
                return;
            }

            // Display function names as tags, grouped by count per phase
            var functionNames = options.GetAllFunctionNames();
            var grouped = functionNames.GroupBy(n => n)
                .Select(g => (name: g.Key, count: g.Count()))
                .OrderBy(x => x.name);

            foreach (var (name, count) in grouped)
            {
                var tag = new System.Windows.Controls.Border
                {
                    Background = (System.Windows.Media.Brush)FindResource("PrimaryMutedBrush"),
                    CornerRadius = new CornerRadius(12),
                    Padding = new Thickness(10, 3, 10, 3),
                    Margin = new Thickness(0, 0, 6, 6)
                };

                var label = count > 1 ? $"\u2713 {name} ({count})" : $"\u2713 {name}";
                var text = new TextBlock
                {
                    Text = label,
                    FontSize = 11,
                    FontWeight = FontWeights.Medium,
                    Foreground = (System.Windows.Media.Brush)FindResource("PrimaryBrush")
                };

                tag.Child = text;
                PSADTOptionTagsWrap.Children.Add(tag);
            }

            PSADTOptionsTagsPanel.Visibility = PSADTOptionTagsWrap.Children.Count > 0
                ? Visibility.Visible
                : Visibility.Collapsed;
        }

        private void ResetPipelineState()
        {
            _currentPipelineStep = 1;
            UpdatePipelineUI();
        }

        public void AdvancePipeline(int toStep)
        {
            if (toStep > _currentPipelineStep)
            {
                _currentPipelineStep = toStep;
                UpdatePipelineUI();
            }
        }

        private void UpdatePipelineUI()
        {
            var steps = new[] { PipelineStep1, PipelineStep2, PipelineStep3, PipelineStep4 };
            var circles = new[] { PipelineCircle1, PipelineCircle2, PipelineCircle3, PipelineCircle4 };
            var connectors = new[] { PipelineConnector1, PipelineConnector2, PipelineConnector3 };
            var labels = new[] { PipelineLabel1, PipelineLabel2, PipelineLabel3, PipelineLabel4 };
            var skipLinks = new TextBlock?[] { null, PipelineSkip2, PipelineSkip3, null };

            var accentBrush = (System.Windows.Media.Brush)FindResource("AccentBrush");
            var accentSoftBrush = (System.Windows.Media.Brush)FindResource("AccentSoftBrush");
            var accentLineBrush = (System.Windows.Media.Brush)FindResource("AccentLineBrush");
            var onAccentBrush = (System.Windows.Media.Brush)FindResource("OnAccentBrush");
            var successBrush = (System.Windows.Media.Brush)FindResource("SuccessBrush");
            var successSoftBrush = (System.Windows.Media.Brush)FindResource("SuccessSoftBrush");
            var surfaceBrush = (System.Windows.Media.Brush)FindResource("Surface4dpBrush");
            var borderBrush = (System.Windows.Media.Brush)FindResource("BorderStrongBrush");

            for (int i = 0; i < 4; i++)
            {
                var stepNum = i + 1;
                var isComplete = stepNum < _currentPipelineStep;
                var isActive = stepNum == _currentPipelineStep;
                var isLocked = stepNum > _currentPipelineStep;

                steps[i].Opacity = isLocked ? 0.65 : 1.0;
                steps[i].Background = isActive ? accentSoftBrush : System.Windows.Media.Brushes.Transparent;
                steps[i].BorderBrush = isActive ? accentLineBrush : System.Windows.Media.Brushes.Transparent;
                steps[i].BorderThickness = new Thickness(1);

                labels[i].Foreground = isActive
                    ? (System.Windows.Media.Brush)FindResource("TextPrimaryBrush")
                    : (System.Windows.Media.Brush)FindResource("TextSecondaryBrush");

                // Text — always use theme brushes, no colored backgrounds to conflict
                var textPrimary = (System.Windows.Media.Brush)FindResource("TextPrimaryBrush");
                var textSecondary = (System.Windows.Media.Brush)FindResource("TextSecondaryBrush");

                if (isComplete)
                {
                    circles[i].Background = successSoftBrush;
                    circles[i].BorderBrush = successBrush;
                    circles[i].BorderThickness = new Thickness(1.5);
                    circles[i].Effect = null;
                    var circleText = VisualTreeHelpers.FindVisualChild<TextBlock>(circles[i]);
                    if (circleText != null) { circleText.Text = "\uE73E"; circleText.FontFamily = new System.Windows.Media.FontFamily("Segoe MDL2 Assets"); circleText.FontSize = 14; circleText.Foreground = successBrush; }
                }
                else if (isActive)
                {
                    circles[i].Background = accentBrush;
                    circles[i].BorderBrush = accentBrush;
                    circles[i].BorderThickness = new Thickness(1.5);
                    circles[i].Effect = new System.Windows.Media.Effects.DropShadowEffect
                    {
                        Color = System.Windows.Media.Color.FromRgb(0x21, 0xB8, 0xAE),
                        Opacity = 0.35,
                        BlurRadius = 10,
                        ShadowDepth = 0
                    };
                    var circleText = VisualTreeHelpers.FindVisualChild<TextBlock>(circles[i]);
                    if (circleText != null) { circleText.Text = stepNum.ToString(); circleText.FontFamily = new System.Windows.Media.FontFamily("Segoe UI"); circleText.FontSize = 13; circleText.Foreground = onAccentBrush; }
                }
                else
                {
                    circles[i].Background = surfaceBrush;
                    circles[i].BorderBrush = borderBrush;
                    circles[i].BorderThickness = new Thickness(1.5);
                    circles[i].Effect = null;
                    var circleText = VisualTreeHelpers.FindVisualChild<TextBlock>(circles[i]);
                    if (circleText != null) { circleText.Text = stepNum.ToString(); circleText.FontFamily = new System.Windows.Media.FontFamily("Segoe UI"); circleText.FontSize = 13; circleText.Foreground = (System.Windows.Media.Brush)FindResource("TextSecondaryBrush"); }
                }

                // Connectors
                if (i < 3)
                {
                    connectors[i].BorderBrush = isComplete ? successBrush : borderBrush;
                }

                // Skip links (only for optional steps 2 and 3)
                if (skipLinks[i] != null)
                {
                    skipLinks[i]!.Visibility = isActive ? Visibility.Visible : Visibility.Collapsed;
                }
            }

            // Show/hide action buttons based on current step
            var isCreateMode = CreateModeForm.Visibility == Visibility.Visible;
            GeneratePackageSection.Visibility = _currentPipelineStep == 1 && isCreateMode ? Visibility.Visible : Visibility.Collapsed;
            UpgradePackageSection.Visibility = _currentPipelineStep == 1 && !isCreateMode ? Visibility.Visible : Visibility.Collapsed;
            OpenScriptButton.Visibility = _currentPipelineStep == 2 ? Visibility.Visible : Visibility.Collapsed;
            btnRemoteTest.Visibility = _currentPipelineStep == 3 ? Visibility.Visible : Visibility.Collapsed;
            UploadButton.Visibility = _currentPipelineStep == 4 ? Visibility.Visible : Visibility.Collapsed;

            // Show skip button for optional steps (2 and 3)
            PipelineSkipButton.Visibility = (_currentPipelineStep == 2 || _currentPipelineStep == 3)
                ? Visibility.Visible : Visibility.Collapsed;

            // Show back button when not on step 1
            PipelineBackButton.Visibility = _currentPipelineStep > 1
                ? Visibility.Visible : Visibility.Collapsed;
        }

        private void PipelineSkip_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            AdvancePipeline(_currentPipelineStep + 1);
        }

        private void PipelineSkipButton_Click(object sender, RoutedEventArgs e)
        {
            AdvancePipeline(_currentPipelineStep + 1);
        }

        private void PipelineBackButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentPipelineStep > 1)
            {
                _currentPipelineStep--;
                UpdatePipelineUI();
            }
        }

        private void DetectPackageType(string extension, string fileName)
        {
            PSADTConfigSection.Visibility = Visibility.Visible;

            if (extension == ".msi")
            {
                DetectedPackageTypeIcon.Text = "\uE7B8";  // Package icon
                DetectedPackageTypeText.Text = "MSI Package";
            }
            else if (extension == ".exe")
            {
                DetectedPackageTypeIcon.Text = "\uE756";  // Executable icon
                DetectedPackageTypeText.Text = "EXE Installer";
            }
            else
            {
                PSADTConfigSection.Visibility = Visibility.Collapsed;
                DetectedPackageTypeIcon.Text = "\uE897";  // Unknown icon
                DetectedPackageTypeText.Text = "Other package type";
            }
        }

        private void ExtractFileMetadata(string filePath)
        {
            try
            {
                string extension = Path.GetExtension(filePath).ToLower();

                if (extension == ".msi")
                {
                    ExtractMsiMetadata(filePath);
                }
                else if (extension == ".exe")
                {
                    ExtractExeMetadata(filePath);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Metadata extraction failed: {ex.Message}");
                ExtractMetadataFromFilename(filePath);
            }
        }

        private void ExtractMsiMetadata(string msiPath)
        {
            try
            {
                var msiInfo = MsiInfoService.ExtractMsiInfo(msiPath);

                if (string.IsNullOrWhiteSpace(AppNameTextBox.Text) && !string.IsNullOrWhiteSpace(msiInfo.ProductName))
                    AppNameTextBox.Text = msiInfo.ProductName;

                if (string.IsNullOrWhiteSpace(ManufacturerTextBox.Text) && !string.IsNullOrWhiteSpace(msiInfo.Manufacturer))
                    ManufacturerTextBox.Text = msiInfo.Manufacturer;

                if (string.IsNullOrWhiteSpace(VersionTextBox.Text) && !string.IsNullOrWhiteSpace(msiInfo.ProductVersion))
                    VersionTextBox.Text = msiInfo.ProductVersion;

                if (!string.IsNullOrWhiteSpace(msiInfo.ProductCode))
                {
                    _msiProductCode = msiInfo.ProductCode;
                    _msiProductVersion = msiInfo.ProductVersion;
                }
            }
            catch (Exception ex)
            {
                Log.Warning(ex, "MSI metadata extraction failed");
                ExtractMetadataFromFilename(msiPath);
            }
        }

        private void ExtractMsiMetadataEnhanced(string msiPath)
        {
            try
            {
                // Use the new MsiInfoService
                _currentMsiInfo = MsiInfoService.ExtractMsiInfo(msiPath);

                if (_currentMsiInfo != null && _currentMsiInfo.IsValid)
                {
                    // Populate UI fields
                    if (string.IsNullOrWhiteSpace(AppNameTextBox.Text) && !string.IsNullOrWhiteSpace(_currentMsiInfo.ProductName))
                        AppNameTextBox.Text = _currentMsiInfo.ProductName;

                    if (string.IsNullOrWhiteSpace(ManufacturerTextBox.Text) && !string.IsNullOrWhiteSpace(_currentMsiInfo.Manufacturer))
                        ManufacturerTextBox.Text = _currentMsiInfo.Manufacturer;

                    if (string.IsNullOrWhiteSpace(VersionTextBox.Text) && !string.IsNullOrWhiteSpace(_currentMsiInfo.ProductVersion))
                        VersionTextBox.Text = _currentMsiInfo.ProductVersion;

                    // Update the package detection display with MSI info
                    DetectedPackageTypeText.Text = $"MSI Package (Product Code: {_currentMsiInfo.ProductCode})";
                    DetectedPackageTypeText.ToolTip = $"Product Code: {_currentMsiInfo.ProductCode}\n" +
                                                      $"Version: {_currentMsiInfo.ProductVersion}\n" +
                                                      $"Upgrade Code: {_currentMsiInfo.UpgradeCode}";

                    Debug.WriteLine($"? MSI detected with Product Code: {_currentMsiInfo.ProductCode}");
                }
                else
                {
                    // Fallback to generic MSI detection
                    DetectedPackageTypeText.Text = "MSI Package (Product Code not found)";
                    ExtractMetadataFromFilename(msiPath);

                    Debug.WriteLine("?? MSI detected but could not extract Product Code");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error in enhanced MSI extraction: {ex.Message}");
                ExtractMetadataFromFilename(msiPath);
            }
        }

        private void ExtractExeMetadata(string exePath)
        {
            try
            {
                var (productName, companyName, version) =
                    MetadataExtractor.ExtractExeMetadata(exePath);

                if (string.IsNullOrWhiteSpace(AppNameTextBox.Text) && !string.IsNullOrWhiteSpace(productName))
                    AppNameTextBox.Text = productName;

                if (string.IsNullOrWhiteSpace(ManufacturerTextBox.Text) && !string.IsNullOrWhiteSpace(companyName))
                    ManufacturerTextBox.Text = companyName;

                if (string.IsNullOrWhiteSpace(VersionTextBox.Text) && !string.IsNullOrWhiteSpace(version))
                    VersionTextBox.Text = version;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"EXE metadata extraction failed: {ex.Message}");
                ExtractMetadataFromFilename(exePath);
            }
        }

        private void ExtractMetadataFromFilename(string filePath)
        {
            if (string.IsNullOrWhiteSpace(AppNameTextBox.Text))
            {
                AppNameTextBox.Text = MetadataExtractor.ExtractNameFromFilename(filePath);
            }
        }

        private bool ValidatePackageInputs()
        {
            return _createPackageViewModel?.ValidatePackageInputs() ?? false;
        }

        private void OpenPackageFolderButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string? packagePath = _createPackageViewModel?.CurrentPackagePath;

                if (string.IsNullOrEmpty(packagePath))
                {
                    ModernMessageBox.Show("No package path available.", "Error",
                        MessageBoxButton.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!Directory.Exists(packagePath))
                {
                    ModernMessageBox.Show("Package folder no longer exists.", "Folder Not Found",
                        MessageBoxButton.OK, MessageBoxIcon.Warning);
                    return;
                }

                Process.Start(new ProcessStartInfo
                {
                    FileName = "explorer.exe",
                    Arguments = $"\"{packagePath}\"",
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error opening folder: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxIcon.Error);
            }
        }

        private void OpenScriptButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string? packagePath = _createPackageViewModel?.CurrentPackagePath;

                if (string.IsNullOrEmpty(packagePath))
                {
                    ModernMessageBox.Show("Please generate a package first.", "No Package",
                        MessageBoxButton.OK, MessageBoxIcon.Warning);
                    return;
                }

                var applicationFolder = Path.Combine(packagePath, "Application");
                var scriptPath = FolderBrowserHelper.GetPSADTScriptPath(applicationFolder);

                if (string.IsNullOrEmpty(scriptPath) || !File.Exists(scriptPath))
                {
                    ModernMessageBox.Show("PSADT script not found.", "File Not Found",
                        MessageBoxButton.OK, MessageBoxIcon.Warning);
                    return;
                }

                var vsCodePath = EditorLocator.FindVSCodePath();
                if (string.IsNullOrEmpty(vsCodePath))
                {
                    // Fall back to default shell handler
                    Process.Start(new ProcessStartInfo
                    {
                        FileName = scriptPath,
                        UseShellExecute = true
                    });
                }
                else
                {
                    Process.Start(new ProcessStartInfo
                    {
                        FileName = vsCodePath,
                        Arguments = $"\"{scriptPath}\"",
                        UseShellExecute = true
                    });
                }

                // Advance pipeline after opening editor
                AdvancePipeline(3);
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error opening script: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRemoteTest_Click(object sender, RoutedEventArgs e)
        {
            string? packagePath = _createPackageViewModel?.CurrentPackagePath ?? "";
            var remoteTest = new RemoteTestWindow(packagePath)
            {
                Owner = this
            };
            remoteTest.ShowDialog();

            // Advance pipeline after remote test
            AdvancePipeline(4);
        }

        private string? ExtractAndSaveIcon(string sourceFilePath)
        {
            return IconExtractor.ExtractIconToTemp(sourceFilePath);
        }

        private void DisplayIcon(System.Windows.Controls.Image imageControl, System.Windows.Controls.Border borderControl, string? iconPath)
        {
            if (string.IsNullOrEmpty(iconPath) || !File.Exists(iconPath))
            {
                imageControl.Visibility = Visibility.Collapsed;
                // Show the default icon when no extracted icon
                if (DetectedPackageTypeIcon != null)
                    DetectedPackageTypeIcon.Visibility = Visibility.Visible;
                return;
            }

            try
            {
                var bitmap = new System.Windows.Media.Imaging.BitmapImage();
                bitmap.BeginInit();
                bitmap.CacheOption = System.Windows.Media.Imaging.BitmapCacheOption.OnLoad;
                bitmap.UriSource = new Uri(iconPath);
                bitmap.EndInit();

                imageControl.Source = bitmap;
                imageControl.Visibility = Visibility.Visible;
                // Hide the default icon when showing extracted icon
                if (DetectedPackageTypeIcon != null)
                    DetectedPackageTypeIcon.Visibility = Visibility.Collapsed;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error displaying icon: {ex.Message}");
                imageControl.Visibility = Visibility.Collapsed;
                if (DetectedPackageTypeIcon != null)
                    DetectedPackageTypeIcon.Visibility = Visibility.Visible;
            }
        }
    }
}
