using Endpoint_Packaging_Suite.Infrastructure;
using Endpoint_Packaging_Suite.Dialogs;
using Microsoft.Extensions.DependencyInjection;
using Serilog;
using System;
using System.Threading.Tasks;
using System.Windows;
using Endpoint_Packaging_Suite.Services;

namespace Endpoint_Packaging_Suite
{
    public partial class App : Application
    {
        /// <summary>
        /// Dependency injection service provider
        /// </summary>
        public static IServiceProvider Services { get; private set; } = null!;

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            try
            {
                // Configure dependency injection
                var services = new ServiceCollection();
                services.AddApplicationServices();
                Services = services.BuildServiceProvider();

                Log.Information("Application services configured successfully");

                // Set up global exception handling
                this.DispatcherUnhandledException += (sender, ex) =>
                {
                    // Log the exception with full details
                    Log.Error(ex.Exception, "Unhandled exception in UI thread");

                    // Show generic message to user (don't expose internal details)
                    ModernMessageBox.Show(
                        "An unexpected error occurred. Please try again or contact support if the problem persists.",
                        "Error",
                        MessageBoxButton.OK,
                        MessageBoxIcon.Error);
                    ex.Handled = true;
                };

                // Handle task exceptions
                TaskScheduler.UnobservedTaskException += (sender, ex) =>
                {
                    Log.Error(ex.Exception, "Unobserved task exception");
                    ex.SetObserved();
                };
            }
            catch (Exception ex)
            {
                // Fatal startup error
                ModernMessageBox.Show(
                    $"Failed to start application: {ex.Message}\n\nPlease check the log files for details.",
                    "Startup Error",
                    MessageBoxButton.OK,
                    MessageBoxIcon.Error);

                Log.Fatal(ex, "Application failed to start");
                Shutdown(1);
            }
        }

        protected override void OnExit(ExitEventArgs e)
        {
            Log.Information("Application exiting with code {ExitCode}", e.ApplicationExitCode);

            // Dispose service provider
            if (Services is IDisposable disposable)
            {
                disposable.Dispose();
            }

            Log.CloseAndFlush();
            base.OnExit(e);
        }
    }
}