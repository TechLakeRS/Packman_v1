﻿using Endpoint_Packaging_Suite.Helpers;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite.Services;

namespace Endpoint_Packaging_Suite.Dialogs
{
    public partial class GroupMembersDialog : Window
    {
        private readonly IntuneService _intuneService;
        private readonly string _groupId;
        private readonly string _groupName;
        private readonly string _assignmentType;

        private ObservableCollection<GroupDevice> _members;
        private ICollectionView _membersView;

        private ObservableCollection<DeviceAddResult> _addResults;

        public GroupMembersDialog(IntuneService intuneService, string groupId, string groupName, string assignmentType)
        {
            InitializeComponent();

            _intuneService = intuneService;
            _groupId = groupId;
            _groupName = groupName;
            _assignmentType = assignmentType;

            _members = new ObservableCollection<GroupDevice>();
            _membersView = CollectionViewSource.GetDefaultView(_members);
            _addResults = new ObservableCollection<DeviceAddResult>();

            InitializeUI();
            LoadGroupMembers();
        }

        private void InitializeUI()
        {
            GroupNameText.Text = _groupName;
            GroupTypeText.Text = _assignmentType;

            // Set up data bindings
            MembersDataGrid.ItemsSource = _membersView;
            AddResultsList.ItemsSource = _addResults;

            // Handle selection changes
            MembersDataGrid.SelectionChanged += (s, e) =>
            {
                RemoveSelectedButton.IsEnabled = MembersDataGrid.SelectedItems.Count > 0;
            };

            // Focus input on load
            Loaded += (s, e) => AddDeviceInput.Focus();
        }

        private async void LoadGroupMembers()
        {
            try
            {
                ShowLoading(true);

                var members = await _intuneService.GetGroupMembersAsync(_groupId);

                Application.Current.Dispatcher.Invoke(() =>
                {
                    _members.Clear();
                    foreach (var member in members)
                    {
                        _members.Add(member);
                    }

                    MemberCountText.Text = $"{_members.Count} Members";

                    ShowLoading(false);

                    if (_members.Count == 0)
                    {
                        EmptyStatePanel.Visibility = Visibility.Visible;
                    }
                });
            }
            catch (Exception ex)
            {
                ShowLoading(false);
                ModernMessageBox.Show($"Error loading group members: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxIcon.Error);
            }
        }

        #region Add Devices Panel

        private async void AddDeviceInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                await AddDeviceByName();
            }
        }

        private async void AddDeviceBtn_Click(object sender, RoutedEventArgs e)
        {
            await AddDeviceByName();
        }

        private async Task AddDeviceByName()
        {
            var deviceName = AddDeviceInput.Text.Trim();

            if (string.IsNullOrWhiteSpace(deviceName))
            {
                ShowAddMessage("Please enter a device name", AddMessageType.Warning);
                return;
            }

            // Clear previous messages
            AddDeviceMessageBorder.Visibility = Visibility.Collapsed;

            // Disable input during processing
            SetAddInputEnabled(false);
            AddDeviceProgress.Visibility = Visibility.Visible;

            try
            {
                // Check if device exists in Intune
                var device = await _intuneService.FindDeviceByNameAsync(deviceName);

                if (device == null)
                {
                    // Device not found
                    var result = new DeviceAddResult
                    {
                        DeviceName = deviceName,
                        Status = AddStatus.NotFound,
                        Message = "Device not found in Intune",
                        Timestamp = DateTime.Now
                    };

                    _addResults.Insert(0, result);
                    ShowAddMessage($"Device '{deviceName}' not found in Intune", AddMessageType.Error);
                }
                else
                {
                    // Check if device is already in the group
                    var isAlreadyMember = await _intuneService.IsDeviceInGroupAsync(device.Id, _groupId);

                    if (isAlreadyMember)
                    {
                        var result = new DeviceAddResult
                        {
                            DeviceName = device.DeviceName,
                            UserPrincipalName = device.UserPrincipalName,
                            Status = AddStatus.AlreadyExists,
                            Message = !string.IsNullOrEmpty(device.UserPrincipalName)
                                ? $"Already in group - {device.UserPrincipalName}"
                                : "Already in group",
                            Timestamp = DateTime.Now
                        };

                        _addResults.Insert(0, result);
                        var userInfo = !string.IsNullOrEmpty(device.UserPrincipalName)
                            ? $" ({device.UserPrincipalName})"
                            : "";
                        ShowAddMessage($"'{device.DeviceName}'{userInfo} is already in this group", AddMessageType.Info);
                    }
                    else
                    {
                        // Add device to group
                        await _intuneService.AddDeviceToGroupAsync(device.Id, _groupId);

                        var userInfo = !string.IsNullOrEmpty(device.UserPrincipalName)
                            ? $" ({device.UserPrincipalName})"
                            : "";

                        var result = new DeviceAddResult
                        {
                            DeviceName = device.DeviceName,
                            UserPrincipalName = device.UserPrincipalName,
                            Status = AddStatus.Success,
                            Message = !string.IsNullOrEmpty(device.UserPrincipalName)
                                ? $"Added - {device.UserPrincipalName}"
                                : "Successfully added",
                            Timestamp = DateTime.Now
                        };

                        _addResults.Insert(0, result);

                        ShowAddMessage($"Added '{device.DeviceName}'{userInfo} to the group", AddMessageType.Success);

                        // Auto-refresh the members list
                        LoadGroupMembers();
                    }
                }

                // Clear input for next entry
                AddDeviceInput.Clear();
                AddDeviceInput.Focus();

                // Show results, hide empty state
                UpdateAddResultsVisibility();
            }
            catch (Exception ex)
            {
                var result = new DeviceAddResult
                {
                    DeviceName = deviceName,
                    Status = AddStatus.Error,
                    Message = $"Error: {ex.Message}",
                    Timestamp = DateTime.Now
                };

                _addResults.Insert(0, result);
                ShowAddMessage($"Error adding device: {ex.Message}", AddMessageType.Error);
                UpdateAddResultsVisibility();
            }
            finally
            {
                SetAddInputEnabled(true);
                AddDeviceProgress.Visibility = Visibility.Collapsed;
            }
        }

        private void ShowAddMessage(string message, AddMessageType type)
        {
            AddDeviceMessageText.Text = message;

            switch (type)
            {
                case AddMessageType.Success:
                    AddDeviceMessageIcon.Text = "✓";
                    AddDeviceMessageBorder.Background = Application.Current.TryFindResource("SuccessLightBrush") as Brush
                        ?? Brushes.LightGreen;
                    AddDeviceMessageText.Foreground = Application.Current.TryFindResource("SuccessColorBrush") as Brush
                        ?? Brushes.Green;
                    break;
                case AddMessageType.Warning:
                    AddDeviceMessageIcon.Text = "⚠";
                    AddDeviceMessageBorder.Background = Application.Current.TryFindResource("WarningLightBrush") as Brush
                        ?? Brushes.LightYellow;
                    AddDeviceMessageText.Foreground = Application.Current.TryFindResource("WarningColorBrush") as Brush
                        ?? Brushes.Orange;
                    break;
                case AddMessageType.Error:
                    AddDeviceMessageIcon.Text = "✗";
                    AddDeviceMessageBorder.Background = Application.Current.TryFindResource("ErrorLightBrush") as Brush
                        ?? Brushes.MistyRose;
                    AddDeviceMessageText.Foreground = Application.Current.TryFindResource("ErrorColorBrush") as Brush
                        ?? Brushes.Red;
                    break;
                case AddMessageType.Info:
                    AddDeviceMessageIcon.Text = "ℹ";
                    AddDeviceMessageBorder.Background = Application.Current.TryFindResource("InfoLightBrush") as Brush
                        ?? Brushes.LightBlue;
                    AddDeviceMessageText.Foreground = Application.Current.TryFindResource("InfoColorBrush") as Brush
                        ?? Brushes.Blue;
                    break;
            }
            AddDeviceMessageIcon.Foreground = AddDeviceMessageText.Foreground;

            AddDeviceMessageBorder.Visibility = Visibility.Visible;
        }

        private void SetAddInputEnabled(bool enabled)
        {
            AddDeviceInput.IsEnabled = enabled;
            AddDeviceBtn.IsEnabled = enabled;
        }

        private void UpdateAddResultsVisibility()
        {
            if (_addResults.Count > 0)
            {
                AddResultsHeader.Visibility = Visibility.Visible;
                AddEmptyState.Visibility = Visibility.Collapsed;
            }
            else
            {
                AddResultsHeader.Visibility = Visibility.Collapsed;
                AddEmptyState.Visibility = Visibility.Visible;
            }
        }

        private void ClearAddResults_Click(object sender, RoutedEventArgs e)
        {
            _addResults.Clear();
            AddDeviceMessageBorder.Visibility = Visibility.Collapsed;
            UpdateAddResultsVisibility();
        }

        #endregion

        #region Member Management

        private async void RemoveMember_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var device = button?.Tag as GroupDevice;

            if (device == null) return;

            var result = ModernMessageBox.Show(
                $"Remove '{device.DeviceName}' from this group?",
                "Confirm Removal",
                MessageBoxButton.YesNo,
                MessageBoxIcon.Question);

            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    await _intuneService.RemoveDeviceFromGroupAsync(_groupId, device.Id);
                    _members.Remove(device);
                    MemberCountText.Text = $"{_members.Count} Members";

                    if (_members.Count == 0)
                    {
                        EmptyStatePanel.Visibility = Visibility.Visible;
                    }
                }
                catch (Exception ex)
                {
                    ModernMessageBox.Show($"Error removing device: {ex.Message}", "Error",
                        MessageBoxButton.OK, MessageBoxIcon.Error);
                }
            }
        }

        private async void RemoveSelectedButton_Click(object sender, RoutedEventArgs e)
        {
            var selected = MembersDataGrid.SelectedItems.Cast<GroupDevice>().ToList();

            if (!selected.Any()) return;

            var result = ModernMessageBox.Show(
                $"Remove {selected.Count} device(s) from this group?",
                "Confirm Removal",
                MessageBoxButton.YesNo,
                MessageBoxIcon.Question);

            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    RemoveSelectedButton.IsEnabled = false;

                    var deviceIds = selected.Select(d => d.Id).ToList();
                    await _intuneService.RemoveDevicesFromGroupAsync(_groupId, deviceIds);

                    foreach (var device in selected)
                    {
                        _members.Remove(device);
                    }

                    MemberCountText.Text = $"{_members.Count} Members";

                    if (_members.Count == 0)
                    {
                        EmptyStatePanel.Visibility = Visibility.Visible;
                    }
                }
                catch (Exception ex)
                {
                    ModernMessageBox.Show($"Error removing devices: {ex.Message}", "Error",
                        MessageBoxButton.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    RemoveSelectedButton.IsEnabled = MembersDataGrid.SelectedItems.Count > 0;
                }
            }
        }

        #endregion

        #region Search and Filter

        private void SearchMembersBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (_membersView != null)
            {
                _membersView.Filter = obj =>
                {
                    var device = obj as GroupDevice;
                    if (device == null) return false;

                    var searchText = SearchMembersBox.Text?.ToLower() ?? "";
                    return string.IsNullOrEmpty(searchText) ||
                           device.DeviceName.ToLower().Contains(searchText);
                };
            }
        }

        #endregion

        #region Utilities

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadGroupMembers();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            Close();
        }

        private void ShowLoading(bool show)
        {
            LoadingPanel.Visibility = show ? Visibility.Visible : Visibility.Collapsed;
            MembersDataGrid.Visibility = show ? Visibility.Collapsed : Visibility.Visible;
            EmptyStatePanel.Visibility = Visibility.Collapsed;
        }

        #endregion
    }

    // Helper classes for Add Device functionality
    public class DeviceAddResult : INotifyPropertyChanged
    {
        private string _deviceName;
        private string _userPrincipalName;
        private AddStatus _status;
        private string _message;
        private DateTime _timestamp;

        public string DeviceName
        {
            get => _deviceName;
            set { _deviceName = value; OnPropertyChanged(); }
        }

        public string UserPrincipalName
        {
            get => _userPrincipalName;
            set { _userPrincipalName = value; OnPropertyChanged(); }
        }

        public AddStatus Status
        {
            get => _status;
            set
            {
                _status = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(StatusIcon));
                OnPropertyChanged(nameof(StatusColor));
            }
        }

        public string StatusIcon => Status switch
        {
            AddStatus.Success => "✓",
            AddStatus.NotFound => "✗",
            AddStatus.AlreadyExists => "ℹ",
            AddStatus.Error => "⚠",
            _ => "?"
        };

        public Brush StatusColor => Status switch
        {
            AddStatus.Success => Application.Current.TryFindResource("SuccessColorBrush") as Brush ?? Brushes.Green,
            AddStatus.NotFound => Application.Current.TryFindResource("ErrorColorBrush") as Brush ?? Brushes.Red,
            AddStatus.AlreadyExists => Application.Current.TryFindResource("InfoColorBrush") as Brush ?? Brushes.Blue,
            AddStatus.Error => Application.Current.TryFindResource("WarningColorBrush") as Brush ?? Brushes.Orange,
            _ => Application.Current.TryFindResource("TextPrimaryBrush") as Brush ?? Brushes.Gray
        };

        public string Message
        {
            get => _message;
            set { _message = value; OnPropertyChanged(); }
        }

        public DateTime Timestamp
        {
            get => _timestamp;
            set { _timestamp = value; OnPropertyChanged(); }
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public enum AddStatus
    {
        Success,
        NotFound,
        AlreadyExists,
        Error
    }

    public enum AddMessageType
    {
        Success,
        Warning,
        Error,
        Info
    }
}