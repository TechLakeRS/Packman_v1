using System;
using Endpoint_Packaging_Suite.Dialogs;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.Win32;
using System.Diagnostics;
using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite.Services;
using Microsoft.Extensions.DependencyInjection;

namespace Endpoint_Packaging_Suite.WizardSteps
{
    public partial class DetectionRulesStep : UserControl
    {
        public event ValidationChangedEventHandler? ValidationChanged;

        // Reference to parent wizard for opening dialogs
        public IntuneUploadWizard? ParentWindow { get; set; }

        private bool _advancedOpen = false;

        private ObservableCollection<DetectionRule>? _detectionRules;
        public ObservableCollection<DetectionRule>? DetectionRules
        {
            get => _detectionRules;
            set
            {
                if (_detectionRules != null)
                {
                    _detectionRules.CollectionChanged -= DetectionRules_CollectionChanged;
                }

                _detectionRules = value;

                if (_detectionRules != null)
                {
                    _detectionRules.CollectionChanged += DetectionRules_CollectionChanged;
                    DetectionRulesList.ItemsSource = _detectionRules;
                }

                UpdateValidation();
                UpdateRuleCount();
            }
        }

        public DetectionRulesStep()
        {
            InitializeComponent();
            InitializeMsiOperatorComboBox();
        }

        private void InitializeMsiOperatorComboBox()
        {
            MsiOperatorComboBox.Items.Clear();
            MsiOperatorComboBox.Items.Add(new ComboBoxItem { Content = "Greater than or equal to", Tag = "greaterThanOrEqual" });
            MsiOperatorComboBox.Items.Add(new ComboBoxItem { Content = "Equal to", Tag = "equal" });
            MsiOperatorComboBox.Items.Add(new ComboBoxItem { Content = "Not equal to", Tag = "notEqual" });
            MsiOperatorComboBox.Items.Add(new ComboBoxItem { Content = "Greater than", Tag = "greaterThan" });
            MsiOperatorComboBox.Items.Add(new ComboBoxItem { Content = "Less than", Tag = "lessThan" });
            MsiOperatorComboBox.Items.Add(new ComboBoxItem { Content = "Less than or equal to", Tag = "lessThanOrEqual" });
            MsiOperatorComboBox.SelectedIndex = 0;
        }

        private void DetectionRules_CollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
        {
            UpdateValidation();
            UpdateRuleCount();
        }

        private void UpdateValidation()
        {
            bool isValid = (_detectionRules?.Count ?? 0) > 0;

            if (isValid)
            {
                NoRulesPanel.Visibility = Visibility.Collapsed;
                RuleCountIndicator.Background = (Brush)FindResource("SuccessLightBrush");
                RuleCountIndicator.BorderBrush = (Brush)FindResource("SuccessBrush");
                RuleCountIcon.Text = "";
                RuleCountIcon.Foreground = (Brush)FindResource("SuccessBrush");
            }
            else
            {
                NoRulesPanel.Visibility = Visibility.Visible;
                RuleCountIndicator.Background = (Brush)FindResource("ErrorLightBrush");
                RuleCountIndicator.BorderBrush = (Brush)FindResource("ErrorColorBrush");
                RuleCountIcon.Text = "";
                RuleCountIcon.Foreground = (Brush)FindResource("WarningColorBrush");
            }

            ValidationChanged?.Invoke(isValid);
        }

        private void UpdateRuleCount()
        {
            var count = _detectionRules?.Count ?? 0;
            RuleCountText.Text = count switch
            {
                0 => "No rules configured",
                1 => "1 rule configured",
                _ => $"{count} rules configured"
            };
        }

        private void AdvancedToggleButton_Click(object sender, RoutedEventArgs e)
        {
            _advancedOpen = !_advancedOpen;
            AdvancedMethodsPanel.Visibility = _advancedOpen ? Visibility.Visible : Visibility.Collapsed;
            AdvancedChevron.Text = _advancedOpen ? "" : "";
        }

        private void CollapseAllEditors()
        {
            FileDetectionEditor.Visibility = Visibility.Collapsed;
            RegistryDetectionEditor.Visibility = Visibility.Collapsed;
            MsiDetectionEditor.Visibility = Visibility.Collapsed;
            ScriptDetectionEditor.Visibility = Visibility.Collapsed;
        }

        #region File Detection

        private void AddFileDetectionButton_Click(object sender, RoutedEventArgs e)
        {
            CollapseAllEditors();
            FileDetectionEditor.Visibility = Visibility.Visible;

            FilePathTextBox.Text = "%ProgramFiles%";
            FileNameTextBox.Text = "";
            FileValueTextBox.Text = "";

            FileNameTextBox.Focus();
        }

        private void BrowseFileButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var openFileDialog = new OpenFileDialog
                {
                    Title = "Select File for Detection Rule",
                    Filter = "All Files (*.*)|*.*|Executable Files (*.exe)|*.exe|DLL Files (*.dll)|*.dll",
                    CheckFileExists = true,
                    CheckPathExists = true
                };

                if (openFileDialog.ShowDialog() == true)
                {
                    var selectedFile = openFileDialog.FileName;
                    var directory = Path.GetDirectoryName(selectedFile);
                    var fileName = Path.GetFileName(selectedFile);

                    if (directory != null)
                    {
                        FilePathTextBox.Text = ConvertToEnvironmentPath(directory);
                    }
                    else
                    {
                        FilePathTextBox.Text = string.Empty;
                    }

                    FileNameTextBox.Text = fileName;
                }
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error selecting file: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxIcon.Error);
            }
        }

        private string ConvertToEnvironmentPath(string absolutePath)
        {
            if (string.IsNullOrEmpty(absolutePath))
                return absolutePath;

            var programFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
            var programFilesX86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
            var system32 = Environment.GetFolderPath(Environment.SpecialFolder.System);

            if (absolutePath.StartsWith(programFiles, StringComparison.OrdinalIgnoreCase))
                return absolutePath.Replace(programFiles, "%ProgramFiles%");
            else if (absolutePath.StartsWith(programFilesX86, StringComparison.OrdinalIgnoreCase))
                return absolutePath.Replace(programFilesX86, "%ProgramFiles(x86)%");
            else if (absolutePath.StartsWith(system32, StringComparison.OrdinalIgnoreCase))
                return absolutePath.Replace(system32, "%System32%");

            return absolutePath;
        }

        private void SaveFileDetectionRule_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(FilePathTextBox.Text))
                {
                    ModernMessageBox.Show("Please enter a file path.", "Validation Error",
                        MessageBoxButton.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(FileNameTextBox.Text))
                {
                    ModernMessageBox.Show("Please enter a file or folder name.", "Validation Error",
                        MessageBoxButton.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(FileValueTextBox.Text))
                {
                    ModernMessageBox.Show("Please enter a version value.", "Validation Error",
                        MessageBoxButton.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Standardized detection: File version, greater than or equal to
                var newRule = new DetectionRule
                {
                    Type = DetectionRuleType.File,
                    Path = FilePathTextBox.Text.Trim(),
                    FileOrFolderName = FileNameTextBox.Text.Trim(),
                    DetectionType = "version",
                    Operator = "greaterThanOrEqual",
                    DetectionValue = FileValueTextBox.Text.Trim(),
                    CheckVersion = true,
                    Check32BitOn64System = true
                };

                _detectionRules?.Add(newRule);
                FileDetectionEditor.Visibility = Visibility.Collapsed;
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error adding file detection rule: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxIcon.Error);
            }
        }

        private void CancelFileEditor_Click(object sender, RoutedEventArgs e)
        {
            FileDetectionEditor.Visibility = Visibility.Collapsed;
        }

        #endregion

        #region Registry Detection

        private void AddRegistryDetectionButton_Click(object sender, RoutedEventArgs e)
        {
            CollapseAllEditors();
            RegistryDetectionEditor.Visibility = Visibility.Visible;

            RegistryPathTextBox.Text = "HKEY_LOCAL_MACHINE\\SOFTWARE";
            RegistryValueNameTextBox.Text = "";
            RegistryDetectionMethodComboBox.SelectedIndex = 0; // "Key exists"
            RegistryOperatorComboBox.SelectedIndex = 0;
            RegistryValueTextBox.Text = "";
            RegistryCheck32BitCheckBox.IsChecked = false;

            UpdateRegistryDetectionFieldVisibility();
            RegistryPathTextBox.Focus();
        }

        private void RegistryDetectionMethodComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateRegistryDetectionFieldVisibility();
        }

        private void UpdateRegistryDetectionFieldVisibility()
        {
            if (RegistryDetectionMethodComboBox?.SelectedItem is not ComboBoxItem selected)
                return;

            var tag = selected.Tag?.ToString() ?? "exists";
            bool showOperatorAndValue = tag != "exists" && tag != "doesNotExist";

            var visibility = showOperatorAndValue ? Visibility.Visible : Visibility.Collapsed;
            RegistryOperatorLabel.Visibility = visibility;
            RegistryOperatorComboBox.Visibility = visibility;
            RegistryValueLabel.Visibility = visibility;
            RegistryValueTextBox.Visibility = visibility;

            if (showOperatorAndValue)
            {
                RegistryValueTextBox.ToolTip = tag switch
                {
                    "string" => "Enter expected string value",
                    "integer" => "Enter expected integer value",
                    "version" => "Enter expected version (e.g. 1.0.0.0)",
                    _ => "Enter expected value"
                };
            }
        }

        private void BrowseRegistryButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var result = ModernMessageBox.Show(
                    "This will open Registry Editor for you to browse and find the registry key.\n\n" +
                    "After finding your desired registry key:\n" +
                    "1. Copy the full registry path\n" +
                    "2. Close Registry Editor\n" +
                    "3. Paste the path in the Key path field\n\n" +
                    "Continue?",
                    "Registry Browser Helper",
                    MessageBoxButton.YesNo,
                    MessageBoxIcon.Information);

                if (result == MessageBoxResult.Yes)
                {
                    Process.Start("regedit.exe");
                }
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error opening Registry Editor: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxIcon.Error);
            }
        }

        private void SaveRegistryDetectionRule_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(RegistryPathTextBox.Text))
                {
                    ModernMessageBox.Show("Please enter a registry key path.", "Validation Error",
                        MessageBoxButton.OK, MessageBoxIcon.Warning);
                    return;
                }

                var detectionMethod = (RegistryDetectionMethodComboBox.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? "exists";
                var operatorValue = (RegistryOperatorComboBox.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? "notConfigured";
                var detectionValue = RegistryValueTextBox.Text.Trim();

                // Validate value is provided for comparison methods
                bool needsValue = detectionMethod != "exists" && detectionMethod != "doesNotExist";
                if (needsValue && string.IsNullOrWhiteSpace(detectionValue))
                {
                    ModernMessageBox.Show("Please enter a comparison value.", "Validation Error",
                        MessageBoxButton.OK, MessageBoxIcon.Warning);
                    return;
                }

                // For comparison methods, value name is required
                if (needsValue && string.IsNullOrWhiteSpace(RegistryValueNameTextBox.Text))
                {
                    ModernMessageBox.Show("Value name is required for comparison detection methods.", "Validation Error",
                        MessageBoxButton.OK, MessageBoxIcon.Warning);
                    return;
                }

                var newRule = new DetectionRule
                {
                    Type = DetectionRuleType.Registry,
                    Path = RegistryPathTextBox.Text.Trim(),
                    FileOrFolderName = RegistryValueNameTextBox.Text.Trim(),
                    DetectionType = detectionMethod,
                    Operator = needsValue ? operatorValue : "",
                    DetectionValue = needsValue ? detectionValue : "",
                    CheckVersion = false,
                    Check32BitOn64System = RegistryCheck32BitCheckBox.IsChecked ?? false
                };

                _detectionRules?.Add(newRule);
                RegistryDetectionEditor.Visibility = Visibility.Collapsed;
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error adding registry detection rule: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxIcon.Error);
            }
        }

        private void CancelRegistryEditor_Click(object sender, RoutedEventArgs e)
        {
            RegistryDetectionEditor.Visibility = Visibility.Collapsed;
        }

        #endregion

        #region MSI Detection

        private void AddMsiDetectionButton_Click(object sender, RoutedEventArgs e)
        {
            CollapseAllEditors();
            MsiDetectionEditor.Visibility = Visibility.Visible;

            // Check if we have MSI info from the parent wizard
            if (ParentWindow?.ApplicationInfo != null && ParentWindow.ApplicationInfo.IsMsiPackage)
            {
                MsiProductCodeTextBox.Text = ParentWindow.ApplicationInfo.MsiProductCode;
                MsiVersionValueTextBox.Text = ParentWindow.ApplicationInfo.MsiProductVersion;
                MsiVersionCheckYes.IsChecked = true;
                MsiVersionCheckNo.IsChecked = false;
                MsiOperatorComboBox.SelectedIndex = 0; // "Greater than or equal to"

                Debug.WriteLine($"Pre-populated MSI detection with Product Code: {ParentWindow.ApplicationInfo.MsiProductCode}");
            }
            else
            {
                MsiProductCodeTextBox.Text = "";
                MsiVersionCheckYes.IsChecked = false;
                MsiVersionCheckNo.IsChecked = true;
                MsiOperatorComboBox.SelectedIndex = 0;
                MsiVersionValueTextBox.Text = "";
            }

            UpdateMsiVersionFieldVisibility();
            MsiProductCodeTextBox.Focus();
        }

        private void MsiVersionCheck_Changed(object sender, RoutedEventArgs e)
        {
            UpdateMsiVersionFieldVisibility();
        }

        private void UpdateMsiVersionFieldVisibility()
        {
            // Guard against being called during InitializeComponent before controls are resolved
            if (MsiOperatorLabel == null || MsiOperatorComboBox == null || MsiVersionLabel == null || MsiVersionValueTextBox == null)
                return;

            bool showVersion = MsiVersionCheckYes.IsChecked ?? false;
            var visibility = showVersion ? Visibility.Visible : Visibility.Collapsed;

            MsiOperatorLabel.Visibility = visibility;
            MsiOperatorComboBox.Visibility = visibility;
            MsiVersionLabel.Visibility = visibility;
            MsiVersionValueTextBox.Visibility = visibility;
        }

        private void SaveMsiDetectionRule_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(MsiProductCodeTextBox.Text))
                {
                    ModernMessageBox.Show("Please enter an MSI product code.", "Validation Error",
                        MessageBoxButton.OK, MessageBoxIcon.Warning);
                    return;
                }

                var productCode = MsiProductCodeTextBox.Text.Trim();
                if (!productCode.StartsWith("{") || !productCode.EndsWith("}"))
                {
                    ModernMessageBox.Show("MSI product code should be in GUID format: {XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX}",
                        "Validation Error", MessageBoxButton.OK, MessageBoxIcon.Warning);
                    return;
                }

                bool checkVersion = MsiVersionCheckYes.IsChecked ?? false;
                if (checkVersion && string.IsNullOrWhiteSpace(MsiVersionValueTextBox.Text))
                {
                    ModernMessageBox.Show("Please enter a version value when version check is enabled.", "Validation Error",
                        MessageBoxButton.OK, MessageBoxIcon.Warning);
                    return;
                }

                var operatorTag = (MsiOperatorComboBox.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? "greaterThanOrEqual";

                var newRule = new DetectionRule
                {
                    Type = DetectionRuleType.MSI,
                    Path = productCode,
                    FileOrFolderName = checkVersion ? MsiVersionValueTextBox.Text.Trim() : "",
                    CheckVersion = checkVersion,
                    Operator = checkVersion ? operatorTag : "notConfigured"
                };

                _detectionRules?.Add(newRule);
                MsiDetectionEditor.Visibility = Visibility.Collapsed;
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error adding MSI detection rule: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxIcon.Error);
            }
        }

        private void CancelMsiEditor_Click(object sender, RoutedEventArgs e)
        {
            MsiDetectionEditor.Visibility = Visibility.Collapsed;
        }

        private void BrowseMsiProductsButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var result = ModernMessageBox.Show(
                    "To find MSI Product Codes:\n\n" +
                    "1. Open Registry Editor (regedit)\n" +
                    "2. Navigate to HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\n" +
                    "3. Look for keys that start with { and end with } (these are MSI product codes)\n" +
                    "4. Copy the key name (product code) and paste it in the field\n\n" +
                    "Open Registry Editor now?",
                    "Find MSI Product Code",
                    MessageBoxButton.YesNo,
                    MessageBoxIcon.Information);

                if (result == MessageBoxResult.Yes)
                {
                    Process.Start("regedit.exe");
                }
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxIcon.Error);
            }
        }

        #endregion

        #region Script Detection

        private void AddScriptDetectionButton_Click(object sender, RoutedEventArgs e)
        {
            CollapseAllEditors();
            ScriptDetectionEditor.Visibility = Visibility.Visible;

            ScriptContentTextBox.Text = "";
            EnforceSignatureCheckBox.IsChecked = false;
            RunAs32BitCheckBox.IsChecked = false;
            ScriptStatusText.Text = "";

            ScriptContentTextBox.Focus();
        }

        private async void SaveScriptDetectionRule_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(ScriptContentTextBox.Text))
            {
                ModernMessageBox.Show("Please provide a PowerShell detection script.", "Validation Error",
                    MessageBoxButton.OK, MessageBoxIcon.Warning);
                return;
            }

            var signer = App.Services.GetService<NativeCodeSigner>();
            if (signer is null || !signer.IsCertificateAvailable())
            {
                ModernMessageBox.Show(
                    "No code-signing certificate is loaded, so the detection script cannot be signed. " +
                    "Ensure the Key Vault certificate was loaded at startup.",
                    "Cannot Sign Script", MessageBoxButton.OK, MessageBoxIcon.Warning);
                return;
            }

            var tempScriptPath = Path.Combine(Path.GetTempPath(), $"eps_detection_{Guid.NewGuid():N}.ps1");

            SaveScriptRuleButton.IsEnabled = false;
            ScriptStatusText.Text = "Signing script...";
            try
            {
                // Create the script from the typed content, then sign it in place.
                File.WriteAllText(tempScriptPath, ScriptContentTextBox.Text, new System.Text.UTF8Encoding(true));

                var signResult = await signer.SignFileAsync(tempScriptPath);
                if (!signResult.Success)
                {
                    ModernMessageBox.Show($"Failed to sign the detection script: {signResult.ErrorMessage}",
                        "Signing Failed", MessageBoxButton.OK, MessageBoxIcon.Error);
                    return;
                }

                // Base64-encode the signed script for the Graph API.
                var base64Script = Convert.ToBase64String(File.ReadAllBytes(tempScriptPath));

                var newRule = new DetectionRule
                {
                    Type = DetectionRuleType.Script,
                    ScriptContent = base64Script,
                    EnforceSignatureCheck = EnforceSignatureCheckBox.IsChecked ?? false,
                    RunAs32Bit = RunAs32BitCheckBox.IsChecked ?? false
                };

                _detectionRules?.Add(newRule);
                ScriptDetectionEditor.Visibility = Visibility.Collapsed;
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error adding script detection rule: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ScriptStatusText.Text = "";
                SaveScriptRuleButton.IsEnabled = true;
                try { if (File.Exists(tempScriptPath)) File.Delete(tempScriptPath); } catch { /* best-effort temp cleanup */ }
            }
        }

        private void CancelScriptEditor_Click(object sender, RoutedEventArgs e)
        {
            ScriptDetectionEditor.Visibility = Visibility.Collapsed;
        }

        #endregion

        #region Remove Detection Rule

        private void RemoveDetectionRule_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (sender is Button button && button.Tag is DetectionRule ruleToRemove)
                {
                    var ruleText = $"{ruleToRemove.Type}: {ruleToRemove.Path}";
                    var result = ModernMessageBox.Show(
                        $"Are you sure you want to remove this detection rule?\n\n{ruleText}",
                        "Remove Detection Rule",
                        MessageBoxButton.YesNo,
                        MessageBoxIcon.Question);

                    if (result == MessageBoxResult.Yes)
                    {
                        _detectionRules?.Remove(ruleToRemove);
                    }
                }
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error removing detection rule: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxIcon.Error);
            }
        }

        #endregion

        #region Public Methods for Wizard

        public bool IsValid()
        {
            return (_detectionRules?.Count ?? 0) > 0;
        }

        public int GetRuleCount()
        {
            return _detectionRules?.Count ?? 0;
        }

        #endregion
    }

    public delegate void ValidationChangedEventHandler(bool isValid);
}
