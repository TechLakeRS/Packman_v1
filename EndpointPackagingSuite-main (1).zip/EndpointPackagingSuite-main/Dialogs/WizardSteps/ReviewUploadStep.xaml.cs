﻿using Endpoint_Packaging_Suite.Constants;
using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite.Services;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace Endpoint_Packaging_Suite.WizardSteps
{
    public partial class ReviewUploadStep : UserControl, IUploadProgress
    {
        public event EventHandler? BackRequested;
        public event EventHandler<UploadCompleteEventArgs>? UploadComplete;

        // Required properties for wizard
        public ApplicationInfo ApplicationInfo { get; set; } = null!;
        public ObservableCollection<DetectionRule> DetectionRules { get; set; }
        public string PackagePath { get; set; } = null!;
        public string? SelectedIconPath { get; set; }
        public string? NotificationId { get; set; } // For toast progress updates
        public string? PredecessorAppId { get; set; }
        public delegate void UploadRequestedEventHandler(string installCommand, string uninstallCommand, string description, string installContext);

        // Private fields
        private ApplicationDetail _applicationDetail = null!;
        private IntuneService _intuneService = null!;
        private ObservableCollection<ProgressStep> _progressSteps;

        // Group names (cached to avoid UI access from background threads)
        private string _sysInstallGroupName = string.Empty;
        private string _usrInstallGroupName = string.Empty;
        private string _sysUninstallGroupName = string.Empty;
        private string _usrUninstallGroupName = string.Empty;

        // Service locator used here because WPF code-behind doesn't support constructor injection
        private NotificationService Notifications => App.Services.GetRequiredService<NotificationService>();

        public ReviewUploadStep()
        {
            InitializeComponent();
            _progressSteps = new ObservableCollection<ProgressStep>();
            ProgressSteps.ItemsSource = _progressSteps;
            DetectionRules = new ObservableCollection<DetectionRule>();
        }

        public void UpdateSummaryData(string installCommand, string uninstallCommand, string description, string installContext)
        {
            // Initialize if needed
            _applicationDetail ??= new ApplicationDetail();

            _applicationDetail.InstallCommand = installCommand;
            _applicationDetail.UninstallCommand = uninstallCommand;
            _applicationDetail.Description = description;
            _applicationDetail.InstallContext = installContext;

            RefreshUI();
        }

        public void LoadFromApplicationInfo(ApplicationInfo appInfo)
        {
            if (appInfo == null)
            {
                Debug.WriteLine("Warning: LoadFromApplicationInfo called with null appInfo");
                return;
            }

            ApplicationInfo = appInfo;

            // Create ApplicationDetail from ApplicationInfo
            // DisplayName should be Manufacturer + AppName + Version for Intune
            var fullDisplayName = $"{appInfo.Manufacturer} {appInfo.Name} {appInfo.Version}".Trim();

            _applicationDetail = new ApplicationDetail
            {
                DisplayName = fullDisplayName,
                Version = appInfo.Version ?? "1.0.0",
                Publisher = appInfo.Manufacturer ?? "Unknown",
                InstallContext = appInfo.InstallContext ?? AppConstants.InstallContext.Default,
                DetectionRules = DetectionRules?.ToList() ?? new List<DetectionRule>()
            };

            EnsureIntuneService();
            RefreshUI();
        }

        private void EnsureIntuneService()
        {
            if (_intuneService == null)
            {
                // Get Intune service from DI container
                _intuneService = App.Services.GetRequiredService<IntuneService>();
            }
        }

        public void RefreshUI()
        {
            if (_applicationDetail == null)
            {
                Debug.WriteLine("Warning: RefreshUI called with null _applicationDetail");
                return;
            }

            // Update UI elements with null checks
            AppNameText.Text = _applicationDetail.DisplayName ?? "Unknown";
            VersionText.Text = _applicationDetail.Version ?? "Unknown";
            PublisherText.Text = _applicationDetail.Publisher ?? "Unknown";
            DescriptionText.Text = _applicationDetail.Description ?? "";

            UpdatePackageSizeDisplay();
            UpdateDetectionRulesDisplay();
            UpdateDeploymentConfiguration();
            GenerateGroupNames();
        }

        private void UpdateDeploymentConfiguration()
        {
            // Populate locked deployment settings with governance defaults
            InstallContextText.Text = _applicationDetail?.InstallContext ?? "System";
            InstallCommandText.Text = _applicationDetail?.InstallCommand ?? "Invoke-AppDeployToolkit.exe -DeploymentType Install";
            UninstallCommandText.Text = _applicationDetail?.UninstallCommand ?? "Invoke-AppDeployToolkit.exe -DeploymentType Uninstall";
        }

        private void UpdatePackageSizeDisplay()
        {
            if (!string.IsNullOrEmpty(PackagePath))
            {
                string fileToCheck = PackagePath;
                bool intuneWinExists = false;

                // If PackagePath is a directory, look for .intunewin file
                if (Directory.Exists(PackagePath))
                {
                    var intuneFolder = Path.Combine(PackagePath, "Intune");
                    if (Directory.Exists(intuneFolder))
                    {
                        var intuneWinFiles = Directory.GetFiles(intuneFolder, "*.intunewin");
                        if (intuneWinFiles.Length > 0)
                        {
                            fileToCheck = intuneWinFiles[0];
                            intuneWinExists = true;
                        }
                    }

                    // If .intunewin doesn't exist, try to estimate size from Application folder
                    if (!intuneWinExists)
                    {
                        var applicationFolder = Path.Combine(PackagePath, "Application");
                        if (Directory.Exists(applicationFolder))
                        {
                            try
                            {
                                var dirInfo = new DirectoryInfo(applicationFolder);
                                long totalSize = dirInfo.EnumerateFiles("*", SearchOption.AllDirectories).Sum(fi => fi.Length);
                                PackageSizeText.Text = $"~{GetFileSizeString(totalSize)} (estimated)";
                                return;
                            }
                            catch
                            {
                                PackageSizeText.Text = "Will be created during upload";
                                return;
                            }
                        }
                    }
                }

                if (File.Exists(fileToCheck))
                {
                    var fileInfo = new FileInfo(fileToCheck);
                    PackageSizeText.Text = GetFileSizeString(fileInfo.Length);
                }
                else
                {
                    PackageSizeText.Text = "Will be created during upload";
                }
            }
            else if (_applicationDetail != null)
            {
                PackageSizeText.Text = _applicationDetail.SizeFormatted ?? "Unknown";
            }
            else
            {
                PackageSizeText.Text = "Unknown";
            }
        }

        private void UpdateDetectionRulesDisplay(List<DetectionRule>? rules = null)
        {
            var rulesToDisplay = rules ?? DetectionRules?.ToList() ?? _applicationDetail?.DetectionRules;

            if (rulesToDisplay != null && rulesToDisplay.Any())
            {
                var detectionRulesList = rulesToDisplay.Select(r =>
                    $"• {GetDetectionRuleTitle(r.Type.ToString())}: {r.Path}").ToList();
                DetectionRulesList.ItemsSource = detectionRulesList;
            }
            else
            {
                DetectionRulesList.ItemsSource = new[] { "• No detection rules configured" };
            }
        }

        private void GenerateGroupNames()
        {
            if (_applicationDetail == null) return;

            var cleanPublisher = CleanForGroupName(_applicationDetail.Publisher);
            // Use ApplicationInfo.Name for group names (without version), not DisplayName (which includes version)
            var cleanAppName = CleanForGroupName(ApplicationInfo?.Name ?? _applicationDetail.DisplayName);
            var cleanVersion = CleanForGroupName(_applicationDetail.Version);

            // Generate group names and store them (both in UI and private fields)
            _sysInstallGroupName = TruncateGroupName($"SY_AZNBB_Intune_WksApp_{cleanPublisher}_{cleanAppName}_{cleanVersion}_Install", cleanPublisher);
            _usrInstallGroupName = TruncateGroupName($"USR_AZNBB_Intune_WksApp_{cleanPublisher}_{cleanAppName}_{cleanVersion}_Install", cleanPublisher);
            _sysUninstallGroupName = TruncateGroupName($"SY_AZNBB_Intune_WksApp_{cleanPublisher}_{cleanAppName}_{cleanVersion}_Uninstall", cleanPublisher);
            _usrUninstallGroupName = TruncateGroupName($"USR_AZNBB_Intune_WksApp_{cleanPublisher}_{cleanAppName}_{cleanVersion}_Uninstall", cleanPublisher);

            // Update UI elements
            SysInstallGroupText.Text = _sysInstallGroupName;
            UsrInstallGroupText.Text = _usrInstallGroupName;
            SysUninstallGroupText.Text = _sysUninstallGroupName;
            UsrUninstallGroupText.Text = _usrUninstallGroupName;
        }

        private string TruncateGroupName(string groupName, string manufacturer)
        {
            const int maxLength = 256;

            // If the group name is within the limit, return as-is
            if (groupName.Length <= maxLength)
                return groupName;

            // Calculate how much we need to truncate
            int excessLength = groupName.Length - maxLength;

            // Find the manufacturer portion in the group name and truncate it
            int manufacturerIndex = groupName.IndexOf(manufacturer);
            if (manufacturerIndex >= 0 && manufacturer.Length > excessLength)
            {
                // Truncate the manufacturer name
                var truncatedManufacturer = manufacturer.Substring(0, manufacturer.Length - excessLength);
                // Replace the original manufacturer with the truncated one
                groupName = groupName.Remove(manufacturerIndex, manufacturer.Length)
                                    .Insert(manufacturerIndex, truncatedManufacturer);
            }
            else if (manufacturerIndex >= 0)
            {
                // If the manufacturer is shorter than what we need to remove,
                // remove it entirely and remove additional characters if needed
                groupName = groupName.Remove(manufacturerIndex, manufacturer.Length);
                if (groupName.Length > maxLength)
                {
                    // Still too long, truncate from the end
                    groupName = groupName.Substring(0, maxLength);
                }
            }
            else
            {
                // Fallback: if we can't find the manufacturer, just truncate from the end
                groupName = groupName.Substring(0, maxLength);
            }

            return groupName;
        }

        private string CleanForGroupName(string input)
        {
            if (string.IsNullOrEmpty(input)) return "Unknown";

            var cleaned = Regex.Replace(input, @"[^a-zA-Z0-9\-\.]", "_");
            cleaned = Regex.Replace(cleaned, @"_{2,}", "_");
            cleaned = cleaned.Trim('_');

            if (cleaned.Length > 50)
                cleaned = cleaned.Substring(0, 50);

            return cleaned;
        }

        private string GetDetectionRuleTitle(string type)
        {
            return type?.ToLower() switch
            {
                "msi" => "MSI Product Code",
                "file" => "File System",
                "registry" => "Registry Key",
                "script" => "PowerShell Script",
                _ => "Detection Rule"
            };
        }

        private string GetFileSizeString(long bytes)
        {
            return bytes switch
            {
                > 1073741824 => $"{bytes / 1073741824.0:F1} GB",
                > 1048576 => $"{bytes / 1048576.0:F1} MB",
                > 1024 => $"{bytes / 1024.0:F1} KB",
                > 0 => $"{bytes} bytes",
                _ => "Unknown"
            };
        }

        public async Task<bool> StartUploadAsync()
        {
            if (_applicationDetail == null)
            {
                Notifications.ShowError(
                    "Upload Error",
                    "Application details not loaded");
                return false;
            }

            // Create notification when upload actually starts (not when wizard opens)
            if (string.IsNullOrEmpty(NotificationId))
            {
                NotificationId = Notifications.ShowInProgress(
                    $"Uploading {_applicationDetail.DisplayName}",
                    "Starting upload...",
                    0);
            }

            Application.Current.Dispatcher.Invoke(() =>
            {
                ProgressPanel.Visibility = Visibility.Visible;
                _progressSteps.Clear();
            });

            try
            {
                // Step 1: Upload application
                AddProgressStep("\uE9F3", "Uploading application package to Intune...");
                await Task.Delay(500);

                var appId = await UploadApplication();
                UpdateProgressStep(0, "\uE73E", "Application uploaded successfully");

                // Step 2: Create groups
                AddProgressStep("\uE9F3", "Creating assignment groups in Azure AD...");
                await Task.Delay(500);

                var groupIds = await CreateAssignmentGroups();
                UpdateProgressStep(1, "\uE73E", $"Created {groupIds.Count} assignment groups");

                // Step 3: Assign groups to app
                AddProgressStep("\uE9F3", "Assigning groups to application...");
                await Task.Delay(500);

                await AssignGroupsToApplication(appId, groupIds);
                UpdateProgressStep(2, "\uE73E", "Groups assigned to application");

                // Step 4: Save detection rules to package metadata
                await SaveDetectionRulesToMetadataAsync();

                // Step 5: Complete
                AddProgressStep("\uE8FB", "Deployment completed successfully!");
                UpdateProgress(100, "Upload complete!");

                UploadComplete?.Invoke(this, new UploadCompleteEventArgs
                {
                    ApplicationId = appId,
                    GroupIds = groupIds
                });

                await Task.Delay(1000);

                // Complete the notification without showing a new toast (updates sidebar only)
                if (!string.IsNullOrEmpty(NotificationId))
                {
                    Notifications.CompleteNotification(
                        NotificationId,
                        success: true,
                        message: $"Application '{_applicationDetail.DisplayName}' deployed to Intune with {groupIds.Count} assignment groups");
                }

                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Upload failed: {ex}");

                // Complete the notification with error (updates sidebar only)
                if (!string.IsNullOrEmpty(NotificationId))
                {
                    Notifications.CompleteNotification(
                        NotificationId,
                        success: false,
                        message: ex.Message);
                }

                AddProgressStep("\uE711", $"Upload failed: {ex.Message}"); // Error icon
                return false;
            }
        }

        public void UpdateProgress(int percentage, string message)
        {
            UpdateProgress(percentage, message, 0, 0);
        }

        public void UpdateProgress(int percentage, string message, int currentChunk = 0, int totalChunks = 0)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                if (ProgressPanel.Visibility != Visibility.Visible)
                    ProgressPanel.Visibility = Visibility.Visible;

                UploadProgressBar.Value = percentage;
                ProgressPercentageText.Text = $"{percentage}%";

                if (currentChunk > 0 && totalChunks > 0)
                {
                    ProgressStatusText.Text = $"Chunk {currentChunk}/{totalChunks}";
                    Debug.WriteLine($"Progress: {percentage}% - {message} (Chunk {currentChunk}/{totalChunks})");
                }
                else
                {
                    ProgressStatusText.Text = message;
                    Debug.WriteLine($"Progress: {percentage}% - {message}");
                }
            });
        }

        private async Task<string> UploadApplication()
        {
            EnsureIntuneService();
            var uploadService = App.Services.GetRequiredService<IntuneUploadService>();

            try
            {
                // Check PackagePath early
                if (string.IsNullOrEmpty(PackagePath))
                {
                    throw new InvalidOperationException(AppConstants.ValidationMessages.PackagePathRequired);
                }
                var appInfo = ApplicationInfo ?? new ApplicationInfo
                {
                    Name = _applicationDetail?.DisplayName ?? "Unknown",
                    Version = _applicationDetail?.Version ?? "1.0.0",
                    Manufacturer = _applicationDetail?.Publisher ?? "Unknown",
                    InstallContext = _applicationDetail?.InstallContext ?? AppConstants.InstallContext.Default,
                    SourcesPath = PackagePath
                };

                var installCommand = _applicationDetail?.InstallCommand ?? "Invoke-AppDeployToolkit.exe -DeploymentType Install";
                var uninstallCommand = _applicationDetail?.UninstallCommand ?? "Invoke-AppDeployToolkit.exe -DeploymentType Uninstall";
                var description = _applicationDetail?.Description ?? "";
                var installContext = _applicationDetail?.InstallContext ?? AppConstants.InstallContext.Default;

                // Combine detection rules from both sources
                var allDetectionRules = new List<DetectionRule>();
                if (DetectionRules != null) allDetectionRules.AddRange(DetectionRules);
                if (_applicationDetail?.DetectionRules != null)
                    allDetectionRules.AddRange(_applicationDetail.DetectionRules);

                // Remove duplicates based on Type and Path
                allDetectionRules = allDetectionRules
                    .GroupBy(r => new { r.Type, r.Path })
                    .Select(g => g.First())
                    .ToList();

                // Create progress tracker that updates both local UI and toast notification
                IUploadProgress progressTracker = this;
                if (!string.IsNullOrEmpty(NotificationId))
                {
                    // Use composite tracker to update both UI and toast
                    progressTracker = new CompositeProgressTracker(this, new Services.ToastProgressAdapter(NotificationId));
                }

                return await uploadService.UploadWin32ApplicationAsync(
                    appInfo,
                    PackagePath,
                    allDetectionRules,
                    installCommand,
                    uninstallCommand,
                    description,
                    installContext,
                    SelectedIconPath,
                    progressTracker,
                    PredecessorAppId
                );
            }
            finally
            {
                uploadService?.Dispose();
            }
        }

        private async Task<GroupAssignmentIds> CreateAssignmentGroups()
        {
            EnsureIntuneService();
            var groupIds = new GroupAssignmentIds();

            // Use cached group names instead of accessing UI elements from background thread
            var tasks = new[]
            {
                CreateOrGetGroup(_sysInstallGroupName, "System devices for required installation")
                    .ContinueWith(t => groupIds.SystemInstallId = t.Result),
                CreateOrGetGroup(_usrInstallGroupName, "Users for required installation")
                    .ContinueWith(t => groupIds.UserInstallId = t.Result),
                CreateOrGetGroup(_sysUninstallGroupName, "System devices for uninstallation")
                    .ContinueWith(t => groupIds.SystemUninstallId = t.Result),
                CreateOrGetGroup(_usrUninstallGroupName, "Users for uninstallation")
                    .ContinueWith(t => groupIds.UserUninstallId = t.Result)
            };

            await Task.WhenAll(tasks);
            return groupIds;
        }

        private async Task<string> CreateOrGetGroup(string displayName, string description)
        {
            var fullDescription = $"{description} - {_applicationDetail?.DisplayName ?? "Unknown"} v{_applicationDetail?.Version ?? "1.0.0"}";

            // Define the 4 owners
            var ownerIds = new List<string>
    {
        "793c1724-5d8b-4ec0-91b0-7c060725a70b",  // SA_NBB_Azure_Snow_A
        "34b301bd-6e41-41b9-b925-a0825a99cdb7",  // SA_NBB_Azure_Snow_P
        "4d570640-6a0c-49e1-bded-0088b4b99507",  // SA_NBB_Intune_Snow_A
        "e8d9d8eb-84dc-4fac-8305-b2b178abbc19"   // SA_NBB_Intune_Snow_P
    };

            return await _intuneService.CreateOrGetGroupAsync(displayName, fullDescription, ownerIds);
        }

        private async Task AssignGroupsToApplication(string appId, GroupAssignmentIds groupIds)
        {
            EnsureIntuneService();
            await _intuneService.AssignGroupsToApplicationAsync(appId, groupIds);
        }

        /// <summary>
        /// Saves detection rules to package metadata (NBB_Info folder)
        /// Saves to both DetectionRulesCache and PackageMetadata for redundancy
        /// </summary>
        private async Task SaveDetectionRulesToMetadataAsync()
        {
            try
            {
                if (DetectionRules == null || DetectionRules.Count == 0)
                {
                    Debug.WriteLine("No detection rules to save");
                    return;
                }

                // Get the actual package folder path (not the .intunewin file)
                var packageFolderPath = PackagePath;
                if (packageFolderPath.EndsWith(".intunewin", StringComparison.OrdinalIgnoreCase))
                {
                    // Get parent directory twice (Intune/.intunewin -> package root)
                    packageFolderPath = Path.GetDirectoryName(Path.GetDirectoryName(packageFolderPath)) ?? packageFolderPath;
                }

                if (!Directory.Exists(packageFolderPath))
                {
                    Debug.WriteLine($"Package folder not found: {packageFolderPath}");
                    return;
                }

                // Save to DetectionRulesCache (detection_rules.json)
                // This is the same format used by remote test discovery
                var rulesList = new List<DetectionRule>(DetectionRules);
                DetectionRulesCache.SetDiscoveredRules(rulesList, packageFolderPath, "Upload Wizard");
                Debug.WriteLine($"Saved {rulesList.Count} detection rules to DetectionRulesCache");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error saving detection rules to metadata: {ex.Message}");
                // Don't throw - this shouldn't fail the upload
            }
        }

        private void AddProgressStep(string icon, string text)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                _progressSteps.Add(new ProgressStep { Icon = icon, Text = text });
            });
        }

        private void UpdateProgressStep(int index, string icon, string text)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                if (index >= 0 && index < _progressSteps.Count)
                {
                    _progressSteps[index].Icon = icon;
                    _progressSteps[index].Text = text;
                }
            });
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            BackRequested?.Invoke(this, EventArgs.Empty);
        }
    }

    // Supporting classes
    public class ProgressStep : System.ComponentModel.INotifyPropertyChanged
    {
        private string _icon = "";
        private string _text = "";

        public string Icon
        {
            get => _icon;
            set
            {
                if (_icon != value)
                {
                    _icon = value;
                    OnPropertyChanged(nameof(Icon));
                }
            }
        }

        public string Text
        {
            get => _text;
            set
            {
                if (_text != value)
                {
                    _text = value;
                    OnPropertyChanged(nameof(Text));
                }
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler? PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
        }
    }

    public class UploadCompleteEventArgs : EventArgs
    {
        public string ApplicationId { get; set; } = "";
        public GroupAssignmentIds GroupIds { get; set; } = new();
    }

    /// <summary>
    /// Composite progress tracker that updates multiple progress targets
    /// </summary>
    internal class CompositeProgressTracker : IUploadProgress
    {
        private readonly IUploadProgress[] _trackers;

        public CompositeProgressTracker(params IUploadProgress[] trackers)
        {
            _trackers = trackers;
        }

        public void UpdateProgress(int percentage, string message)
        {
            foreach (var tracker in _trackers)
            {
                tracker.UpdateProgress(percentage, message);
            }
        }
    }
}