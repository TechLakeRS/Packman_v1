﻿using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite.Constants;
using Endpoint_Packaging_Suite.Dialogs;
using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite.Services;
using Microsoft.Win32;
using System;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace Endpoint_Packaging_Suite.WizardSteps
{
    public partial class AppDetailsStep : UserControl
    {
        public event ValidationChangedEventHandler? ValidationChanged;
        public event DataChangedEventHandler? DataChanged;

        private ApplicationInfo? _applicationInfo;
        private string _selectedIconPath = "";
        private bool _isLoadingData = false; // Flag to prevent event firing during data load
        private string _packagePath = ""; // Store package path for icon loading

        public ApplicationInfo? ApplicationInfo
        {
            get => _applicationInfo;
            set
            {
                _applicationInfo = value;
                LoadApplicationData();
            }
        }

        public string PackagePath
        {
            get => _packagePath;
            set => _packagePath = value;
        }

        public string SelectedIconPath => _selectedIconPath;

        public AppDetailsStep()
        {
            InitializeComponent();

            // Wire up validation events for real-time feedback
            AppNameTextBox.TextChanged += (s, e) => ValidateAndNotify();
            PublisherTextBox.TextChanged += (s, e) => ValidateAndNotify();
            VersionTextBox.TextChanged += (s, e) => ValidateAndNotify();
            DescriptionTextBox.TextChanged += (s, e) => ValidateAndNotify();

            // Set default values
            SetDefaultValues();

            // Initial validation
            ValidateAndNotify();
        }

        private void SetDefaultValues()
        {
            DescriptionTextBox.Text = "Application packaged with EPS";
        }

        private async void LoadApplicationData()
        {
            if (_applicationInfo != null)
            {
                // Set flag to prevent event handlers from firing during initialization
                _isLoadingData = true;

                try
                {
                    // Populate fields from ApplicationInfo
                    if (!string.IsNullOrWhiteSpace(_applicationInfo.Name))
                        AppNameTextBox.Text = _applicationInfo.Name;

                    if (!string.IsNullOrWhiteSpace(_applicationInfo.Manufacturer))
                        PublisherTextBox.Text = _applicationInfo.Manufacturer;

                    if (!string.IsNullOrWhiteSpace(_applicationInfo.Version))
                        VersionTextBox.Text = _applicationInfo.Version;

                    // Update description with app info if default
                    if (string.IsNullOrWhiteSpace(DescriptionTextBox.Text) ||
                        DescriptionTextBox.Text == "Application packaged with EPS")
                    {
                        DescriptionTextBox.Text = $"{_applicationInfo.Name} {_applicationInfo.Version} - Packaged with EPS";
                    }

                    // Auto-load icon from package metadata if available
                    await TryLoadIconFromPackageAsync();
                }
                finally
                {
                    // Clear flag after loading is complete
                    _isLoadingData = false;
                }

                // Now trigger validation to notify the wizard that the form is ready
                Debug.WriteLine("LoadApplicationData complete - triggering validation only");
                var isValid = ValidateForm();
                ValidationChanged?.Invoke(isValid);
            }
        }

        /// <summary>
        /// Auto-loads icon from Icon folder by scanning for image files
        /// </summary>
        private async System.Threading.Tasks.Task TryLoadIconFromPackageAsync()
        {
            try
            {
                // Need package path to load icon
                if (string.IsNullOrEmpty(_packagePath))
                {
                    Debug.WriteLine("PackagePath not set - cannot auto-load icon");
                    return;
                }

                var iconFolder = Path.Combine(_packagePath, "Icon");
                if (!Directory.Exists(iconFolder))
                {
                    Debug.WriteLine("Icon folder not found");
                    return;
                }

                // Look for common icon file extensions
                var iconExtensions = new[] { "*.png", "*.ico", "*.jpg", "*.jpeg" };
                string? iconPath = null;

                foreach (var ext in iconExtensions)
                {
                    var files = Directory.GetFiles(iconFolder, ext);
                    if (files.Length > 0)
                    {
                        iconPath = files[0]; // Use first icon found
                        break;
                    }
                }

                if (iconPath == null || !File.Exists(iconPath))
                {
                    Debug.WriteLine("No icon file found in Icon folder");
                    return;
                }

                // Load and display the icon
                _selectedIconPath = iconPath;

                await System.Threading.Tasks.Task.Run(() =>
                {
                    Dispatcher.Invoke(() =>
                    {
                        var bitmap = new BitmapImage();
                        bitmap.BeginInit();
                        bitmap.CacheOption = BitmapCacheOption.OnLoad;
                        bitmap.UriSource = new Uri(iconPath);
                        bitmap.DecodePixelWidth = 32;
                        bitmap.EndInit();

                        SelectedIconImage.Source = bitmap;
                        SelectedIconImage.Visibility = Visibility.Visible;
                        DefaultIconText.Visibility = Visibility.Collapsed;

                        SelectedIconText.Text = $"Loaded from package: {Path.GetFileName(iconPath)}";
                        SelectedIconText.Visibility = Visibility.Visible;
                    });
                });

                Debug.WriteLine($"✅ Auto-loaded icon from package: {iconPath}");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error auto-loading icon from package: {ex.Message}");
                // Don't throw - this is optional
            }
        }

        private void BrowseIconButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dialog = new OpenFileDialog
                {
                    Title = "Select Application Icon",
                    Filter = "Image files (*.png;*.ico;*.jpg)|*.png;*.ico;*.jpg|All files (*.*)|*.*"
                };

                if (dialog.ShowDialog() == true)
                {
                    _selectedIconPath = dialog.FileName;

                    // Try to load and display the icon
                    try
                    {
                        var bitmap = new BitmapImage();
                        bitmap.BeginInit();
                        bitmap.UriSource = new Uri(dialog.FileName);
                        bitmap.DecodePixelWidth = 32;
                        bitmap.EndInit();

                        SelectedIconImage.Source = bitmap;
                        SelectedIconImage.Visibility = Visibility.Visible;
                        DefaultIconText.Visibility = Visibility.Collapsed;
                    }
                    catch
                    {
                        // If image fails to load, just show checkmark
                        DefaultIconText.Text = "✅";
                    }

                    SelectedIconText.Text = $"Selected: {Path.GetFileName(dialog.FileName)}";
                    SelectedIconText.Visibility = Visibility.Visible;

                    // Notify parent of data change
                    NotifyDataChanged();
                }
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error selecting icon: {ex.Message}", "Icon Selection Error",
                    MessageBoxButton.OK, MessageBoxIcon.Error);
            }
        }

        private void ValidateAndNotify()
        {
            // Skip if we're currently loading data to prevent overwriting initial values
            if (_isLoadingData)
            {
                Debug.WriteLine("ValidateAndNotify skipped - loading data in progress");
                return;
            }

            var isValid = ValidateForm();
            ValidationChanged?.Invoke(isValid);

            if (isValid)
            {
                NotifyDataChanged();
            }
        }

        private bool ValidateForm()
        {
            // Check required fields - SIMPLIFIED: only user-editable fields
            return !string.IsNullOrWhiteSpace(AppNameTextBox.Text) &&
                   !string.IsNullOrWhiteSpace(PublisherTextBox.Text) &&
                   !string.IsNullOrWhiteSpace(VersionTextBox.Text) &&
                   !string.IsNullOrWhiteSpace(DescriptionTextBox.Text);
        }

        private void NotifyDataChanged()
        {
            if (_applicationInfo != null)
            {
                // Create updated ApplicationInfo with current form values
                var updatedInfo = new ApplicationInfo
                {
                    Name = AppNameTextBox.Text.Trim(),
                    Manufacturer = PublisherTextBox.Text.Trim(),
                    Version = VersionTextBox.Text.Trim(),
                    SourcesPath = _applicationInfo.SourcesPath,
                    ServiceNowSRI = _applicationInfo.ServiceNowSRI,
                    // Preserve MSI information if present
                    MsiProductCode = _applicationInfo.MsiProductCode,
                    MsiProductVersion = _applicationInfo.MsiProductVersion,
                    MsiUpgradeCode = _applicationInfo.MsiUpgradeCode,
                    // Preserve install context from original application info
                    InstallContext = _applicationInfo.InstallContext
                };

                DataChanged?.Invoke(updatedInfo);
            }
        }

        // Public methods for wizard to access data
        public string GetDescription() => DescriptionTextBox.Text.Trim();
        public string GetSelectedIconPath() => _selectedIconPath;

        // Public methods to set values
        public void SetDescription(string description)
        {
            DescriptionTextBox.Text = description;
        }

        // Populate data from ApplicationInfo
        public void LoadFromApplicationInfo(ApplicationInfo appInfo)
        {
            if (appInfo != null)
            {
                _applicationInfo = appInfo;
                LoadApplicationData();
            }
        }
    }
}