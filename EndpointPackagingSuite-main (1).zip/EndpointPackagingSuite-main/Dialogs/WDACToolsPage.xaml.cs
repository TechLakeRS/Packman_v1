﻿using Endpoint_Packaging_Suite.Dialogs;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Win32;
using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite.Services;
using Endpoint_Packaging_Suite.Helpers;

namespace Endpoint_Packaging_Suite
{
    public partial class WDACToolsPage : UserControl
    {
        private readonly ObservableCollection<CatalogTask> _catalogTasks;
        private readonly HyperVCatalogService _hyperVService;
        private readonly SemaphoreSlim _queueSemaphore;
        private bool _isProcessorRunning;

        public ObservableCollection<CatalogTask> CatalogTasks => _catalogTasks;

        public WDACToolsPage()
        {
            InitializeComponent();
            _catalogTasks = new ObservableCollection<CatalogTask>();

            // Native Authenticode signer from DI — used to sign the generated .cat file.
            var signer = App.Services.GetService<NativeCodeSigner>();
            _hyperVService = new HyperVCatalogService(signer);
            _hyperVService.StatusChanged += HyperVService_StatusChanged;
            _hyperVService.DetailChanged += HyperVService_DetailChanged;
            _queueSemaphore = new SemaphoreSlim(1, 1);
            _isProcessorRunning = false;

            DataContext = this;
            CatalogQueueGrid.ItemsSource = _catalogTasks;

            // Start the background queue processor
            _catalogTasks.CollectionChanged += (s, e) => UpdateStatusBar();
            _ = QueueProcessor();
        }
        private void UpdateStatusBar()
        {
            Dispatcher.Invoke(() =>
            {
                TotalTasksText.Text = _catalogTasks.Count.ToString();
                QueuedTasksText.Text = _catalogTasks.Count(t => t.Status == "Queued").ToString();
                RunningTasksText.Text = _catalogTasks.Count(t => t.Status == "Running").ToString();
            });
        }
        #region Queue Processor

        private async Task QueueProcessor()
        {
            _isProcessorRunning = true;

            while (_isProcessorRunning)
            {
                try
                {
                    await Task.Delay(1000); // Check every second

                    // Find next queued task
                    var nextTask = _catalogTasks.FirstOrDefault(t => t.Status == "Queued");

                    if (nextTask != null)
                    {
                        await ProcessTask(nextTask);
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"Queue processor error: {ex.Message}");
                }
            }
        }

        private async Task ProcessTask(CatalogTask task)
        {
            await _queueSemaphore.WaitAsync();

            try
            {
                await ProcessHyperVTask(task);
            }
            finally
            {
                _queueSemaphore.Release();
            }
        }

        private async Task ProcessHyperVTask(CatalogTask task)
        {
            await Dispatcher.InvokeAsync(() =>
            {
                task.Status = "Running";
                HyperVStatusPanel.Visibility = Visibility.Visible;
                UpdateStatusBar();
            });

            try
            {
                var result = await _hyperVService.GenerateCatalogAsync(
                    task.HyperVHost,
                    task.VMName,
                    task.SnapshotName,
                    task.PackagePath);

                await Dispatcher.InvokeAsync(() =>
                {
                    if (result.Success)
                    {
                        task.Status = "Complete";
                        task.CatalogPath = result.CatalogFilePath;
                        task.Hash = result.CatalogHash;
                    }
                    else
                    {
                        task.Status = $"Failed: {result.ErrorMessage}";
                    }

                    UpdateStatusBar();
                });
            }
            catch (Exception ex)
            {
                await Dispatcher.InvokeAsync(() =>
                {
                    task.Status = $"Error: {ex.Message}";
                    UpdateStatusBar();
                });
            }
            finally
            {
                await Dispatcher.InvokeAsync(() =>
                {
                    HyperVStatusPanel.Visibility = Visibility.Collapsed;
                });
            }
        }

        #endregion

        #region Event Handlers

        private void HyperVService_StatusChanged(object? sender, string status)
        {
            Dispatcher.Invoke(() =>
            {
                HyperVStatusText.Text = status;
            });
        }

        private void HyperVService_DetailChanged(object? sender, string detail)
        {
            Dispatcher.Invoke(() =>
            {
                HyperVStatusDetail.Text = detail;
            });
        }

        private void BrowseHyperVApp_Click(object sender, RoutedEventArgs e)
        {
            // Use modern folder browser for better UX
            var selectedPath = FolderBrowserHelper.ShowPackageFolderBrowser(
                validatePackageStructure: FolderBrowserHelper.ValidatePackageStructure);

            if (string.IsNullOrEmpty(selectedPath))
                return;

            // Get the actual package root (in case user selected Application folder)
            var applicationPath = FolderBrowserHelper.GetPackageRootPath(selectedPath);

            HyperVAppPathTextBox.Text = applicationPath;
            GenerateHyperVCatalogButton.IsEnabled = true;
        }
        private void VerifyCatalogs_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.OpenFileDialog
            {
                Title = "Select Catalog Files to Verify",
                Filter = "Catalog Files (*.cat)|*.cat|All Files (*.*)|*.*",
                Multiselect = true,
                InitialDirectory = @"\\nbb.local\sys\SCCMData\SCRIPTS\Intune\CreateSecurityCatalog\CatTS"
            };

            // Fallback if network path not accessible
            if (!Directory.Exists(dialog.InitialDirectory))
            {
                dialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            }

            if (dialog.ShowDialog() == true)
            {
                var catalogPaths = dialog.FileNames.ToList();

                if (catalogPaths.Count == 0)
                {
                    ModernMessageBox.Show("No catalog files selected.",
                        "No Selection", MessageBoxButton.OK, MessageBoxIcon.Information);
                    return;
                }

                var verificationWindow = new CatalogVerificationWindow(catalogPaths);
                verificationWindow.Owner = Window.GetWindow(this);
                verificationWindow.ShowDialog();
            }
        }

      

        private void GenerateHyperVCatalog_Click(object sender, RoutedEventArgs e)
        {

            var appPath = HyperVAppPathTextBox.Text.Trim();

            if (string.IsNullOrEmpty(appPath))
            {
                ModernMessageBox.Show("Please select an application path.", "Input Required",
                    MessageBoxButton.OK, MessageBoxIcon.Warning);
                return;
            }

            var appInfo = ApplicationHelper.ParseApplicationInfo(appPath);

            var task = new CatalogTask
            {
                AppName = appInfo.Name,
                Version = appInfo.Version,
                PackagePath = appPath,
                HyperVHost = Paths.WDACHyperV.Host,
                VMName = Paths.WDACHyperV.VMName,
                SnapshotName = Paths.WDACHyperV.SnapshotName,
                Status = "Queued",
                IsSelected = true
            };

            _catalogTasks.Add(task);

            // Clear the path so user can add another
            HyperVAppPathTextBox.Text = "";
            GenerateHyperVCatalogButton.IsEnabled = false;
        }

        #endregion

        #region Context Menu

        private void CatalogQueueGrid_MouseRightButtonUp(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            var menu = new ContextMenu();

            var removeItem = new MenuItem { Header = "Remove Selected" };
            removeItem.Click += (s, args) =>
            {
                var selected = _catalogTasks.Where(t => t.IsSelected && t.Status == "Queued").ToList();
                foreach (var task in selected)
                    _catalogTasks.Remove(task);
            };
            menu.Items.Add(removeItem);

            menu.Items.Add(new Separator());

            var clearCompletedItem = new MenuItem { Header = "Clear Completed" };
            clearCompletedItem.Click += (s, args) =>
            {
                var completed = _catalogTasks
                    .Where(t => t.Status.Contains("Complete") || t.Status.Contains("Failed") || t.Status.Contains("Error"))
                    .ToList();
                foreach (var task in completed)
                    _catalogTasks.Remove(task);
            };
            menu.Items.Add(clearCompletedItem);

            menu.Items.Add(new Separator());

            var exportItem = new MenuItem { Header = "Export Results to CSV" };
            exportItem.Click += ExportResults_Click;
            menu.Items.Add(exportItem);

            menu.IsOpen = true;
        }

        private void ExportResults_Click(object sender, RoutedEventArgs e)
        {
            var saveDialog = new SaveFileDialog
            {
                Title = "Export Catalog Results",
                Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*",
                FileName = $"WDAC_Catalogs_{DateTime.Now:yyyyMMdd_HHmmss}.csv"
            };

            if (saveDialog.ShowDialog() == true)
            {
                try
                {
                    var csv = new System.Text.StringBuilder();
                    csv.AppendLine("AppName,Version,Status,CatalogPath,Hash,HyperVHost,VMName");

                    foreach (var task in _catalogTasks)
                    {
                        csv.AppendLine($"\"{task.AppName}\",\"{task.Version}\",\"{task.Status}\",\"{task.CatalogPath}\",\"{task.Hash}\",\"{task.HyperVHost}\",\"{task.VMName}\"");
                    }

                    File.WriteAllText(saveDialog.FileName, csv.ToString());
                    ModernMessageBox.Show("Results exported successfully!", "Export Complete",
                        MessageBoxButton.OK, MessageBoxIcon.Success);
                }
                catch (Exception ex)
                {
                    ModernMessageBox.Show($"Error exporting results: {ex.Message}", "Export Error",
                        MessageBoxButton.OK, MessageBoxIcon.Error);
                }
            }
        }

        #endregion
    }
}