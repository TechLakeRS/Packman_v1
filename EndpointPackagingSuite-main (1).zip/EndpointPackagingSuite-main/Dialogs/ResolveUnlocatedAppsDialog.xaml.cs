using Endpoint_Packaging_Suite.Helpers;
using Endpoint_Packaging_Suite.ViewModels;
using Microsoft.Win32;
using System.IO;
using System.Windows;

namespace Endpoint_Packaging_Suite.Dialogs
{
    public partial class ResolveUnlocatedAppsDialog : Window
    {
        private readonly List<UnlocatedAppItem> _items;

        public int ResolvedCount { get; private set; }

        public ResolveUnlocatedAppsDialog(IReadOnlyList<(string appId, string displayName, string? version)> apps)
        {
            InitializeComponent();

            _items = apps
                .Select(a => new UnlocatedAppItem(a.appId, a.displayName, a.version))
                .ToList();
            AppsList.ItemsSource = _items;

            SubtitleText.Text =
                $"{_items.Count} package(s) could not be auto-located. " +
                "Browse to each Invoke-AppDeployToolkit.exe to pin its folder, then Save.";
            UpdateFooter();
        }

        private void Browse_Click(object sender, RoutedEventArgs e)
        {
            if (((FrameworkElement)sender).DataContext is not UnlocatedAppItem item)
                return;

            var path = BrowseForPackageFolder();
            if (path == null)
                return;

            item.ResolvedPath = path;
            UpdateFooter();
        }

        private string? BrowseForPackageFolder()
        {
            var dialog = new OpenFileDialog
            {
                Title = "Select Invoke-AppDeployToolkit.exe",
                Filter = "Invoke-AppDeployToolkit|Invoke-AppDeployToolkit.exe|All Files|*.*",
                FileName = "Invoke-AppDeployToolkit.exe",
                CheckFileExists = true,
                CheckPathExists = true,
                InitialDirectory = NetworkShareHelper.ShareRoot
            };

            if (dialog.ShowDialog(this) != true)
                return null;

            if (!Path.GetFileName(dialog.FileName).Equals(
                    "Invoke-AppDeployToolkit.exe", StringComparison.OrdinalIgnoreCase))
            {
                ModernMessageBox.Show("Please select the Invoke-AppDeployToolkit.exe file.",
                    "Invalid File", MessageBoxButton.OK, MessageBoxIcon.Warning);
                return null;
            }

            var applicationFolder = Path.GetDirectoryName(dialog.FileName);
            var packageRoot = Path.GetDirectoryName(applicationFolder);
            if (string.IsNullOrEmpty(packageRoot))
            {
                ModernMessageBox.Show("Could not determine the package folder from the selected file.",
                    "Invalid Path", MessageBoxButton.OK, MessageBoxIcon.Warning);
                return null;
            }

            return packageRoot;
        }

        private async void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            var resolved = _items.Where(i => i.IsResolved).ToList();
            if (resolved.Count == 0)
            {
                Close();
                return;
            }

            SaveButton.IsEnabled = false;
            CancelButton.IsEnabled = false;
            FooterStatus.Text = "Saving markers...";

            ResolvedCount = await Task.Run(() =>
            {
                int saved = 0;
                foreach (var item in resolved)
                {
                    if (NetworkShareHelper.SaveMarker(
                            item.ResolvedPath!, item.AppId, item.DisplayName, item.Version))
                        saved++;
                }
                return saved;
            });

            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void UpdateFooter()
        {
            FooterStatus.Text = $"{_items.Count(i => i.IsResolved)} of {_items.Count} assigned";
        }
    }

    public class UnlocatedAppItem : ViewModelBase
    {
        public UnlocatedAppItem(string appId, string displayName, string? version)
        {
            AppId = appId;
            DisplayName = displayName;
            Version = version;
        }

        public string AppId { get; }
        public string DisplayName { get; }
        public string? Version { get; }

        public string DisplayLabel =>
            string.IsNullOrWhiteSpace(Version) ? DisplayName : $"{DisplayName}  ({Version})";

        private string? _resolvedPath;
        public string? ResolvedPath
        {
            get => _resolvedPath;
            set
            {
                if (SetProperty(ref _resolvedPath, value))
                {
                    OnPropertyChanged(nameof(IsResolved));
                    OnPropertyChanged(nameof(StatusText));
                }
            }
        }

        public bool IsResolved => !string.IsNullOrEmpty(ResolvedPath);

        public string StatusText => IsResolved ? ResolvedPath! : "No folder assigned";
    }
}
