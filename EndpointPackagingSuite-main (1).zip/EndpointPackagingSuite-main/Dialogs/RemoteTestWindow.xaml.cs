using System.Windows;
using Endpoint_Packaging_Suite.Services;
using Microsoft.Extensions.DependencyInjection;

namespace Endpoint_Packaging_Suite
{
    public partial class RemoteTestWindow : Window
    {
        // Service locator used here because WPF code-behind doesn't support constructor injection
        private NotificationService Notifications => App.Services.GetRequiredService<NotificationService>();

        // Constructor with optional package path parameter (supports both modes)
        public RemoteTestWindow(string packagePath = "")
        {
            InitializeComponent();

            // Initialize the content control with the package path (dialog mode hides internal Deploy button)
            remoteTestContent.Initialize(packagePath, isDialogMode: true);

            // Subscribe to CanDeploy state changes to enable/disable footer Deploy button
            remoteTestContent.CanDeployChanged += RemoteTestContent_CanDeployChanged;

            // Use this dialog's ToastContainer for notifications while it's open
            Loaded += (s, e) => Notifications.Initialize(ToastContainer);
        }

        // Event Handler: CanDeploy state changed
        private void RemoteTestContent_CanDeployChanged(object? sender, System.EventArgs e)
        {
            btnDeploy.IsEnabled = remoteTestContent.CanDeploy;
        }

        // Event Handler: Deploy Button Click
        private void btnDeploy_Click(object sender, RoutedEventArgs e)
        {
            remoteTestContent.TriggerDeploy();
        }

        // Event Handler: Close Button Click
        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}