﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace Endpoint_Packaging_Suite.Dialogs
{
    public enum MessageBoxIcon
    {
        None,
        Information,
        Warning,
        Error,
        Question,
        Success
    }

    public partial class ModernMessageBox : Window
    {
        private MessageBoxResult _result = MessageBoxResult.None;
        private MessageBoxButton _buttonConfig = MessageBoxButton.OK;
        private bool _detailsExpanded = false;
        private Button? _primaryButton = null;

        private ModernMessageBox()
        {
            InitializeComponent();
            Loaded += ModernMessageBox_Loaded;
        }

        private void ModernMessageBox_Loaded(object sender, RoutedEventArgs e)
        {
            // Play open animation
            var storyboard = (Storyboard)FindResource("OpenAnimation");
            storyboard.Begin(this);

            // Focus primary button for Enter key support
            _primaryButton?.Focus();
        }

        #region Static Show Methods

        /// <summary>
        /// Shows a message box with OK button
        /// </summary>
        public static MessageBoxResult Show(string message, string title = "Message")
        {
            return Show(message, title, MessageBoxButton.OK, MessageBoxIcon.Information);
        }

        /// <summary>
        /// Shows a message box with specified buttons
        /// </summary>
        public static MessageBoxResult Show(string message, string title, MessageBoxButton buttons)
        {
            return Show(message, title, buttons, MessageBoxIcon.Information);
        }

        /// <summary>
        /// Shows a message box with specified buttons and icon
        /// </summary>
        public static MessageBoxResult Show(string message, string title, MessageBoxButton buttons, MessageBoxIcon icon)
        {
            return Show(null, message, title, buttons, icon);
        }

        /// <summary>
        /// Shows a message box with owner window
        /// </summary>
        public static MessageBoxResult Show(Window? owner, string message, string title, MessageBoxButton buttons, MessageBoxIcon icon)
        {
            return ShowWithDetails(owner, message, title, buttons, icon, null);
        }

        /// <summary>
        /// Shows a message box with expandable details section
        /// </summary>
        public static MessageBoxResult ShowWithDetails(string message, string title, MessageBoxButton buttons, MessageBoxIcon icon, string? details)
        {
            return ShowWithDetails(null, message, title, buttons, icon, details);
        }

        /// <summary>
        /// Shows a message box with owner window and expandable details section
        /// </summary>
        public static MessageBoxResult ShowWithDetails(Window? owner, string message, string title, MessageBoxButton buttons, MessageBoxIcon icon, string? details)
        {
            var msgBox = new ModernMessageBox();
            msgBox.Owner = owner;
            msgBox._buttonConfig = buttons;
            msgBox.TitleText.Text = title;
            msgBox.Title = title;
            msgBox.MessageText.Text = message ?? string.Empty;

            msgBox.SetIcon(icon);
            msgBox.CreateButtons(buttons);

            // Set up details section if provided
            if (!string.IsNullOrWhiteSpace(details))
            {
                msgBox.DetailsSection.Visibility = Visibility.Visible;
                msgBox.DetailsText.Text = details;
            }

            msgBox.ShowDialog();
            return msgBox._result;
        }

        #endregion

        #region Icon Setup

        private void SetIcon(MessageBoxIcon icon)
        {
            Geometry? iconData = null;
            Brush? iconColor = null;

            switch (icon)
            {
                case MessageBoxIcon.Information:
                    iconData = (Geometry)FindResource("InfoIcon");
                    iconColor = (Brush)FindResource("InfoColorBrush");
                    break;
                case MessageBoxIcon.Warning:
                    iconData = (Geometry)FindResource("WarningIcon");
                    iconColor = (Brush)FindResource("WarningColorBrush");
                    break;
                case MessageBoxIcon.Error:
                    iconData = (Geometry)FindResource("ErrorIcon");
                    iconColor = (Brush)FindResource("ErrorColorBrush");
                    break;
                case MessageBoxIcon.Question:
                    iconData = (Geometry)FindResource("QuestionIcon");
                    iconColor = (Brush)FindResource("InfoColorBrush");
                    break;
                case MessageBoxIcon.Success:
                    iconData = (Geometry)FindResource("SuccessIcon");
                    iconColor = (Brush)FindResource("SuccessBrush");
                    break;
                default:
                    IconPath.Visibility = Visibility.Collapsed;
                    return;
            }

            IconPath.Data = iconData;
            IconPath.Fill = iconColor;
        }

        #endregion

        #region Button Creation

        private void CreateButtons(MessageBoxButton buttons)
        {
            ButtonPanel.Children.Clear();
            bool isFirst = true;

            switch (buttons)
            {
                case MessageBoxButton.OK:
                    AddButton("OK", MessageBoxResult.OK, true, ref isFirst);
                    // Single button - center it
                    ButtonPanel.HorizontalAlignment = HorizontalAlignment.Center;
                    break;

                case MessageBoxButton.OKCancel:
                    AddButton("Cancel", MessageBoxResult.Cancel, false, ref isFirst);
                    AddButton("OK", MessageBoxResult.OK, true, ref isFirst);
                    break;

                case MessageBoxButton.YesNo:
                    AddButton("No", MessageBoxResult.No, false, ref isFirst);
                    AddButton("Yes", MessageBoxResult.Yes, true, ref isFirst);
                    break;

                case MessageBoxButton.YesNoCancel:
                    AddButton("Cancel", MessageBoxResult.Cancel, false, ref isFirst);
                    AddButton("No", MessageBoxResult.No, false, ref isFirst);
                    AddButton("Yes", MessageBoxResult.Yes, true, ref isFirst);
                    break;
            }
        }

        private void AddButton(string text, MessageBoxResult result, bool isPrimary, ref bool isFirst)
        {
            var button = new Button
            {
                Content = text,
                MinWidth = 80,
                Padding = new Thickness(16, 8, 16, 8),
                Margin = new Thickness(isFirst ? 0 : 8, 0, 0, 0),
                Cursor = Cursors.Hand
            };

            isFirst = false;

            if (isPrimary)
            {
                button.Style = (Style)FindResource("ModernButton");
                _primaryButton = button;
            }
            else
            {
                button.Style = (Style)FindResource("SecondaryButton");
            }

            button.Click += (s, e) =>
            {
                _result = result;
                Close();
            };

            ButtonPanel.Children.Add(button);
        }

        #endregion

        #region Window Events

        private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount == 1)
            {
                DragMove();
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            // Smart close behavior based on button configuration
            _result = GetSmartCloseResult();
            Close();
        }

        private MessageBoxResult GetSmartCloseResult()
        {
            // Return appropriate result based on button config
            switch (_buttonConfig)
            {
                case MessageBoxButton.OK:
                    return MessageBoxResult.OK;
                case MessageBoxButton.OKCancel:
                case MessageBoxButton.YesNoCancel:
                    return MessageBoxResult.Cancel;
                case MessageBoxButton.YesNo:
                    return MessageBoxResult.No;
                default:
                    return MessageBoxResult.None;
            }
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                _result = GetSmartCloseResult();
                Close();
                e.Handled = true;
            }
            else if (e.Key == Key.Enter && _primaryButton != null)
            {
                // Trigger primary button click
                _primaryButton.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                e.Handled = true;
            }
        }

        #endregion

        #region Details Section

        private void DetailsToggle_Click(object sender, RoutedEventArgs e)
        {
            _detailsExpanded = !_detailsExpanded;
            DetailsContent.Visibility = _detailsExpanded ? Visibility.Visible : Visibility.Collapsed;

            // Animate arrow rotation
            var arrow = FindName("ExpandArrow") as System.Windows.Shapes.Path;
            if (arrow?.RenderTransform is RotateTransform rotate)
            {
                var animation = new DoubleAnimation
                {
                    To = _detailsExpanded ? 180 : 0,
                    Duration = TimeSpan.FromMilliseconds(150),
                    EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
                };
                rotate.BeginAnimation(RotateTransform.AngleProperty, animation);
            }
        }

        private void CopyDetails_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Clipboard.SetText(DetailsText.Text);

                // Visual feedback - briefly change tooltip
                CopyDetailsButton.ToolTip = "Copied!";
                var timer = new System.Windows.Threading.DispatcherTimer
                {
                    Interval = TimeSpan.FromSeconds(1.5)
                };
                timer.Tick += (s, args) =>
                {
                    CopyDetailsButton.ToolTip = "Copy to clipboard";
                    timer.Stop();
                };
                timer.Start();
            }
            catch
            {
                // Ignore clipboard errors
            }
        }

        #endregion
    }
}