using Endpoint_Packaging_Suite.Services;
using Endpoint_Packaging_Suite.ViewModels;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace Endpoint_Packaging_Suite.Dialogs
{
    public partial class PurgeGroupDialog : Window
    {
        private readonly IntuneService _intuneService;
        private readonly string _groupId;
        private readonly string _groupName;

        private readonly ObservableCollection<PurgeAppItem> _items = new ObservableCollection<PurgeAppItem>();
        private bool _suppressSelectAllSync;

        public int RemovedCount { get; private set; }

        public PurgeGroupDialog(IntuneService intuneService, string groupId, string groupName)
        {
            InitializeComponent();

            _intuneService = intuneService ?? throw new ArgumentNullException(nameof(intuneService));
            _groupId = groupId;
            _groupName = groupName;

            SubtitleText.Text = $"Applications with '{_groupName}' assigned. Remove the assignment from selected apps or from all of them.";
            AppsList.ItemsSource = _items;

            Loaded += async (_, _) => await LoadAssignmentsAsync();
        }

        private async Task LoadAssignmentsAsync()
        {
            ShowLoading(true, "Scanning applications...");
            FooterStatus.Text = "";

            try
            {
                var progress = new Progress<(int current, int total)>(p =>
                {
                    LoadingText.Text = $"Scanning applications... {p.current}/{p.total}";
                });

                var matches = await _intuneService.GetApplicationsAssignedToGroupAsync(_groupId, progress);

                _items.Clear();
                foreach (var match in matches)
                {
                    var item = new PurgeAppItem(match);
                    item.PropertyChanged += Item_PropertyChanged;
                    _items.Add(item);
                }

                ShowLoading(false);

                if (_items.Count == 0)
                {
                    EmptyPanel.Visibility = Visibility.Visible;
                    ListScrollViewer.Visibility = Visibility.Collapsed;
                    SelectAllCheckBox.IsEnabled = false;
                    FooterStatus.Text = "";
                }
                else
                {
                    EmptyPanel.Visibility = Visibility.Collapsed;
                    ListScrollViewer.Visibility = Visibility.Visible;
                    SelectAllCheckBox.IsEnabled = true;
                    RemoveAllButton.IsEnabled = true;
                    UpdateSelectionUi();
                }
            }
            catch (Exception ex)
            {
                ShowLoading(false);
                ModernMessageBox.Show($"Failed to load assignments:\n\n{ex.Message}",
                    "Purge Group", MessageBoxButton.OK, MessageBoxIcon.Error);
                Close();
            }
        }

        private void Item_PropertyChanged(object? sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(PurgeAppItem.IsSelected))
            {
                UpdateSelectionUi();
            }
        }

        private void UpdateSelectionUi()
        {
            var selectedCount = _items.Count(i => i.IsSelected);
            SelectionCountText.Text = $"{selectedCount} of {_items.Count} selected";
            RemoveSelectedButton.IsEnabled = selectedCount > 0;

            _suppressSelectAllSync = true;
            if (selectedCount == 0)
                SelectAllCheckBox.IsChecked = false;
            else if (selectedCount == _items.Count)
                SelectAllCheckBox.IsChecked = true;
            else
                SelectAllCheckBox.IsChecked = null;
            _suppressSelectAllSync = false;
        }

        private void SelectAllCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            if (_suppressSelectAllSync) return;
            foreach (var item in _items) item.IsSelected = true;
        }

        private void SelectAllCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            if (_suppressSelectAllSync) return;
            foreach (var item in _items) item.IsSelected = false;
        }

        private async void RemoveSelectedButton_Click(object sender, RoutedEventArgs e)
        {
            var selected = _items.Where(i => i.IsSelected).ToList();
            if (selected.Count == 0) return;

            var confirm = ModernMessageBox.Show(
                $"Remove '{_groupName}' from {selected.Count} application(s)?",
                "Confirm Purge", MessageBoxButton.YesNo, MessageBoxIcon.Question);
            if (confirm != MessageBoxResult.Yes) return;

            await RemoveAssignmentsAsync(selected);
        }

        private async void RemoveAllButton_Click(object sender, RoutedEventArgs e)
        {
            if (_items.Count == 0) return;

            var confirm = ModernMessageBox.Show(
                $"Remove '{_groupName}' from all {_items.Count} application(s)?",
                "Confirm Purge", MessageBoxButton.YesNo, MessageBoxIcon.Warning);
            if (confirm != MessageBoxResult.Yes) return;

            await RemoveAssignmentsAsync(_items.ToList());
        }

        private async Task RemoveAssignmentsAsync(List<PurgeAppItem> targets)
        {
            SetActionsEnabled(false);
            RemoveProgressBar.Visibility = Visibility.Visible;
            RemoveProgressBar.Maximum = targets.Count;
            RemoveProgressBar.Value = 0;

            int succeeded = 0;
            int failed = 0;
            var failures = new List<string>();

            for (int i = 0; i < targets.Count; i++)
            {
                var item = targets[i];
                FooterStatus.Text = $"Removing {i + 1} of {targets.Count}: {item.DisplayLabel}";

                try
                {
                    await _intuneService.RemoveAssignmentAsync(item.AppId, item.AssignmentId);
                    _items.Remove(item);
                    succeeded++;
                }
                catch (Exception ex)
                {
                    failed++;
                    failures.Add($"{item.DisplayLabel}: {ex.Message}");
                }

                RemoveProgressBar.Value = i + 1;
            }

            RemovedCount += succeeded;
            RemoveProgressBar.Visibility = Visibility.Collapsed;
            FooterStatus.Text = failed == 0
                ? $"Removed from {succeeded} application(s)."
                : $"Removed from {succeeded} application(s); {failed} failed.";

            SetActionsEnabled(_items.Count > 0);
            UpdateSelectionUi();

            if (_items.Count == 0)
            {
                EmptyPanel.Visibility = Visibility.Visible;
                ListScrollViewer.Visibility = Visibility.Collapsed;
                SelectAllCheckBox.IsEnabled = false;
            }

            if (failed > 0)
            {
                var details = string.Join("\n", failures.Take(10));
                if (failures.Count > 10) details += $"\n…and {failures.Count - 10} more";
                ModernMessageBox.Show(
                    $"Removed: {succeeded}\nFailed: {failed}\n\n{details}",
                    "Purge Group", MessageBoxButton.OK, MessageBoxIcon.Warning);
            }
        }

        private void SetActionsEnabled(bool listHasItems)
        {
            RemoveAllButton.IsEnabled = listHasItems;
            RemoveSelectedButton.IsEnabled = listHasItems && _items.Any(i => i.IsSelected);
            SelectAllCheckBox.IsEnabled = listHasItems;
        }

        private void ShowLoading(bool show, string? text = null)
        {
            LoadingPanel.Visibility = show ? Visibility.Visible : Visibility.Collapsed;
            ListScrollViewer.Visibility = show ? Visibility.Collapsed : Visibility.Visible;
            if (text != null) LoadingText.Text = text;
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = RemovedCount > 0;
            Close();
        }
    }

    public class PurgeAppItem : ViewModelBase
    {
        public PurgeAppItem(AppGroupAssignment match)
        {
            AppId = match.AppId;
            AppName = match.AppName;
            Version = match.Version;
            AssignmentId = match.AssignmentId;
            Intent = string.IsNullOrEmpty(match.Intent) ? "available" : match.Intent;
        }

        public string AppId { get; }
        public string AppName { get; }
        public string Version { get; }
        public string AssignmentId { get; }
        public string Intent { get; }

        public string DisplayLabel =>
            string.IsNullOrWhiteSpace(Version) ? AppName : $"{AppName}  ({Version})";

        public string StatusText => $"App id: {AppId}";

        private bool _isSelected;
        public bool IsSelected
        {
            get => _isSelected;
            set => SetProperty(ref _isSelected, value);
        }
    }
}
