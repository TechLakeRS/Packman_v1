﻿using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite.Services;
using Endpoint_Packaging_Suite.Dialogs;
using Endpoint_Packaging_Suite.WizardSteps;
using Microsoft.Extensions.DependencyInjection;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;

namespace Endpoint_Packaging_Suite
{
    public partial class IntuneUploadWizard : Window, IUploadProgress
    {
        // Keep all existing properties and services
        public ApplicationInfo? ApplicationInfo { get; set; }
        public string PackagePath { get; set; } = "";

        // Background upload support
        public Task<string>? UploadTask { get; private set; }
        public string? SelectedIconPath { get; private set; }
        public string? InstallCommand { get; private set; }
        public string? UninstallCommand { get; private set; }
        public string? Description { get; private set; }
        public string? InstallContext { get; private set; }
        public string? NotificationId { get; set; } // For progress tracking
        public string? PredecessorAppId { get; set; }

        private ObservableCollection<DetectionRule> _detectionRules = new ObservableCollection<DetectionRule>();
        private IntuneService _intuneService;
        private IntuneUploadService _uploadService;

        // Wizard-specific properties
        private int _currentStep = 0;
        private readonly UserControl[] _stepControls = new UserControl[3];

        // Step validation states
        private bool _step1Valid = false;
        private bool _step2Valid = false;
        private bool _step3Valid = false;

        // Service locator used here because WPF code-behind doesn't support constructor injection
        private NotificationService Notifications => App.Services.GetRequiredService<NotificationService>();

        public IntuneUploadWizard()
        {
            InitializeComponent();

            // Get services from DI container
            _intuneService = App.Services.GetRequiredService<IntuneService>();
            _uploadService = App.Services.GetRequiredService<IntuneUploadService>();

            LoadStep(0);
        }


        protected override async void OnContentRendered(EventArgs e)
        {
            base.OnContentRendered(e);

            if (ApplicationInfo != null)
            {
                AppSummaryText.Text = $"{ApplicationInfo.Manufacturer} {ApplicationInfo.Name} v{ApplicationInfo.Version}";

                // Try to load detection rules from package metadata first
                bool loadedFromMetadata = await TryLoadDetectionRulesFromMetadataAsync();

                if (!loadedFromMetadata && _detectionRules.Count == 0)
                {
                    // Standardized default: File version, greater than or equal to the package version
                    _detectionRules.Add(new DetectionRule
                    {
                        Type = DetectionRuleType.File,
                        Path = "%ProgramFiles%",
                        FileOrFolderName = $"{ApplicationInfo?.Name ?? "MyApp"}.exe",
                        DetectionType = "version",
                        Operator = "greaterThanOrEqual",
                        DetectionValue = string.IsNullOrEmpty(ApplicationInfo?.Version) ? "1.0.0" : ApplicationInfo!.Version,
                        CheckVersion = true,
                        Check32BitOn64System = true
                    });
                }
            }

            UpdateStepData();
        }

        /// <summary>
        /// Tries to load detection rules from DetectionRulesCache (remote test discovery)
        /// Priority: 1) DetectionRulesCache (from remote test), 2) Auto-generated defaults
        /// Returns true if rules were loaded, false otherwise
        /// </summary>
        private Task<bool> TryLoadDetectionRulesFromMetadataAsync()
        {
            try
            {
                if (string.IsNullOrEmpty(PackagePath) || !Directory.Exists(PackagePath))
                {
                    return Task.FromResult(false);
                }

                // Check DetectionRulesCache (from remote test discovery)
                if (DetectionRulesCache.HasCachedRules(PackagePath))
                {
                    var cachedRules = DetectionRulesCache.GetRulesFromPackage(PackagePath, out string computerName);
                    if (cachedRules != null && cachedRules.Count > 0)
                    {
                        _detectionRules.Clear();
                        foreach (var rule in cachedRules)
                        {
                            _detectionRules.Add(rule);
                        }

                        Debug.WriteLine($"Loaded {_detectionRules.Count} detection rules from DetectionRulesCache (discovered on {computerName})");
                        return Task.FromResult(true);
                    }
                }

                // No cached rules found - will use auto-generated defaults
                return Task.FromResult(false);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error loading detection rules from cache: {ex.Message}");
                return Task.FromResult(false);
            }
        }

        #region Step Management (High Performance)

        private void LoadStep(int stepIndex)
        {

            if (_stepControls[stepIndex] == null)
            {
                _stepControls[stepIndex] = stepIndex switch
                {
                    0 => new AppDetailsStep(),
                    1 => new DetectionRulesStep(),
                    2 => new ReviewUploadStep(),
                    _ => throw new ArgumentException("Invalid step index")
                };


                SetupStepEvents(_stepControls[stepIndex], stepIndex);
            }


            StepContentArea.Content = _stepControls[stepIndex];
            _currentStep = stepIndex;

            UpdateStepData();
            UpdateProgressIndicators();
            UpdateNavigationButtons();
        }

        private void SetupStepEvents(UserControl stepControl, int stepIndex)
        {
            switch (stepIndex)
            {
                case 0:
                    if (stepControl is AppDetailsStep appStep)
                    {
                        appStep.PackagePath = PackagePath; // Pass package path for icon loading
                        appStep.ApplicationInfo = ApplicationInfo;
                        appStep.ValidationChanged += (valid) =>
                        {
                            _step1Valid = valid;
                            UpdateNavigationButtons();
                        };
                        appStep.DataChanged += UpdateApplicationDataFromStep1;
                    }
                    break;

                case 1:
                    if (stepControl is DetectionRulesStep detectionStep)
                    {
                        detectionStep.DetectionRules = _detectionRules;
                        detectionStep.ParentWindow = this; // For opening child dialogs
                        detectionStep.ValidationChanged += (valid) =>
                        {
                            _step2Valid = valid;
                            UpdateNavigationButtons();
                        };
                    }
                    break;

                case 2:
                    if (stepControl is ReviewUploadStep reviewStep)
                    {
                        if (ApplicationInfo != null)
                        {
                            reviewStep.ApplicationInfo = ApplicationInfo;
                            reviewStep.LoadFromApplicationInfo(ApplicationInfo);
                        }

                        if (_detectionRules != null)
                        {
                            reviewStep.DetectionRules = _detectionRules;
                        }

                        if (PackagePath != null)
                        {
                            var intuneFolder = Path.Combine(PackagePath, "Intune");
                            if (Directory.Exists(intuneFolder))
                            {
                                var intuneWinFiles = Directory.GetFiles(intuneFolder, "*.intunewin");
                                reviewStep.PackagePath = intuneWinFiles.Length > 0 ? intuneWinFiles[0] : PackagePath;
                            }
                            else
                            {
                                reviewStep.PackagePath = PackagePath;
                            }
                        }

                        reviewStep.PredecessorAppId = PredecessorAppId;

                        // FIX: Update summary data on first load
                        if (_stepControls[0] is AppDetailsStep appDetailsStep)
                        {
                            var installCommand = GetInstallCommand();
                            var uninstallCommand = GetUninstallCommand();

                            reviewStep.UpdateSummaryData(
                                installCommand,
                                uninstallCommand,
                                appDetailsStep.GetDescription(),
                                ApplicationInfo?.InstallContext ?? "System"
                            );
                            reviewStep.SelectedIconPath = appDetailsStep.SelectedIconPath;
                        }

                        // FIX: Force UI refresh to show package size and detection rules
                        reviewStep.RefreshUI();
                    }
                    break;
            }
        }

        private void UpdateStepData()
        {
            // Share data between steps
            if (_stepControls[0] is AppDetailsStep appStep)
            {
                // Set PackagePath FIRST so icon can be auto-loaded when ApplicationInfo triggers LoadApplicationData
                appStep.PackagePath = PackagePath;
                appStep.ApplicationInfo = ApplicationInfo;
            }

            if (_stepControls[1] is DetectionRulesStep detectionStep)
            {
                detectionStep.DetectionRules = _detectionRules;
            }

            if (_stepControls[2] is ReviewUploadStep reviewStep)
            {
                reviewStep.ApplicationInfo = ApplicationInfo!;
                reviewStep.DetectionRules = _detectionRules;
                reviewStep.PackagePath = PackagePath;
                reviewStep.PredecessorAppId = PredecessorAppId;
            }

        }

        #endregion

        #region Navigation

        private async void NextButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentStep < 2 && ValidateCurrentStep())
            {
                // ? PERFORMANCE: Share data between steps before moving
                await ShareDataToNextStep();
                LoadStep(_currentStep + 1);
            }
            else if (_currentStep == 2)
            {
                if (_stepControls[0] is AppDetailsStep appStep &&
            _stepControls[2] is ReviewUploadStep reviewStep)
                {
                    // Use PSADT version-specific commands
                    var installCommand = GetInstallCommand();
                    var uninstallCommand = GetUninstallCommand();

                    reviewStep.UpdateSummaryData(
                        installCommand,
                        uninstallCommand,
                        appStep.GetDescription(),
                        ApplicationInfo?.InstallContext ?? "System"
                    );
                }
                // ? PERFORMANCE: Trigger upload from final step
                await TriggerUploadFromStep3();
            }
        }

        private Task ShareDataToNextStep()
        {
            // Share data from current step to next step
            if (_currentStep == 0 && _stepControls[1] != null)
            {
                // Share app details to detection rules step (if needed)
            }
            else if (_currentStep == 1 && _stepControls[2] != null)
            {
                // Share everything to review step
                if (_stepControls[0] is AppDetailsStep appStep &&
                    _stepControls[2] is ReviewUploadStep reviewStep)
                {
                    reviewStep.LoadFromApplicationInfo(reviewStep.ApplicationInfo);

                    // Use PSADT version-specific commands
                    var installCommand = GetInstallCommand();
                    var uninstallCommand = GetUninstallCommand();

                    reviewStep.UpdateSummaryData(
                        installCommand,
                        uninstallCommand,
                        appStep.GetDescription(),
                        ApplicationInfo?.InstallContext ?? "System"
                    );
                }
            }
            return Task.CompletedTask;
        }

        private async Task TriggerUploadFromStep3()
        {
            if (_stepControls[0] is AppDetailsStep appStep &&
                _stepControls[2] is ReviewUploadStep reviewStep)
            {
                // Use PSADT version-specific commands
                var installCommand = GetInstallCommand();
                var uninstallCommand = GetUninstallCommand();
                var installContext = ApplicationInfo?.InstallContext ?? "System";

                // Update the review step with current values RIGHT BEFORE upload
                reviewStep.UpdateSummaryData(
                    installCommand,
                    uninstallCommand,
                    appStep.GetDescription(),
                    installContext
                );
                reviewStep.SelectedIconPath = appStep.SelectedIconPath;
                Debug.WriteLine($"Passing install command to upload: '{installCommand}'");
                Debug.WriteLine($"Passing icon path to upload: '{appStep.SelectedIconPath}'");

                // Now perform the upload with updated values
                await PerformUpload(
                    installCommand,
                    uninstallCommand,
                    appStep.GetDescription(),
                    installContext
                );
            }
        }

        private void PreviousButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentStep > 0)
            {
                LoadStep(_currentStep - 1);
            }
        }

        private bool ValidateCurrentStep()
        {
            return _currentStep switch
            {
                0 => _step1Valid,
                1 => _step2Valid,
                2 => _step3Valid,
                _ => false
            };
        }

        private void UpdateProgressIndicators()
        {
            // Update visual progress indicators
            UpdateStepIndicator(0, _currentStep >= 0, _currentStep > 0);
            UpdateStepIndicator(1, _currentStep >= 1, _currentStep > 1);
            UpdateStepIndicator(2, _currentStep >= 2, _currentStep > 2);

            // Update connection lines
            ConnectionLine1.Background = _currentStep >= 1 ? FindResource("SuccessBrush") as SolidColorBrush : new SolidColorBrush(Color.FromArgb(64, 255, 255, 255));
            ConnectionLine2.Background = _currentStep >= 2 ? FindResource("SuccessBrush") as SolidColorBrush : new SolidColorBrush(Color.FromArgb(64, 255, 255, 255));

            // Update step text
            StepIndicatorText.Text = $"Step {_currentStep + 1} of 3";
            StepDescriptionText.Text = _currentStep switch
            {
                0 => "Configure application details",
                1 => "Define detection rules",
                2 => "Review and upload",
                _ => ""
            };
        }

        private void UpdateStepIndicator(int stepIndex, bool active, bool completed)
        {
            var circle = stepIndex switch
            {
                0 => Step1Circle,
                1 => Step2Circle,
                2 => Step3Circle,
                _ => null
            };

            var checkMark = stepIndex switch
            {
                0 => Step1CheckMark,
                1 => Step2CheckMark,
                2 => Step3CheckMark,
                _ => null
            };

            var icon = stepIndex switch
            {
                0 => Step1Icon,
                1 => Step2Icon,
                2 => Step3Icon,
                _ => null
            };

            if (circle == null || checkMark == null || icon == null) return;

            if (completed)
            {
                circle.Background = FindResource("SuccessBrush") as SolidColorBrush;
                checkMark.Visibility = Visibility.Visible;
                icon.Visibility = Visibility.Collapsed;
            }
            else if (active)
            {
                circle.Background = FindResource("PrimaryButtonBrush") as SolidColorBrush;
                checkMark.Visibility = Visibility.Collapsed;
                icon.Visibility = Visibility.Visible;
                icon.Foreground = System.Windows.Media.Brushes.White;
            }
            else
            {
                circle.Background = new SolidColorBrush(System.Windows.Media.Color.FromArgb(64, 255, 255, 255));
                checkMark.Visibility = Visibility.Collapsed;
                icon.Visibility = Visibility.Visible;
                icon.Foreground = new SolidColorBrush(System.Windows.Media.Color.FromArgb(128, 255, 255, 255));
            }
        }

        private void UpdateNavigationButtons()
        {
            PreviousButton.IsEnabled = _currentStep > 0;

            if (_currentStep < 2)
            {
                // Create TextBlock with Run elements for Continue button
                var textBlock = new TextBlock { TextAlignment = TextAlignment.Center };
                textBlock.Inlines.Add(new Run("Continue "));
                textBlock.Inlines.Add(new Run("\uE76C") { FontFamily = new System.Windows.Media.FontFamily("Segoe MDL2 Assets") });
                NextButton.Content = textBlock;
                NextButton.Style = (Style)FindResource("WizardPrimaryButton");
                NextButton.IsEnabled = ValidateCurrentStep();
            }
            else
            {
                // Create TextBlock with Run elements for Upload button
                var textBlock = new TextBlock { TextAlignment = TextAlignment.Center };
                textBlock.Inlines.Add(new Run("\uE753") { FontFamily = new System.Windows.Media.FontFamily("Segoe MDL2 Assets") });
                textBlock.Inlines.Add(new Run(" Upload to Intune"));
                NextButton.Content = textBlock;
                NextButton.Style = (Style)FindResource("WizardSuccessButton");
                NextButton.IsEnabled = _step2Valid; // Must have valid detection rules
            }

            // Show validation feedback
            if (!ValidateCurrentStep() && _currentStep < 2)
            {
                ValidationStatusPanel.Visibility = Visibility.Visible;
                ValidationIcon.Text = "\uE7BA"; // Warning icon
                ValidationMessage.Text = _currentStep switch
                {
                    0 => "Please complete all application details",
                    1 => "Please configure at least one detection rule",
                    _ => ""
                };
            }
            else
            {
                ValidationStatusPanel.Visibility = Visibility.Collapsed;
            }
        }

        #endregion

        #region Event Handlers from Step Controls

        private void UpdateApplicationDataFromStep1(ApplicationInfo updatedInfo)
        {
            ApplicationInfo = updatedInfo;
            AppSummaryText.Text = $"{updatedInfo.Manufacturer} {updatedInfo.Name} v{updatedInfo.Version}";

            // Only update ReviewUploadStep - don't call UpdateStepData() which would
            // re-set AppDetailsStep.ApplicationInfo and trigger LoadApplicationData again
            if (_stepControls[2] is ReviewUploadStep reviewStep)
            {
                reviewStep.ApplicationInfo = updatedInfo;
            }
        }

        // This method will be called from DetectionRulesStep when user opens detection dialogs

        public void RemoveDetectionRule(DetectionRule rule)
        {
            var result = ModernMessageBox.Show(
                $"Are you sure you want to remove this detection rule?\n\n{rule.Title}",
                "Remove Detection Rule",
                MessageBoxButton.YesNo,
                MessageBoxIcon.Question);

            if (result == MessageBoxResult.Yes)
            {
                _detectionRules.Remove(rule);
                UpdateStepData(); // Refresh detection rules step
            }
        }

        #endregion

        #region Upload Logic (Preserved from Original)

        private async Task PerformUpload(string installCommand, string uninstallCommand, string description, string installContext)
        {
            try
            {
                if (_detectionRules.Count == 0)
                {
                    ModernMessageBox.Show("Please add at least one detection rule.", "Validation Error",
                        MessageBoxButton.OK, MessageBoxIcon.Warning);
                    return;
                }

                Debug.WriteLine("=== UI DETECTION RULES ===");
                Debug.WriteLine($"Total rules from UI: {_detectionRules.Count}");
                foreach (var rule in _detectionRules)
                {
                    Debug.WriteLine($"Rule: Type={rule.Type}, Path='{rule.Path}', File='{rule.FileOrFolderName}', CheckVersion={rule.CheckVersion}");
                }
                Debug.WriteLine("=== END UI DETECTION RULES ===");

                if (string.IsNullOrEmpty(PackagePath) || ApplicationInfo == null)
                {
                    ModernMessageBox.Show("Package information is not available.", "Error",
                        MessageBoxButton.OK, MessageBoxIcon.Error);
                    return;
                }

                // Store configuration for background upload
                InstallCommand = installCommand;
                UninstallCommand = uninstallCommand;
                Description = description;
                InstallContext = installContext;

                // Get icon path from AppDetailsStep
                if (_stepControls[0] is AppDetailsStep appStep)
                {
                    SelectedIconPath = appStep.SelectedIconPath;
                }

                // Start upload in a fire-and-forget background task that survives wizard closure
                if (_stepControls[2] is ReviewUploadStep reviewStep)
                {
                    // Pass notification ID to review step for progress updates
                    reviewStep.NotificationId = NotificationId;

                    // Start background upload task
                    var appName = ApplicationInfo?.Name ?? "Application";
                    _ = Task.Run(async () =>
                    {
                        try
                        {
                            bool success = await reviewStep.StartUploadAsync();
                            if (!success)
                            {
                                Debug.WriteLine("Upload completed with failure");
                            }
                        }
                        catch (Exception ex)
                        {
                            Debug.WriteLine($"Background upload exception: {ex.Message}");
                            // Error notifications are already shown by ReviewUploadStep
                        }
                    });

                    // Close wizard immediately - upload continues in background
                    DialogResult = true;
                    Close();
                }
                else
                {
                    ModernMessageBox.Show("Review step not loaded properly", "Error",
                        MessageBoxButton.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                Notifications.ShowError(
                    "Upload Error",
                    $"{ex.Message}\n\nThe .intunewin file may have been created locally.");

                Debug.WriteLine($"Upload error: {ex}");
            }
        }

        // Implement IUploadProgress interface (same as original)
        public void UpdateProgress(int percentage, string message)
        {
            Dispatcher.Invoke(() =>
            {
                // Update the progress in ReviewUploadStep
                if (_stepControls[2] is ReviewUploadStep reviewStep)
                {
                    reviewStep.UpdateProgress(percentage, message);
                }
            });
        }

        #endregion

        #region Event Handlers

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }



        #endregion

        #region Public Methods for Step Access (Performance Optimized)

        public ObservableCollection<DetectionRule> GetDetectionRules()
        {
            return _detectionRules;
        }

        public void UpdateDetectionRules(ObservableCollection<DetectionRule> newRules)
        {
            _detectionRules.Clear();
            foreach (var rule in newRules)
            {
                _detectionRules.Add(rule);
            }

            // Update validation
            _step2Valid = _detectionRules.Count > 0;
            UpdateNavigationButtons();
        }

        #endregion

        #region PSADT v4 Commands

        /// <summary>
        /// Gets the install command for PSADT v4
        /// </summary>
        private string GetInstallCommand()
        {
            return "Invoke-AppDeployToolkit.exe -DeploymentType Install";
        }

        /// <summary>
        /// Gets the uninstall command for PSADT v4
        /// </summary>
        private string GetUninstallCommand()
        {
            return "Invoke-AppDeployToolkit.exe -DeploymentType Uninstall";
        }

        #endregion

    }

    // ? PERFORMANCE: Event delegates for fast step communication
    public delegate void ValidationChangedEventHandler(bool isValid);
    public delegate void DataChangedEventHandler(ApplicationInfo applicationInfo);
    public delegate Task UploadRequestedEventHandler(string installCommand, string uninstallCommand, string description, string installContext);
}