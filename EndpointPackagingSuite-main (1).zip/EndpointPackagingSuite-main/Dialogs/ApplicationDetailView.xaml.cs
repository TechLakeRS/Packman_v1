using Endpoint_Packaging_Suite.Constants;
using Endpoint_Packaging_Suite.Helpers;
using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite.Services;
using Endpoint_Packaging_Suite.Dialogs;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Endpoint_Packaging_Suite
{
    public partial class ApplicationDetailView : UserControl
    {
        public event EventHandler? BackToListRequested;
        private ApplicationDetail? _currentApp;
        private string _activeTab = "overview";

        // Service locator used here because WPF code-behind doesn't support constructor injection
        private NotificationService Notifications => App.Services.GetRequiredService<NotificationService>();

        // Tab button references for styling
        private Button[] TabButtons => new[] { TabOverview, TabPackage, TabDetection, TabDeployment, TabActivity };
        private FrameworkElement[] TabPanels => new FrameworkElement[] { OverviewTab, PackageTab, DetectionTab, DeploymentTab, ActivityTab };

        public ApplicationDetailView()
        {
            InitializeComponent();

            this.DataContextChanged += (s, e) =>
            {
                if (e.NewValue is ApplicationDetail app && app.IconImage != null)
                {
                    AppIconImage.Source = app.IconImage;
                }
            };
        }

        public async void LoadApplicationDetail(ApplicationDetail app)
        {
            _currentApp = app;
            this.DataContext = app;

            // Reset to overview tab
            SwitchToTab("overview");

            // Update all sections
            UpdateHeader(app);
            UpdateOverview(app);
            UpdateDescription(app);
            UpdateDetectionRules(app);
            UpdateGroups(app);
            UpdatePublishing(app);
            UpdateUrls(app);
            UpdatePackageTab(app);
            UpdateDeploymentTab(app);
            UpdateCodeSigning(app);

            // Load deployment stats and per-device activity asynchronously
            LoadDeploymentStatusAsync(app);
            LoadRecentDeploymentsAsync(app);

            // Load network path asynchronously
            await LoadNetworkPathAsync(app);

            // Update status
            StatusText.Text = $"Loaded details for {app.DisplayName}";
        }

        #region Tab Switching

        private void Tab_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is string tabId)
            {
                SwitchToTab(tabId);
            }
        }

        private void SwitchToTab(string tabId)
        {
            _activeTab = tabId;

            // Update tab button styles
            var activeStyle = FindResource("ActiveTabButtonStyle") as Style;
            var inactiveStyle = FindResource("TabButtonStyle") as Style;

            foreach (var btn in TabButtons)
            {
                btn.Style = (btn.Tag as string) == tabId ? activeStyle : inactiveStyle;
            }

            // Show/hide tab panels
            string[] tabIds = { "overview", "package", "detection", "deployment", "activity" };
            for (int i = 0; i < tabIds.Length; i++)
            {
                TabPanels[i].Visibility = tabIds[i] == tabId ? Visibility.Visible : Visibility.Collapsed;
            }

            // Scroll to top when switching tabs
            DetailScrollViewer?.ScrollToTop();
        }

        #endregion

        #region Update Methods

        private void UpdateHeader(ApplicationDetail app)
        {
            AppTitleText.Text = app.DisplayName;
            BreadcrumbAppName.Text = app.DisplayName;

            var hasCategory = !string.IsNullOrWhiteSpace(app.Category);
            BreadcrumbCategory.Text = hasCategory ? app.Category : string.Empty;
            BreadcrumbCategorySeparator.Visibility = hasCategory ? Visibility.Visible : Visibility.Collapsed;

            var subtitleParts = new List<string>();
            if (!string.IsNullOrWhiteSpace(app.Publisher)) subtitleParts.Add(app.Publisher);
            if (app.LastModifiedDateTime != DateTime.MinValue)
            {
                var relative = FormatRelativeTime(app.LastModifiedDateTime);
                subtitleParts.Add(!string.IsNullOrWhiteSpace(app.Owner)
                    ? $"Updated {relative} by {app.Owner}"
                    : $"Updated {relative}");
            }
            if (app.Size > 0) subtitleParts.Add(app.SizeFormatted);
            AppSubtitleText.Text = string.Join("  ·  ", subtitleParts);

            if (!string.IsNullOrWhiteSpace(app.Version))
            {
                VersionChipText.Text = app.Version.StartsWith("v", StringComparison.OrdinalIgnoreCase)
                    ? app.Version
                    : $"v{app.Version}";
                VersionChip.Visibility = Visibility.Visible;
            }
            else
            {
                VersionChip.Visibility = Visibility.Collapsed;
            }

            if (app.IconImage != null)
            {
                AppIconImage.Source = app.IconImage;
            }

            // Show deployed badge if publishing state is published
            DeployedBadge.Visibility = !string.IsNullOrEmpty(app.PublishingState) &&
                app.PublishingState.Equals("published", StringComparison.OrdinalIgnoreCase)
                ? Visibility.Visible : Visibility.Collapsed;
        }

        private static string FormatRelativeTime(DateTime when)
        {
            var delta = DateTime.Now - when;
            if (delta.TotalSeconds < 60) return "just now";
            if (delta.TotalMinutes < 60) return $"{(int)delta.TotalMinutes} min ago";
            if (delta.TotalHours < 24)
            {
                var hr = (int)delta.TotalHours;
                return hr == 1 ? "1 hour ago" : $"{hr} hours ago";
            }
            if (delta.TotalDays < 7)
            {
                var d = (int)delta.TotalDays;
                return d == 1 ? "yesterday" : $"{d} days ago";
            }
            return when.ToString("MMM d, yyyy");
        }

        private void UpdateOverview(ApplicationDetail app)
        {
            AppVersionText.Text = app.Version;
            PublisherText.Text = app.Publisher;
            CategoryText.Text = app.Category;
            FileSizeText.Text = app.Size > 0 ? app.SizeFormatted : "Unknown";
            InstallContextText.Text = app.InstallContext;
            OwnerText.Text = string.IsNullOrEmpty(app.Owner) ? "Not specified" : app.Owner;
            DeveloperText.Text = string.IsNullOrEmpty(app.Developer) ? "Not specified" : app.Developer;
            LastModifiedText.Text = app.LastModifiedDateTime != DateTime.MinValue
                ? app.LastModifiedFormatted
                : "Unknown";
            LanguageText.Text = "Not specified";
        }

        private void UpdateDescription(ApplicationDetail app)
        {
            DescriptionText.Text = string.IsNullOrEmpty(app.Description)
                ? "No description provided"
                : app.Description;
        }

        private void CategoryText_MouseLeftButtonUp(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (_currentApp == null || sender is not FrameworkElement anchor) return;

            var menu = new ContextMenu { PlacementTarget = anchor, Placement = System.Windows.Controls.Primitives.PlacementMode.Bottom };
            foreach (var category in AppConstants.Categories.Available)
            {
                var item = new MenuItem { Header = category };
                var captured = category;
                item.Click += async (_, _) => await ChangeCategoryAsync(captured);
                menu.Items.Add(item);
            }
            menu.IsOpen = true;
        }

        private async Task ChangeCategoryAsync(string newCategory)
        {
            if (_currentApp == null) return;

            var app = _currentApp;
            if (string.Equals(app.Category, newCategory, StringComparison.OrdinalIgnoreCase))
                return;

            CategoryText.IsEnabled = false;
            StatusText.Text = $"Updating category to {newCategory}...";

            try
            {
                var intuneService = App.Services.GetRequiredService<IntuneService>();
                var (success, newDescription) = await intuneService.SetAppCategoryAsync(app.Id, newCategory, app.Description);

                if (success)
                {
                    app.Category = newCategory;
                    app.Description = newDescription;
                    CategoryText.Text = newCategory;
                    BreadcrumbCategory.Text = newCategory;
                    BreadcrumbCategorySeparator.Visibility = Visibility.Visible;
                    UpdateDescription(app);
                    StatusText.Text = $"Category set to {newCategory}";
                    Notifications.ShowSuccess("Category updated", $"{app.DisplayName} → {newCategory}");
                }
                else
                {
                    StatusText.Text = "Failed to update category";
                    Notifications.ShowError("Category update failed", "See logs for details.");
                }
            }
            catch (Exception ex)
            {
                StatusText.Text = "Failed to update category";
                Notifications.ShowError("Category update failed", ex.Message);
            }
            finally
            {
                CategoryText.IsEnabled = true;
            }
        }

        private void UpdateDetectionRules(ApplicationDetail app)
        {
            DetectionRulesList.ItemsSource = app.DetectionRules;

            var ruleCount = app.DetectionRules?.Count ?? 0;
            DetectionBadgeCount.Text = ruleCount.ToString();
            DetectionSubtitle.Text = ruleCount == 1
                ? "1 rule configured"
                : $"{ruleCount} rules configured — all conditions must be met";
        }

        private void UpdateGroups(ApplicationDetail app)
        {
            var groups = app.AssignedGroups ?? new List<AssignedGroup>();

            foreach (var group in groups)
            {
                if (group.AssignmentType?.Equals("required", StringComparison.OrdinalIgnoreCase) == true)
                {
                    group.AssignmentType = "Install";
                }
                else if (group.AssignmentType?.Equals("uninstall", StringComparison.OrdinalIgnoreCase) == true)
                {
                    group.AssignmentType = "Uninstall";
                }
            }

            var sortedGroups = groups
                .OrderBy(g => g.AssignmentType?.Equals("Install", StringComparison.OrdinalIgnoreCase) == true ? 0 : 1)
                .ThenBy(g => g.GroupName)
                .ToList();

            AssignedGroupsList.ItemsSource = sortedGroups;
            GroupCountText.Text = sortedGroups.Count == 1 ? "1 group" : $"{sortedGroups.Count} groups";

            NoGroupsPanel.Visibility = sortedGroups.Count == 0
                ? Visibility.Visible
                : Visibility.Collapsed;
        }

        private void UpdatePublishing(ApplicationDetail app)
        {
            UploadStateText.Text = string.IsNullOrEmpty(app.UploadState) ? "Unknown" : app.UploadState;
            PublishingStateText.Text = string.IsNullOrEmpty(app.PublishingState) ? "Unknown" : app.PublishingState;
            IntuneAppIdText.Text = string.IsNullOrEmpty(app.Id) ? "Unknown" : app.Id;
            IntuneAppIdText.ToolTip = app.Id;
            CreatedDateText.Text = app.CreatedDateTime != DateTime.MinValue
                ? app.CreatedDateFormatted
                : "Unknown";
            PublishedDateText.Text = app.LastModifiedDateTime != DateTime.MinValue
                ? app.LastModifiedFormatted
                : "Unknown";
        }

        private void UpdateUrls(ApplicationDetail app)
        {
            if (!string.IsNullOrEmpty(app.PrivacyInformationUrl))
            {
                PrivacyUrlPanel.Visibility = Visibility.Visible;
                PrivacyUrlText.Text = app.PrivacyInformationUrl;
            }
            else
            {
                PrivacyUrlPanel.Visibility = Visibility.Collapsed;
            }

            if (!string.IsNullOrEmpty(app.InformationUrl))
            {
                InfoUrlPanel.Visibility = Visibility.Visible;
                InfoUrlText.Text = app.InformationUrl;
            }
            else
            {
                InfoUrlPanel.Visibility = Visibility.Collapsed;
            }

            UrlsPanel.Visibility = string.IsNullOrEmpty(app.PrivacyInformationUrl) &&
                string.IsNullOrEmpty(app.InformationUrl)
                ? Visibility.Collapsed
                : Visibility.Visible;
        }

        private void UpdatePackageTab(ApplicationDetail app)
        {
            PkgFileSizeText.Text = app.Size > 0 ? app.SizeFormatted : "Unknown";
            PkgMemoryText.Text = app.MinimumMemoryInMB > 0
                ? $"{app.MinimumMemoryInMB} MB"
                : "Not specified";
            ProcessorsText.Text = app.MinimumNumberOfProcessors > 0
                ? $"{app.MinimumNumberOfProcessors}"
                : "Not specified";
            CpuSpeedText.Text = app.MinimumCpuSpeedInMHz > 0
                ? $"{app.MinimumCpuSpeedInMHz} MHz"
                : "Not specified";
        }

        private void UpdateDeploymentTab(ApplicationDetail app)
        {
            DeployInstallContextText.Text = app.InstallContext;
            DeployInstallCommandText.Text = app.InstallCommand;
            DeployUninstallCommandText.Text = app.UninstallCommand;

            // Restart behavior - format the API value for display
            var restartText = app.DeviceRestartBehavior switch
            {
                "basedOnReturnCode" => "Determine by return code",
                "allow" => "App may force a device restart",
                "suppress" => "No specific action",
                "force" => "Force restart",
                _ => string.IsNullOrEmpty(app.DeviceRestartBehavior)
                    ? "Not specified"
                    : app.DeviceRestartBehavior
            };
            DeployRestartBehaviorText.Text = restartText;

            // Max install time
            DeployMaxInstallTimeText.Text = app.MaxInstallTimeInMinutes.HasValue
                ? $"{app.MaxInstallTimeInMinutes} minutes"
                : "Not specified";

            // Return codes
            if (app.ReturnCodes != null && app.ReturnCodes.Count > 0)
            {
                ReturnCodesList.ItemsSource = app.ReturnCodes;
                ReturnCodesCard.Visibility = Visibility.Visible;
            }
            else
            {
                ReturnCodesCard.Visibility = Visibility.Collapsed;
            }

            // Install requirements
            DiskSpaceText.Text = app.MinimumFreeDiskSpaceInMB > 0
                ? $"{app.MinimumFreeDiskSpaceInMB} MB"
                : "Not specified";
            MemoryText.Text = app.MinimumMemoryInMB > 0
                ? $"{app.MinimumMemoryInMB} MB"
                : "Not specified";
            ArchitecturesText.Text = string.IsNullOrEmpty(app.ApplicableArchitectures)
                ? "Not specified"
                : app.ApplicableArchitectures;
            MinWindowsText.Text = string.IsNullOrEmpty(app.MinimumSupportedWindowsRelease)
                ? "Not specified"
                : app.MinimumSupportedWindowsRelease;
        }

        private void UpdateCodeSigning(ApplicationDetail app)
        {
            ScriptSignatureStatusText.Text = "Checking...";
            if (app.IsCodeSigned)
            {
                ScriptSignatureStatusText.Text = "Valid — Authenticode";
                ScriptSignatureStatusText.Foreground = (Brush)(FindResource("SuccessColorBrush") ?? Foreground);
                ScriptSignatureIcon.Text = "";
                ScriptSignatureIcon.Foreground = (Brush)(FindResource("SuccessColorBrush") ?? Foreground);
                CodeSigningCard.Visibility = Visibility.Visible;
                CodeSignedDetailText.Text = app.CodeSignedDate.HasValue
                    ? $"Signed on {app.CodeSignedDate.Value:MMMM dd, yyyy} at {app.CodeSignedDate.Value:HH:mm}"
                    : "Signed with enterprise certificate";
            }
            else
            {
                CheckCodeSigningAsync(app);
            }
        }

        private async void CheckCodeSigningAsync(ApplicationDetail app)
        {
            if (string.IsNullOrEmpty(app.NetworkSharePath))
            {
                ScriptSignatureStatusText.Text = "No package path";
                ScriptSignatureStatusText.Foreground = (Brush)(FindResource("TextMutedBrush") ?? Foreground);
                CodeSigningCard.Visibility = Visibility.Collapsed;
                return;
            }

            await Task.Run(() =>
            {
                try
                {
                    var appFolder = Path.Combine(app.NetworkSharePath, "Application");

                    // Find the script to check — try ps1 files first, then exe
                    var candidateFiles = new[]
                    {
                        Path.Combine(appFolder, "Invoke-AppDeployToolkit.ps1"),
                        Path.Combine(appFolder, "Deploy-Application.ps1"),
                        Path.Combine(app.NetworkSharePath, "Invoke-AppDeployToolkit.ps1"),
                        Path.Combine(app.NetworkSharePath, "Deploy-Application.ps1"),
                        Path.Combine(appFolder, "Invoke-AppDeployToolkit.exe")
                    };

                    var targetFile = candidateFiles.FirstOrDefault(f => File.Exists(f));
                    if (targetFile == null)
                    {
                        Dispatcher.Invoke(() =>
                        {
                            ScriptSignatureStatusText.Text = "No script found";
                            ScriptSignatureStatusText.Foreground = (Brush)(TryFindResource("TextMutedBrush") ?? Foreground);
                            CodeSigningCard.Visibility = Visibility.Collapsed;
                        });
                        return;
                    }

                    var fileName = Path.GetFileName(targetFile);

                    // Build PowerShell script and encode as Base64 to avoid all quoting issues
                    var psScript =
                        "$sig = Get-AuthenticodeSignature '" + targetFile.Replace("'", "''") + "'\n" +
                        "$s = $sig.SignerCertificate\n" +
                        "Write-Output \"STATUS=$($sig.Status)\"\n" +
                        "if ($s) {\n" +
                        "  Write-Output \"SUBJECT=$($s.Subject)\"\n" +
                        "  Write-Output \"ISSUER=$($s.Issuer)\"\n" +
                        "  Write-Output \"VALID_FROM=$($s.NotBefore.ToString('o'))\"\n" +
                        "  Write-Output \"VALID_TO=$($s.NotAfter.ToString('o'))\"\n" +
                        "  $ts = $sig.TimeStamperCertificate\n" +
                        "  if ($ts) { Write-Output \"TIMESTAMP=$($ts.NotBefore.ToString('o'))\" }\n" +
                        "}";

                    var encodedCommand = Convert.ToBase64String(System.Text.Encoding.Unicode.GetBytes(psScript));

                    var psi = new ProcessStartInfo
                    {
                        FileName = "powershell.exe",
                        Arguments = $"-NoProfile -NonInteractive -EncodedCommand {encodedCommand}",
                        UseShellExecute = false,
                        RedirectStandardOutput = true,
                        CreateNoWindow = true
                    };

                    var proc = Process.Start(psi);
                    if (proc == null)
                    {
                        Dispatcher.Invoke(() =>
                        {
                            ScriptSignatureStatusText.Text = "Unable to check";
                            ScriptSignatureStatusText.Foreground = (Brush)(TryFindResource("TextMutedBrush") ?? Foreground);
                            CodeSigningCard.Visibility = Visibility.Collapsed;
                        });
                        return;
                    }

                    var output = proc.StandardOutput.ReadToEnd();
                    proc.WaitForExit(10000);

                    var lines = output.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
                    var sigData = new Dictionary<string, string>();
                    foreach (var line in lines)
                    {
                        var eqIdx = line.IndexOf('=');
                        if (eqIdx > 0)
                            sigData[line.Substring(0, eqIdx)] = line.Substring(eqIdx + 1);
                    }

                    sigData.TryGetValue("STATUS", out var status);
                    var hasCert = sigData.ContainsKey("SUBJECT");

                    if (status == "NotSigned")
                    {
                        Dispatcher.Invoke(() =>
                        {
                            ScriptSignatureStatusText.Text = $"Not signed ({fileName})";
                            ScriptSignatureStatusText.Foreground = (Brush)(TryFindResource("WarningColorBrush") ?? Foreground);
                            ScriptSignatureIcon.Text = "\uE7BA";
                            ScriptSignatureIcon.Foreground = (Brush)(TryFindResource("WarningColorBrush") ?? Foreground);
                            CodeSigningCard.Visibility = Visibility.Collapsed;
                        });
                        return;
                    }

                    // Extract cert details if available (works for Valid, UnknownError, HashMismatch, etc.)
                    var rawSubject = sigData.GetValueOrDefault("SUBJECT", "Unknown");
                    var rawIssuer = sigData.GetValueOrDefault("ISSUER", "");
                    // Extract CN= value from distinguished name, or use as-is
                    var subject = ExtractCN(rawSubject);
                    var issuer = ExtractCN(rawIssuer);
                    DateTime.TryParse(sigData.GetValueOrDefault("VALID_FROM", ""), out var validFrom);
                    DateTime.TryParse(sigData.GetValueOrDefault("VALID_TO", ""), out var validTo);
                    DateTime? timestamp = sigData.TryGetValue("TIMESTAMP", out var tsStr) && DateTime.TryParse(tsStr, out var ts) ? ts : null;

                    // Determine display status
                    var isValid = status == "Valid";
                    // UnknownError typically means signed but cert not in trusted root store
                    var isSigned = hasCert;

                    var statusDisplay = status switch
                    {
                        "Valid" => "Valid",
                        "UnknownError" => "Signed (untrusted certificate)",
                        "HashMismatch" => "Signed (modified after signing)",
                        "NotTrusted" => "Signed (not trusted)",
                        _ => hasCert ? $"Signed ({status})" : status ?? "Unknown"
                    };

                    Dispatcher.Invoke(() =>
                    {
                        app.IsCodeSigned = isSigned;
                        app.CodeSignedDate = timestamp ?? (validFrom != DateTime.MinValue ? validFrom : null);

                        ScriptSignatureStatusText.Text = statusDisplay;
                        var statusBrush = isValid
                            ? (Brush)(TryFindResource("SuccessColorBrush") ?? Foreground)
                            : isSigned
                                ? (Brush)(TryFindResource("WarningColorBrush") ?? Foreground)
                                : (Brush)(TryFindResource("ErrorColorBrush") ?? Foreground);
                        ScriptSignatureStatusText.Foreground = statusBrush;
                        ScriptSignatureIcon.Text = isValid ? "\uE73E" : isSigned ? "\uE7BA" : "\uE783";
                        ScriptSignatureIcon.Foreground = statusBrush;

                        if (isSigned)
                        {
                            CodeSigningCard.Visibility = Visibility.Visible;

                            var details = $"Signed by: {subject}";
                            if (!string.IsNullOrEmpty(issuer) && issuer != subject)
                                details += $"\nIssuer: {issuer}";
                            if (validFrom != DateTime.MinValue)
                                details += $"\nValid: {validFrom:MMM dd, yyyy} — {validTo:MMM dd, yyyy}";
                            details += $"\nFile: {fileName}";

                            CodeSignedDetailText.Text = details;
                        }
                        else
                        {
                            CodeSigningCard.Visibility = Visibility.Collapsed;
                        }
                    });
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"Error checking code signing: {ex.Message}");
                    Dispatcher.Invoke(() =>
                    {
                        ScriptSignatureStatusText.Text = "Error checking";
                        ScriptSignatureStatusText.Foreground = (Brush)(TryFindResource("TextMutedBrush") ?? Foreground);
                        CodeSigningCard.Visibility = Visibility.Collapsed;
                    });
                }
            });
        }

        private async void LoadDeploymentStatusAsync(ApplicationDetail app)
        {
            try
            {
                var mainWindow = Application.Current.MainWindow as MainWindow;
                var intuneService = mainWindow?.GetIntuneService();
                if (intuneService == null) return;

                // Aggregate from the deduplicated per-device list so the card
                // matches the rows shown in the Installation Report. Intune's
                // overview report returns stale cumulative counts.
                var devices = await intuneService.GetApplicationInstallStatusAsync(app.Id);
                var stats = InstallationStatistics.FromDeviceStatuses(devices);
                if (stats.TotalDevices == 0) return;

                await Dispatcher.InvokeAsync(() =>
                {
                    var installed = stats.SuccessfulInstalls;
                    var pending = stats.PendingInstalls;
                    var failed = stats.FailedInstalls;
                    var notApplicable = stats.NotApplicable;
                    var total = stats.TotalDevices;

                    if (total == 0)
                    {
                        DeploymentStatusCard.Visibility = Visibility.Collapsed;
                        return;
                    }

                    DeployInstalledCount.Text = installed.ToString();
                    DeployPendingCount.Text = pending.ToString();
                    DeployFailedCount.Text = failed.ToString();
                    DeployNotApplicableCount.Text = notApplicable.ToString();
                    DeployTargetedText.Text = $"{total} devices targeted";
                    DeployTotalText.Text = $"Updated {DateTime.Now:HH:mm}";
                    DeploySuccessRateText.Text = $"{stats.SuccessRate}% success rate";

                    // Update progress bar proportions
                    ProgressInstalledCol.Width = new GridLength(Math.Max(installed, 0), GridUnitType.Star);
                    ProgressPendingCol.Width = new GridLength(Math.Max(pending, 0), GridUnitType.Star);
                    ProgressFailedCol.Width = new GridLength(Math.Max(failed, 0), GridUnitType.Star);
                    ProgressNotApplicableCol.Width = new GridLength(Math.Max(notApplicable, 0), GridUnitType.Star);

                    DeploymentStatusCard.Visibility = Visibility.Visible;
                });
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error loading deployment status: {ex.Message}");
                DeploymentStatusCard.Visibility = Visibility.Collapsed;
            }
        }

        private async void LoadRecentDeploymentsAsync(ApplicationDetail app)
        {
            try
            {
                var mainWindow = Application.Current.MainWindow as MainWindow;
                var intuneService = mainWindow?.GetIntuneService();
                if (intuneService == null) return;

                var devices = await intuneService.GetApplicationInstallStatusAsync(app.Id);
                if (devices == null) return;

                var items = devices
                    .Where(d => !string.IsNullOrEmpty(d.DeviceName))
                    .OrderByDescending(d => d.LastSyncDateTime ?? DateTime.MinValue)
                    .Select(d => new DeploymentActivityItem(d))
                    .ToList();

                await Dispatcher.InvokeAsync(() =>
                {
                    RecentDeploymentsList.ItemsSource = items.Take(5).ToList();
                    NoRecentDeploymentsText.Visibility = items.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
                    RecentDeploymentsCard.Visibility = Visibility.Visible;

                    ActivityEventsList.ItemsSource = items;
                    ActivitySubtitle.Text = items.Count == 0
                        ? "No activity recorded"
                        : $"{items.Count} per-device event{(items.Count == 1 ? "" : "s")}";
                    NoActivityPanel.Visibility = items.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
                });
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error loading recent deployments: {ex.Message}");
            }
        }

        #endregion

        #region Network Path Loading

        private async Task LoadNetworkPathAsync(ApplicationDetail app)
        {
            StatusText.Text = "Finding network share path...";
            SourcePathText.Text = "Searching...";
            ActionButtonsPanel.Visibility = Visibility.Collapsed;
            ManualBrowsePanel.Visibility = Visibility.Collapsed;

            await Task.Run(async () =>
            {
                try
                {
                    var networkPath = NetworkShareHelper.FindApplicationPath(app.DisplayName, app.Version, app.Id);

                    await Dispatcher.InvokeAsync(async () =>
                    {
                        if (!string.IsNullOrEmpty(networkPath))
                        {
                            if (_currentApp != null)
                            {
                                _currentApp.NetworkSharePath = networkPath;
                            }
                            SourcePathText.Text = networkPath;
                            ActionButtonsPanel.Visibility = Visibility.Visible;
                            ManualBrowsePanel.Visibility = Visibility.Collapsed;
                            PathHelpText.Text = "Package path validated - ready for updates";
                            StatusText.Text = $"Loaded details for {app.DisplayName}";
                            LoadPackageContents(networkPath);
                            CheckCodeSigningAsync(app);

                            await SaveIconToNetworkFolderAsync(app, networkPath);
                        }
                        else
                        {
                            SourcePathText.Text = "Network share folder not found";
                            ActionButtonsPanel.Visibility = Visibility.Collapsed;
                            ManualBrowsePanel.Visibility = Visibility.Visible;
                            PathHelpText.Text = "Click Browse to manually locate the package folder";
                            StatusText.Text = $"Loaded details for {app.DisplayName} - Network path not found";

                            var result = ModernMessageBox.Show(
                                $"Could not automatically locate the package folder for:\n\n" +
                                $"'{app.DisplayName}'\n\n" +
                                $"Would you like to manually browse for the package folder?\n\n" +
                                $"Your selection will be saved for future use.",
                                "Package Folder Not Found",
                                MessageBoxButton.YesNo,
                                MessageBoxIcon.Question);

                            if (result == MessageBoxResult.Yes)
                            {
                                await PromptForManualFolderSelectionAsync(app);
                            }
                        }
                    });
                }
                catch (Exception ex)
                {
                    await Dispatcher.InvokeAsync(() =>
                    {
                        SourcePathText.Text = "Error searching network path";
                        ActionButtonsPanel.Visibility = Visibility.Collapsed;
                        ManualBrowsePanel.Visibility = Visibility.Visible;
                        PathHelpText.Text = "Click Browse to manually locate the package folder";
                        StatusText.Text = $"Error: {ex.Message}";
                        Debug.WriteLine($"Error loading network path: {ex}");
                    });
                }
            });
        }

        private async Task PromptForManualFolderSelectionAsync(ApplicationDetail app)
        {
            try
            {
                StatusText.Text = "Browsing for package folder...";

                var packagePath = BrowseForPackageFolder();
                if (!string.IsNullOrEmpty(packagePath))
                {
                    NetworkShareHelper.SaveMarker(packagePath, app.Id, app.DisplayName, app.Version);

                    if (_currentApp != null)
                    {
                        _currentApp.NetworkSharePath = packagePath;
                    }
                    RefreshPathValidation(packagePath);
                    StatusText.Text = $"Package folder saved: {Path.GetFileName(packagePath)}";

                    await SaveIconToNetworkFolderAsync(app, packagePath);

                    ModernMessageBox.Show(
                        $"Package folder location saved successfully!\n\n" +
                        $"Path: {packagePath}\n\n" +
                        $"This location will be remembered for future sessions.",
                        "Folder Mapping Saved",
                        MessageBoxButton.OK,
                        MessageBoxIcon.Success);
                }
                else
                {
                    StatusText.Text = "Browse cancelled";
                }
            }
            catch (Exception ex)
            {
                StatusText.Text = "Error saving folder mapping";
                Debug.WriteLine($"Error in PromptForManualFolderSelectionAsync: {ex}");
                ModernMessageBox.Show($"Error saving folder mapping:\n\n{ex.Message}",
                    "Error", MessageBoxButton.OK, MessageBoxIcon.Error);
            }
        }

        private static async Task SaveIconToNetworkFolderAsync(ApplicationDetail? app, string networkPath)
        {
            if (app?.IconData == null || app.IconData.Length == 0 || string.IsNullOrEmpty(networkPath))
                return;

            try
            {
                var iconFolder = Path.Combine(networkPath, "Icon");
                Directory.CreateDirectory(iconFolder);

                var invalidChars = Path.GetInvalidFileNameChars();
                var sanitized = new string(app.DisplayName.Where(c => !invalidChars.Contains(c)).ToArray()).Trim();
                var destPath = Path.Combine(iconFolder, $"{sanitized}.png");

                if (File.Exists(destPath))
                    return;

                await File.WriteAllBytesAsync(destPath, app.IconData);
                Debug.WriteLine($"Saved icon to: {destPath}");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Failed to save icon to {networkPath}: {ex.Message}");
            }
        }

        #endregion

        #region Group Interactions

        private void GroupItem_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            var grid = sender as Grid;
            var group = grid?.Tag as AssignedGroup;

            if (group != null && !string.IsNullOrEmpty(group.GroupId))
            {
                var mainWindow = Application.Current.MainWindow as MainWindow;
                var intuneService = mainWindow?.GetIntuneService();

                if (intuneService != null)
                {
                    var dialog = new GroupMembersDialog(
                        intuneService,
                        group.GroupId,
                        group.GroupName,
                        group.AssignmentType)
                    {
                        Owner = Window.GetWindow(this)
                    };
                    dialog.ShowDialog();
                }
                else
                {
                    ModernMessageBox.Show("Unable to access Intune service. Please ensure you're connected.",
                        "Service Unavailable", MessageBoxButton.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void GroupItem_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            if (sender is Border border)
            {
                var hoverBrush = Application.Current.TryFindResource("InfoLightBrush") as SolidColorBrush
                    ?? new SolidColorBrush(Color.FromRgb(239, 246, 255));
                border.Background = hoverBrush;
                var hint = FindVisualChild<TextBlock>(border, "ViewMembersHint");
                if (hint != null)
                {
                    hint.Visibility = Visibility.Visible;
                }
            }
        }

        private void GroupItem_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
            if (sender is Border border)
            {
                var surfaceBrush = Application.Current.TryFindResource("SurfaceAltBrush") as SolidColorBrush
                    ?? Brushes.White;
                border.Background = surfaceBrush;
                var hint = FindVisualChild<TextBlock>(border, "ViewMembersHint");
                if (hint != null)
                {
                    hint.Visibility = Visibility.Collapsed;
                }
            }
        }

        private T? FindVisualChild<T>(DependencyObject parent, string name) where T : FrameworkElement
        {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);

                if (child is T element && element.Name == name)
                    return element;

                var result = FindVisualChild<T>(child, name);
                if (result != null)
                    return result;
            }
            return null;
        }

        #endregion

        #region Action Buttons

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            BackToListRequested?.Invoke(this, EventArgs.Empty);
        }

        private async void UpdateApplicationButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentApp == null)
            {
                ModernMessageBox.Show("No application selected.", "Error",
                    MessageBoxButton.OK, MessageBoxIcon.Warning);
                return;
            }

            var currentApp = _currentApp;
            string packagePath = "";

            if (!string.IsNullOrEmpty(currentApp.NetworkSharePath) &&
                ValidatePackageForUpdate(currentApp.NetworkSharePath))
            {
                packagePath = currentApp.NetworkSharePath;
            }
            else
            {
                var result = ModernMessageBox.Show(
                    $"Network share path for '{currentApp.DisplayName}' was not found or is invalid.\n\n" +
                    $"Would you like to manually browse for the package folder?\n\n" +
                    $"Your selection will be saved for future use.",
                    "Network Path Not Found",
                    MessageBoxButton.YesNo,
                    MessageBoxIcon.Question);

                if (result != MessageBoxResult.Yes)
                    return;

                packagePath = BrowseForPackageFolder();
                if (string.IsNullOrEmpty(packagePath))
                    return;

                if (!string.IsNullOrEmpty(currentApp.Id))
                {
                    NetworkShareHelper.SaveMarker(packagePath, currentApp.Id, currentApp.DisplayName, currentApp.Version);
                }

                await SaveIconToNetworkFolderAsync(currentApp, packagePath);
                RefreshPathValidation(packagePath);
            }

            await PerformPackageUpdate(packagePath);
        }

        private void OpenScriptButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(_currentApp?.NetworkSharePath))
                {
                    var scriptPath = Path.Combine(_currentApp.NetworkSharePath, "Application", "Invoke-AppDeployToolkit.ps1");

                    if (!File.Exists(scriptPath))
                    {
                        scriptPath = Path.Combine(_currentApp.NetworkSharePath, "Invoke-AppDeployToolkit.ps1");
                    }

                    if (File.Exists(scriptPath))
                    {
                        OpenScriptInEditor(scriptPath);
                        return;
                    }
                }

                var message = string.IsNullOrEmpty(_currentApp?.NetworkSharePath)
                    ? $"Network share path not found for {_currentApp?.DisplayName}.\n\nWould you like to browse for the Invoke-AppDeployToolkit.ps1 file manually?"
                    : $"Invoke-AppDeployToolkit.ps1 not found in:\n{_currentApp.NetworkSharePath}\n\nWould you like to browse for the file manually?";

                var result = ModernMessageBox.Show(message, "Script Not Found",
                    MessageBoxButton.YesNo, MessageBoxIcon.Question);

                if (result == MessageBoxResult.Yes)
                {
                    BrowseForScriptManually();
                }
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error opening script: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxIcon.Error);
                StatusText.Text = "Error opening script";
            }
        }

        private void DeploymentStatusCard_Click(object sender, RoutedEventArgs e)
        {
            if (_currentApp == null)
            {
                ModernMessageBox.Show("No application selected.", "Error",
                    MessageBoxButton.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                StatusText.Text = "Opening installation report...";

                var reportingWindow = new Views.ReportingWindow(_currentApp.Id, _currentApp.DisplayName)
                {
                    Owner = Window.GetWindow(this)
                };

                reportingWindow.ShowDialog();

                StatusText.Text = $"Viewing report for {_currentApp.DisplayName}";
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error opening reporting window:\n\n{ex.Message}",
                    "Error", MessageBoxButton.OK, MessageBoxIcon.Error);
                StatusText.Text = "Failed to open reporting window";
            }
        }

        private void TestApplicationButton_Click(object sender, RoutedEventArgs e)
        {
            var currentApp = _currentApp;
            if (currentApp == null)
            {
                ModernMessageBox.Show("No application selected.", "Error",
                    MessageBoxButton.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                var packagePath = currentApp.NetworkSharePath ?? "";
                var remoteTest = new RemoteTestWindow(packagePath)
                {
                    Owner = Window.GetWindow(this)
                };
                remoteTest.ShowDialog();
                StatusText.Text = $"Test window closed for {currentApp.DisplayName}";
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error opening test window:\n\n{ex.Message}",
                    "Error", MessageBoxButton.OK, MessageBoxIcon.Error);
                StatusText.Text = "Failed to open test window";
            }
        }

        private void OpenIntunePortalButton_Click(object sender, RoutedEventArgs e)
        {
            var currentApp = _currentApp;
            if (currentApp == null || string.IsNullOrEmpty(currentApp.Id))
            {
                ModernMessageBox.Show("Application has no Intune App ID.", "Error",
                    MessageBoxButton.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                var url = $"https://intune.microsoft.com/#view/Microsoft_Intune_Apps/SettingsMenu/~/0/appId/{currentApp.Id}";
                Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
                StatusText.Text = "Opened Intune portal";
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error opening Intune portal:\n\n{ex.Message}",
                    "Error", MessageBoxButton.OK, MessageBoxIcon.Error);
                StatusText.Text = "Failed to open Intune portal";
            }
        }

        private void OpenFolderButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(_currentApp?.NetworkSharePath))
            {
                ModernMessageBox.Show("Network share path not found for this application.", "Path Not Found",
                    MessageBoxButton.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                Process.Start("explorer.exe", _currentApp.NetworkSharePath);
                StatusText.Text = $"Opened folder: {_currentApp.DisplayName}";
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error opening folder: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxIcon.Error);
                StatusText.Text = "Error opening folder";
            }
        }

        private async void BrowsePackageFolderButton_Click(object sender, RoutedEventArgs e)
        {
            StatusText.Text = "Browsing for package folder...";

            var packagePath = BrowseForPackageFolder();
            if (!string.IsNullOrEmpty(packagePath))
            {
                if (_currentApp != null && !string.IsNullOrEmpty(_currentApp.Id))
                {
                    NetworkShareHelper.SaveMarker(packagePath, _currentApp.Id, _currentApp.DisplayName, _currentApp.Version);
                    Debug.WriteLine($"Saved app-id marker for {_currentApp.DisplayName}");

                    await SaveIconToNetworkFolderAsync(_currentApp, packagePath);
                }

                RefreshPathValidation(packagePath);
                StatusText.Text = $"Package path set and saved: {Path.GetFileName(packagePath)}";
            }
            else
            {
                StatusText.Text = "Browse cancelled";
            }
        }

        private void PrivacyUrl_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(_currentApp?.PrivacyInformationUrl))
            {
                try
                {
                    Process.Start(new ProcessStartInfo
                    {
                        FileName = _currentApp.PrivacyInformationUrl,
                        UseShellExecute = true
                    });
                }
                catch (Exception ex)
                {
                    ModernMessageBox.Show($"Error opening URL: {ex.Message}", "Error",
                        MessageBoxButton.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void InfoUrl_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(_currentApp?.InformationUrl))
            {
                try
                {
                    Process.Start(new ProcessStartInfo
                    {
                        FileName = _currentApp.InformationUrl,
                        UseShellExecute = true
                    });
                }
                catch (Exception ex)
                {
                    ModernMessageBox.Show($"Error opening URL: {ex.Message}", "Error",
                        MessageBoxButton.OK, MessageBoxIcon.Error);
                }
            }
        }

        #endregion

        #region Helper Methods

        private string BrowseForPackageFolder()
        {
            try
            {
                string? initialDir = null;
                if (_currentApp != null && !string.IsNullOrEmpty(_currentApp.NetworkSharePath)
                    && Directory.Exists(_currentApp.NetworkSharePath))
                {
                    initialDir = _currentApp.NetworkSharePath;
                }
                else if (Directory.Exists(NetworkShareHelper.ShareRoot))
                {
                    initialDir = NetworkShareHelper.ShareRoot;
                }

                var selected = FolderBrowserHelper.ShowFolderBrowser(
                    title: $"Select package folder for {_currentApp?.DisplayName ?? "this application"}",
                    initialDirectory: initialDir);

                if (string.IsNullOrEmpty(selected))
                    return "";

                // If the user picked the Application subfolder, walk up to the package root.
                var packageRoot = FolderBrowserHelper.GetPackageRootPath(selected);

                if (!ValidatePackageForUpdate(packageRoot))
                {
                    ModernMessageBox.Show(
                        $"The selected folder is not a valid package.\n\n" +
                        $"Expected an 'Application' subfolder containing Invoke-AppDeployToolkit.exe, Deploy-Application.exe, or Deploy-Application.ps1.\n\n" +
                        $"Selected: {packageRoot}",
                        "Invalid Package Folder",
                        MessageBoxButton.OK,
                        MessageBoxIcon.Warning);
                    return "";
                }

                if (_currentApp != null)
                {
                    _currentApp.NetworkSharePath = packageRoot;
                }

                return packageRoot;
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error browsing for folder: {ex.Message}", "Browse Error",
                    MessageBoxButton.OK, MessageBoxIcon.Error);
                return "";
            }
        }

        private bool ValidatePackageForUpdate(string networkSharePath)
        {
            try
            {
                if (!Directory.Exists(networkSharePath))
                    return false;

                var applicationFolder = Path.Combine(networkSharePath, "Application");
                if (!Directory.Exists(applicationFolder))
                    return false;

                // Support both PSADTv4 (Invoke-AppDeployToolkit.exe) and PSADTv3 (Deploy-Application.exe/.ps1)
                if (File.Exists(Path.Combine(applicationFolder, "Invoke-AppDeployToolkit.exe")))
                    return true;
                if (File.Exists(Path.Combine(applicationFolder, "Deploy-Application.exe")))
                    return true;
                if (File.Exists(Path.Combine(applicationFolder, "Deploy-Application.ps1")))
                    return true;

                return false;
            }
            catch
            {
                return false;
            }
        }

        private void RefreshPathValidation(string path)
        {
            if (!string.IsNullOrEmpty(path) && ValidatePackageForUpdate(path))
            {
                SourcePathText.Text = path;
                ActionButtonsPanel.Visibility = Visibility.Visible;
                ManualBrowsePanel.Visibility = Visibility.Collapsed;
                PathHelpText.Text = "Package path validated - ready for updates";
                LoadPackageContents(path);
            }
            else
            {
                SourcePathText.Text = string.IsNullOrEmpty(path) ? "No path specified" : "Invalid package structure";
                ActionButtonsPanel.Visibility = Visibility.Collapsed;
                ManualBrowsePanel.Visibility = Visibility.Visible;
                PathHelpText.Text = "Click Browse to manually locate the package folder";
                PackageContentsCard.Visibility = Visibility.Collapsed;
            }
        }

        private async Task PerformPackageUpdate(string packagePath)
        {
            if (_currentApp == null)
            {
                ModernMessageBox.Show("No application selected.", "Error",
                    MessageBoxButton.OK, MessageBoxIcon.Warning);
                return;
            }

            var currentApp = _currentApp;

            try
            {
                UpdateApplicationButton.IsEnabled = false;
                UpdateApplicationButton.Content = "\uE895 Updating...";

                StatusText.Text = "Starting package update...";

                // GitLab version control - collect commit message before upload
                string? gitLabCommitMessage = null;
                var gitLabService = App.Services.GetRequiredService<Services.GitLabService>();
                if (gitLabService.IsPartiallyConfigured)
                {
                    var configError = gitLabService.GetConfigurationErrors();
                    if (configError != null)
                    {
                        ModernMessageBox.Show(
                            $"GitLab push is enabled but not fully configured.\n\n{configError}\n\nThe update will continue without pushing to GitLab.",
                            "GitLab Configuration Incomplete",
                            MessageBoxButton.OK,
                            MessageBoxIcon.Warning);
                    }
                    else
                    {
                        var (committed, skipped, message) = Dialogs.CommitMessageDialog.Show(
                            currentApp.DisplayName, packagePath, Window.GetWindow(this));

                        if (!committed && !skipped)
                            return; // User closed the dialog (cancelled)

                        if (committed && !skipped)
                            gitLabCommitMessage = message;
                    }
                }

                var notificationId = Notifications.ShowInProgress(
                    $"Upgrading {currentApp.DisplayName}",
                    "Starting package update...",
                    0
                );

                var toastAdapter = new Services.ToastProgressAdapter(notificationId);
                var progressTracker = new CompositeUpdateProgressTracker(this, toastAdapter);

                var intuneService = App.Services.GetRequiredService<IntuneService>();
                using var uploadService = App.Services.GetRequiredService<IntuneUploadService>();

                var success = await uploadService.UpdateExistingApplicationAsync(
                    currentApp.Id,
                    packagePath,
                    progressTracker,
                    currentApp.DisplayName,
                    gitLabCommitMessage
                );

                if (success)
                {
                    intuneService.InvalidateApplicationCache(currentApp.Id);
                    StatusText.Text = $"Package updated successfully \u2022 {DateTime.Now:HH:mm:ss}";

                    Notifications.CompleteNotification(
                        notificationId,
                        success: true,
                        message: $"Updated successfully \u2022 auto-closing in 20s"
                    );
                }
                else
                {
                    StatusText.Text = "Package update failed";

                    Notifications.CompleteNotification(
                        notificationId,
                        success: false,
                        message: "Package update failed"
                    );
                }
            }
            catch (Exception ex)
            {
                StatusText.Text = "Package update failed";
                Notifications.ShowError(
                    $"Update Failed: {currentApp.DisplayName}",
                    ex.Message
                );
            }
            finally
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    UpdateApplicationButton.IsEnabled = true;
                    UpdateApplicationButton.Content = new StackPanel
                    {
                        Orientation = Orientation.Horizontal,
                        Children =
                        {
                            new TextBlock { Text = "\uE895", FontFamily = new FontFamily("Segoe MDL2 Assets"), Margin = new Thickness(0,0,6,0), VerticalAlignment = VerticalAlignment.Center },
                            new TextBlock { Text = "Update" }
                        }
                    };
                    StatusText.Text = "Ready";
                }));
            }
        }

        private async Task PushToGitLabAsync(string applicationName, string packagePath)
        {
            try
            {
                var gitLabService = App.Services.GetRequiredService<Services.GitLabService>();
                if (!gitLabService.IsConfigured)
                    return;

                var (committed, skipped, message) = Dialogs.CommitMessageDialog.Show(applicationName, packagePath, Window.GetWindow(this));

                if (!committed || skipped)
                    return;

                await PushToGitLabWithMessageAsync(applicationName, packagePath, message);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"GitLab push error: {ex.Message}");
                ModernMessageBox.Show(
                    $"Error pushing to GitLab:\n\n{ex.Message}",
                    "GitLab Error",
                    MessageBoxButton.OK,
                    MessageBoxIcon.Warning);
            }
        }

        private async Task PushToGitLabWithMessageAsync(string applicationName, string packagePath, string commitMessage)
        {
            try
            {
                var gitLabService = App.Services.GetRequiredService<Services.GitLabService>();

                StatusText.Text = "Pushing to GitLab...";

                var (success, error) = await gitLabService.PushScriptToGitLabAsync(
                    applicationName,
                    packagePath,
                    commitMessage,
                    new Progress<string>(status => StatusText.Text = status));

                if (success)
                {
                    StatusText.Text = $"Pushed to GitLab \u2022 {DateTime.Now:HH:mm:ss}";
                    Notifications.ShowSuccess("GitLab Push", $"Script for '{applicationName}' pushed to GitLab");
                }
                else
                {
                    StatusText.Text = "GitLab push failed";
                    ModernMessageBox.Show(
                        $"Failed to push script to GitLab.\n\n{error}",
                        "GitLab Push Failed",
                        MessageBoxButton.OK,
                        MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"GitLab push error: {ex.Message}");
                ModernMessageBox.Show(
                    $"Error pushing to GitLab:\n\n{ex.Message}",
                    "GitLab Error",
                    MessageBoxButton.OK,
                    MessageBoxIcon.Warning);
            }
        }

        private void BrowseForScriptManually()
        {
            var openFileDialog = new OpenFileDialog
            {
                Title = $"Locate Invoke-AppDeployToolkit.ps1 for {_currentApp?.DisplayName}",
                Filter = "PowerShell Scripts (*.ps1)|*.ps1|All Files (*.*)|*.*",
                FileName = "Invoke-AppDeployToolkit.ps1",
                InitialDirectory = @"\\nbb.local\sys\SCCMData"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                var selectedFile = openFileDialog.FileName;

                var directory = Path.GetDirectoryName(selectedFile);
                if (directory != null)
                {
                    if (directory.EndsWith("Application", StringComparison.OrdinalIgnoreCase))
                    {
                        if (_currentApp != null)
                        {
                            _currentApp.NetworkSharePath = Path.GetDirectoryName(directory) ?? directory;
                        }
                    }
                    else
                    {
                        if (_currentApp != null)
                        {
                            _currentApp.NetworkSharePath = directory;
                        }
                    }

                    if (_currentApp != null)
                    {
                        SourcePathText.Text = _currentApp.NetworkSharePath;
                        ActionButtonsPanel.Visibility = Visibility.Visible;
                    }
                }

                OpenScriptInEditor(selectedFile);
            }
        }

        private void OpenScriptInEditor(string scriptPath)
        {
            try
            {
                var vsCodePath = FindVSCodePath();
                if (!string.IsNullOrEmpty(vsCodePath))
                {
                    var psi = new ProcessStartInfo
                    {
                        FileName = vsCodePath,
                        Arguments = $"\"{scriptPath}\"",
                        UseShellExecute = true
                    };
                    Process.Start(psi);
                    StatusText.Text = $"Opened script in VS Code: {Path.GetFileName(scriptPath)}";
                    return;
                }
            }
            catch { }

            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = "powershell_ise.exe",
                    Arguments = $"\"{scriptPath}\"",
                    UseShellExecute = true
                };
                Process.Start(psi);
                StatusText.Text = $"Opened script in PowerShell ISE: {Path.GetFileName(scriptPath)}";
            }
            catch
            {
                try
                {
                    Process.Start("notepad.exe", $"\"{scriptPath}\"");
                    StatusText.Text = $"Opened script in Notepad: {Path.GetFileName(scriptPath)}";
                }
                catch (Exception ex)
                {
                    ModernMessageBox.Show($"Could not open script in any editor: {ex.Message}",
                        "Error", MessageBoxButton.OK, MessageBoxIcon.Error);
                }
            }
        }

        private string? FindVSCodePath()
        {
            string[] possiblePaths = {
                @"C:\Program Files\Microsoft VS Code\Code.exe",
                @"C:\Program Files (x86)\Microsoft VS Code\Code.exe",
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    @"Programs\Microsoft VS Code\Code.exe")
            };

            foreach (var path in possiblePaths)
            {
                if (File.Exists(path))
                    return path;
            }

            return null;
        }

        public void ResetScrollPosition()
        {
            DetailScrollViewer?.ScrollToTop();
        }

        #endregion

        #region Progress Tracker

        private class UpdateProgressTracker : IUploadProgress
        {
            private readonly ApplicationDetailView _view;

            public UpdateProgressTracker(ApplicationDetailView view)
            {
                _view = view;
            }

            public void UpdateProgress(int percentage, string message)
            {
                _view.Dispatcher.Invoke(() =>
                {
                    _view.StatusText.Text = $"{message} ({percentage}%)";
                });
            }
        }

        private class CompositeUpdateProgressTracker : IUploadProgress
        {
            private readonly ApplicationDetailView _view;
            private readonly IUploadProgress _toastAdapter;

            public CompositeUpdateProgressTracker(ApplicationDetailView view, IUploadProgress toastAdapter)
            {
                _view = view;
                _toastAdapter = toastAdapter;
            }

            public void UpdateProgress(int percentage, string message)
            {
                _view.Dispatcher.Invoke(() =>
                {
                    _view.StatusText.Text = $"{message} ({percentage}%)";
                });

                _toastAdapter.UpdateProgress(percentage, message);
            }
        }

        #endregion

        #region Package Contents

        private List<FileTreeItem>? _fileTreeItems;

        private void LoadPackageContents(string networkPath)
        {
            try
            {
                if (string.IsNullOrEmpty(networkPath) || !Directory.Exists(networkPath))
                {
                    PackageContentsCard.Visibility = Visibility.Collapsed;
                    return;
                }

                _fileTreeItems = new List<FileTreeItem>();
                int totalFiles = 0;
                int totalFolders = 0;
                long totalSize = 0;

                BuildFileTree(networkPath, _fileTreeItems, 0, networkPath, ref totalFiles, ref totalFolders, ref totalSize);

                PackageFileTree.ItemsSource = _fileTreeItems;
                PackageContentsCard.Visibility = Visibility.Visible;
                PackageContentsSummary.Text = $"{totalFolders} folders, {totalFiles} files · {FormatFileSize(totalSize)}";
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error loading package contents: {ex}");
                PackageContentsCard.Visibility = Visibility.Collapsed;
            }
        }

        private void BuildFileTree(string path, List<FileTreeItem> items, int depth, string rootPath,
            ref int totalFiles, ref int totalFolders, ref long totalSize, int maxDepth = 5)
        {
            if (depth > maxDepth) return;

            try
            {
                var directories = Directory.GetDirectories(path).OrderBy(d => Path.GetFileName(d));
                foreach (var dir in directories)
                {
                    var dirName = Path.GetFileName(dir);
                    totalFolders++;

                    items.Add(new FileTreeItem
                    {
                        Name = dirName,
                        Icon = "\uE8B7",
                        IconColor = Application.Current.TryFindResource("WarningColorBrush") as Brush
                                    ?? new SolidColorBrush(Color.FromRgb(234, 179, 8)),
                        Indent = new Thickness(depth * 20, 0, 0, 0),
                        IsFolder = true,
                        FontFamily = new FontFamily("Segoe UI"),
                        Depth = depth,
                        FolderPath = dir,
                        ParentPath = path,
                        IsExpanded = true
                    });

                    BuildFileTree(dir, items, depth + 1, rootPath, ref totalFiles, ref totalFolders, ref totalSize, maxDepth);
                }

                var files = Directory.GetFiles(path).OrderBy(f => Path.GetFileName(f));
                foreach (var file in files)
                {
                    var fileName = Path.GetFileName(file);
                    long fileSize = 0;
                    try
                    {
                        fileSize = new FileInfo(file).Length;
                        totalSize += fileSize;
                    }
                    catch { }

                    totalFiles++;

                    items.Add(new FileTreeItem
                    {
                        Name = fileName,
                        Icon = GetFileIcon(fileName),
                        IconColor = Application.Current.TryFindResource("TextSecondaryBrush") as Brush
                                    ?? new SolidColorBrush(Color.FromRgb(156, 163, 175)),
                        SizeText = FormatFileSize(fileSize),
                        Indent = new Thickness(depth * 20, 0, 0, 0),
                        IsFolder = false,
                        FontFamily = new FontFamily("Consolas"),
                        Depth = depth,
                        ParentPath = path
                    });
                }
            }
            catch (UnauthorizedAccessException)
            {
                items.Add(new FileTreeItem
                {
                    Name = "(access denied)",
                    Icon = "\uE7BA",
                    IconColor = Application.Current.TryFindResource("ErrorColorBrush") as Brush
                                ?? new SolidColorBrush(Color.FromRgb(239, 68, 68)),
                    Indent = new Thickness(depth * 20, 0, 0, 0),
                    FontFamily = new FontFamily("Segoe UI"),
                    Depth = depth,
                    ParentPath = path
                });
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error reading directory {path}: {ex.Message}");
            }
        }

        private void FileTreeItem_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (sender is Border border && border.Tag is FileTreeItem item && item.IsFolder && _fileTreeItems != null)
            {
                item.IsExpanded = !item.IsExpanded;
                item.NotifyChevronChanged();

                // Show or hide all descendant items
                SetChildrenVisibility(item.FolderPath, item.IsExpanded);
            }
        }

        private void SetChildrenVisibility(string parentFolderPath, bool visible)
        {
            if (_fileTreeItems == null) return;

            foreach (var item in _fileTreeItems)
            {
                // Check if this item is a direct or nested child of the folder
                if (!string.IsNullOrEmpty(item.ParentPath) &&
                    (item.ParentPath == parentFolderPath ||
                     item.ParentPath.StartsWith(parentFolderPath + Path.DirectorySeparatorChar) ||
                     item.ParentPath.StartsWith(parentFolderPath + Path.AltDirectorySeparatorChar)))
                {
                    if (visible)
                    {
                        // When expanding, only show direct children or children of expanded folders
                        var isDirectChild = item.ParentPath == parentFolderPath;
                        if (isDirectChild)
                        {
                            item.Visibility = Visibility.Visible;
                            // If this is a collapsed folder, keep its children hidden
                            if (item.IsFolder && !item.IsExpanded)
                            {
                                SetChildrenVisibility(item.FolderPath, false);
                            }
                        }
                        else
                        {
                            // For nested items, check if all ancestor folders are expanded
                            if (AreAllAncestorsExpanded(item.ParentPath, parentFolderPath))
                            {
                                item.Visibility = Visibility.Visible;
                            }
                        }
                    }
                    else
                    {
                        item.Visibility = Visibility.Collapsed;
                    }
                }
            }
        }

        private bool AreAllAncestorsExpanded(string itemParentPath, string rootFolderPath)
        {
            if (_fileTreeItems == null) return false;

            foreach (var folder in _fileTreeItems)
            {
                if (folder.IsFolder &&
                    folder.FolderPath != rootFolderPath &&
                    !string.IsNullOrEmpty(folder.FolderPath) &&
                    (itemParentPath == folder.FolderPath ||
                     itemParentPath.StartsWith(folder.FolderPath + Path.DirectorySeparatorChar) ||
                     itemParentPath.StartsWith(folder.FolderPath + Path.AltDirectorySeparatorChar)))
                {
                    if (!folder.IsExpanded) return false;
                }
            }
            return true;
        }

        private static string ExtractCN(string distinguishedName)
        {
            if (string.IsNullOrEmpty(distinguishedName)) return "";
            // Extract CN= value from "CN=Name, O=Org, ..." format
            if (distinguishedName.StartsWith("CN=", StringComparison.OrdinalIgnoreCase))
            {
                var commaIdx = distinguishedName.IndexOf(',');
                return commaIdx > 3 ? distinguishedName.Substring(3, commaIdx - 3).Trim() : distinguishedName.Substring(3).Trim();
            }
            return distinguishedName;
        }

        private static string GetFileIcon(string fileName)
        {
            var ext = Path.GetExtension(fileName).ToLowerInvariant();
            return ext switch
            {
                ".exe" => "\uE7AC",   // App icon
                ".msi" => "\uE7AC",
                ".ps1" => "\uE756",   // Code icon
                ".psm1" => "\uE756",
                ".psd1" => "\uE756",
                ".bat" => "\uE756",
                ".cmd" => "\uE756",
                ".xml" => "\uE8A5",   // Page icon
                ".json" => "\uE8A5",
                ".config" => "\uE713", // Settings icon
                ".cfg" => "\uE713",
                ".ini" => "\uE713",
                ".log" => "\uE8FD",   // Preview icon
                ".txt" => "\uE8A5",
                ".dll" => "\uE74C",   // Component icon
                ".intunewin" => "\uE896", // Cloud icon
                ".zip" => "\uE8B9",   // Zip icon
                ".ico" => "\uEB9F",   // Photo icon
                ".png" => "\uEB9F",
                ".jpg" => "\uEB9F",
                ".jpeg" => "\uEB9F",
                ".bmp" => "\uEB9F",
                _ => "\uE8A5"         // Default page icon
            };
        }

        private static string FormatFileSize(long bytes)
        {
            if (bytes <= 0) return "";
            if (bytes < 1024) return $"{bytes} B";
            if (bytes < 1024 * 1024) return $"{bytes / 1024.0:F1} KB";
            if (bytes < 1024 * 1024 * 1024) return $"{bytes / (1024.0 * 1024.0):F1} MB";
            return $"{bytes / (1024.0 * 1024.0 * 1024.0):F2} GB";
        }

        private void RefreshContentsButton_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(_currentApp?.NetworkSharePath))
            {
                LoadPackageContents(_currentApp.NetworkSharePath);
                StatusText.Text = "Package contents refreshed";
            }
        }

        #endregion
    }

    public class DeploymentActivityItem
    {
        public DeviceInstallStatus Source { get; }

        public DeploymentActivityItem(DeviceInstallStatus src)
        {
            Source = src;
        }

        public string DeviceName => Source.DeviceName;

        public string UserName => !string.IsNullOrEmpty(Source.UserName)
            ? Source.UserName
            : Source.UserPrincipalName;

        public string DisplayInstallState => (Source.InstallState?.ToLowerInvariant()) switch
        {
            "installed" => "Installed",
            "failed" => "Failed",
            "pending" => "Pending",
            "notinstalled" => "Not Installed",
            "notapplicable" => "N/A",
            _ => string.IsNullOrEmpty(Source.InstallState) ? "Unknown" : Source.InstallState
        };

        public string ShortSyncTime
        {
            get
            {
                if (!Source.LastSyncDateTime.HasValue) return "";
                var dt = Source.LastSyncDateTime.Value.ToLocalTime();
                var today = DateTime.Now.Date;
                return dt.Date == today ? dt.ToString("HH:mm") : dt.ToString("MMM dd HH:mm");
            }
        }

        public Brush StatusDotBrush
        {
            get
            {
                var key = (Source.InstallState?.ToLowerInvariant()) switch
                {
                    "installed" => "SuccessColorBrush",
                    "failed" => "ErrorColorBrush",
                    "pending" => "WarningColorBrush",
                    _ => "TextMutedBrush"
                };
                return (Application.Current?.TryFindResource(key) as Brush) ?? Brushes.Gray;
            }
        }
    }

    public class FileTreeItem : System.ComponentModel.INotifyPropertyChanged
    {
        public string Name { get; set; } = "";
        public string Icon { get; set; } = "\uE8A5";
        public Brush? IconColor { get; set; }
        public string SizeText { get; set; } = "";
        public Thickness Indent { get; set; }
        public bool IsFolder { get; set; }
        public FontFamily FontFamily { get; set; } = new FontFamily("Segoe UI");
        public int Depth { get; set; }
        public string FolderPath { get; set; } = "";
        public string ParentPath { get; set; } = "";
        public bool IsExpanded { get; set; } = true;

        public string ChevronIcon => IsFolder ? (IsExpanded ? "\uE70D" : "\uE76C") : "";

        private Visibility _visibility = Visibility.Visible;
        public Visibility Visibility
        {
            get => _visibility;
            set { _visibility = value; OnPropertyChanged(nameof(Visibility)); }
        }

        public event System.ComponentModel.PropertyChangedEventHandler? PropertyChanged;
        public void OnPropertyChanged(string name) =>
            PropertyChanged?.Invoke(this, new System.ComponentModel.PropertyChangedEventArgs(name));

        public void NotifyChevronChanged() => OnPropertyChanged(nameof(ChevronIcon));
    }
}
