using Microsoft.Extensions.DependencyInjection;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;


namespace Endpoint_Packaging_Suite.Dialogs
{
    public partial class CommitMessageDialog : Window
    {
        public string CommitMessage { get; private set; } = "";
        public bool WasCommitted { get; private set; } = false;
        public bool WasSkipped { get; private set; } = false;

        public CommitMessageDialog(string applicationName, string sourcePath)
        {
            InitializeComponent();
            AppNameText.Text = applicationName;
            AppPathText.Text = sourcePath;
            CommitMessageTextBox.Text = $"Update {applicationName}";
            Loaded += OnLoaded;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            CommitMessageTextBox.Focus();
            CommitMessageTextBox.SelectAll();
        }

        public static (bool committed, bool skipped, string message) Show(string applicationName, string sourcePath, Window? owner = null)
        {
            var dialog = new CommitMessageDialog(applicationName, sourcePath);
            if (owner != null)
                dialog.Owner = owner;
            dialog.ShowDialog();
            return (dialog.WasCommitted, dialog.WasSkipped, dialog.CommitMessage);
        }

        private void CommitButton_Click(object sender, RoutedEventArgs e)
        {
            var message = CommitMessageTextBox.Text?.Trim();
            if (string.IsNullOrEmpty(message))
            {
                ModernMessageBox.Show("Please enter a commit message.", "Validation",
                    MessageBoxButton.OK, MessageBoxIcon.Warning);
                return;
            }

            CommitMessage = message;
            WasCommitted = true;
            Close();
        }

        private void SkipButton_Click(object sender, RoutedEventArgs e)
        {
            WasSkipped = true;
            Close();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private async void TestConnectionButton_Click(object sender, RoutedEventArgs e)
        {
            TestConnectionButton.IsEnabled = false;
            TestConnectionButton.Content = "Testing...";
            ConnectionStatusText.Visibility = Visibility.Visible;
            ConnectionStatusText.Text = "Connecting to GitLab...";
            ConnectionStatusText.Foreground = (Brush)FindResource("TextSecondaryBrush");

            try
            {
                var gitLabService = App.Services.GetRequiredService<Services.GitLabService>();
                var (success, message) = await gitLabService.TestConnectionAsync();

                ConnectionStatusText.Text = message;
                ConnectionStatusText.Foreground = success
                    ? (Brush)(FindResource("SuccessColorBrush") ?? Foreground)
                    : (Brush)(FindResource("ErrorColorBrush") ?? Foreground);
            }
            catch (System.Exception ex)
            {
                ConnectionStatusText.Text = $"Error: {ex.Message}";
                ConnectionStatusText.Foreground = (Brush)(FindResource("ErrorColorBrush") ?? Foreground);
            }
            finally
            {
                TestConnectionButton.IsEnabled = true;
                TestConnectionButton.Content = "Test Connection";
            }
        }

        private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount == 1)
                DragMove();
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                Close();
                e.Handled = true;
            }
        }
    }
}
