using Endpoint_Packaging_Suite.Constants;
using Endpoint_Packaging_Suite.Helpers;
using Endpoint_Packaging_Suite.Managers;
using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite.Services;
using Endpoint_Packaging_Suite.Dialogs;
using Endpoint_Packaging_Suite.Views;
using Microsoft.Extensions.DependencyInjection;
using Serilog;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Endpoint_Packaging_Suite
{
    public partial class MainWindow
    {
        private bool _isSidebarCollapsed = false;

        private void UploadExistingNavButton_Click(object sender, RoutedEventArgs e)
        {
            _navigationManager?.ShowPage(NavigationManager.PageNameUploadExisting);
            _navigationManager?.SetActiveNavButton(UploadExistingNavButton);
        }

        private void CreateAppNavButton_Click(object sender, RoutedEventArgs e)
        {
            _navigationManager?.ShowPage(NavigationManager.PageNameCreateApplication);
            _navigationManager?.SetActiveNavButton(CreateAppNavButton);
        }

        private async void ViewAppsNavButton_Click(object sender, RoutedEventArgs e)
        {
            _navigationManager?.ShowPage(NavigationManager.PageNameViewApplications);
            _navigationManager?.SetActiveNavButton(ViewAppsNavButton);

            if (_applicationListViewModel != null)
            {
                if (!_applicationListViewModel.ApplicationsLoaded)
                {
                    await _applicationListViewModel.LoadAllApplicationsAsync();
                }
                else
                {
                    _applicationListViewModel.ApplyFiltersAndPagination();
                }
            }
        }

        private void WDACToolsNavButton_Click(object sender, RoutedEventArgs e)
        {
            _navigationManager?.ShowPage(NavigationManager.PageNameWDACTools);
            _navigationManager?.SetActiveNavButton(WDACToolsNavButton);
        }

        private void LogsNavButton_Click(object sender, RoutedEventArgs e)
        {
            _navigationManager?.ShowPage(NavigationManager.PageNameLogs);
            _navigationManager?.SetActiveNavButton(LogsNavButton);
        }

        private void RemoteTestNavButton_Click(object sender, RoutedEventArgs e)
        {
            _navigationManager?.ShowPage(NavigationManager.PageNameRemoteTest);
            _navigationManager?.SetActiveNavButton(RemoteTestNavButton);
        }

        private void SignNavButton_Click(object sender, RoutedEventArgs e)
        {
            _navigationManager?.ShowPage(NavigationManager.PageNameSign);
            _navigationManager?.SetActiveNavButton(SignNavButton);
        }

        private void AdvancedNavButton_Click(object sender, RoutedEventArgs e)
        {
            _navigationManager?.ShowPage(NavigationManager.PageNameAdvanced);
            _navigationManager?.SetActiveNavButton(AdvancedNavButton);
        }

        private void SidebarToggleButton_Click(object sender, RoutedEventArgs e)
        {
            _isSidebarCollapsed = !_isSidebarCollapsed;
            var collapsedVisibility = _isSidebarCollapsed ? Visibility.Collapsed : Visibility.Visible;
            var iconMargin = _isSidebarCollapsed ? new Thickness(0) : new Thickness(0, 0, 11, 0);
            var contentAlignment = _isSidebarCollapsed ? HorizontalAlignment.Center : HorizontalAlignment.Left;
            var buttonPadding = _isSidebarCollapsed ? new Thickness(8, 8, 8, 8) : new Thickness(12, 8, 12, 8);
            var buttonMargin = _isSidebarCollapsed ? new Thickness(2, 4, 2, 4) : new Thickness(6, 1, 6, 1);

            if (_isSidebarCollapsed)
            {
                // Collapse sidebar to icon-only mode
                SidebarColumn.Width = new GridLength(64);
                SidebarColumn.MinWidth = 64;
                SidebarColumn.MaxWidth = 64;

                // Adjust header padding and logo margin for collapsed mode
                SidebarHeader.Padding = new Thickness(8, 12, 8, 12);
                SidebarLogo.Margin = new Thickness(0);
                NavButtonsPanel.Margin = new Thickness(0, 12, 0, 0);
            }
            else
            {
                // Expand sidebar (back to EPS 2026 design width)
                SidebarColumn.Width = new GridLength(248);
                SidebarColumn.MinWidth = 60;
                SidebarColumn.MaxWidth = 300;

                // Restore header padding and logo margin
                SidebarHeader.Padding = new Thickness(16, 16, 16, 16);
                SidebarLogo.Margin = new Thickness(0, 0, 0, 10);
                NavButtonsPanel.Margin = new Thickness(8, 16, 8, 0);
            }

            // Hide/show header text
            SidebarTitle.Visibility = collapsedVisibility;
            SidebarSubtitle.Visibility = collapsedVisibility;

            // Hide/show nav button text panels, adjust icon margins and button sizing
            CreateAppNavText.Visibility = collapsedVisibility;
            CreateAppNavIcon.Margin = iconMargin;
            CreateAppNavContent.HorizontalAlignment = contentAlignment;
            CreateAppNavButton.Padding = buttonPadding;
            CreateAppNavButton.Margin = buttonMargin;

            UploadNavText.Visibility = collapsedVisibility;
            UploadNavIcon.Margin = iconMargin;
            UploadNavContent.HorizontalAlignment = contentAlignment;
            UploadExistingNavButton.Padding = buttonPadding;
            UploadExistingNavButton.Margin = buttonMargin;

            ViewAppsNavText.Visibility = collapsedVisibility;
            ViewAppsNavIcon.Margin = iconMargin;
            ViewAppsNavContent.HorizontalAlignment = contentAlignment;
            ViewAppsNavButton.Padding = buttonPadding;
            ViewAppsNavButton.Margin = buttonMargin;

            RemoteTestNavText.Visibility = collapsedVisibility;
            RemoteTestNavIcon.Margin = iconMargin;
            RemoteTestNavContent.HorizontalAlignment = contentAlignment;
            RemoteTestNavButton.Padding = buttonPadding;
            RemoteTestNavButton.Margin = buttonMargin;

            LogsNavText.Visibility = collapsedVisibility;
            LogsNavIcon.Margin = iconMargin;
            LogsNavContent.HorizontalAlignment = contentAlignment;
            LogsNavButton.Padding = buttonPadding;
            LogsNavButton.Margin = buttonMargin;

            WDACNavText.Visibility = collapsedVisibility;
            WDACNavIcon.Margin = iconMargin;
            WDACNavContent.HorizontalAlignment = contentAlignment;
            WDACToolsNavButton.Padding = buttonPadding;
            WDACToolsNavButton.Margin = buttonMargin;

            AdvancedNavText.Visibility = collapsedVisibility;
            AdvancedNavIcon.Margin = iconMargin;
            AdvancedNavContent.HorizontalAlignment = contentAlignment;
            AdvancedNavButton.Padding = buttonPadding;
            AdvancedNavButton.Margin = buttonMargin;

            // Hide/show user info text
            UserNamePanel.Visibility = collapsedVisibility;
            UserInfoPanel.HorizontalAlignment = contentAlignment;
            UserInfoPanel.Margin = _isSidebarCollapsed ? new Thickness(0, 0, 0, 8) : new Thickness(8, 0, 0, 12);
            UserInitialsBorder.Margin = _isSidebarCollapsed ? new Thickness(0) : new Thickness(0, 0, 12, 0);

            // Adjust footer padding for collapsed mode
            SidebarFooter.Padding = _isSidebarCollapsed ? new Thickness(8) : new Thickness(12);
            SidebarFooter.Margin = _isSidebarCollapsed ? new Thickness(0, 12, 0, 0) : new Thickness(0, 20, 0, 0);

            // Update toggle button via template
            if (SidebarToggleButton.Template.FindName("CollapseText", SidebarToggleButton) is TextBlock collapseText)
            {
                collapseText.Visibility = collapsedVisibility;
            }
            if (SidebarToggleButton.Template.FindName("CollapseIcon", SidebarToggleButton) is TextBlock collapseIcon)
            {
                collapseIcon.Text = _isSidebarCollapsed ? "\uE76C" : "\uE76B";
            }
            SidebarToggleButton.HorizontalAlignment = contentAlignment;

            // Theme toggle is now always compact (icons built into toggle)
        }
    }
}
