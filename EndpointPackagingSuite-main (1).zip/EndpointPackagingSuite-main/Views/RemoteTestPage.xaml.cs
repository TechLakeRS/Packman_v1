using System.Windows.Controls;

namespace Endpoint_Packaging_Suite.Views
{
    public partial class RemoteTestPage : UserControl
    {
        public RemoteTestPage()
        {
            InitializeComponent();

            // Initialize in standalone mode (with browse button and internal Deploy button)
            remoteTestContent.Initialize("", isDialogMode: false);
        }
    }
}