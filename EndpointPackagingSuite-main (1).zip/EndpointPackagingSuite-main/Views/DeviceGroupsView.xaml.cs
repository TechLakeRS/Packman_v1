using Endpoint_Packaging_Suite.Dialogs;
using Endpoint_Packaging_Suite.Services;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Endpoint_Packaging_Suite.Views
{
    public partial class DeviceGroupsView : UserControl
    {
        private readonly ObservableCollection<DeviceGroupInfo> _groups = new ObservableCollection<DeviceGroupInfo>();

        public DeviceGroupsView()
        {
            InitializeComponent();
            GroupsList.ItemsSource = _groups;
        }

        private IntuneService? GetIntuneService()
        {
            var svc = App.Services.GetService<IntuneService>();
            if (svc == null)
            {
                ModernMessageBox.Show("Intune service is not initialized.",
                    "Device Groups", MessageBoxButton.OK, MessageBoxIcon.Error);
            }
            return svc;
        }

        private async void LookupButton_Click(object sender, RoutedEventArgs e) => await LookupAsync();

        private async void DeviceNameInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter) await LookupAsync();
        }

        private async Task LookupAsync()
        {
            var name = DeviceNameInput.Text.Trim();
            if (string.IsNullOrWhiteSpace(name))
            {
                StatusText.Text = "Enter a computer name.";
                return;
            }

            var svc = GetIntuneService();
            if (svc == null) return;

            LookupButton.IsEnabled = false;
            StatusText.Text = $"Looking up '{name}'...";
            ShowState(ResultsState.Loading);

            try
            {
                var device = await svc.FindDeviceByNameAsync(name);
                if (device == null)
                {
                    _groups.Clear();
                    StatusText.Text = $"Device '{name}' was not found in Intune.";
                    ShowState(ResultsState.Placeholder);
                    return;
                }

                var groups = await svc.GetDeviceGroupsAsync(device.Id);
                _groups.Clear();
                foreach (var g in groups) _groups.Add(g);

                StatusText.Text = $"{device.DeviceName} — member of {_groups.Count} group(s)";
                ShowState(_groups.Count == 0 ? ResultsState.Empty : ResultsState.List);
            }
            catch (Exception ex)
            {
                StatusText.Text = "Lookup failed.";
                ShowState(ResultsState.Placeholder);
                ModernMessageBox.Show($"Failed to look up groups:\n\n{ex.Message}",
                    "Device Groups", MessageBoxButton.OK, MessageBoxIcon.Error);
            }
            finally
            {
                LookupButton.IsEnabled = true;
            }
        }

        private enum ResultsState { Placeholder, Loading, Empty, List }

        private void ShowState(ResultsState state)
        {
            PlaceholderPanel.Visibility = state == ResultsState.Placeholder ? Visibility.Visible : Visibility.Collapsed;
            LoadingPanel.Visibility = state == ResultsState.Loading ? Visibility.Visible : Visibility.Collapsed;
            EmptyPanel.Visibility = state == ResultsState.Empty ? Visibility.Visible : Visibility.Collapsed;
            GroupsScroll.Visibility = state == ResultsState.List ? Visibility.Visible : Visibility.Collapsed;
        }
    }
}
