using Endpoint_Packaging_Suite.Dialogs;
using Endpoint_Packaging_Suite.Helpers;
using Endpoint_Packaging_Suite.Services;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Endpoint_Packaging_Suite.Views
{
    public partial class AdvancedView : UserControl
    {
        private static readonly HttpClient _graphHttpClient = new HttpClient { Timeout = TimeSpan.FromMinutes(2) };
        private string? _lastResponseBody;

        public AdvancedView()
        {
            InitializeComponent();
        }

        private void PurgeGroupButton_Click(object sender, RoutedEventArgs e)
        {
            var intuneService = App.Services.GetService<IntuneService>();
            if (intuneService == null)
            {
                ModernMessageBox.Show("Intune service is not initialized.",
                    "Purge Group", MessageBoxButton.OK, MessageBoxIcon.Error);
                return;
            }

            var dialog = new PurgeGroupDialog(
                intuneService,
                IntuneService.AllPackagersGroupId,
                IntuneService.AllPackagersGroupName)
            {
                Owner = Window.GetWindow(this)
            };
            dialog.ShowDialog();
        }

        private async void BuildFolderIndexButton_Click(object sender, RoutedEventArgs e)
        {
            var intuneService = App.Services.GetService<IntuneService>();
            if (intuneService == null)
            {
                ModernMessageBox.Show("Intune service is not initialized.",
                    "Build Folder Index", MessageBoxButton.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                BuildFolderIndexButton.IsEnabled = false;
                BuildFolderIndexProgressBar.Visibility = Visibility.Visible;
                BuildFolderIndexProgressBar.IsIndeterminate = true;
                BuildFolderIndexStatusText.Text = "Loading applications from Intune...";

                var apps = await intuneService.GetApplicationsAsync(forceRefresh: false);
                if (apps.Count == 0)
                {
                    BuildFolderIndexStatusText.Text = "No applications found.";
                    ModernMessageBox.Show("No applications were returned from Intune.",
                        "Build Folder Index", MessageBoxButton.OK, MessageBoxIcon.Information);
                    return;
                }

                var confirm = ModernMessageBox.Show(
                    $"This scans the network share and writes an app-id marker for each of " +
                    $"the {apps.Count} application(s), so package folders can be found directly " +
                    $"by Intune app id.\n\nIt is safe to re-run and may take a few minutes. Continue?",
                    "Build Folder Index", MessageBoxButton.YesNo, MessageBoxIcon.Question);
                if (confirm != MessageBoxResult.Yes)
                {
                    BuildFolderIndexStatusText.Text = "Cancelled.";
                    return;
                }

                var seedApps = apps
                    .Select(a => (a.Id, a.DisplayName, (string?)a.Version))
                    .ToList();

                BuildFolderIndexProgressBar.IsIndeterminate = false;
                var progress = new Progress<(int current, int total)>(p =>
                {
                    BuildFolderIndexProgressBar.Maximum = p.total;
                    BuildFolderIndexProgressBar.Value = p.current;
                    BuildFolderIndexStatusText.Text = $"Building folder index... {p.current}/{p.total}";
                });

                var result = await Task.Run(() => NetworkShareHelper.SeedMarkers(seedApps, progress));

                BuildFolderIndexStatusText.Text =
                    $"Folder index built - {result.Marked} marked, {result.NotLocated} not located";

                var summary = "Folder index updated.\n\n" +
                              $"Newly marked: {result.Marked}\n" +
                              $"Already indexed: {result.AlreadyIndexed}\n" +
                              $"Could not be located: {result.NotLocated}";

                if (result.UnlocatedApps.Count > 0)
                {
                    var choice = ModernMessageBox.Show(
                        summary +
                        $"\n\n{result.UnlocatedApps.Count} application(s) could not be auto-located. " +
                        "Would you like to assign their package folders now?",
                        "Build Folder Index", MessageBoxButton.YesNo, MessageBoxIcon.Question);

                    if (choice == MessageBoxResult.Yes)
                    {
                        var resolveDialog = new ResolveUnlocatedAppsDialog(result.UnlocatedApps)
                        {
                            Owner = Window.GetWindow(this)
                        };
                        resolveDialog.ShowDialog();

                        if (resolveDialog.ResolvedCount > 0)
                            BuildFolderIndexStatusText.Text =
                                $"Assigned package folders for {resolveDialog.ResolvedCount} application(s)";
                    }
                }
                else
                {
                    ModernMessageBox.Show(summary, "Build Folder Index",
                        MessageBoxButton.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                BuildFolderIndexStatusText.Text = "Error building folder index";
                ModernMessageBox.Show($"Error building folder index:\n\n{ex.Message}",
                    "Build Folder Index", MessageBoxButton.OK, MessageBoxIcon.Error);
            }
            finally
            {
                BuildFolderIndexButton.IsEnabled = true;
                BuildFolderIndexProgressBar.Visibility = Visibility.Collapsed;
                BuildFolderIndexProgressBar.IsIndeterminate = false;
            }
        }

        private void GraphUrlTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                e.Handled = true;
                SendGraphRequestButton_Click(sender, e);
            }
        }

        private async void SendGraphRequestButton_Click(object sender, RoutedEventArgs e)
        {
            var url = (GraphUrlTextBox.Text ?? "").Trim();

            if (string.IsNullOrWhiteSpace(url))
            {
                ShowGraphError("Enter a Graph API URL.");
                return;
            }

            if (!Uri.TryCreate(url, UriKind.Absolute, out var parsedUri) ||
                !parsedUri.Host.Equals("graph.microsoft.com", StringComparison.OrdinalIgnoreCase) ||
                (parsedUri.Scheme != Uri.UriSchemeHttps))
            {
                ShowGraphError("URL must be an https://graph.microsoft.com/... endpoint.");
                return;
            }

            var intuneService = App.Services.GetService<IntuneService>();
            if (intuneService == null)
            {
                ShowGraphError("Intune service is not initialized. Cannot acquire an access token.");
                return;
            }

            SendGraphRequestButton.IsEnabled = false;
            GraphResponseTextBox.Text = "Sending request...";
            GraphResponseStatusBar.Visibility = Visibility.Collapsed;

            var stopwatch = Stopwatch.StartNew();
            try
            {
                var token = await intuneService.GetAccessTokenAsync();

                using var request = new HttpRequestMessage(HttpMethod.Get, parsedUri);
                request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
                request.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                using var response = await _graphHttpClient.SendAsync(request);
                var body = await response.Content.ReadAsStringAsync();
                stopwatch.Stop();

                _lastResponseBody = body;
                var formatted = TryPrettyPrintJson(body);

                GraphResponseTextBox.Text = string.IsNullOrEmpty(formatted) ? "(empty response)" : formatted;
                ShowGraphStatus((int)response.StatusCode, response.ReasonPhrase ?? "", stopwatch.ElapsedMilliseconds, body.Length);
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                ShowGraphError($"Request failed: {ex.Message}");
            }
            finally
            {
                SendGraphRequestButton.IsEnabled = true;
            }
        }

        private void CopyResponseButton_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(_lastResponseBody))
            {
                try { Clipboard.SetText(_lastResponseBody); } catch { }
            }
        }

        private void ShowGraphError(string message)
        {
            _lastResponseBody = null;
            GraphResponseTextBox.Text = message;
            GraphResponseStatusBar.Visibility = Visibility.Collapsed;
        }

        private void ShowGraphStatus(int statusCode, string reason, long elapsedMs, int bytes)
        {
            GraphStatusCodeText.Text = $"{statusCode} {reason}".TrimEnd();
            GraphStatusCodeText.Foreground = statusCode switch
            {
                >= 200 and < 300 => new SolidColorBrush(Color.FromRgb(0x3F, 0xB9, 0x50)),
                >= 300 and < 400 => new SolidColorBrush(Color.FromRgb(0xD2, 0x9E, 0x2C)),
                _ => new SolidColorBrush(Color.FromRgb(0xF8, 0x51, 0x49)),
            };
            GraphElapsedText.Text = $"{elapsedMs} ms";
            GraphSizeText.Text = FormatBytes(bytes);
            GraphResponseStatusBar.Visibility = Visibility.Visible;
        }

        private static string FormatBytes(int bytes)
        {
            if (bytes < 1024) return $"{bytes} B";
            if (bytes < 1024 * 1024) return $"{bytes / 1024.0:0.#} KB";
            return $"{bytes / (1024.0 * 1024.0):0.##} MB";
        }

        private static string TryPrettyPrintJson(string raw)
        {
            if (string.IsNullOrWhiteSpace(raw)) return raw;
            try
            {
                using var doc = JsonDocument.Parse(raw);
                return JsonSerializer.Serialize(doc.RootElement, new JsonSerializerOptions { WriteIndented = true });
            }
            catch
            {
                return raw;
            }
        }
    }
}
