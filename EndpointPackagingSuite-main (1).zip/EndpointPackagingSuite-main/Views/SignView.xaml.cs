using Endpoint_Packaging_Suite.Dialogs;
using Endpoint_Packaging_Suite.Helpers;
using Endpoint_Packaging_Suite.Services;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace Endpoint_Packaging_Suite.Views
{
    public partial class SignView : UserControl
    {
        private readonly ObservableCollection<SignFileEntry> _files = new();
        private CancellationTokenSource? _cts;
        private bool _isSigning;

        public SignView()
        {
            InitializeComponent();
            FilesGrid.ItemsSource = _files;
            _files.CollectionChanged += (_, _) => UpdateSignButtonEnabled();

            // Defer cert availability check so the DI container is ready.
            Loaded += (_, _) => UpdateCertStatus();
        }

        private void UpdateCertStatus()
        {
            try
            {
                var signer = App.Services.GetService<NativeCodeSigner>();
                if (signer is null)
                {
                    CertStatusText.Text = "Signer service not registered";
                    return;
                }

                if (signer.IsCertificateAvailable())
                {
                    CertStatusText.Text = "Certificate ready";
                }
                else
                {
                    CertStatusText.Text = "Certificate not loaded — check Key Vault";
                }
            }
            catch (Exception ex)
            {
                CertStatusText.Text = $"Cert check failed: {ex.Message}";
            }
        }

        // -----------------------------------------------------------------
        // Add files / folder
        // -----------------------------------------------------------------
        private void AddFileButton_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Title = "Select a file to sign",
                Filter = "All files (*.*)|*.*",
                Multiselect = false
            };
            if (dialog.ShowDialog() == true)
                AddFiles(new[] { dialog.FileName });
        }

        private void AddFilesButton_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Title = "Select files to sign",
                Filter = "All files (*.*)|*.*",
                Multiselect = true
            };
            if (dialog.ShowDialog() == true)
                AddFiles(dialog.FileNames);
        }

        private void AddFolderButton_Click(object sender, RoutedEventArgs e)
        {
            var folder = FolderBrowserHelper.ShowFolderBrowser("Select folder containing files to sign");
            if (string.IsNullOrEmpty(folder)) return;

            try
            {
                var opt = RecursiveCheckBox.IsChecked == true
                    ? SearchOption.AllDirectories
                    : SearchOption.TopDirectoryOnly;

                // Always filter by signable extensions — anything else would just queue
                // thousands of guaranteed-failures from .txt/.json/.png files.
                var files = Directory.EnumerateFiles(folder, "*.*", opt)
                    .Where(f => NativeCodeSigner.DefaultSignableExtensions.Contains(Path.GetExtension(f)))
                    .OrderBy(f => f, StringComparer.OrdinalIgnoreCase)
                    .ToList();

                AddFiles(files);
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show(
                    $"Failed to enumerate folder: {ex.Message}",
                    "Add Folder",
                    MessageBoxButton.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void AddFiles(IEnumerable<string> paths)
        {
            int added = 0, skipped = 0;
            var existing = new HashSet<string>(_files.Select(f => f.FullPath), StringComparer.OrdinalIgnoreCase);

            foreach (var p in paths)
            {
                if (string.IsNullOrWhiteSpace(p) || !File.Exists(p))
                {
                    skipped++;
                    continue;
                }
                if (!existing.Add(p))
                {
                    skipped++;
                    continue;
                }
                _files.Add(new SignFileEntry(p));
                added++;
            }

            StatusText.Text = $"Added {added} file(s){(skipped > 0 ? $", skipped {skipped} duplicate/missing" : "")}.";
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            if (_isSigning) return;
            _files.Clear();
            SignProgressBar.Value = 0;
            ProgressText.Text = "Idle";
            StatusText.Text = "Cleared.";
        }

        private void UpdateSignButtonEnabled()
        {
            SignButton.IsEnabled = !_isSigning && _files.Count > 0;
        }

        // -----------------------------------------------------------------
        // Sign
        // -----------------------------------------------------------------
        private async void SignButton_Click(object sender, RoutedEventArgs e)
        {
            if (_isSigning || _files.Count == 0) return;

            var signer = App.Services.GetService<NativeCodeSigner>();
            if (signer is null)
            {
                ModernMessageBox.Show(
                    "NativeCodeSigner is not registered in the DI container.",
                    "Sign", MessageBoxButton.OK, MessageBoxIcon.Error);
                return;
            }

            if (!signer.IsCertificateAvailable())
            {
                ModernMessageBox.Show(
                    "No code-signing certificate is loaded. Ensure the Key Vault certificate was loaded at startup.",
                    "Sign", MessageBoxButton.OK, MessageBoxIcon.Warning);
                return;
            }

            _isSigning = true;
            UpdateSignButtonEnabled();
            AddFileButton.IsEnabled = false;
            AddFilesButton.IsEnabled = false;
            AddFolderButton.IsEnabled = false;
            ClearButton.IsEnabled = false;

            // Reset entries
            foreach (var entry in _files)
            {
                entry.Status = "Pending";
                entry.Detail = "";
            }

            _cts = new CancellationTokenSource();
            SignProgressBar.Value = 0;
            ProgressText.Text = $"0 / {_files.Count}";
            StatusText.Text = "Signing...";

            var indexByPath = _files
                .Select((f, i) => (f.FullPath, i))
                .ToDictionary(t => t.FullPath, t => t.i, StringComparer.OrdinalIgnoreCase);

            var progress = new Progress<BatchSigningProgress>(p =>
            {
                SignProgressBar.Value = p.TotalFiles == 0
                    ? 0
                    : (double)p.CurrentIndex / p.TotalFiles * 100.0;
                ProgressText.Text = $"{p.CurrentIndex} / {p.TotalFiles}";

                if (p.LastResult is not null
                    && indexByPath.TryGetValue(p.LastResult.FilePath, out var idx)
                    && idx >= 0 && idx < _files.Count)
                {
                    var entry = _files[idx];
                    entry.Status = p.LastResult.Success ? "Signed" : "Failed";
                    entry.Detail = p.LastResult.Success
                        ? "SHA-256 + RFC 3161"
                        : p.LastResult.ErrorMessage;
                    // Force a refresh of the row binding
                    FilesGrid.Items.Refresh();
                }
            });

            BatchSigningResult? result = null;
            try
            {
                result = await signer.SignFilesAsync(
                    _files.Select(f => f.FullPath).ToList(),
                    progress,
                    _cts.Token);
            }
            catch (OperationCanceledException)
            {
                StatusText.Text = "Cancelled.";
            }
            catch (Exception ex)
            {
                StatusText.Text = $"Signing error: {ex.Message}";
            }
            finally
            {
                _isSigning = false;
                _cts?.Dispose();
                _cts = null;
                AddFileButton.IsEnabled = true;
                AddFilesButton.IsEnabled = true;
                AddFolderButton.IsEnabled = true;
                ClearButton.IsEnabled = true;
                UpdateSignButtonEnabled();
            }

            if (result is not null)
            {
                StatusText.Text =
                    $"Done. {result.SuccessCount} signed, {result.FailureCount} failed of {result.TotalFiles}.";
                SignProgressBar.Value = 100;
            }
        }
    }

    /// <summary>
    /// Row model for the files grid.
    /// </summary>
    public class SignFileEntry : System.ComponentModel.INotifyPropertyChanged
    {
        public SignFileEntry(string fullPath)
        {
            FullPath = fullPath;
            FileName = Path.GetFileName(fullPath);
            Folder = Path.GetDirectoryName(fullPath) ?? "";
            Extension = Path.GetExtension(fullPath);
        }

        public string FullPath { get; }
        public string FileName { get; }
        public string Folder { get; }
        public string Extension { get; }

        private string _status = "Pending";
        public string Status
        {
            get => _status;
            set { _status = value; OnPropertyChanged(nameof(Status)); }
        }

        private string _detail = "";
        public string Detail
        {
            get => _detail;
            set { _detail = value; OnPropertyChanged(nameof(Detail)); }
        }

        public event System.ComponentModel.PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged(string name)
            => PropertyChanged?.Invoke(this, new System.ComponentModel.PropertyChangedEventArgs(name));
    }
}
