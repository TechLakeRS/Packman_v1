using Endpoint_Packaging_Suite.Dialogs;
using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite.Services;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;

namespace Endpoint_Packaging_Suite.Views
{
    public partial class GroupsView : UserControl
    {
        private readonly ObservableCollection<GroupDevice> _members = new ObservableCollection<GroupDevice>();
        private readonly ICollectionView _membersView;
        private readonly ObservableCollection<DeviceAddResult> _results = new ObservableCollection<DeviceAddResult>();

        private string? _groupId;
        private string? _groupName;

        public GroupsView()
        {
            InitializeComponent();

            _membersView = CollectionViewSource.GetDefaultView(_members);
            MembersDataGrid.ItemsSource = _membersView;
            ResultsList.ItemsSource = _results;

            MembersDataGrid.SelectionChanged += MembersDataGrid_SelectionChanged;
        }

        private IntuneService? GetIntuneService()
        {
            var svc = App.Services.GetService<IntuneService>();
            if (svc == null)
            {
                ModernMessageBox.Show("Intune service is not initialized.",
                    "Groups", MessageBoxButton.OK, MessageBoxIcon.Error);
            }
            return svc;
        }

        #region Load group

        private async void LoadGroupButton_Click(object sender, RoutedEventArgs e) => await LoadGroupAsync();

        private async void GroupNameInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter) await LoadGroupAsync();
        }

        private async void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(_groupId)) await LoadMembersAsync();
        }

        private async Task LoadGroupAsync()
        {
            var name = GroupNameInput.Text.Trim();
            if (string.IsNullOrWhiteSpace(name))
            {
                ModernMessageBox.Show("Enter a group name.",
                    "Groups", MessageBoxButton.OK, MessageBoxIcon.Warning);
                return;
            }

            var svc = GetIntuneService();
            if (svc == null) return;

            LoadGroupButton.IsEnabled = false;
            GroupStatusText.Text = $"Looking up '{name}'...";

            try
            {
                var group = await svc.FindGroupByNameAsync(name);
                if (group == null)
                {
                    GroupStatusText.Text = $"No group named '{name}' was found.";
                    return;
                }

                _groupId = group.Value.Id;
                _groupName = group.Value.DisplayName;
                GroupNameInput.Text = _groupName;

                SetGroupLoaded(true);
                await LoadMembersAsync();
            }
            catch (Exception ex)
            {
                GroupStatusText.Text = "Failed to load group.";
                ModernMessageBox.Show($"Failed to load group:\n\n{ex.Message}",
                    "Groups", MessageBoxButton.OK, MessageBoxIcon.Error);
            }
            finally
            {
                LoadGroupButton.IsEnabled = true;
            }
        }

        private async Task LoadMembersAsync()
        {
            var svc = GetIntuneService();
            if (svc == null || string.IsNullOrEmpty(_groupId)) return;

            ShowMembersState(MembersState.Loading);

            try
            {
                var members = await svc.GetGroupMembersAsync(_groupId);
                _members.Clear();
                foreach (var m in members) _members.Add(m);

                UpdateGroupStatus();
                ShowMembersState(_members.Count == 0 ? MembersState.Empty : MembersState.List);
            }
            catch (Exception ex)
            {
                ShowMembersState(MembersState.Empty);
                ModernMessageBox.Show($"Failed to load members:\n\n{ex.Message}",
                    "Groups", MessageBoxButton.OK, MessageBoxIcon.Error);
            }
        }

        #endregion

        #region Add devices

        private async void AddDeviceInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter) await AddSingleAsync();
        }

        private async void SingleAddButton_Click(object sender, RoutedEventArgs e) => await AddSingleAsync();

        private async Task AddSingleAsync()
        {
            var name = AddDeviceInput.Text.Trim();
            if (string.IsNullOrWhiteSpace(name))
            {
                AddStatusText.Text = "Enter a computer name.";
                return;
            }

            var svc = GetIntuneService();
            if (svc == null || string.IsNullOrEmpty(_groupId)) return;

            SetBusy(true);
            try
            {
                await ProcessAddAsync(svc, name);
                AddDeviceInput.Clear();
                AddDeviceInput.Focus();
                await LoadMembersAsync();
            }
            finally
            {
                SetBusy(false);
            }
        }

        private void BulkNamesInput_TextChanged(object sender, TextChangedEventArgs e)
        {
            BulkCountText.Text = ParseBulkNames().Count.ToString();
        }

        private List<string> ParseBulkNames()
        {
            return BulkNamesInput.Text
                .Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(n => n.Trim())
                .Where(n => n.Length > 0)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();
        }

        private void LoadFromFileButton_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Title = "Select a text file with computer names",
                Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*",
                Multiselect = false
            };
            if (dialog.ShowDialog() != true) return;

            try
            {
                BulkNamesInput.Text = string.Join(Environment.NewLine, File.ReadAllLines(dialog.FileName));
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Could not read file:\n\n{ex.Message}",
                    "Groups", MessageBoxButton.OK, MessageBoxIcon.Error);
            }
        }

        private async void BulkAddButton_Click(object sender, RoutedEventArgs e)
        {
            var names = ParseBulkNames();
            if (names.Count == 0)
            {
                AddStatusText.Text = "Enter at least one computer name, or load a .txt file.";
                return;
            }

            var svc = GetIntuneService();
            if (svc == null || string.IsNullOrEmpty(_groupId)) return;

            var confirm = ModernMessageBox.Show(
                $"Add {names.Count} computer(s) to '{_groupName}'?",
                "Bulk Add", MessageBoxButton.YesNo, MessageBoxIcon.Question);
            if (confirm != MessageBoxResult.Yes) return;

            SetBusy(true);
            AddProgressBar.Maximum = names.Count;
            AddProgressBar.Value = 0;
            AddProgressBar.Visibility = Visibility.Visible;

            int added = 0, already = 0, notFound = 0, failed = 0;

            try
            {
                for (int i = 0; i < names.Count; i++)
                {
                    AddStatusText.Text = $"Processing {i + 1} of {names.Count}: {names[i]}";
                    switch (await ProcessAddAsync(svc, names[i]))
                    {
                        case AddStatus.Success: added++; break;
                        case AddStatus.AlreadyExists: already++; break;
                        case AddStatus.NotFound: notFound++; break;
                        default: failed++; break;
                    }
                    AddProgressBar.Value = i + 1;
                }

                AddStatusText.Text =
                    $"Done — {added} added, {already} already members, {notFound} not found, {failed} failed.";
                await LoadMembersAsync();
            }
            finally
            {
                AddProgressBar.Visibility = Visibility.Collapsed;
                SetBusy(false);
            }
        }

        private async Task<AddStatus> ProcessAddAsync(IntuneService svc, string name)
        {
            try
            {
                var device = await svc.FindDeviceByNameAsync(name);
                if (device == null)
                {
                    AddResult(name, AddStatus.NotFound, "Device not found in Intune");
                    return AddStatus.NotFound;
                }

                if (await svc.IsDeviceInGroupAsync(device.Id, _groupId!))
                {
                    AddResult(device.DeviceName, AddStatus.AlreadyExists, "Already in group");
                    return AddStatus.AlreadyExists;
                }

                await svc.AddDeviceToGroupAsync(device.Id, _groupId!);
                AddResult(device.DeviceName, AddStatus.Success, "Added to group");
                return AddStatus.Success;
            }
            catch (Exception ex)
            {
                AddResult(name, AddStatus.Error, $"Error: {ex.Message}");
                return AddStatus.Error;
            }
        }

        private void AddResult(string deviceName, AddStatus status, string message)
        {
            _results.Insert(0, new DeviceAddResult
            {
                DeviceName = deviceName,
                Status = status,
                Message = message,
                Timestamp = DateTime.Now
            });
            UpdateResultsVisibility();
        }

        private void ClearResults_Click(object sender, RoutedEventArgs e)
        {
            _results.Clear();
            AddStatusText.Text = "";
            UpdateResultsVisibility();
        }

        private void UpdateResultsVisibility()
        {
            var has = _results.Count > 0;
            ResultsHeader.Visibility = has ? Visibility.Visible : Visibility.Collapsed;
            ResultsScroll.Visibility = has ? Visibility.Visible : Visibility.Collapsed;
            ResultsEmptyState.Visibility = has ? Visibility.Collapsed : Visibility.Visible;
        }

        #endregion

        #region Remove

        private async void RemoveSelectedButton_Click(object sender, RoutedEventArgs e)
        {
            var svc = GetIntuneService();
            if (svc == null || string.IsNullOrEmpty(_groupId)) return;

            var selected = MembersDataGrid.SelectedItems.Cast<GroupDevice>().ToList();
            if (selected.Count == 0) return;

            var confirm = ModernMessageBox.Show(
                $"Remove {selected.Count} device(s) from '{_groupName}'?",
                "Confirm Removal", MessageBoxButton.YesNo, MessageBoxIcon.Warning);
            if (confirm != MessageBoxResult.Yes) return;

            try
            {
                RemoveSelectedButton.IsEnabled = false;
                await svc.RemoveDevicesFromGroupAsync(_groupId, selected.Select(d => d.Id).ToList());
                foreach (var d in selected) _members.Remove(d);
                UpdateGroupStatus();
                if (_members.Count == 0) ShowMembersState(MembersState.Empty);
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error removing devices:\n\n{ex.Message}",
                    "Groups", MessageBoxButton.OK, MessageBoxIcon.Error);
            }
        }

        private async void RemoveMember_Click(object sender, RoutedEventArgs e)
        {
            var svc = GetIntuneService();
            if (svc == null || string.IsNullOrEmpty(_groupId)) return;

            var device = (sender as Button)?.Tag as GroupDevice;
            if (device == null) return;

            var confirm = ModernMessageBox.Show(
                $"Remove '{device.DeviceName}' from '{_groupName}'?",
                "Confirm Removal", MessageBoxButton.YesNo, MessageBoxIcon.Question);
            if (confirm != MessageBoxResult.Yes) return;

            try
            {
                await svc.RemoveDeviceFromGroupAsync(_groupId, device.Id);
                _members.Remove(device);
                UpdateGroupStatus();
                if (_members.Count == 0) ShowMembersState(MembersState.Empty);
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error removing device:\n\n{ex.Message}",
                    "Groups", MessageBoxButton.OK, MessageBoxIcon.Error);
            }
        }

        #endregion

        #region Search & selection

        private void SearchMembersBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            var search = SearchMembersBox.Text?.Trim().ToLowerInvariant() ?? "";
            _membersView.Filter = obj =>
            {
                if (obj is not GroupDevice d) return false;
                return string.IsNullOrEmpty(search) ||
                       (d.DeviceName?.ToLowerInvariant().Contains(search) ?? false);
            };
        }

        private void MembersDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var count = MembersDataGrid.SelectedItems.Count;
            SelectionCountText.Text = count > 0 ? $"{count} selected" : "";
            RemoveSelectedButton.IsEnabled = count > 0;
        }

        #endregion

        #region State helpers

        private enum MembersState { Loading, Empty, List }

        private void SetGroupLoaded(bool loaded)
        {
            AddPanel.IsEnabled = loaded;
            RefreshButton.IsEnabled = loaded;
            SearchMembersBox.IsEnabled = loaded;
        }

        private void ShowMembersState(MembersState state)
        {
            PlaceholderPanel.Visibility = Visibility.Collapsed;
            LoadingPanel.Visibility = state == MembersState.Loading ? Visibility.Visible : Visibility.Collapsed;
            EmptyStatePanel.Visibility = state == MembersState.Empty ? Visibility.Visible : Visibility.Collapsed;
            MembersDataGrid.Visibility = state == MembersState.List ? Visibility.Visible : Visibility.Collapsed;
        }

        private void UpdateGroupStatus()
        {
            GroupStatusText.Text = $"{_groupName} — {_members.Count} member(s)";
        }

        private void SetBusy(bool busy)
        {
            SingleAddButton.IsEnabled = !busy;
            BulkAddButton.IsEnabled = !busy;
            LoadFromFileButton.IsEnabled = !busy;
            AddDeviceInput.IsEnabled = !busy;
            BulkNamesInput.IsEnabled = !busy;
            LoadGroupButton.IsEnabled = !busy;
            RefreshButton.IsEnabled = !busy;
        }

        #endregion
    }
}
