using Endpoint_Packaging_Suite.Constants;
using Endpoint_Packaging_Suite.Helpers;
using Endpoint_Packaging_Suite.Managers;
using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite.Services;
using Endpoint_Packaging_Suite.Dialogs;
using Endpoint_Packaging_Suite.ViewModels;
using Endpoint_Packaging_Suite.Views;
using Microsoft.Extensions.DependencyInjection;
using Serilog;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Endpoint_Packaging_Suite
{
    public partial class MainWindow
    {
        private void InitializeNotificationService()
        {
            // Resolve services from DI container
            _notificationService = App.Services.GetRequiredService<NotificationService>();

            // Initialize notification service with toast container
            _notificationService.Initialize(ToastContainer);

            // Handle notification clicks - open status panel
            _notificationService.NotificationClicked += (s, notificationId) =>
            {
                OpenStatusPanel();
            };

            // Update notification history list when new notifications arrive
            _notificationService.NotificationAdded += (s, item) =>
            {
                UpdateNotificationHistory();
            };

            // Update notification history list when notifications are updated (progress changes)
            _notificationService.NotificationUpdated += (s, item) =>
            {
                UpdateNotificationHistory();
            };

            // Update notification history list when notifications are removed
            _notificationService.NotificationRemoved += (s, notificationId) =>
            {
                UpdateNotificationHistory();
            };
        }

        private void InitializeTimer()
        {
            _searchTimer = new System.Windows.Threading.DispatcherTimer();
            _searchTimer.Interval = TimeSpan.FromMilliseconds(AppConstants.Defaults.SearchDebounceMilliseconds);
            _searchTimer.Tick += SearchTimer_Tick;
        }

        private void SetLoadingStep(int stepNumber, string state)
        {
            // state: "pending", "active", "done"
            var circle = (Border)FindName($"LoadingStep{stepNumber}Circle");
            var check = (TextBlock)FindName($"LoadingStep{stepNumber}Check");
            var text = (TextBlock)FindName($"LoadingStep{stepNumber}Text");

            if (circle == null || check == null || text == null) return;

            var primaryBrush = (Brush)FindResource("PrimaryBrush");
            var successBrush = (Brush)FindResource("SuccessBrush");
            var borderBrush = (Brush)FindResource("BorderBrush");
            var textPrimaryBrush = (Brush)FindResource("TextPrimaryBrush");
            var textMutedBrush = (Brush)FindResource("TextMutedBrush");

            switch (state)
            {
                case "done":
                    circle.Background = successBrush;
                    circle.BorderBrush = successBrush;
                    check.Visibility = Visibility.Visible;
                    text.Foreground = textMutedBrush;
                    break;
                case "active":
                    circle.Background = primaryBrush;
                    circle.BorderBrush = primaryBrush;
                    check.Visibility = Visibility.Collapsed;
                    text.Foreground = textPrimaryBrush;
                    break;
                default: // pending
                    circle.Background = Brushes.Transparent;
                    circle.BorderBrush = borderBrush;
                    check.Visibility = Visibility.Collapsed;
                    text.Foreground = textMutedBrush;
                    break;
            }
        }

        private async Task InitializeServicesAsync()
        {
            _initCancellation = new CancellationTokenSource();
            LoadingCancelButton.Click += (s, e) =>
            {
                _initCancellation?.Cancel();
                LoadingOverlay.Visibility = Visibility.Collapsed;
            };

            try
            {
                Debug.WriteLine("=== Starting Service Initialization ===");

                // Show loading overlay
                LoadingOverlay.Visibility = Visibility.Visible;

                // Step 1: Loading configuration
                SetLoadingStep(1, "active");
                SetLoadingStep(2, "pending");
                SetLoadingStep(3, "pending");
                SetLoadingStep(4, "pending");
                LoadingTitle.Text = "Connecting to Azure Key Vault";
                LoadingStatusText.Text = "Loading application configuration...";
                Debug.WriteLine("Loading configuration from appsettings.json...");

                _settingsService = App.Services.GetRequiredService<SettingsService>();
                _initCancellation.Token.ThrowIfCancellationRequested();

                // Step 1 done, Step 2 active
                SetLoadingStep(1, "done");
                SetLoadingStep(2, "active");
                LoadingStatusText.Text = "A browser window will open for authentication.\nPlease sign in with your enterprise account.";
                Debug.WriteLine("Attempting to load settings from Key Vault...");

                await _settingsService.LoadSettingsWithKeyVaultAsync();
                _initCancellation.Token.ThrowIfCancellationRequested();

                Debug.WriteLine("Key Vault authentication completed successfully");

                var settings = _settingsService.Settings;
                Debug.WriteLine($"Authentication Settings Loaded:");
                Debug.WriteLine($"   TenantId: {settings.Authentication.TenantId}");
                Debug.WriteLine($"   ClientId: {settings.Authentication.ClientId}");
                Debug.WriteLine($"   CertificateName: {settings.Authentication.CertificateName}");

                // Step 2 done, Step 3 active
                SetLoadingStep(2, "done");
                SetLoadingStep(3, "active");
                LoadingStatusText.Text = "Loading certificates from Key Vault...";
                Debug.WriteLine("Loading certificates from Key Vault...");

                var keyVaultService = App.Services.GetRequiredService<KeyVaultService>();

                var codeSigningCertName = "CodeSigningCert";
                await keyVaultService.LoadCertificateAsync(codeSigningCertName);
                Log.Information("Code-signing certificate '{CertificateName}' loaded and kept in memory for session", codeSigningCertName);
                _initCancellation.Token.ThrowIfCancellationRequested();

                var appRegCertName = _settingsService.Settings.Authentication?.CertificateName;
                if (string.IsNullOrWhiteSpace(appRegCertName))
                    throw new Exception("Authentication.CertificateName is not configured in appsettings.json.");

                await keyVaultService.LoadAppRegistrationCertificateAsync(appRegCertName);
                Log.Information("App-registration certificate '{CertificateName}' loaded and kept in memory for session", appRegCertName);
                _initCancellation.Token.ThrowIfCancellationRequested();

                // Step 3 done, Step 4 active
                SetLoadingStep(3, "done");
                SetLoadingStep(4, "active");
                LoadingStatusText.Text = "Initializing Intune service and managers...";
                Debug.WriteLine("Initializing Intune service...");

                _intuneService = App.Services.GetRequiredService<IntuneService>();
                Debug.WriteLine("Intune service initialized successfully");

                _psadtGenerator = new PSADTGenerator();

                if (_intuneService != null)
                {
                    _uploadService = App.Services.GetRequiredService<IntuneUploadService>();
                }

                InitializeManagers();

                // Step 4 done - all complete
                SetLoadingStep(4, "done");
                LoadingTitle.Text = "Ready";
                LoadingStatusText.Text = "All services initialized successfully.";

                // Brief pause to show completion
                await Task.Delay(400);
            }
            catch (OperationCanceledException)
            {
                Debug.WriteLine("Service initialization was cancelled by user.");
                _intuneService = null;

                // Still initialize basic components
                _psadtGenerator = new PSADTGenerator();
                InitializeManagers();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Service initialization failed: {ex.Message}");
                Debug.WriteLine($"   Exception type: {ex.GetType().Name}");
                Debug.WriteLine($"   Stack trace: {ex.StackTrace}");
                if (ex.InnerException != null)
                {
                    Debug.WriteLine($"   Inner exception: {ex.InnerException.Message}");
                }

                LoadingOverlay.Visibility = Visibility.Collapsed;

                var errorMessage = $"Failed to initialize services:\n\n{ex.Message}";
                if (ex.InnerException != null)
                {
                    errorMessage += $"\n\nDetails: {ex.InnerException.Message}";
                }

                ModernMessageBox.Show(errorMessage, "Initialization Error", MessageBoxButton.OK, MessageBoxIcon.Error);
                _intuneService = null;

                _psadtGenerator = new PSADTGenerator();
                InitializeManagers();

                Debug.WriteLine("Error displayed to user, continuing with initialization...");
            }

            // Show initial page
            _navigationManager?.ShowPage(NavigationManager.PageNameCreateApplication);
            _navigationManager?.SetActiveNavButton(CreateAppNavButton);

            // Hide loading overlay
            LoadingOverlay.Visibility = Visibility.Collapsed;
        }

        private void InitializeUI()
        {
            // Set up UI (managers will be initialized after services load)

            ApplicationDetailView.BackToListRequested += ApplicationDetailView_BackToListRequested;

            this.DataContext = this;



            // Set current user

            SetCurrentUser();
        }

        private void InitializeManagers()
        {
            // Initialize NavigationManager
            _navigationManager = new NavigationManager(
                CreateApplicationPage,
                UploadExistingPage,
                ViewApplicationsPage,
                null, // SettingsPage removed
                PaginationPanel,
                MainContentGrid,
                PageTitle,
                PageSubtitle,
                SearchTextBox,
                PageHeader,
                ApplicationsListPanel,
                ApplicationDetailView,
                CreateAppNavButton,
                UploadExistingNavButton,
                ViewAppsNavButton,
                null, // SettingsNavButton removed
                LogsNavButton,
                WDACToolsNavButton,
                RemoteTestNavButton,
                CreateAppNavIconText,
                UploadNavIconText,
                ViewAppsNavIconText,
                RemoteTestNavIconText,
                LogsNavIconText,
                WDACNavIconText,
                SignNavButton,
                SignNavIconText,
                AdvancedNavButton,
                AdvancedNavIconText
            );

            // Initialize ApplicationListViewModel (DataContext for the Apps list panel + pagination)
            _applicationListViewModel = App.Services.GetRequiredService<ApplicationListViewModel>();
            ApplicationsListPanel.DataContext = _applicationListViewModel;
            PaginationPanel.DataContext = _applicationListViewModel;

            // Mirror VM status props onto window-scoped UI (shared status bar)
            _applicationListViewModel.PropertyChanged += OnApplicationListVmPropertyChanged;

            CategoryFilter.SelectionChanged -= CategoryFilter_SelectionChanged;
            PopulateCategoryDropdown();
            CategoryFilter.SelectionChanged += CategoryFilter_SelectionChanged;

            // Initialize UpgradePackageViewModel (DataContext for the Upgrade Mode form).
            // Set this BEFORE CreateApplicationPage.DataContext so the nested UpgradeModeForm
            // doesn't briefly inherit the wrong VM and emit binding errors.
            _upgradePackageViewModel = App.Services.GetRequiredService<UpgradePackageViewModel>();
            UpgradeModeForm.DataContext = _upgradePackageViewModel;

            // Initialize CreatePackageViewModel (DataContext for the Create Application page)
            _createPackageViewModel = App.Services.GetRequiredService<CreatePackageViewModel>();
            CreateApplicationPage.DataContext = _createPackageViewModel;

            // Keep the Install Context segmented control in sync with the view model
            // (UserInstallToggle binds via XAML; SystemInstallToggle is its mirror.)
            SyncInstallContextToggles();
            _createPackageViewModel.PropertyChanged += (_, args) =>
            {
                if (args.PropertyName == nameof(CreatePackageViewModel.UserInstall))
                    SyncInstallContextToggles();
            };

            // Initialize UploadPackageViewModel (DataContext for the Upload Existing page)
            _uploadPackageViewModel = App.Services.GetRequiredService<UploadPackageViewModel>();
            UploadExistingPage.DataContext = _uploadPackageViewModel;
        }

        private void SetCurrentUser()
        {
            try
            {
                string userName = Environment.UserName;
                string domainUser = Environment.UserDomainName + "\\" + userName;

                // Set display name
                UserNameDisplay.Text = userName;

                // Set initials (first 2 letters of username)
                if (!string.IsNullOrEmpty(userName))
                {
                    UserInitials.Text = userName.Length >= 2 ? userName.Substring(0, 2).ToUpper() : userName.ToUpper();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error setting current user: {ex.Message}");
                UserNameDisplay.Text = "User";
                UserInitials.Text = "U";
            }
        }

        protected override void OnClosed(EventArgs e)
        {
            // Unsubscribe from event handlers to prevent memory leaks
            if (ApplicationDetailView != null)
            {
                ApplicationDetailView.BackToListRequested -= ApplicationDetailView_BackToListRequested;
            }

            // Cancel any pending operations on the application list VM
            _applicationListViewModel?.CancelPendingOperations();
            if (_applicationListViewModel != null)
            {
                _applicationListViewModel.PropertyChanged -= OnApplicationListVmPropertyChanged;
            }

            // Stop search timer
            if (_searchTimer != null)
            {
                _searchTimer.Stop();
                _searchTimer.Tick -= SearchTimer_Tick;
            }

            // Dispose KeyVaultService (disposes certificate)
            try
            {
                var keyVaultService = App.Services.GetService<KeyVaultService>();
                keyVaultService?.Dispose();
                Debug.WriteLine("KeyVaultService disposed - certificate cleaned up");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error disposing KeyVaultService: {ex.Message}");
            }

            base.OnClosed(e);
        }
    }
}
