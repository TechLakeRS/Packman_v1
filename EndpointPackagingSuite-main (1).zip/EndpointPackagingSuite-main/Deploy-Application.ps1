<#
.SYNOPSIS
    PSADT Toolkit is used by NBB Packaging team to create SCCM application.
    The logic structure and SCCM applications are performed by the NBB Right Click Tools

	This script performs the installation or uninstallation of an application(s).
	# LICENSE #
	PowerShell App Deployment Toolkit - Provides a set of functions to perform common application deployment tasks on Windows.
	Copyright (C) 2017 - Sean Lillis, Dan Cunningham, Muhammad Mashwani, Aman Motazedian.
	This program is free software: you can redistribute it and/or modify it under the terms of the GNU Lesser General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version. This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
	You should have received a copy of the GNU Lesser General Public License along with this program. If not, see <http://www.gnu.org/licenses/>.
.DESCRIPTION
	The script is provided as a template to perform an install or uninstall of an application(s).
	The script either performs an "Install" deployment type or an "Uninstall" deployment type.
	The install deployment type is broken down into 3 main sections/phases: Pre-Install, Install, and Post-Install.
	The script dot-sources the AppDeployToolkitMain.ps1 script which contains the logic and functions required to install or uninstall an application.
.PARAMETER DeploymentType
	The type of deployment to perform. Default is: Install.
.PARAMETER DeployMode
	Specifies whether the installation should be run in Interactive, Silent, or NonInteractive mode. Default is: Interactive. Options: Interactive = Shows dialogs, Silent = No dialogs, NonInteractive = Very silent, i.e. no blocking apps. NonInteractive mode is automatically set if it is detected that the process is not user interactive.
.PARAMETER AllowRebootPassThru
	Allows the 3010 return code (requires restart) to be passed back to the parent process (e.g. SCCM) if detected from an installation. If 3010 is passed back to SCCM, a reboot prompt will be triggered.
.PARAMETER TerminalServerMode
	Changes to "user install mode" and back to "user execute mode" for installing/uninstalling applications for Remote Destkop Session Hosts/Citrix servers.
.PARAMETER DisableLogging
	Disables logging to file for the script. Default is: $false.
.EXAMPLE
    powershell.exe -Command "& { & '.\Deploy-Application.ps1' -DeployMode 'Silent'; Exit $LastExitCode }"
.EXAMPLE
    powershell.exe -Command "& { & '.\Deploy-Application.ps1' -AllowRebootPassThru; Exit $LastExitCode }"
.EXAMPLE
    powershell.exe -Command "& { & '.\Deploy-Application.ps1' -DeploymentType 'Uninstall'; Exit $LastExitCode }"
.EXAMPLE
    Deploy-Application.exe -DeploymentType "Install" -DeployMode "Silent"
.NOTES
	Toolkit Exit Code Ranges:
	60000 - 68999: Reserved for built-in exit codes in Deploy-Application.ps1, Deploy-Application.exe, and AppDeployToolkitMain.ps1
	69000 - 69999: Recommended for user customized exit codes in Deploy-Application.ps1
	70000 - 79999: Recommended for user customized exit codes in AppDeployToolkitExtensions.ps1
.LINK
	http://psappdeploytoolkit.com
#>
[CmdletBinding()]
Param (
	[Parameter(Mandatory=$false)]
	[ValidateSet('Install','Uninstall','Repair')]
	[string]$DeploymentType = 'Install',
	[Parameter(Mandatory=$false)]
	[ValidateSet('Interactive','Silent','NonInteractive')]
	[string]$DeployMode = 'Interactive',
	[Parameter(Mandatory=$false)]
	[switch]$AllowRebootPassThru = $true,
	[Parameter(Mandatory=$false)]
	[switch]$TerminalServerMode = $false,
	[Parameter(Mandatory=$false)]
	[switch]$DisableLogging = $false
)

Try {
	## Set the script execution policy for this process
	Try { Set-ExecutionPolicy -ExecutionPolicy 'ByPass' -Scope 'Process' -Force -ErrorAction 'Stop' } Catch {}

	##*===============================================
	##* VARIABLE DECLARATION
	##*===============================================
	## Variables: Application
	[string]$appVendor = "Seiko Epson"
	[string]$appName = "Epson scan"
	[string]$appVersion = "1.6"
	[string]$appArch = 
	[string]$appLang = 'EN'
	[string]$appRevision = '01'
	[string]$appScriptVersion = '1.0.0'
	[string]$appScriptDate = "29/05/2024"
	[string]$appScriptAuthor = "admin.kestena"
	##*===============================================
	## Variables: Install Titles (Only set here to override defaults set by the toolkit)
	[string]$installName = ''
	[string]$installTitle = ''

	##* Do not modify section below
	#region DoNotModify

	## Variables: Exit Code
	[int32]$mainExitCode = 0

	## Variables: Script
	[string]$deployAppScriptFriendlyName = 'Deploy Application'
	[version]$deployAppScriptVersion = [version]'3.8.4'
	[string]$deployAppScriptDate = '26/01/2021'
	[hashtable]$deployAppScriptParameters = $psBoundParameters

	## Variables: Environment
	If (Test-Path -LiteralPath 'variable:HostInvocation') { $InvocationInfo = $HostInvocation } Else { $InvocationInfo = $MyInvocation }
	[string]$scriptDirectory = Split-Path -Path $InvocationInfo.MyCommand.Definition -Parent

	## Dot source the required App Deploy Toolkit Functions
	Try {
		[string]$moduleAppDeployToolkitMain = "$scriptDirectory\AppDeployToolkit\AppDeployToolkitMain.ps1"
		If (-not (Test-Path -LiteralPath $moduleAppDeployToolkitMain -PathType 'Leaf')) { Throw "Module does not exist at the specified location [$moduleAppDeployToolkitMain]." }
		If ($DisableLogging) { . $moduleAppDeployToolkitMain -DisableLogging } Else { . $moduleAppDeployToolkitMain }
	}
	Catch {
		If ($mainExitCode -eq 0){ [int32]$mainExitCode = 60008 }
		Write-Error -Message "Module [$moduleAppDeployToolkitMain] failed to load: `n$($_.Exception.Message)`n `n$($_.InvocationInfo.PositionMessage)" -ErrorAction 'Continue'
		## Exit the script, returning the exit code to SCCM
		If (Test-Path -LiteralPath 'variable:HostInvocation') { $script:ExitCode = $mainExitCode; Exit } Else { Exit $mainExitCode }
	}

	#endregion
	##* Do not modify section above
	##*===============================================
	##* END VARIABLE DECLARATION
	##*===============================================

	If ($deploymentType -ine 'Uninstall' -and $deploymentType -ine 'Repair') {
		##*===============================================
		##* PRE-INSTALLATION
		##*===============================================
		[string]$installPhase = 'Pre-Installation'

		##*===============================================
		##* INSTALLATION
		##*===============================================
		[string]$installPhase = 'Installation'

        #Variable adding by Fabrice BEAUCAMP to differentiate the script steps (Install, Uninstall, Repair)
        $deploymentTypeName="Installation"

		## Handle UI setup for logged on user
		Execute-Process -Path "$Dirfiles\epson15550.exe" 
		
	}
	ElseIf ($deploymentType -ieq 'Uninstall')
	{
		##*===============================================
		##* UNINSTALLATION
		##*===============================================
		[string]$installPhase = 'Uninstallation'

        #Variable adding by Fabrice BEAUCAMP to differentiate the script steps (Install, Uninstall, Repair)
        $deploymentTypeName="Uninstallation"

		Execute-Process -Path "C:\Program Files (x86)\epson\escndv\setup\setup.exe" -Parameters "/r"
	}
	ElseIf ($deploymentType -ieq 'Repair')
	{
		##*===============================================
		##* REPAIR
		##*===============================================
		[string]$installPhase = 'Repair'

        #Variable adding by Fabrice BEAUCAMP to differentiate the script steps (Install, Uninstall, Repair)
        $deploymentTypeName="Repair"

		#uninstall
		Execute-Process -Path "C:\Program Files (x86)\epson\escndv\setup\setup.exe" -Parameters "/r"

		#Install
		Execute-Process -Path "$Dirfiles\epson15550.exe" 

    }
	##*===============================================
	##* END SCRIPT BODY
	##*===============================================

	## Call the Exit-Script function to perform final cleanup operations
	Exit-Script -ExitCode $mainExitCode
}
Catch {
	[int32]$mainExitCode = 60001
	[string]$mainErrorMessage = "$(Resolve-Error)"
	Write-Log -Message $mainErrorMessage -Severity 3 -Source $deployAppScriptFriendlyName
	Show-DialogBox -Text $mainErrorMessage -Icon 'Stop'
	Exit-Script -ExitCode $mainExitCode
}

# SIG # Begin signature block
# MIInkwYJKoZIhvcNAQcCoIInhDCCJ4ACAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCA0gV4MHNxssxuh
# TwvNAhqfrH/b1ey8c0c4czJtzazCPqCCIaowggWNMIIEdaADAgECAhAOmxiO+dAt
# 5+/bUOIIQBhaMA0GCSqGSIb3DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNV
# BAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBa
# Fw0zMTExMDkyMzU5NTlaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lD
# ZXJ0IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoC
# ggIBAL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3E
# MB/zG6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKy
# unWZanMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsF
# xl7sWxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU1
# 5zHL2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJB
# MtfbBHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObUR
# WBf3JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6
# nj3cAORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxB
# YKqxYxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5S
# UUd0viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+x
# q4aLT8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIB
# NjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwP
# TzAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMC
# AYYweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdp
# Y2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0
# aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENB
# LmNybDARBgNVHSAECjAIMAYGBFUdIAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0Nc
# Vec4X6CjdBs9thbX979XB72arKGHLOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnov
# Lbc47/T/gLn4offyct4kvFIDyE7QKt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65Zy
# oUi0mcudT6cGAxN3J0TU53/oWajwvy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFW
# juyk1T3osdz9HNj0d1pcVIxv76FQPfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPF
# mCLBsln1VWvPJ6tsds5vIy30fnFqI2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9z
# twGpn1eqXijiuZQwggauMIIElqADAgECAhAHNje3JFR82Ees/ShmKl5bMA0GCSqG
# SIb3DQEBCwUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMx
# GTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRy
# dXN0ZWQgUm9vdCBHNDAeFw0yMjAzMjMwMDAwMDBaFw0zNzAzMjIyMzU5NTlaMGMx
# CzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMy
# RGlnaUNlcnQgVHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcg
# Q0EwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDGhjUGSbPBPXJJUVXH
# JQPE8pE3qZdRodbSg9GeTKJtoLDMg/la9hGhRBVCX6SI82j6ffOciQt/nR+eDzMf
# UBMLJnOWbfhXqAJ9/UO0hNoR8XOxs+4rgISKIhjf69o9xBd/qxkrPkLcZ47qUT3w
# 1lbU5ygt69OxtXXnHwZljZQp09nsad/ZkIdGAHvbREGJ3HxqV3rwN3mfXazL6IRk
# tFLydkf3YYMZ3V+0VAshaG43IbtArF+y3kp9zvU5EmfvDqVjbOSmxR3NNg1c1eYb
# qMFkdECnwHLFuk4fsbVYTXn+149zk6wsOeKlSNbwsDETqVcplicu9Yemj052FVUm
# cJgmf6AaRyBD40NjgHt1biclkJg6OBGz9vae5jtb7IHeIhTZgirHkr+g3uM+onP6
# 5x9abJTyUpURK1h0QCirc0PO30qhHGs4xSnzyqqWc0Jon7ZGs506o9UD4L/wojzK
# QtwYSH8UNM/STKvvmz3+DrhkKvp1KCRB7UK/BZxmSVJQ9FHzNklNiyDSLFc1eSuo
# 80VgvCONWPfcYd6T/jnA+bIwpUzX6ZhKWD7TA4j+s4/TXkt2ElGTyYwMO1uKIqjB
# Jgj5FBASA31fI7tk42PgpuE+9sJ0sj8eCXbsq11GdeJgo1gJASgADoRU7s7pXche
# MBK9Rp6103a50g5rmQzSM7TNsQIDAQABo4IBXTCCAVkwEgYDVR0TAQH/BAgwBgEB
# /wIBADAdBgNVHQ4EFgQUuhbZbU2FL3MpdpovdYxqII+eyG8wHwYDVR0jBBgwFoAU
# 7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoG
# CCsGAQUFBwMIMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0cDovL29j
# c3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0cy5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNVHR8EPDA6MDig
# NqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9v
# dEc0LmNybDAgBgNVHSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEwDQYJKoZI
# hvcNAQELBQADggIBAH1ZjsCTtm+YqUQiAX5m1tghQuGwGC4QTRPPMFPOvxj7x1Bd
# 4ksp+3CKDaopafxpwc8dB+k+YMjYC+VcW9dth/qEICU0MWfNthKWb8RQTGIdDAiC
# qBa9qVbPFXONASIlzpVpP0d3+3J0FNf/q0+KLHqrhc1DX+1gtqpPkWaeLJ7giqzl
# /Yy8ZCaHbJK9nXzQcAp876i8dU+6WvepELJd6f8oVInw1YpxdmXazPByoyP6wCeC
# RK6ZJxurJB4mwbfeKuv2nrF5mYGjVoarCkXJ38SNoOeY+/umnXKvxMfBwWpx2cYT
# gAnEtp/Nh4cku0+jSbl3ZpHxcpzpSwJSpzd+k1OsOx0ISQ+UzTl63f8lY5knLD0/
# a6fxZsNBzU+2QJshIUDQtxMkzdwdeDrknq3lNHGS1yZr5Dhzq6YBT70/O3itTK37
# xJV77QpfMzmHQXh6OOmc4d0j/R0o08f56PGYX/sr2H7yRp11LB4nLCbbbxV7HhmL
# NriT1ObyF5lZynDwN7+YAN8gFk8n+2BnFqFmut1VwDophrCYoCvtlUG3OtUVmDG0
# YgkPCr2B2RP+v6TR81fZvAT6gt4y3wSJ8ADNXcL50CN/AAvkdgIm2fBldkKmKYcJ
# RyvmfxqkhQ/8mJb2VVQrH4D6wPIOK+XW+6kvRBVK5xMOHds3OBqhK/bt1nz8MIIG
# wjCCBKqgAwIBAgIQBUSv85SdCDmmv9s/X+VhFjANBgkqhkiG9w0BAQsFADBjMQsw
# CQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNVBAMTMkRp
# Z2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1waW5nIENB
# MB4XDTIzMDcxNDAwMDAwMFoXDTM0MTAxMzIzNTk1OVowSDELMAkGA1UEBhMCVVMx
# FzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMSAwHgYDVQQDExdEaWdpQ2VydCBUaW1l
# c3RhbXAgMjAyMzCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAKNTRYcd
# g45brD5UsyPgz5/X5dLnXaEOCdwvSKOXejsqnGfcYhVYwamTEafNqrJq3RApih5i
# Y2nTWJw1cb86l+uUUI8cIOrHmjsvlmbjaedp/lvD1isgHMGXlLSlUIHyz8sHpjBo
# yoNC2vx/CSSUpIIa2mq62DvKXd4ZGIX7ReoNYWyd/nFexAaaPPDFLnkPG2ZS48jW
# Pl/aQ9OE9dDH9kgtXkV1lnX+3RChG4PBuOZSlbVH13gpOWvgeFmX40QrStWVzu8I
# F+qCZE3/I+PKhu60pCFkcOvV5aDaY7Mu6QXuqvYk9R28mxyyt1/f8O52fTGZZUdV
# nUokL6wrl76f5P17cz4y7lI0+9S769SgLDSb495uZBkHNwGRDxy1Uc2qTGaDiGhi
# u7xBG3gZbeTZD+BYQfvYsSzhUa+0rRUGFOpiCBPTaR58ZE2dD9/O0V6MqqtQFcmz
# yrzXxDtoRKOlO0L9c33u3Qr/eTQQfqZcClhMAD6FaXXHg2TWdc2PEnZWpST618Rr
# IbroHzSYLzrqawGw9/sqhux7UjipmAmhcbJsca8+uG+W1eEQE/5hRwqM/vC2x9XH
# 3mwk8L9CgsqgcT2ckpMEtGlwJw1Pt7U20clfCKRwo+wK8REuZODLIivK8SgTIUlR
# fgZm0zu++uuRONhRB8qUt+JQofM604qDy0B7AgMBAAGjggGLMIIBhzAOBgNVHQ8B
# Af8EBAMCB4AwDAYDVR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDAg
# BgNVHSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEwHwYDVR0jBBgwFoAUuhbZ
# bU2FL3MpdpovdYxqII+eyG8wHQYDVR0OBBYEFKW27xPn783QZKHVVqllMaPe1eNJ
# MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdp
# Q2VydFRydXN0ZWRHNFJTQTQwOTZTSEEyNTZUaW1lU3RhbXBpbmdDQS5jcmwwgZAG
# CCsGAQUFBwEBBIGDMIGAMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2Vy
# dC5jb20wWAYIKwYBBQUHMAKGTGh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9E
# aWdpQ2VydFRydXN0ZWRHNFJTQTQwOTZTSEEyNTZUaW1lU3RhbXBpbmdDQS5jcnQw
# DQYJKoZIhvcNAQELBQADggIBAIEa1t6gqbWYF7xwjU+KPGic2CX/yyzkzepdIpLs
# jCICqbjPgKjZ5+PF7SaCinEvGN1Ott5s1+FgnCvt7T1IjrhrunxdvcJhN2hJd6Pr
# kKoS1yeF844ektrCQDifXcigLiV4JZ0qBXqEKZi2V3mP2yZWK7Dzp703DNiYdk9W
# uVLCtp04qYHnbUFcjGnRuSvExnvPnPp44pMadqJpddNQ5EQSviANnqlE0PjlSXcI
# WiHFtM+YlRpUurm8wWkZus8W8oM3NG6wQSbd3lqXTzON1I13fXVFoaVYJmoDRd7Z
# ULVQjK9WvUzF4UbFKNOt50MAcN7MmJ4ZiQPq1JE3701S88lgIcRWR+3aEUuMMsOI
# 5ljitts++V+wQtaP4xeR0arAVeOGv6wnLEHQmjNKqDbUuXKWfpd5OEhfysLcPTLf
# ddY2Z1qJ+Panx+VPNTwAvb6cKmx5AdzaROY63jg7B145WPR8czFVoIARyxQMfq68
# /qTreWWqaNYiyjvrmoI1VygWy2nyMpqy0tg6uLFGhmu6F/3Ed2wVbK6rr3M66ElG
# t9V/zLY4wNjsHPW2obhDLN9OTH0eaHDAdwrUAuBcYLso/zjlUlrWrBciI0707NMX
# +1Br/wd3H3GXREHJuEbTbDJ8WC9nR2XlG3O2mflrLAZG70Ee8PBf4NvZrZCARK+A
# EEGKMIIHMzCCBRugAwIBAgIQZgybEpoKbCFVCTjdVKDtLTANBgkqhkiG9w0BAQsF
# ADBTMQswCQYDVQQGEwJFVTEpMCcGA1UECgwgRVVST1BFQU4gU1lTVEVNIE9GIENF
# TlRSQUwgQkFOS1MxGTAXBgNVBAMMEEVTQ0ItUEtJIFJPT1QgQ0EwIBgPMjAxMTA3
# MjIxMDQ2MzVaFw0yNjA3MjIxMDQ2MzVaMFUxCzAJBgNVBAYTAkVVMSkwJwYDVQQK
# DCBFVVJPUEVBTiBTWVNURU0gT0YgQ0VOVFJBTCBCQU5LUzEbMBkGA1UEAwwSRVND
# Qi1QS0kgT05MSU5FIENBMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA
# 0m/LhkKzQSfOJdqFphnmA/mj3zuy8eZ8LuT4VgmPHV0pSivWaCCY0KLYXdhJTF7s
# 9pJvGLcaQTJeGID4inupwfB/P4pbKveBl3OEBkjGjMXNXlfk75WMapThdtGkPBI7
# XpI8buVlrdyPOMEN51PRviJqv4vj6awv6CiUGySXT+8UeJynOQ/DmLcmJ8NeVaPC
# mUnzATc2WLtYGjL3sStuxKzGQNwnXFwGYSGsmpH29c3E8Ucn4dxs15iBEct4JfYn
# W6THW8oKfXDYR4jEVMaTENH1GOJSmYMEfmDcLxLs3k8ZlnwTwQGJj7BC985LKszn
# URi7QlP5X6YVMad9+2/UZI0RiNTiug9cWiWjNvII5xB59XrBStEFb4X9iZigC2hO
# YD8bRe8TPdhPbhHqsN6KlwrpCph98t9RhmguUoT6RSg46HYZm+aqBqf2HrEDvkq7
# k7pp59dmcPrO8kkJS7mD1G0B/LWQ62OqpL6ASLCW+UmKEixUcROV/qPFemb3QKex
# dBx68axXexuUodhpjG5PSlkeB95nXoiRle3U6UpeTet4wifMm2REdR14MQ/SfMuV
# B0O+nsi+SWky/xSccVFz5g2IrRu+EXSxZ8lr32A1HtWxxR8mi2v9Lsodsf60Pq+b
# p9rd5fWepqbbEA1BVs7VDfFA5pJPRGpEAwIXZLvcb7kCAwEAAaOCAf0wggH5MA8G
# A1UdEwEB/wQFMAMBAf8wDgYDVR0PAQH/BAQDAgEGMB0GA1UdDgQWBBTkWd5EJLak
# PINDNyiwyKSuJi09AzAfBgNVHSMEGDAWgBTVhR1pY5coyVnm0WcHzVS83AJ+6jA8
# BgNVHSAENTAzMDEGBFUdIAAwKTAnBggrBgEFBQcCARYbaHR0cDovL3BraS5lc2Ni
# LmV1L3BvbGljaWVzMD8GCCsGAQUFBwEBBDMwMTAvBggrBgEFBQcwAoYjaHR0cDov
# L3BraS5lc2NiLmV1L2NlcnRzL3Jvb3RDQS5jcnQwggEVBgNVHR8EggEMMIIBCDCC
# AQSgggEAoIH9hiJodHRwOi8vcGtpLmVzY2IuZXUvY3Jscy9yb290Q0EuY3JshoGO
# bGRhcDovL2xkYXAtcGtpLmVzY2IuZXUvQ049RVNDQi1QS0klMjBSb290JTIwQ0Es
# T1U9UEtJLE9VPUVTQ0ItUEtJLE89RVNDQixDPUVVP2NlcnRpZmljYXRlUmV2b2Nh
# dGlvbkxpc3Q/YmFzZT9vYmplY3RjbGFzcz1jUkxEaXN0cmlidXRpb25Qb2ludIYm
# aHR0cDovL2lhbS1jcmwuZXNjYi5ldS9lc2NiL3Jvb3RDQS5jcmyGHmh0dHA6Ly9l
# c2NicGtpL2NybHMvcm9vdENBLmNybDANBgkqhkiG9w0BAQsFAAOCAgEANKj8sGwW
# 5pc+iKwAKrVTTKaAq/8kJrFq05p+hncEokBnivD0PdVz+NycTcufpkaz/Mv7Pldt
# f2/7pUSNFDlVTauu7nXz2G4c53uHqSatNOCTLw/L9Nx74/uh9iUTYW3OlON6qnKY
# 0oeyPyIDnwbqVlfS5W0GL5sChEUhIbsU8EduTaEsC9Yo3KfaIn77W9S3UxdF7bH3
# I6Fc01wh1ELoG2clRYvDEMAHtROxKDHgFz9oIZN8MKwzcIqIWijspMzd6JYdpI2U
# 3U+3lFpLBwWJPixFcIkZzoRukbgV6cgFS82oqdMe5ye35T36nsg8BYuxZivGMwfw
# C36HkoSan5KyfFnXcpiFpndmw5kQNu7hgpkcoEuxVjTl4PTWXHdKmTmpl3+9jsKK
# mTL7Ol7Zv37qCcPnOyvfV2y7cOu+kxGZR+dJ4Uso7/S/bkZRd+OUo9qW2fRf3Q02
# tWfZ0EO4qn78soBe6FMS40lRLXoyIDdVsy4Whf33TGoLB4YLfl5MyjEuXTIe+PgW
# qQKlt1JMGxm4PSF2rvasBXGeVQmd5Xln4Pj0TTYONJG830ybAMqX/1WRP2b6F9/s
# RB793IqUtXQcywf+pU2E36FMwxCYET259d6cm5IyZ7qkHtc2wQIK+qTBbKmw8WZP
# UKGZxz4iRIzXQcBw+KhcoaVEcra6SjC3VVwwggdmMIIFTqADAgECAhBuEy7ZziR6
# 9mVmBTcP7a7OMA0GCSqGSIb3DQEBCwUAMFUxCzAJBgNVBAYTAkVVMSkwJwYDVQQK
# DCBFVVJPUEVBTiBTWVNURU0gT0YgQ0VOVFJBTCBCQU5LUzEbMBkGA1UEAwwSRVND
# Qi1QS0kgT05MSU5FIENBMB4XDTIzMTEyODE1MjAyM1oXDTI2MDcyMjEwNDYzNVow
# gYAxCzAJBgNVBAYTAkJFMSkwJwYDVQQKDCBFVVJPUEVBTiBTWVNURU0gT0YgQ0VO
# VFJBTCBCQU5LUzEmMCQGA1UECwwdTmF0aW9uYWwgQmFuayBvZiBCZWxnaXVtIChC
# RSkxHjAcBgNVBAMMFU5CQiBEaWdpdGFsIFdvcmtwbGFjZTCCASIwDQYJKoZIhvcN
# AQEBBQADggEPADCCAQoCggEBALM003OjqGQSRvtt/zMJfPePoEg+z6b5xwKWdZgT
# ALtJaJV9Q78Wv2ust0i3NkPNiFiTow1yymp6KAR5W9AcgnfV1Tljn7BrxoKUErco
# NLDlNoCgCh22E+mgC5fq+/RbfY5uc/wz2UbVoZ+ssg0+gUhpgNazvAEkVsjiCexK
# 6U2FzoLLIlUMjelnYzJQCvQGNm+95m3RSm4CfIu5k3pL8+JPxhpb9lQGF/r4uRal
# TRZqFkt1BIpo10FOJklEmwJNHfmBErYDUWk4IQY3XR/jlj1Tb3QSjHCeq7sAYY1z
# 4XfAICBgVpWYBWkEHr1SrAyt5JcScIFlDF7yx9lbUlnHB/UCAwEAAaOCAwQwggMA
# MCIGA1UdEQQbMBmBF2RpZ2l0YWx3b3JrcGxhY2VAbmJiLmJlMA4GA1UdDwEB/wQE
# AwIHgDAWBgNVHSUBAf8EDDAKBggrBgEFBQcDAzAdBgNVHQ4EFgQUXdB63ft2T/3S
# QwRb1ndJw+kIBwQwHwYDVR0jBBgwFoAU5FneRCS2pDyDQzcosMikriYtPQMwQQYD
# VR0gBDowODA2BgkEAH8ACgECBAMwKTAnBggrBgEFBQcCARYbaHR0cDovL3BraS5l
# c2NiLmV1L3BvbGljaWVzMIHcBggrBgEFBQcBAQSBzzCBzDAvBggrBgEFBQcwAoYj
# aHR0cDovL3BraS5lc2NiLmV1L2NlcnRzL3Jvb3RDQS5jcnQwLgYIKwYBBQUHMAKG
# Imh0dHA6Ly9wa2kuZXNjYi5ldS9jZXJ0cy9zdWJDQS5jcnQwHwYIKwYBBQUHMAGG
# E2h0dHA6Ly9vY3NwLWVzY2Jwa2kwIwYIKwYBBQUHMAGGF2h0dHA6Ly9vY3NwLXBr
# aS5lc2NiLmV1MCMGCCsGAQUFBzABhhdodHRwOi8vaWFtLW9jc3AuZXNjYi5ldTAc
# BggEAH8ACgEDAgQQQkFOQ08gREUgRVNQQcORQTAbBggEAH8ACgEDAwQPVkFURVMt
# UTI4MDI0NzJHMIIBEwYDVR0fBIIBCjCCAQYwggECoIH/oIH8hh1odHRwOi8vZXNj
# YnBraS9jcmxzL3N1YkNBLmNybIYhaHR0cDovL3BraS5lc2NiLmV1L2NybHMvc3Vi
# Q0EuY3JshoGQbGRhcDovL2xkYXAtcGtpLmVzY2IuZXUvQ049RVNDQi1QS0klMjBP
# TkxJTkUlMjBDQSxPVT1QS0ksT1U9RVNDQi1QS0ksTz1FU0NCLEM9RVU/Y2VydGlm
# aWNhdGVSZXZvY2F0aW9uTGlzdD9iYXNlP29iamVjdGNsYXNzPWNSTERpc3RyaWJ1
# dGlvblBvaW50hiVodHRwOi8vaWFtLWNybC5lc2NiLmV1L2VzY2Ivc3ViQ0EuY3Js
# MA0GCSqGSIb3DQEBCwUAA4ICAQAP1aH0XkPy1W+Tm5bzszcJVxkcJGD20CVxn+bh
# vPz+oGSWAVid7z0LJ67HIdQ89JjRjQMycUMg1VWInsCScm2e3UobHqaSR7LfTz+G
# Y06G1ZqaumHc1Np+V6NwukzHpFeLCwqX1uzAoinJqNI6lBdfny9AEqhdZ4mArvhn
# 2v+V+Vqa8/jSgsPnFYrsoOTjzPaz1QPPfwswoDi407KA5HMAxnuiQPlNtCgoBaAe
# JrRpVv4bhw/JWTdiRTBlsLps8CzSVUxSm+n5/VT9ONS+JkUcHQ6xUEzujVNOYHLh
# Rrlo1YywBNG8gu+nPvsDdchfdUldFoNlW6JOa0NYJCdhEeSpmkTjFsV4YPGUo7W4
# JtxemNZA+WA64EwIY3nFlN4xAy14c/IjYmjz3R1OK6GvO7HDZp5Iw4nx348qaef2
# bt0LQ9VnYfRy8s6E1xw3oahQFqAzTaQoeTzLrd5wxrMNdNaGjaNQoXLMvc+wQfDu
# 6cYRjA/idOfGPSXFDivv6bI+f2sHGvuDvq2YNPyZfOOcw66aqGBxMxXrXOdWm1zI
# sNtv3Gb168MJqfsjVGyIymcxdL1cArHX6G8v3EqKn2cSGdr1atAvM4V5uflfLh2l
# cE8MIoCjTD3+oTLolSV/MopGnID7EDnRYSt/NRX12uC5pVsYey2Ec8GTIAmSpweN
# gI/xezGCBT8wggU7AgEBMGkwVTELMAkGA1UEBhMCRVUxKTAnBgNVBAoMIEVVUk9Q
# RUFOIFNZU1RFTSBPRiBDRU5UUkFMIEJBTktTMRswGQYDVQQDDBJFU0NCLVBLSSBP
# TkxJTkUgQ0ECEG4TLtnOJHr2ZWYFNw/trs4wDQYJYIZIAWUDBAIBBQCggYQwGAYK
# KwYBBAGCNwIBDDEKMAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIB
# BDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg
# rpBxN8qjXUCWs60dUin61MA7vczZBjxSxUG3p3xg5O0wDQYJKoZIhvcNAQEBBQAE
# ggEABMZ7jinvtNhYv48z7bwgqYoYy8PeB2XgqKQVt7GSJ4FBMLD3jNHHWAd78t+p
# 4AQPJnYZ0c/5EHH2L4D3e7zgxlkoruueqrMKAbdZdnwzYdG232V3p47ykmIVg1RD
# EqL72ouMoSRl7Xin3ASB/gwHdfUUAT7WepBWOCWeeJfZm5x2D52RWZyUmk34qc/f
# Q/fDh3J4UgBLqZkQKSei00ZnhH4PwIcRCKywp+5hRFdM4tHaydnZ9Avv+whYR/Da
# ktDxA6LK9gvB8Y3LQeqLW48IwsGfzJFMFXuzeuhu+O/BRc2KD5Xl5jN9kotMWQUQ
# HuJ30MeXMSOJgTt1I3DsNkMauaGCAyAwggMcBgkqhkiG9w0BCQYxggMNMIIDCQIB
# ATB3MGMxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkG
# A1UEAxMyRGlnaUNlcnQgVHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3Rh
# bXBpbmcgQ0ECEAVEr/OUnQg5pr/bP1/lYRYwDQYJYIZIAWUDBAIBBQCgaTAYBgkq
# hkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0yNDA2MTAxMTI3
# MzNaMC8GCSqGSIb3DQEJBDEiBCBMM0qG7mwDsl+ic0BN935PXwfWV+Mr91KG81qe
# Y/NniDANBgkqhkiG9w0BAQEFAASCAgA3HPsm/Vl6UpKnFuMQ6kr/3vyFgqrIUoTR
# QR1TQ8iBGARnua3VMZljnFjRyreBSk1Cwm5kfFWFmkSm9S2JbM4jOu+7ay8SkLW7
# DRuPYLhFnxr940eiyHshUMcZICLPskGdnLHYcV72H32cWa9bPztknwNbyfCkPo2s
# lBZKHwIXIq7OmEyQavFbltjntASa7YNOTo/AgbYgPp+LdJDT7MDNviQvtz8I3Ewf
# pcLmVOYMGjIAeDuYGwh1/7zhIfDywRCCWv6PErvtScV6POZP6D32uA+Mzl9139Fp
# 9zUHeJSzmY77lP0xg7oR3kHxKf4yMscz9H2FOGY0Gazo8VoqXGs9T8mR+v8yO60h
# snf2B0a30lQpxiJVRMplKaiPkOpuUFgFLjREwQXkqSyII2UJzSBX6QkwCL4fxC4V
# No1byCCoFlj8hV966GkCME4LJ7cpwztuzjMqRlGP4O4XUI1odX3WHjiVyaM7f3V3
# cPWAmQbxLCiSmVFIe4nGiIvSKG3D7x0pywbhV1Rg/v7VgLVedyIMmxfOZNuBwlyn
# CgO8zlrhVEORES0xua1jYLdM08j2rPjffqgKy/twYhEbZl7kDOzwFuoht6ZhSZW/
# Cz0okJYLniCpEluhsSHJRhEGWuqd4lt0anbEZkNc/uZwFvO4zuupxtNZyk19OERR
# L7F5NZ3HgQ==
# SIG # End signature block
