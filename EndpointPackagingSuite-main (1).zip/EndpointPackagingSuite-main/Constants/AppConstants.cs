using System.Windows.Media;
namespace Endpoint_Packaging_Suite.Constants
{
    /// <summary>
    /// Application constants that should never change at runtime.
    /// For configurable settings (timeouts, upload settings, UI preferences, etc.),
    /// see AppSettings.cs and appsettings.json.
    /// </summary>
    public static class AppConstants
    {
        // Navigation page names
        public static class Navigation
        {
            public const string PageNameCreateApplication = "CreateApplication";
            public const string PageNameUploadExisting = "UploadExisting";
            public const string PageNameViewApplications = "ViewApplications";
            public const string PageNameSettings = "Settings";
            public const string PageNameLogs = "Logs";
            public const string PageNameWDACTools = "WDACTools";
            public const string PageNameRemoteTest = "RemoteTest";
            public const string PageNameSign = "Sign";
            public const string PageNameAdvanced = "Advanced";
        }
        // UI defaults
        public static class Defaults
        {
            public const int DefaultPageSize = 50;
            public const int SearchDebounceMilliseconds = 500;
            public const string AllCategoriesFilter = "All Categories";
        }
        // Categories available in the picker for assigning a single category.
        // "Uncategorized" means "remove all categories from the app".
        public static class Categories
        {
            public const string Uncategorized = "Uncategorized";
            public static readonly string[] Available = new[]
            {
                "Business",
                "Hidden",
                "OSD",
                "Retired",
                "Technical",
                "Test",
                Uncategorized
            };
        }
        // Install Context Types
        public static class InstallContext
        {
            public const string System = "System";
            public const string User = "User";
            public const string Default = System; // Default to System context
        }
        // Install State Codes
        public static class InstallState
        {
            public const int NotApplicable = 0;
            public const int Installed = 1;
            public const int Failed = 2;
            public const int Pending = 3;
            public const int NotInstalled = 4;
            public const int UninstallFailed = 5;
        }
        // Validation Messages
        public static class ValidationMessages
        {
            public const string PackagePathRequired = "Package path is required for upload. Please ensure a package has been selected.";
            public const string AppNameRequired = "Application name is required.";
            public const string DetectionRulesRequired = "Please add at least one detection rule.";
            public const string InvalidPackageStructure = "Invalid package structure. Please select a valid Invoke-AppDeployToolkit.exe file.";
        }
        // Error Messages
        public static class ErrorMessages
        {
            public const string ConfigModificationFailed = "Failed to modify AppDeployToolkitConfig.xml for User Install. Package may require admin rights.";
            public const string UploadFailed = "Upload Failed";
            public const string InvalidOperation = "Invalid Operation";
        }
        // Color Palette - UI theme colors
        public static class Colors
        {
            public static readonly Color Success = Color.FromRgb(39, 174, 96);
            public static readonly Color Error = Color.FromRgb(231, 76, 60);
            public static readonly Color Warning = Color.FromRgb(243, 156, 18);
            public static readonly Color Info = Color.FromRgb(52, 152, 219);
            public static readonly Color Neutral = Color.FromRgb(127, 140, 141);
            public static SolidColorBrush SuccessBrush => new SolidColorBrush(Success);
            public static SolidColorBrush ErrorBrush => new SolidColorBrush(Error);
            public static SolidColorBrush WarningBrush => new SolidColorBrush(Warning);
            public static SolidColorBrush InfoBrush => new SolidColorBrush(Info);
            public static SolidColorBrush NeutralBrush => new SolidColorBrush(Neutral);
        }
    }
}
