﻿using System.Diagnostics;
using System.IO;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace Endpoint_Packaging_Suite.Helpers
{
    public static class NetworkShareHelper
    {
        private static readonly string SharePath = @"\\nbb.local\sys\sccmdata\intuneapplications";

        // Marker file written into each package folder; pins the folder to an Intune app id.
        private const string MarkerFileName = ".intune-appid.json";

        // Lookup index at the share root, mapping app id -> package folder path.
        private const string IndexFileName = "_eps-appid-index.json";

        private static string IndexFilePath => Path.Combine(SharePath, IndexFileName);

        /// <summary>Root path of the package network share.</summary>
        public static string ShareRoot => SharePath;

        private static readonly JsonSerializerOptions _jsonOptions = new() { WriteIndented = true };

        /// <summary>
        /// Find an application's package folder. Resolves directly by Intune app id
        /// via the marker index when possible, otherwise falls back to name/version
        /// matching and records a marker so future lookups are exact.
        /// </summary>
        public static string? FindApplicationPath(string displayName, string? version = null, string? appId = null)
        {
            try
            {
                // 1. Exact lookup by app id via the shared marker index
                if (!string.IsNullOrEmpty(appId))
                {
                    var indexedPath = ResolveFromIndex(appId);
                    if (indexedPath != null)
                    {
                        Debug.WriteLine($"✓ Resolved by app-id marker: {indexedPath}");
                        return indexedPath;
                    }
                }

                // 2. Fall back to automatic name/version matching (legacy folders)
                var matchedPath = FindApplicationPathAutomatic(displayName, version);

                // 3. Self-heal: record a marker so the next lookup is an exact hit
                if (matchedPath != null && !string.IsNullOrEmpty(appId))
                {
                    SaveMarker(matchedPath, appId, displayName, version);
                }

                return matchedPath;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error finding app path: {ex.Message}");
                return null;
            }
        }

        /// <summary>
        /// Automatic folder matching based on display name and version
        /// </summary>
        private static string? FindApplicationPathAutomatic(string displayName, string? version = null)
        {
            try
            {
                if (!Directory.Exists(SharePath))
                {
                    Debug.WriteLine($"Network share not accessible: {SharePath}");
                    return null;
                }

                // Extract version from display name if present
                var (nameWithoutVersion, extractedVersion) = ExtractVersion(displayName);

                // Use extracted version if no explicit version provided
                if (string.IsNullOrEmpty(version) && !string.IsNullOrEmpty(extractedVersion))
                {
                    version = extractedVersion;
                }

                Debug.WriteLine($"Looking for: '{nameWithoutVersion}' version '{version}'");

                // Convert display name to expected folder format (replace spaces with underscores)
                var expectedFolderName = nameWithoutVersion.Replace(" ", "_");
                Debug.WriteLine($"Expected folder name: {expectedFolderName}");

                // Find the base folder
                var baseFolder = FindBaseFolder(expectedFolderName);

                if (baseFolder != null)
                {
                    Debug.WriteLine($"Found base folder: {baseFolder}");

                    // If we have a version, look for the version subfolder
                    if (!string.IsNullOrEmpty(version))
                    {
                        var versionPath = FindVersionFolder(baseFolder, version);
                        if (versionPath != null)
                        {
                            Debug.WriteLine($"✓ Found complete path: {versionPath}");
                            return versionPath;
                        }
                        else
                        {
                            Debug.WriteLine($"Version folder '{version}' not found, returning base folder");
                            return baseFolder;
                        }
                    }

                    return baseFolder;
                }

                Debug.WriteLine($"❌ No network share folder found for: {displayName}");
                return null;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error finding app path: {ex.Message}");
                return null;
            }
        }

        private static (string nameWithoutVersion, string? version) ExtractVersion(string displayName)
        {
            if (string.IsNullOrEmpty(displayName))
                return (displayName, null);

            // Look for version pattern at the end (e.g., "1.2.3.4" or "1.2.3")
            var versionMatch = Regex.Match(displayName, @"\s+(\d+(?:\.\d+)+)$");

            if (versionMatch.Success)
            {
                var version = versionMatch.Groups[1].Value;
                var nameWithoutVersion = displayName.Substring(0, versionMatch.Index).Trim();
                Debug.WriteLine($"Extracted version '{version}' from display name");
                return (nameWithoutVersion, version);
            }

            return (displayName, null);
        }

        private static string? FindBaseFolder(string expectedFolderName)
        {
            try
            {
                var folders = Directory.GetDirectories(SharePath);

                // Try exact match first (case-insensitive)
                var exactMatch = folders.FirstOrDefault(f =>
                    string.Equals(Path.GetFileName(f), expectedFolderName, StringComparison.OrdinalIgnoreCase));

                if (exactMatch != null)
                {
                    Debug.WriteLine($"Found exact match: {Path.GetFileName(exactMatch)}");
                    return exactMatch;
                }

                // Generate variations to try
                var variations = GenerateFolderVariations(expectedFolderName);

                foreach (var variation in variations)
                {
                    var match = folders.FirstOrDefault(f =>
                        string.Equals(Path.GetFileName(f), variation, StringComparison.OrdinalIgnoreCase));

                    if (match != null)
                    {
                        Debug.WriteLine($"Found with variation '{variation}': {Path.GetFileName(match)}");
                        return match;
                    }
                }

                // Try partial match as last resort
                var partialMatch = FindByPartialMatch(expectedFolderName, folders);
                if (partialMatch != null)
                {
                    Debug.WriteLine($"Found by partial match: {Path.GetFileName(partialMatch)}");
                    return partialMatch;
                }

                return null;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error in FindBaseFolder: {ex.Message}");
                return null;
            }
        }

        private static string[] GenerateFolderVariations(string folderName)
        {
            var variations = new HashSet<string>();

            // Original
            variations.Add(folderName);

            // Replace different separators
            variations.Add(folderName.Replace("_", "-"));
            variations.Add(folderName.Replace("_", "."));
            variations.Add(folderName.Replace("_", " "));

            // Handle multiple underscores (in case of extra underscores)
            variations.Add(Regex.Replace(folderName, @"_+", "_"));

            // Remove trailing/leading underscores
            variations.Add(folderName.Trim('_'));

            // Try with common suffixes/prefixes that might be added or removed
            variations.Add(folderName + "_x64");
            variations.Add(folderName + "_x86");
            variations.Add(folderName.Replace("_x64", "").Replace("_x86", ""));

            return variations.ToArray();
        }

        private static string? FindByPartialMatch(string expectedName, string[] folders)
        {
            // Clean the expected name for comparison
            var cleanExpected = Regex.Replace(expectedName.ToLower(), @"[_\-\.\s]", "");

            // If the name is too short, don't do partial matching
            if (cleanExpected.Length < 5)
                return null;

            string? bestMatch = null;
            double bestScore = 0.6; // Minimum 60% match

            foreach (var folder in folders)
            {
                var folderName = Path.GetFileName(folder);
                var cleanFolder = Regex.Replace(folderName.ToLower(), @"[_\-\.\s]", "");

                // Skip folders whose length differs by more than 40% — they can't score above 0.6
                int maxLen = Math.Max(cleanExpected.Length, cleanFolder.Length);
                int minLen = Math.Min(cleanExpected.Length, cleanFolder.Length);
                if (minLen < maxLen * 0.6)
                    continue;

                // Fast substring check before expensive Levenshtein computation
                if (cleanExpected.Contains(cleanFolder) || cleanFolder.Contains(cleanExpected))
                {
                    double containsScore = 0.8;
                    if (containsScore > bestScore)
                    {
                        bestScore = containsScore;
                        bestMatch = folder;
                        Debug.WriteLine($"Potential match: {folderName} (score: {containsScore:P0})");
                    }
                    continue;
                }

                // Calculate similarity score (Levenshtein-based)
                double score = CalculateSimilarity(cleanExpected, cleanFolder);

                if (score > bestScore)
                {
                    bestScore = score;
                    bestMatch = folder;
                    Debug.WriteLine($"Potential match: {folderName} (score: {score:P0})");
                }
            }

            return bestMatch;
        }

        private static double CalculateSimilarity(string s1, string s2)
        {
            if (string.IsNullOrEmpty(s1) || string.IsNullOrEmpty(s2))
                return 0;

            // Check if one contains the other
            if (s1.Contains(s2) || s2.Contains(s1))
                return 0.8;

            // Calculate Levenshtein distance for similarity
            int maxLen = Math.Max(s1.Length, s2.Length);
            if (maxLen == 0)
                return 1.0;

            int distance = LevenshteinDistance(s1, s2);
            return 1.0 - (double)distance / maxLen;
        }

        private static int LevenshteinDistance(string s1, string s2)
        {
            // Ensure s1 is the shorter string for O(min(n,m)) space
            if (s1.Length > s2.Length)
                (s1, s2) = (s2, s1);

            var prev = new int[s1.Length + 1];
            var curr = new int[s1.Length + 1];

            for (int i = 0; i <= s1.Length; i++)
                prev[i] = i;

            for (int j = 1; j <= s2.Length; j++)
            {
                curr[0] = j;
                for (int i = 1; i <= s1.Length; i++)
                {
                    int cost = s1[i - 1] == s2[j - 1] ? 0 : 1;
                    curr[i] = Math.Min(Math.Min(curr[i - 1] + 1, prev[i] + 1), prev[i - 1] + cost);
                }
                (prev, curr) = (curr, prev);
            }
            return prev[s1.Length];
        }

        private static string? FindVersionFolder(string basePath, string version)
        {
            try
            {
                if (!Directory.Exists(basePath))
                    return null;

                var subFolders = Directory.GetDirectories(basePath);

                if (subFolders.Length == 0)
                    return null;

                // Clean the version
                var cleanVersion = version.Trim().TrimStart('v', 'V');

                // Generate version variations
                var versionVariations = new HashSet<string>
                {
                    cleanVersion,
                    $"v{cleanVersion}",
                    $"V{cleanVersion}",
                    cleanVersion.Replace(".", "_"),
                    cleanVersion.Replace(".", "-"),
                    cleanVersion.Replace(".", "")
                };

                // Add variations with different zero padding
                if (Regex.IsMatch(cleanVersion, @"^\d+\.\d+\.\d+\.\d+$"))
                {
                    // If it's a 4-part version, try 3-part as well
                    var parts = cleanVersion.Split('.');
                    if (parts[3] == "0")
                    {
                        versionVariations.Add($"{parts[0]}.{parts[1]}.{parts[2]}");
                    }
                }

                // Try exact match with variations
                foreach (var variant in versionVariations)
                {
                    var match = subFolders.FirstOrDefault(f =>
                        string.Equals(Path.GetFileName(f), variant, StringComparison.OrdinalIgnoreCase));

                    if (match != null)
                    {
                        Debug.WriteLine($"Found version folder: {Path.GetFileName(match)}");
                        return match;
                    }
                }

                // Try folders that start with the version
                foreach (var variant in versionVariations)
                {
                    var match = subFolders.FirstOrDefault(f =>
                        Path.GetFileName(f).StartsWith(variant, StringComparison.OrdinalIgnoreCase));

                    if (match != null)
                    {
                        Debug.WriteLine($"Found version folder by prefix: {Path.GetFileName(match)}");
                        return match;
                    }
                }

                // Try folders that CONTAIN the version (e.g., "2021 21.0.391" contains "21.0.391")
                foreach (var variant in versionVariations)
                {
                    var match = subFolders.FirstOrDefault(f =>
                    {
                        var folderName = Path.GetFileName(f);
                        // Check if the version appears as a word (with space before it or at the end)
                        return folderName.Contains($" {variant}", StringComparison.OrdinalIgnoreCase) ||
                               folderName.EndsWith(variant, StringComparison.OrdinalIgnoreCase);
                    });

                    if (match != null)
                    {
                        Debug.WriteLine($"Found version folder by containment: {Path.GetFileName(match)}");
                        return match;
                    }
                }

                // Log available folders for debugging
                Debug.WriteLine($"Version '{version}' not found. Available subfolders:");
                foreach (var folder in subFolders.Take(5))
                {
                    Debug.WriteLine($"  - {Path.GetFileName(folder)}");
                }

                return null;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error finding version folder: {ex.Message}");
                return null;
            }
        }

        // ── App-id markers ────────────────────────────────────────────────

        /// <summary>
        /// Writes an app-id marker into the package folder and updates the shared
        /// index, so the folder can later be found directly by Intune app id.
        /// Best-effort: returns false if the marker could not be written.
        /// </summary>
        public static bool SaveMarker(string folderPath, string appId, string? displayName = null, string? version = null)
        {
            if (string.IsNullOrEmpty(folderPath) || string.IsNullOrEmpty(appId))
                return false;

            try
            {
                if (!Directory.Exists(folderPath))
                    return false;

                WriteMarkerFile(folderPath, new AppMarker
                {
                    IntuneAppId = appId,
                    DisplayName = displayName ?? "",
                    Version = version ?? "",
                    Updated = DateTime.UtcNow.ToString("o")
                });

                UpsertIndex(appId, folderPath);
                Debug.WriteLine($"✓ Saved app-id marker: {appId} -> {folderPath}");
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error saving app-id marker: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Returns the Intune app id recorded in the folder's marker, or null
        /// if the folder has no marker.
        /// </summary>
        public static string? GetMarkerAppId(string folderPath)
        {
            if (string.IsNullOrEmpty(folderPath))
                return null;
            var marker = ReadMarker(folderPath);
            return string.IsNullOrEmpty(marker?.IntuneAppId) ? null : marker.IntuneAppId;
        }

        /// <summary>
        /// Bulk-writes app-id markers for a set of applications, resolving each via
        /// name/version matching. Skips apps already indexed to an existing folder
        /// and writes the index once at the end.
        /// </summary>
        public static SeedResult SeedMarkers(
            IReadOnlyList<(string appId, string displayName, string? version)> apps,
            IProgress<(int current, int total)>? progress = null)
        {
            var result = new SeedResult { Total = apps.Count };
            var existingIndex = LoadIndex();
            var newEntries = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

            for (int i = 0; i < apps.Count; i++)
            {
                progress?.Report((i + 1, apps.Count));
                var (appId, displayName, version) = apps[i];

                if (string.IsNullOrEmpty(appId))
                {
                    result.NotLocated++;
                    continue;
                }

                // Already indexed to a folder that still exists - nothing to do.
                if (existingIndex.TryGetValue(appId, out var existing)
                    && !string.IsNullOrEmpty(existing)
                    && Directory.Exists(existing))
                {
                    result.AlreadyIndexed++;
                    continue;
                }

                var path = FindApplicationPathAutomatic(displayName, version);
                if (path == null)
                {
                    result.NotLocated++;
                    result.UnlocatedApps.Add(apps[i]);
                    continue;
                }

                try
                {
                    WriteMarkerFile(path, new AppMarker
                    {
                        IntuneAppId = appId,
                        DisplayName = displayName,
                        Version = version ?? "",
                        Updated = DateTime.UtcNow.ToString("o")
                    });
                    newEntries[appId] = path;
                    result.Marked++;
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"Error writing marker for {displayName}: {ex.Message}");
                    result.NotLocated++;
                    result.UnlocatedApps.Add(apps[i]);
                }
            }

            // Merge the new entries into a fresh index read, then write once.
            if (newEntries.Count > 0)
            {
                var index = LoadIndex();
                foreach (var entry in newEntries)
                    index[entry.Key] = entry.Value;
                SaveIndex(index);
            }

            return result;
        }

        /// <summary>
        /// Resolves a package folder from the shared index, confirming the folder
        /// still exists and its marker still matches the requested app id.
        /// </summary>
        private static string? ResolveFromIndex(string appId)
        {
            var index = LoadIndex();
            if (!index.TryGetValue(appId, out var path) || string.IsNullOrEmpty(path))
                return null;

            if (!Directory.Exists(path))
            {
                Debug.WriteLine($"⚠️ Indexed path no longer exists: {path}");
                return null;
            }

            var marker = ReadMarker(path);
            if (marker == null || !string.Equals(marker.IntuneAppId, appId, StringComparison.OrdinalIgnoreCase))
            {
                Debug.WriteLine($"⚠️ Marker missing or mismatched at indexed path: {path}");
                return null;
            }

            return path;
        }

        private static void WriteMarkerFile(string folderPath, AppMarker marker)
        {
            var markerPath = Path.Combine(folderPath, MarkerFileName);

            // A hidden file cannot be overwritten directly - clear attributes first.
            if (File.Exists(markerPath))
                File.SetAttributes(markerPath, FileAttributes.Normal);

            File.WriteAllText(markerPath, JsonSerializer.Serialize(marker, _jsonOptions));
            File.SetAttributes(markerPath, FileAttributes.Hidden);
        }

        private static AppMarker? ReadMarker(string folderPath)
        {
            try
            {
                var markerPath = Path.Combine(folderPath, MarkerFileName);
                if (!File.Exists(markerPath))
                    return null;

                return JsonSerializer.Deserialize<AppMarker>(File.ReadAllText(markerPath));
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error reading app-id marker: {ex.Message}");
                return null;
            }
        }

        private static Dictionary<string, string> LoadIndex()
        {
            try
            {
                if (!File.Exists(IndexFilePath))
                    return new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

                var index = JsonSerializer.Deserialize<Dictionary<string, string>>(File.ReadAllText(IndexFilePath));
                return index == null
                    ? new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
                    : new Dictionary<string, string>(index, StringComparer.OrdinalIgnoreCase);
            }
            catch (Exception ex)
            {
                // A corrupt/unreadable index is non-fatal - markers re-populate it over time.
                Debug.WriteLine($"Error loading app-id index: {ex.Message}");
                return new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            }
        }

        private static void UpsertIndex(string appId, string folderPath)
        {
            // Re-read before writing so concurrent updates from other machines merge.
            var index = LoadIndex();
            index[appId] = folderPath;
            SaveIndex(index);
        }

        private static void SaveIndex(Dictionary<string, string> index)
        {
            try
            {
                File.WriteAllText(IndexFilePath, JsonSerializer.Serialize(index, _jsonOptions));
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error writing app-id index: {ex.Message}");
            }
        }

        public class SeedResult
        {
            public int Total { get; set; }
            public int Marked { get; set; }
            public int AlreadyIndexed { get; set; }
            public int NotLocated { get; set; }
            public List<(string appId, string displayName, string? version)> UnlocatedApps { get; set; } = new();
        }

        private class AppMarker
        {
            public string IntuneAppId { get; set; } = "";
            public string DisplayName { get; set; } = "";
            public string Version { get; set; } = "";
            public string Updated { get; set; } = "";
        }
    }
}