﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

namespace Endpoint_Packaging_Suite.Helpers
{
    /// <summary>
    /// Helper class for extracting icons from executable files (MSI/EXE)
    /// </summary>
    public static class IconExtractor
    {
        private const string TEMP_FOLDER_NAME = "Endpoint_Packaging_Suite";

        /// <summary>
        /// Extracts icon from an EXE or MSI file and saves it as PNG to a temporary location
        /// </summary>
        /// <param name="sourceFilePath">Path to the EXE or MSI file</param>
        /// <returns>Path to the extracted PNG icon, or null if extraction failed</returns>
        public static string? ExtractIconToTemp(string sourceFilePath)
        {
            if (string.IsNullOrEmpty(sourceFilePath) || !File.Exists(sourceFilePath))
            {
                Debug.WriteLine($"IconExtractor: Source file not found: {sourceFilePath}");
                return null;
            }

            try
            {
                // Extract icon from EXE/MSI
                var icon = Icon.ExtractAssociatedIcon(sourceFilePath);
                if (icon == null)
                {
                    Debug.WriteLine($"IconExtractor: Could not extract icon from {sourceFilePath}");
                    return null;
                }

                // Create temp directory
                var tempPath = Path.Combine(Path.GetTempPath(), TEMP_FOLDER_NAME);
                Directory.CreateDirectory(tempPath);

                // Generate unique filename
                var iconFileName = $"{Path.GetFileNameWithoutExtension(sourceFilePath)}_icon.png";
                var iconPath = Path.Combine(tempPath, iconFileName);

                // Convert icon to bitmap and save as PNG
                using (var bitmap = icon.ToBitmap())
                {
                    bitmap.Save(iconPath, ImageFormat.Png);
                }

                Debug.WriteLine($"IconExtractor: Icon extracted successfully to {iconPath}");
                return iconPath;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"IconExtractor: Error extracting icon from {sourceFilePath}: {ex.Message}");
                return null;
            }
        }

        /// <summary>
        /// Copies an extracted icon to a package's Icon folder
        /// </summary>
        /// <param name="extractedIconPath">Path to the extracted PNG icon</param>
        /// <param name="packageFolderPath">Root path of the package</param>
        /// <param name="appName">Application name to use in the icon filename</param>
        /// <returns>True if copy was successful, false otherwise</returns>
        public static bool CopyIconToPackage(string extractedIconPath, string packageFolderPath, string appName)
        {
            if (string.IsNullOrEmpty(extractedIconPath) || !File.Exists(extractedIconPath))
            {
                Debug.WriteLine($"IconExtractor: Extracted icon not found: {extractedIconPath}");
                return false;
            }

            if (string.IsNullOrEmpty(packageFolderPath) || !Directory.Exists(packageFolderPath))
            {
                Debug.WriteLine($"IconExtractor: Package folder not found: {packageFolderPath}");
                return false;
            }

            try
            {
                var iconFolder = Path.Combine(packageFolderPath, "Icon");
                if (!Directory.Exists(iconFolder))
                {
                    Debug.WriteLine($"IconExtractor: Icon folder not found in package: {iconFolder}");
                    return false;
                }

                // Sanitize app name for filename
                var sanitizedAppName = SanitizeFileName(appName);
                var iconFileName = $"{sanitizedAppName}_icon.png";
                var destinationPath = Path.Combine(iconFolder, iconFileName);

                File.Copy(extractedIconPath, destinationPath, overwrite: true);
                Debug.WriteLine($"IconExtractor: Icon copied to package: {destinationPath}");
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"IconExtractor: Error copying icon to package: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Extracts icon from source file and copies it directly to package in one step
        /// </summary>
        /// <param name="sourceFilePath">Path to the EXE or MSI file</param>
        /// <param name="packageFolderPath">Root path of the package</param>
        /// <param name="appName">Application name to use in the icon filename</param>
        /// <returns>Path to the icon in the package, or null if operation failed</returns>
        public static string? ExtractAndCopyToPackage(string sourceFilePath, string packageFolderPath, string appName)
        {
            var tempIconPath = ExtractIconToTemp(sourceFilePath);
            if (tempIconPath == null)
                return null;

            var success = CopyIconToPackage(tempIconPath, packageFolderPath, appName);
            if (!success)
                return null;

            var iconFolder = Path.Combine(packageFolderPath, "Icon");
            var sanitizedAppName = SanitizeFileName(appName);
            return Path.Combine(iconFolder, $"{sanitizedAppName}_icon.png");
        }

        /// <summary>
        /// Sanitizes a filename by removing invalid characters
        /// </summary>
        private static string SanitizeFileName(string fileName)
        {
            if (string.IsNullOrEmpty(fileName))
                return "app";

            var invalidChars = Path.GetInvalidFileNameChars();
            var sanitized = string.Join("_", fileName.Split(invalidChars, StringSplitOptions.RemoveEmptyEntries));
            return string.IsNullOrEmpty(sanitized) ? "app" : sanitized;
        }

        /// <summary>
        /// Cleans up old icon files from the temp directory
        /// </summary>
        /// <param name="olderThanDays">Delete files older than this many days (default: 7)</param>
        public static void CleanupTempIcons(int olderThanDays = 7)
        {
            try
            {
                var tempPath = Path.Combine(Path.GetTempPath(), TEMP_FOLDER_NAME);
                if (!Directory.Exists(tempPath))
                    return;

                var cutoffDate = DateTime.Now.AddDays(-olderThanDays);
                var files = Directory.GetFiles(tempPath, "*_icon.png");
                var deletedCount = 0;

                foreach (var file in files)
                {
                    var fileInfo = new FileInfo(file);
                    if (fileInfo.LastWriteTime < cutoffDate)
                    {
                        File.Delete(file);
                        deletedCount++;
                    }
                }

                if (deletedCount > 0)
                {
                    Debug.WriteLine($"IconExtractor: Cleaned up {deletedCount} old temp icons");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"IconExtractor: Error cleaning temp icons: {ex.Message}");
            }
        }
    }
}