using System;
using System.IO;
using System.Windows;
using Endpoint_Packaging_Suite.Dialogs;
using Microsoft.WindowsAPICodePack.Dialogs;

namespace Endpoint_Packaging_Suite.Helpers
{
    /// <summary>
    /// Helper class for modern folder browsing dialogs using Windows API Code Pack
    /// </summary>
    public static class FolderBrowserHelper
    {
        /// <summary>
        /// Shows a modern folder browser dialog
        /// </summary>
        /// <param name="title">Dialog title</param>
        /// <param name="initialDirectory">Initial directory to show (optional)</param>
        /// <param name="allowNonFileSystemItems">Allow non-file system items (default: false)</param>
        /// <returns>Selected folder path, or null if cancelled</returns>
        public static string? ShowFolderBrowser(
            string title = "Select Folder",
            string? initialDirectory = null,
            bool allowNonFileSystemItems = false)
        {
            try
            {
                using var dialog = new CommonOpenFileDialog
                {
                    Title = title,
                    IsFolderPicker = true,
                    AllowNonFileSystemItems = allowNonFileSystemItems,
                    EnsurePathExists = true,
                    Multiselect = false
                };

                // Set initial directory if provided and valid
                if (!string.IsNullOrEmpty(initialDirectory) && Directory.Exists(initialDirectory))
                {
                    dialog.InitialDirectory = initialDirectory;
                }

                var result = dialog.ShowDialog();

                if (result == CommonFileDialogResult.Ok)
                {
                    return dialog.FileName;
                }

                return null;
            }
            catch (Exception ex)
            {
                // Fall back to basic folder browser if modern dialog fails
                ModernMessageBox.Show(
                    $"Modern folder picker failed: {ex.Message}\nFalling back to basic folder browser.",
                    "Folder Browser",
                    MessageBoxButton.OK,
                    MessageBoxIcon.Information);

                return ShowBasicFolderBrowser(title, initialDirectory);
            }
        }

        /// <summary>
        /// Shows a modern folder browser dialog specifically for package selection
        /// Validates that the selected folder contains a valid PSADT v4 package structure
        /// </summary>
        /// <param name="validatePackageStructure">Function to validate package structure (optional)</param>
        /// <returns>Selected package folder path, or null if cancelled or invalid</returns>
        public static string? ShowPackageFolderBrowser(Func<string, bool>? validatePackageStructure = null, string? initialDirectory = null)
        {
            var selectedPath = ShowFolderBrowser(
                title: "Select Package Folder",
                initialDirectory: initialDirectory,
                allowNonFileSystemItems: false);

            if (string.IsNullOrEmpty(selectedPath))
                return null;

            // If validation function provided, validate the package structure
            if (validatePackageStructure != null)
            {
                if (!validatePackageStructure(selectedPath))
                {
                    ModernMessageBox.Show(
                        "The selected folder does not contain a valid PSADT v4 package structure.\n\n" +
                        "Expected structure:\n" +
                        "- Application folder with PSADT v4 executable:\n" +
                        "  Invoke-AppDeployToolkit.exe + Invoke-AppDeployToolkit.ps1\n" +
                        "- Files folder (optional)\n" +
                        "- SupportFiles folder (optional)",
                        "Invalid Package Structure",
                        MessageBoxButton.OK,
                        MessageBoxIcon.Warning);
                    return null;
                }
            }

            return selectedPath;
        }

        /// <summary>
        /// Fallback basic folder browser using Windows Forms
        /// Used when modern dialog fails
        /// </summary>
        private static string? ShowBasicFolderBrowser(string description, string? selectedPath)
        {
            try
            {
                using var dialog = new System.Windows.Forms.FolderBrowserDialog
                {
                    Description = description,
                    ShowNewFolderButton = false,
                    UseDescriptionForTitle = true
                };

                if (!string.IsNullOrEmpty(selectedPath) && Directory.Exists(selectedPath))
                {
                    dialog.SelectedPath = selectedPath;
                }

                var result = dialog.ShowDialog();

                if (result == System.Windows.Forms.DialogResult.OK)
                {
                    return dialog.SelectedPath;
                }

                return null;
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show(
                    $"Error opening folder browser: {ex.Message}",
                    "Folder Browser Error",
                    MessageBoxButton.OK,
                    MessageBoxIcon.Error);
                return null;
            }
        }

        /// <summary>
        /// Validates PSADT v4 package structure
        /// </summary>
        public static bool ValidatePackageStructure(string packagePath)
        {
            if (string.IsNullOrEmpty(packagePath) || !Directory.Exists(packagePath))
                return false;

            // Check for Application folder
            var applicationFolder = Path.Combine(packagePath, "Application");
            if (!Directory.Exists(applicationFolder))
            {
                // Maybe the selected folder IS the Application folder
                if (HasPSADTExecutable(packagePath))
                {
                    // User selected the Application folder directly
                    return true;
                }

                return false;
            }

            // Check for required PSADT v4 files in Application folder
            return HasPSADTExecutable(applicationFolder);
        }

        /// <summary>
        /// Checks if a folder contains PSADT v4 executable (Invoke-AppDeployToolkit.exe)
        /// </summary>
        private static bool HasPSADTExecutable(string folderPath)
        {
            var v4Exe = Path.Combine(folderPath, "Invoke-AppDeployToolkit.exe");
            var v4Ps1 = Path.Combine(folderPath, "Invoke-AppDeployToolkit.ps1");
            return File.Exists(v4Exe) && File.Exists(v4Ps1);
        }

        /// <summary>
        /// Gets the PSADT v4 executable path from a folder
        /// </summary>
        public static string? GetPSADTExecutablePath(string folderPath)
        {
            if (string.IsNullOrEmpty(folderPath) || !Directory.Exists(folderPath))
                return null;

            var v4Exe = Path.Combine(folderPath, "Invoke-AppDeployToolkit.exe");
            if (File.Exists(v4Exe))
                return v4Exe;

            return null;
        }

        /// <summary>
        /// Gets the PSADT script path from a folder (supports both v4 and v3)
        /// </summary>
        public static string? GetPSADTScriptPath(string folderPath)
        {
            if (string.IsNullOrEmpty(folderPath) || !Directory.Exists(folderPath))
                return null;

            // PSADT v4
            var v4Script = Path.Combine(folderPath, "Invoke-AppDeployToolkit.ps1");
            if (File.Exists(v4Script))
                return v4Script;

            // PSADT v3
            var v3Script = Path.Combine(folderPath, "Deploy-Application.ps1");
            if (File.Exists(v3Script))
                return v3Script;

            return null;
        }

        /// <summary>
        /// Determines if a script is PSADT v3 (Deploy-Application.ps1)
        /// </summary>
        public static bool IsPSADTv3Script(string scriptPath)
        {
            return Path.GetFileName(scriptPath).Equals("Deploy-Application.ps1", StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>
        /// Gets the package root path from a selected folder
        /// Handles cases where user might select Application folder instead of root
        /// </summary>
        public static string GetPackageRootPath(string selectedPath)
        {
            if (string.IsNullOrEmpty(selectedPath))
                return selectedPath;

            // Check if this is the Application folder (has PSADT executable)
            if (HasPSADTExecutable(selectedPath))
            {
                // This is the Application folder, get parent
                var parent = Directory.GetParent(selectedPath);
                if (parent != null)
                    return parent.FullName;
            }

            return selectedPath;
        }
    }
}
