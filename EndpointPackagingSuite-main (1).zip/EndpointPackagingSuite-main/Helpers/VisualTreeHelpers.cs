using System.Collections.Generic;
using System.Windows;
using System.Windows.Media;

namespace Endpoint_Packaging_Suite.Helpers
{
    /// <summary>
    /// Visual-tree traversal helpers for finding descendants of a WPF element by type.
    /// </summary>
    public static class VisualTreeHelpers
    {
        /// <summary>
        /// Returns the first descendant of <paramref name="parent"/> of type T, depth-first,
        /// or null if none is found.
        /// </summary>
        public static T? FindVisualChild<T>(DependencyObject parent) where T : DependencyObject
        {
            if (parent == null) return null;

            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);
                if (child is T found) return found;

                var result = FindVisualChild<T>(child);
                if (result != null) return result;
            }
            return null;
        }

        /// <summary>
        /// Yields every descendant of <paramref name="parent"/> of type T, depth-first.
        /// </summary>
        public static IEnumerable<T> FindVisualChildren<T>(DependencyObject parent) where T : DependencyObject
        {
            if (parent == null) yield break;

            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);
                if (child is T typedChild)
                    yield return typedChild;

                foreach (var childOfChild in FindVisualChildren<T>(child))
                    yield return childOfChild;
            }
        }
    }
}
