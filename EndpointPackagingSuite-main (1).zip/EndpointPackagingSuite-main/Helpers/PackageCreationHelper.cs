using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite.Dialogs;
using Serilog;
using System.Windows;
using System.Windows.Controls;
using Endpoint_Packaging_Suite.Constants;
using Endpoint_Packaging_Suite.Services;

namespace Endpoint_Packaging_Suite.Helpers
{
    public static class PackageCreationHelper
    {
        private static readonly Serilog.ILogger _logger = Log.ForContext(typeof(PackageCreationHelper));
        /// <summary>
        /// Collects and validates PSADT options from the UI
        /// </summary>
        public static PSADTOptions? CollectPSADTOptions(
            bool userInstall,
            PSADTOptions? currentOptions,
            string packageType)
        {
            // If options were configured via dialog, use those as base
            var options = currentOptions ?? new PSADTOptions
            {
                PackageType = packageType
            };

            return options;
        }

        /// <summary>
        /// Shows success UI after package creation
        /// </summary>
        public static void ShowPackageSuccess(
            Border packageStatusPanel,
            TextBlock packageStatusText,
            TextBlock statusText,
            TextBlock packagePathText,
            Button openPackageFolderButton,
            ProgressBar progressBar,
            string currentPackagePath,
            PSADTOptions? psadtOptions)
        {
            packageStatusPanel.Visibility = Visibility.Visible;
            packageStatusText.Text = "✅ Package created successfully!";
            packagePathText.Text = currentPackagePath;
            openPackageFolderButton.Visibility = Visibility.Visible;
            progressBar.IsIndeterminate = true;

            int enabledFeatures = psadtOptions != null ? CountEnabledFeatures(psadtOptions) : 0;
            string featuresText = enabledFeatures > 0 ? $" with {enabledFeatures} PSADT cheatsheet functions" : "";
            statusText.Text = $"Package created successfully{featuresText} • {DateTime.Now:HH:mm:ss}";
        }

        /// <summary>
        /// Counts enabled boolean features in PSADTOptions
        /// </summary>
        public static int CountEnabledFeatures(PSADTOptions options)
        {
            return options.GetEnabledOptionsCount();
        }

        /// <summary>
        /// Updates PSADT summary panel in UI
        /// </summary>
        public static void UpdatePSADTSummary(
            PSADTOptions? currentOptions,
            TextBlock statusText,
            TextBlock selectedOptionsCount,
            TextBlock estimatedScriptSize,
            TextBlock injectionCount,
            UIElement summaryPanel,
            Button configureButton)
        {
            if (currentOptions == null)
            {
                statusText.Text = "Not configured - Click to select deployment options";
                summaryPanel.Visibility = Visibility.Collapsed;
                return;
            }

            // Count selected options
            int count = CountEnabledFeatures(currentOptions);

            // Update UI
            statusText.Text = $"Configured - {count} options selected";
            statusText.Foreground = AppConstants.Colors.SuccessBrush;

            selectedOptionsCount.Text = count.ToString();
            estimatedScriptSize.Text = $"~{8 + count * 2}KB";
            injectionCount.Text = Math.Ceiling(count / 2.0).ToString();

            summaryPanel.Visibility = Visibility.Visible;
            configureButton.Content = "Modify Options";
        }

        /// <summary>
        /// Validates package inputs before generation
        /// </summary>
        public static bool ValidatePackageInputs(string appName)
        {
            if (string.IsNullOrWhiteSpace(appName))
            {
                ModernMessageBox.Show("Please enter an Application Name.", "Validation Error",
                    MessageBoxButton.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Creates ApplicationInfo from UI inputs
        /// </summary>
        public static ApplicationInfo CreateApplicationInfo(
            string appName,
            string manufacturer,
            string version,
            string sourcesPath,
            MsiInfoService.MsiInfo? msiInfo,
            string installContext = "System")
        {
            _logger.Debug("CreateApplicationInfo called with InstallContext: {InstallContext}", installContext);

            var appInfo = new ApplicationInfo
            {
                Name = appName.Trim(),
                Manufacturer = string.IsNullOrWhiteSpace(manufacturer) ? "Unknown" : manufacturer.Trim(),
                Version = string.IsNullOrWhiteSpace(version) ? "1.0.0" : version.Trim(),
                SourcesPath = sourcesPath.Trim(),
                ServiceNowSRI = "",
                InstallContext = installContext
            };

            _logger.Debug("ApplicationInfo created: {AppName} v{Version}, Context: {InstallContext}",
                appInfo.Name, appInfo.Version, appInfo.InstallContext);

            // Include MSI information if available
            if (msiInfo != null && msiInfo.IsValid)
            {
                appInfo.MsiProductCode = msiInfo.ProductCode;
                appInfo.MsiProductVersion = msiInfo.ProductVersion;
                appInfo.MsiUpgradeCode = msiInfo.UpgradeCode;
            }

            return appInfo;
        }
    }
}