using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace Endpoint_Packaging_Suite.Helpers
{
    /// <summary>
    /// Determines the install context (User vs System) for a PSADT package.
    /// PSADT v3 packages: read RequireAdmin from AppDeployToolkitConfig.xml.
    /// PSADT v4 packages: read RequireAdmin from $adtSession in Invoke-AppDeployToolkit.ps1.
    /// </summary>
    public static class InstallContextParser
    {
        /// <summary>
        /// Returns "User" or "System" for the given package root.
        /// Falls back to "System" if no config or script is found, or on parse error.
        /// </summary>
        public static string ExtractFromPackage(string packagePath)
        {
            try
            {
                var applicationFolder = Path.Combine(packagePath, "Application");

                // PSADT v4: extract RequireAdmin from $adtSession hashtable in the script
                var v4ScriptPath = Path.Combine(applicationFolder, "Invoke-AppDeployToolkit.ps1");
                if (File.Exists(v4ScriptPath))
                {
                    return ExtractFromV4Script(v4ScriptPath);
                }

                // PSADT v3: read from XML config
                var configPath = Path.Combine(applicationFolder, "AppDeployToolkit", "AppDeployToolkitConfig.xml");
                if (!File.Exists(configPath))
                {
                    Debug.WriteLine("AppDeployToolkitConfig.xml not found - defaulting to System");
                    return "System";
                }

                var xmlContent = File.ReadAllText(configPath);
                var doc = XDocument.Parse(xmlContent);

                var requireAdminElement = doc.Descendants("Toolkit_RequireAdmin").FirstOrDefault();

                if (requireAdminElement != null)
                {
                    var requireAdminValue = requireAdminElement.Value.Trim();
                    if (requireAdminValue.Equals("False", StringComparison.OrdinalIgnoreCase))
                    {
                        Debug.WriteLine("Detected User Install from config (Toolkit_RequireAdmin=False)");
                        return "User";
                    }
                }

                Debug.WriteLine("Detected System Install from config (Toolkit_RequireAdmin=True or not specified)");
                return "System";
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error extracting install context from config: {ex.Message}");
                return "System";
            }
        }

        /// <summary>
        /// Extracts install context from a PSADT v4 script by reading RequireAdmin from $adtSession.
        /// </summary>
        private static string ExtractFromV4Script(string scriptPath)
        {
            try
            {
                var scriptContent = File.ReadAllText(scriptPath);

                var match = Regex.Match(
                    scriptContent,
                    @"^\s*RequireAdmin\s*=\s*\$(\w+)",
                    RegexOptions.Multiline | RegexOptions.IgnoreCase);

                if (match.Success)
                {
                    var requireAdminValue = match.Groups[1].Value;
                    if (requireAdminValue.Equals("false", StringComparison.OrdinalIgnoreCase))
                    {
                        Debug.WriteLine("Detected User Install from v4 script (RequireAdmin=$false)");
                        return "User";
                    }
                    else
                    {
                        Debug.WriteLine("Detected System Install from v4 script (RequireAdmin=$true)");
                        return "System";
                    }
                }

                Debug.WriteLine("RequireAdmin not found in v4 script - defaulting to System");
                return "System";
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error extracting install context from v4 script: {ex.Message}");
                return "System";
            }
        }
    }
}
