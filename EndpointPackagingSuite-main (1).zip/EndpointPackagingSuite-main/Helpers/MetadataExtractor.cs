using Serilog;
using System.Diagnostics;
using System.IO;

namespace Endpoint_Packaging_Suite.Helpers
{
    /// <summary>
    /// Extracts metadata from EXE files, PowerShell scripts, and filenames.
    /// For MSI files, use MsiInfoService instead.
    /// </summary>
    public static class MetadataExtractor
    {
        private static readonly Serilog.ILogger _logger = Log.ForContext(typeof(MetadataExtractor));

        /// <summary>
        /// Extracts metadata from EXE file version info
        /// </summary>
        public static (string productName, string companyName, string version) ExtractExeMetadata(string exePath)
        {
            try
            {
                FileVersionInfo versionInfo = FileVersionInfo.GetVersionInfo(exePath);

                string? productName = versionInfo.ProductName;
                string? companyName = versionInfo.CompanyName;
                string? version = versionInfo.ProductVersion ?? versionInfo.FileVersion;

                _logger.Debug("Extracted EXE metadata: {ProductName} v{Version} by {CompanyName}",
                    productName, version, companyName);

                return (
                    CleanProductName(productName ?? ""),
                    companyName ?? "",
                    version ?? ""
                );
            }
            catch (Exception ex)
            {
                _logger.Warning(ex, "EXE metadata extraction failed for {ExePath}", exePath);
                return (string.Empty, string.Empty, string.Empty);
            }
        }

        /// <summary>
        /// Cleans common installer suffixes from product names
        /// </summary>
        public static string CleanProductName(string productName)
        {
            if (string.IsNullOrWhiteSpace(productName)) return "";

            return productName
                .Replace(" Setup", "", StringComparison.OrdinalIgnoreCase)
                .Replace(" Installer", "", StringComparison.OrdinalIgnoreCase)
                .Replace(" Installation", "", StringComparison.OrdinalIgnoreCase)
                .Trim();
        }

        /// <summary>
        /// Extracts application name from filename as fallback
        /// </summary>
        public static string ExtractNameFromFilename(string filePath)
        {
            string appName = Path.GetFileNameWithoutExtension(filePath);

            appName = appName
                .Replace("_setup", "", StringComparison.OrdinalIgnoreCase)
                .Replace("Setup", "", StringComparison.OrdinalIgnoreCase)
                .Replace("_installer", "", StringComparison.OrdinalIgnoreCase)
                .Replace("Installer", "", StringComparison.OrdinalIgnoreCase)
                .Replace("_install", "", StringComparison.OrdinalIgnoreCase)
                .Replace("Install", "", StringComparison.OrdinalIgnoreCase)
                .Trim();

            _logger.Debug("Extracted name from filename: {AppName}", appName);
            return appName;
        }

        /// <summary>
        /// Extracts a version number from a filename. Matches dotted-numeric runs
        /// like 13.0.1.0 or 13.0.1.0.24954779. Returns "" if no match.
        /// </summary>
        public static string ExtractVersionFromFilename(string fileName)
        {
            if (string.IsNullOrEmpty(fileName))
                return "";

            try
            {
                var match = System.Text.RegularExpressions.Regex.Match(fileName, @"(\d+\.){1,}\d+");
                if (match.Success)
                    return match.Value;
            }
            catch (Exception ex)
            {
                _logger.Warning(ex, "Error extracting version from filename: {FileName}", fileName);
            }

            return "";
        }

        /// <summary>
        /// Extracts metadata from PSADT PowerShell script (v3 or v4).
        /// v4: Uses $adtSession = @{ AppVendor = 'value' } hashtable format
        /// v3: Uses $appVendor = 'value' variable format
        /// </summary>
        public static Dictionary<string, string> ExtractMetadataFromScript(string scriptPath)
        {
            var metadata = new Dictionary<string, string>();

            try
            {
                var scriptContent = File.ReadAllText(scriptPath);
                var isV3 = Path.GetFileName(scriptPath).Equals("Deploy-Application.ps1", StringComparison.OrdinalIgnoreCase);

                if (isV3)
                {
                    // PSADT v3: Extract from $appVariable = 'value' format
                    metadata["Vendor"] = ExtractPowerShellVariable(scriptContent, "appVendor") ?? "";
                    metadata["AppName"] = ExtractPowerShellVariable(scriptContent, "appName") ?? "";
                    metadata["Version"] = ExtractPowerShellVariable(scriptContent, "appVersion") ?? "";
                    metadata["ScriptDate"] = ExtractPowerShellVariable(scriptContent, "appScriptDate") ?? "";
                    metadata["ScriptAuthor"] = ExtractPowerShellVariable(scriptContent, "appScriptAuthor") ?? "";
                    _logger.Debug("Extracted PSADT v3 metadata from script: {ScriptPath}", scriptPath);
                }
                else
                {
                    // PSADT v4: Extract from $adtSession hashtable
                    metadata["Vendor"] = ExtractHashtableValue(scriptContent, "AppVendor") ?? "";
                    metadata["AppName"] = ExtractHashtableValue(scriptContent, "AppName") ?? "";
                    metadata["Version"] = ExtractHashtableValue(scriptContent, "AppVersion") ?? "";
                    metadata["ScriptDate"] = ExtractHashtableValue(scriptContent, "AppScriptDate") ?? "";
                    metadata["ScriptAuthor"] = ExtractHashtableValue(scriptContent, "AppScriptAuthor") ?? "";
                    _logger.Debug("Extracted PSADT v4 metadata from script: {ScriptPath}", scriptPath);
                }

                // Alternative: Try to find variables in comment blocks if not found
                if (string.IsNullOrEmpty(metadata["AppName"]))
                {
                    var altNameMatch = System.Text.RegularExpressions.Regex.Match(
                        scriptContent, @"#\s*App Name\s*:\s*(.+)$",
                        System.Text.RegularExpressions.RegexOptions.Multiline | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                    if (altNameMatch.Success)
                    {
                        metadata["AppName"] = altNameMatch.Groups[1].Value.Trim();
                        _logger.Debug("Found app name in comments: {AppName}", altNameMatch.Groups[1].Value);
                    }
                }

                _logger.Debug("Script metadata extracted: Vendor={Vendor}, AppName={AppName}, Version={Version}",
                    metadata["Vendor"], metadata["AppName"], metadata["Version"]);
            }
            catch (Exception ex)
            {
                _logger.Warning(ex, "Error extracting metadata from script: {ScriptPath}", scriptPath);
            }

            return metadata;
        }

        /// <summary>
        /// Extracts a value from a PowerShell hashtable (PSADT v4 format)
        /// Matches patterns like: AppVendor = 'value' or AppVendor = "value"
        /// </summary>
        private static string? ExtractHashtableValue(string scriptContent, string keyName)
        {
            // Look for hashtable entry pattern: KeyName = 'value' or KeyName = "value"
            var match = System.Text.RegularExpressions.Regex.Match(
                scriptContent, $@"^\s*{keyName}\s*=\s*['""]([^'""]*)['""]",
                System.Text.RegularExpressions.RegexOptions.Multiline | System.Text.RegularExpressions.RegexOptions.IgnoreCase);

            if (match.Success)
            {
                return match.Groups[1].Value;
            }

            return null;
        }

        /// <summary>
        /// Extracts PowerShell variable value from script content
        /// </summary>
        private static string? ExtractPowerShellVariable(string scriptContent, string variableName)
        {
            // Try standard pattern first
            var match = System.Text.RegularExpressions.Regex.Match(
                scriptContent, $@"\${variableName}\s*=\s*['""]([^'""]*)['""]",
                System.Text.RegularExpressions.RegexOptions.Multiline);

            if (!match.Success)
            {
                // Try pattern with leading whitespace
                match = System.Text.RegularExpressions.Regex.Match(
                    scriptContent, $@"^\s*\${variableName}\s*=\s*['""]([^'""]*)['""]",
                    System.Text.RegularExpressions.RegexOptions.Multiline);
            }

            if (match.Success)
            {
                return match.Groups[1].Value;
            }

            return null;
        }
    }
}