using System;
using System.Text.Json;
namespace Endpoint_Packaging_Suite.Helpers
{
    public static class JsonElementExtensions
    {
        public static int GetSafeInt(this JsonElement element, string propertyName = null)
        {
            var targetElement = propertyName != null && element.TryGetProperty(propertyName, out var prop)
                ? prop
                : element;
            return targetElement.ValueKind switch
            {
                JsonValueKind.Number => targetElement.GetInt32(),
                JsonValueKind.String when int.TryParse(targetElement.GetString(), out var value) => value,
                _ => 0
            };
        }
        public static long GetSafeLong(this JsonElement element, string propertyName = null)
        {
            var targetElement = propertyName != null && element.TryGetProperty(propertyName, out var prop)
                ? prop
                : element;
            return targetElement.ValueKind switch
            {
                JsonValueKind.Number => targetElement.GetInt64(),
                JsonValueKind.String when long.TryParse(targetElement.GetString(), out var value) => value,
                _ => 0L
            };
        }
        public static DateTime GetSafeDateTime(this JsonElement element, string propertyName = null)
        {
            var targetElement = propertyName != null && element.TryGetProperty(propertyName, out var prop)
                ? prop
                : element;
            if (targetElement.ValueKind == JsonValueKind.String)
            {
                var dateString = targetElement.GetString();
                if (!string.IsNullOrEmpty(dateString) && DateTime.TryParse(dateString, out var result))
                    return result;
            }
            return DateTime.MinValue;
        }
        public static bool GetSafeBoolean(this JsonElement element, string propertyName = null)
        {
            var targetElement = propertyName != null && element.TryGetProperty(propertyName, out var prop)
                ? prop
                : element;
            return targetElement.ValueKind == JsonValueKind.True;
        }
    }
}
