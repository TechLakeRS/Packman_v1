using System;
using System.IO;

namespace Endpoint_Packaging_Suite.Helpers
{
    /// <summary>
    /// Locates installed editors. Currently supports Visual Studio Code; falls back
    /// to the OS shell handler when not found.
    /// </summary>
    public static class EditorLocator
    {
        /// <summary>
        /// Returns the absolute path to the VS Code executable if installed, or null.
        /// Checks the standard machine-wide and per-user installation locations.
        /// </summary>
        public static string? FindVSCodePath()
        {
            string[] possiblePaths = {
                @"C:\Program Files\Microsoft VS Code\Code.exe",
                @"C:\Program Files (x86)\Microsoft VS Code\Code.exe",
                Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    @"Programs\Microsoft VS Code\Code.exe")
            };

            foreach (var path in possiblePaths)
            {
                if (File.Exists(path))
                    return path;
            }

            return null;
        }
    }
}
