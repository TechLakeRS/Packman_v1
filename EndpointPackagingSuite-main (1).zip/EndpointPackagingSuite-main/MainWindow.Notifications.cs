using Endpoint_Packaging_Suite.Constants;
using Endpoint_Packaging_Suite.Helpers;
using Endpoint_Packaging_Suite.Managers;
using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite.Services;
using Endpoint_Packaging_Suite.Dialogs;
using Endpoint_Packaging_Suite.Views;
using Microsoft.Extensions.DependencyInjection;
using Serilog;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Endpoint_Packaging_Suite
{
    public partial class MainWindow
    {
        private void OpenStatusPanel()
        {
            StatusPanel.Visibility = Visibility.Visible;

            // Slide in animation
            var slideIn = new System.Windows.Media.Animation.DoubleAnimation
            {
                From = 400,
                To = 0,
                Duration = TimeSpan.FromMilliseconds(300),
                EasingFunction = new System.Windows.Media.Animation.CubicEase { EasingMode = System.Windows.Media.Animation.EasingMode.EaseOut }
            };

            StatusPanelTransform.BeginAnimation(System.Windows.Media.TranslateTransform.XProperty, slideIn);
        }

        private void NotificationsButton_Click(object sender, RoutedEventArgs e)
        {
            OpenStatusPanel();
        }

        private void CloseStatusPanel_Click(object sender, RoutedEventArgs e)
        {
            // Slide out animation
            var slideOut = new System.Windows.Media.Animation.DoubleAnimation
            {
                From = 0,
                To = 400,
                Duration = TimeSpan.FromMilliseconds(300),
                EasingFunction = new System.Windows.Media.Animation.CubicEase { EasingMode = System.Windows.Media.Animation.EasingMode.EaseIn }
            };

            slideOut.Completed += (s, args) =>
            {
                StatusPanel.Visibility = Visibility.Collapsed;
            };

            StatusPanelTransform.BeginAnimation(System.Windows.Media.TranslateTransform.XProperty, slideOut);
        }

        private void UpdateNotificationHistory()
        {
            Dispatcher.Invoke(() =>
            {
                var history = _notificationService!.History.Select(h => new NotificationHistoryItemViewModel(h)).ToList();
                NotificationHistoryList.ItemsSource = history;
            });
        }

        private void RemoveNotificationButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is System.Windows.Controls.Button button && button.Tag is string notificationId)
            {
                _notificationService!.RemoveNotification(notificationId);
            }
        }

        private void ClearAllNotificationsButton_Click(object sender, RoutedEventArgs e)
        {
            _notificationService!.ClearAllNotifications();
        }
    }

    // ViewModel for notification history display
    public class NotificationHistoryItemViewModel
    {
        private readonly NotificationHistoryItem _item;

        public NotificationHistoryItemViewModel(NotificationHistoryItem item)
        {
            _item = item;
        }

        public string Id => _item.Id;

        // Use the TypeIcon from NotificationHistoryItem which returns Segoe MDL2 Assets codes
        public string TypeIcon => _item.TypeIcon;

        public string Title => _item.Title;
        public string Message => _item.Message;
        public string TimeAgo => _item.TimeAgo;
        public string Duration => _item.Duration;
        public Visibility HasMessage => string.IsNullOrEmpty(_item.Message) ? Visibility.Collapsed : Visibility.Visible;
    }
}
