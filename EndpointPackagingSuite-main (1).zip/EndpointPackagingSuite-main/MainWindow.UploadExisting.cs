using Endpoint_Packaging_Suite.Constants;
using Endpoint_Packaging_Suite.Helpers;
using Endpoint_Packaging_Suite.Managers;
using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite.Services;
using Endpoint_Packaging_Suite.Dialogs;
using Endpoint_Packaging_Suite.Views;
using Microsoft.Extensions.DependencyInjection;
using Serilog;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Endpoint_Packaging_Suite
{
    public partial class MainWindow
    {
        private void BrowseDeployExeButton_Click(object sender, RoutedEventArgs e)
        {
            // Use modern folder browser for better UX - default to IntuneApplications path
            var intuneAppsPath = _settingsService?.Settings?.NetworkPaths?.IntuneApplications;
            var selectedPath = FolderBrowserHelper.ShowPackageFolderBrowser(
                validatePackageStructure: FolderBrowserHelper.ValidatePackageStructure,
                initialDirectory: intuneAppsPath);

            if (string.IsNullOrEmpty(selectedPath))
                return;

            // Get the actual package root (in case user selected Application folder)
            var packageRoot = FolderBrowserHelper.GetPackageRootPath(selectedPath);

            // Find PSADT executable in the Application folder (supports both v3 and v4)
            var applicationFolder = Path.Combine(packageRoot, "Application");
            string? psadtExePath;

            if (Directory.Exists(applicationFolder))
            {
                psadtExePath = FolderBrowserHelper.GetPSADTExecutablePath(applicationFolder);
            }
            else
            {
                // Maybe the package root IS the application folder
                psadtExePath = FolderBrowserHelper.GetPSADTExecutablePath(packageRoot);
            }

            if (!string.IsNullOrEmpty(psadtExePath) && File.Exists(psadtExePath))
            {
                ProcessSelectedDeployExe(psadtExePath);
            }
            else
            {
                ShowValidationError("PSADT executable not found. Expected Invoke-AppDeployToolkit.exe (v4).");
            }
        }

        private async void UploadToIntune_Click(object sender, RoutedEventArgs e)

        {
            try

            {
                // PackageFolderPath on the ViewModel is already the package root
                var packagePath = _uploadPackageViewModel?.PackageFolderPath ?? "";

                // Determine install context from user's checkbox selection
                var isUserInstall = ExistingUserInstallToggle.IsChecked == true;
                var installContext = isUserInstall ? "User" : "System";
                Debug.WriteLine($"📋 Install context from user selection: '{installContext}'");

                // Modify the AppDeployToolkitConfig.xml to match the user's selection
                // This ensures the package config reflects the install context
                if (_psadtGenerator != null)
                {
                    await _psadtGenerator.ModifyConfigForUserInstallAsync(packagePath, isUserInstall);
                    Debug.WriteLine($"📋 Updated AppDeployToolkitConfig.xml - RequireAdmin={!isUserInstall}");
                }

                var appInfo = new ApplicationInfo

                {

                    Name = ExistingAppName.Text.Trim(),

                    Manufacturer = ExistingVendor.Text.Trim(),

                    Version = ExistingVersion.Text.Trim(),

                    SourcesPath = _uploadPackageViewModel?.PackageFolderPath ?? "",

                    InstallContext = installContext,

                };



                // Open upload wizard with all the data

                // Create toast notification BEFORE showing wizard
                var notificationId = _notificationService!.ShowInProgress(
                    $"Uploading {appInfo.Name}",
                    "Starting upload...",
                    0
                );

                var uploadWizard = new IntuneUploadWizard

                {

                    Owner = this,

                    ApplicationInfo = appInfo,

                    PackagePath = packagePath,

                    NotificationId = notificationId  // Pass notification ID to wizard

                };



                // Pre-populate detection rules
                // First check if there are cached rules from remote testing in package metadata
                var cachedRules = DetectionRulesCache.GetRulesFromPackage(packagePath, out string computerName);
                if (cachedRules != null && cachedRules.Count > 0)
                {
                    Debug.WriteLine($"Using {cachedRules.Count} cached detection rules from package metadata (discovered on {computerName})");
                    var rulesCollection = new ObservableCollection<DetectionRule>(cachedRules);
                    uploadWizard.UpdateDetectionRules(rulesCollection);
                }
                else if (_uploadPackageViewModel != null && _uploadPackageViewModel.DetectionRules.Count > 0)
                {
                    uploadWizard.UpdateDetectionRules(_uploadPackageViewModel.DetectionRules);
                }



                // If we have an icon, pass it to the wizard

                if (!string.IsNullOrEmpty(_uploadPackageViewModel?.SelectedIconPath))

                {

                    // The wizard will handle the icon through the AppDetailsStep

                }



                // Show wizard (it will close immediately after user clicks Upload)

                if (uploadWizard.ShowDialog() == true)

                {

                    // Wizard closed - upload is now running in background
                    // Note: notification was already created above and passed to wizard

                    // Reset form immediately - user can continue working

                    ResetUploadExistingForm();



                    // Monitor background upload without blocking UI thread

                    if (uploadWizard.UploadTask != null)

                    {

                        _ = Task.Run(async () =>

                        {

                            try

                            {

                                await uploadWizard.UploadTask;

                                // Success notification is shown by ReviewUploadStep

                                await Dispatcher.InvokeAsync(() =>

                                {

                                    _notificationService!.CloseToast(notificationId);

                                });

                            }

                            catch (Exception uploadEx)

                            {

                                // Error notification is shown by ReviewUploadStep

                                await Dispatcher.InvokeAsync(() =>

                                {

                                    _notificationService!.CloseToast(notificationId);

                                });

                                Debug.WriteLine($"Background upload failed: {uploadEx.Message}");

                            }

                        });

                    }

                }

            }

            catch (Exception ex)

            {

                // Show error notification (doesn't auto-close)

                _notificationService!.ShowError(

                    "Upload Failed",

                    ex.Message);
            }
        }

        private void ShowAllSections()
        {
            AppInfoSection.Visibility = Visibility.Visible;
            MetadataPlaceholder.Visibility = Visibility.Collapsed;
        }

        private void HideAllSections()
        {
            AppInfoSection.Visibility = Visibility.Collapsed;
            MetadataPlaceholder.Visibility = Visibility.Visible;
        }

        private void ShowValidationSuccess()
        {
            PackageValidationStatus.Visibility = Visibility.Visible;
            ValidationIcon.Text = "\uE73E"; // Checkmark - Segoe MDL2 Assets
            ValidationIcon.Foreground = AppConstants.Colors.SuccessBrush;
            ValidationTitle.Text = "Valid Package Detected";
            ValidationMessage.Text = "Successfully extracted metadata from PSADT script";
        }

        private void ShowValidationError(string message)
        {
            PackageValidationStatus.Visibility = Visibility.Visible;
            ValidationIcon.Text = "\uE711"; // Error/Cancel - Segoe MDL2 Assets
            ValidationIcon.Foreground = AppConstants.Colors.ErrorBrush;
            ValidationTitle.Text = "Invalid Selection";
            ValidationMessage.Text = message;
        }

        private void ValidateUploadButton()
        {
            bool isValid = !string.IsNullOrWhiteSpace(ExistingAppName.Text) &&
                           !string.IsNullOrWhiteSpace(ExistingVendor.Text) &&
                           !string.IsNullOrWhiteSpace(ExistingVersion.Text);

            UploadToIntuneButton.IsEnabled = isValid;

            if (isValid)
            {
                ReadyStatusText.Text = "Ready to upload to Microsoft Intune";
                ValidationSummary.Text = "All required information provided";
                ValidationSummary.Foreground = AppConstants.Colors.SuccessBrush;
                ReadyStatusIcon.Foreground = AppConstants.Colors.SuccessBrush;
            }

        }

        private void ResetUploadExistingForm()
        {
            _uploadPackageViewModel?.ResetForm();

            PackageValidationStatus.Visibility = Visibility.Collapsed;
            HideAllSections();
        }

        private async void ProcessSelectedDeployExe(string deployExePath)
        {
            try
            {
                // Validate it's a valid PSADT executable (v4)
                var fileName = Path.GetFileName(deployExePath);
                var isV4 = fileName.Equals("Invoke-AppDeployToolkit.exe", StringComparison.OrdinalIgnoreCase);

                if (!isV4)
                {
                    ShowValidationError("Please select a valid PSADT executable (Invoke-AppDeployToolkit.exe)");
                    return;
                }

                // Get the folder path - need to go up one level to package root
                var applicationFolder = Path.GetDirectoryName(deployExePath);
                var packageRoot = Path.GetDirectoryName(applicationFolder) ?? "";

                if (_uploadPackageViewModel != null)
                {
                    _uploadPackageViewModel.PackageFolderPath = packageRoot;
                    _uploadPackageViewModel.DeployExePath = deployExePath;
                }

                // Look for the corresponding .ps1 script in the same folder as the exe
                var scriptName = "Invoke-AppDeployToolkit.ps1";
                var scriptPath = Path.Combine(applicationFolder ?? "", scriptName);

                if (!File.Exists(scriptPath))
                {
                    ShowValidationError($"{scriptName} not found in the same folder");
                    HideAllSections();
                    return;
                }

                // For existing packages on share: always extract from PSADT script
                // These are legacy packages that don't have package-metadata.json
                ExtractMetadataFromScript(scriptPath);

                // Auto-populate the User Install checkbox based on the package config
                var detectedInstallContext = InstallContextParser.ExtractFromPackage(packageRoot);
                if (_uploadPackageViewModel != null)
                {
                    _uploadPackageViewModel.UserInstall = detectedInstallContext == "User";
                }
                Debug.WriteLine($"📋 Auto-detected install context from package: '{detectedInstallContext}'");

                ShowValidationSuccess();
                ShowAllSections();
                CheckForMsiInFiles();
                ValidateUploadButton();
            }
            catch (Exception ex)
            {
                ShowValidationError($"Error processing file: {ex.Message}");
                HideAllSections();
            }
        }

        private void ExtractMetadataFromScript(string scriptPath)
        {
            try
            {
                var metadata = MetadataExtractor.ExtractMetadataFromScript(scriptPath);

                if (_uploadPackageViewModel == null) return;

                _uploadPackageViewModel.Manufacturer = metadata.GetValueOrDefault("Vendor", "");
                _uploadPackageViewModel.AppName = metadata.GetValueOrDefault("AppName", "");
                _uploadPackageViewModel.Version = metadata.GetValueOrDefault("Version", "");
                _uploadPackageViewModel.ScriptDate = metadata.GetValueOrDefault("ScriptDate", "");
                _uploadPackageViewModel.ScriptAuthor = metadata.GetValueOrDefault("ScriptAuthor", "");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error extracting metadata: {ex.Message}");
                ModernMessageBox.Show($"Warning: Could not extract all metadata from script.\n\nPlease fill in the missing fields manually.",
                    "Partial Data Extraction", MessageBoxButton.OK, MessageBoxIcon.Information);
            }
        }

        private void CheckForMsiInFiles()
        {
            try
            {
                if (_uploadPackageViewModel == null) return;

                var filesFolder = Path.Combine(_uploadPackageViewModel.PackageFolderPath, "Application", "Files");
                if (Directory.Exists(filesFolder))
                {
                    var msiFiles = Directory.GetFiles(filesFolder, "*.msi", SearchOption.TopDirectoryOnly);
                    if (msiFiles.Length > 0)
                    {
                        var msiInfo = MsiInfoService.ExtractMsiInfo(msiFiles[0]);
                        if (msiInfo != null && msiInfo.IsValid)
                        {
                            // Auto-add standardized File version detection rule (from MSI version info)
                            _uploadPackageViewModel.DetectionRules.Clear();
                            _uploadPackageViewModel.DetectionRules.Add(new DetectionRule
                            {
                                Type = DetectionRuleType.File,
                                Path = "%ProgramFiles%",
                                FileOrFolderName = $"{_uploadPackageViewModel.AppName}.exe",
                                DetectionType = "version",
                                Operator = "greaterThanOrEqual",
                                DetectionValue = string.IsNullOrEmpty(msiInfo.ProductVersion) ? _uploadPackageViewModel.Version : msiInfo.ProductVersion,
                                CheckVersion = true,
                                Check32BitOn64System = true
                            });

                            Debug.WriteLine($"Auto-added File detection rule from MSI version: {msiInfo.ProductVersion}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error checking for MSI: {ex.Message}");
            }
        }

        private void OpenExistingScriptButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string? exePath = ExistingDeployExePath.Text;

                if (string.IsNullOrEmpty(exePath))
                {
                    ModernMessageBox.Show("Please select a package first.", "No Package",
                        MessageBoxButton.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Get the folder containing the exe, then find the PSADT script in the same folder
                var applicationFolder = Path.GetDirectoryName(exePath);
                var scriptPath = FolderBrowserHelper.GetPSADTScriptPath(applicationFolder ?? "");

                if (string.IsNullOrEmpty(scriptPath) || !File.Exists(scriptPath))
                {
                    ModernMessageBox.Show("PSADT script not found.", "File Not Found",
                        MessageBoxButton.OK, MessageBoxIcon.Warning);
                    return;
                }

                var vsCodePath = EditorLocator.FindVSCodePath();
                if (string.IsNullOrEmpty(vsCodePath))
                {
                    // Fall back to default shell handler
                    Process.Start(new ProcessStartInfo
                    {
                        FileName = scriptPath,
                        UseShellExecute = true
                    });
                }
                else
                {
                    Process.Start(new ProcessStartInfo
                    {
                        FileName = vsCodePath,
                        Arguments = $"\"{scriptPath}\"",
                        UseShellExecute = true
                    });
                }
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error opening script: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxIcon.Error);
            }
        }
    }
}
