param(
    [Parameter(Mandatory=$true)]
    [string]$CatalogPath,
    [Parameter(Mandatory=$false)]
    [string]$OriginalPath
)

$ErrorActionPreference = 'Continue'  # Changed from 'Stop' to handle unsigned files
Write-Host "STARTED:$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"

if (-not (Test-Path $CatalogPath)) {
    Write-Error "Catalog file not found: $CatalogPath"
    exit 1
}

try {
    # Get file info
    $fileInfo = Get-Item $CatalogPath
    Write-Host "FILE_SIZE:$($fileInfo.Length)"
    
    # Check signature - this tells us if catalog is signed, not if it's valid
    $sig = Get-AuthenticodeSignature -FilePath $CatalogPath -ErrorAction SilentlyContinue
    Write-Host "SIGNATURE:$($sig.Status)"
    if ($sig.StatusMessage) {
        Write-Host "SIGNATURE_MESSAGE:$($sig.StatusMessage)"
    }
    
    # Initialize variables
    $catalogValid = $false
    $catalogItems = @()
    $statusDetermined = $false
    
    # Try Test-FileCatalog first (this determines actual validity)
    Write-Host "Attempting Test-FileCatalog..."
    try {
        # Use a job with timeout to avoid hanging
        $job = Start-Job -ScriptBlock {
            param($path)
            $ErrorActionPreference = 'Stop'
            $ProgressPreference = 'SilentlyContinue'
            
            # Test-FileCatalog returns Valid/NotValid status
            $result = Test-FileCatalog -Path $path -Detailed -ErrorAction Stop
            return $result
        } -ArgumentList $CatalogPath
        
        # Wait for job with timeout
        $completed = $job | Wait-Job -Timeout 15
        
        if ($completed) {
            $result = Receive-Job -Job $job -ErrorAction SilentlyContinue
            if ($result) {
                # Test-FileCatalog Status is what determines if catalog is valid
                $catalogValid = ($result.Status -eq 'Valid')
                $statusDetermined = $true
                Write-Host "CATALOG_STATUS:$($result.Status)"
                
                if ($result.CatalogItems) {
                    $catalogItems = $result.CatalogItems
                    Write-Host "METHOD:Test-FileCatalog"
                }
            }
        } else {
            Write-Host "Test-FileCatalog timed out after 15 seconds"
            Stop-Job -Job $job -Force
        }
        Remove-Job -Job $job -Force -ErrorAction SilentlyContinue
    } catch {
        Write-Host "Test-FileCatalog error: $_"
    }
    
    # If Test-FileCatalog didn't work, try alternative validation
    if (-not $statusDetermined) {
        Write-Host "Trying alternative validation..."
        
        # For unsigned catalogs, we can still validate structure
        try {
            # Try certutil to validate catalog structure
            $tempFile = [System.IO.Path]::GetTempFileName()
            $errorFile = [System.IO.Path]::GetTempFileName()
            
            $certutilProcess = Start-Process -FilePath "certutil.exe" `
                -ArgumentList "-dump", "`"$CatalogPath`"" `
                -NoNewWindow -Wait -PassThru `
                -RedirectStandardOutput $tempFile `
                -RedirectStandardError $errorFile
            
            if ($certutilProcess.ExitCode -eq 0) {
                $certutilOutput = Get-Content $tempFile -Raw
                $certutilError = Get-Content $errorFile -Raw
                
                # If certutil can parse it, it's a valid catalog structure
                if ($certutilOutput -match "CertUtil:" -and -not ($certutilError -match "ERROR")) {
                    $catalogValid = $true
                    $statusDetermined = $true
                    Write-Host "CATALOG_STATUS:Valid (structure verified)"
                    
                    # Try to extract catalog items from certutil output
                    $memberPattern = '(?ms)Name:\s*(.+?)\r?\n.*?Value:\s*([0-9a-fA-F\s]+)'
                    $altPattern = '(?ms)File:\s*(.+?)\r?\n.*?Hash:\s*([0-9a-fA-F]+)'
                    
                    $matches = [regex]::Matches($certutilOutput, $memberPattern)
                    if ($matches.Count -eq 0) {
                        $matches = [regex]::Matches($certutilOutput, $altPattern)
                    }
                    
                    foreach ($match in $matches) {
                        if ($match.Groups.Count -ge 3) {
                            $filePath = $match.Groups[1].Value.Trim()
                            $hashValue = $match.Groups[2].Value -replace '\s', ''
                            
                            if ($filePath -and $hashValue) {
                                $catalogItems += [PSCustomObject]@{
                                    Path = $filePath
                                    Hash = $hashValue
                                }
                            }
                        }
                    }
                    
                    if ($catalogItems.Count -gt 0) {
                        Write-Host "METHOD:Certutil"
                    }
                }
            }
            
            Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
            Remove-Item $errorFile -Force -ErrorAction SilentlyContinue
        } catch {
            Write-Host "Certutil validation error: $_"
        }
    }
    
    # If still no status, check file structure
    if (-not $statusDetermined) {
        try {
            $bytes = [System.IO.File]::ReadAllBytes($CatalogPath)
            if ($bytes.Length -gt 100) {
                # Check for ASN.1 DER encoding (catalog files start with 0x30 0x82)
                if ($bytes[0] -eq 0x30 -and $bytes[1] -eq 0x82) {
                    $catalogValid = $true
                    Write-Host "CATALOG_STATUS:Valid (ASN.1 structure detected)"
                } else {
                    Write-Host "CATALOG_STATUS:Invalid (not a catalog file)"
                }
            } else {
                Write-Host "CATALOG_STATUS:Invalid (file too small)"
            }
        } catch {
            Write-Host "File structure check error: $_"
            Write-Host "CATALOG_STATUS:Unknown"
        }
    }
    
    # Output final status (catalog validity, not signature status)
    if ($catalogValid) {
        Write-Host "STATUS:Valid"
    } else {
        Write-Host "STATUS:Invalid"
    }
    
    # Output item count and items
    Write-Host "ITEM_COUNT:$($catalogItems.Count)"
    
    if ($catalogItems.Count -gt 0) {
        foreach ($item in $catalogItems) {
            $displayPath = $item.Path
            
            # Adjust path if using original path
            if ($OriginalPath -and ($CatalogPath -ne $OriginalPath)) {
                if (-not [System.IO.Path]::IsPathRooted($displayPath)) {
                    $catalogDir = [System.IO.Path]::GetDirectoryName($OriginalPath)
                    $displayPath = [System.IO.Path]::Combine($catalogDir, $displayPath)
                }
            }
            
            Write-Host "ITEM:$displayPath|$($item.Hash)"
        }
    } else {
        if ($catalogValid) {
            Write-Host "WARNING:Catalog is valid but unable to retrieve file list"
        } else {
            Write-Host "WARNING:Invalid catalog or unable to parse"
        }
    }
    
} catch {
    Write-Host "ERROR:$($_.Exception.Message)"
    Write-Host "STATUS:Error"
    exit 1
}

Write-Host "COMPLETED:$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
exit 0
# SIG # Begin signature block
# MIInygYJKoZIhvcNAQcCoIInuzCCJ7cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBHBkDtqItuhKLQ
# y+6TEnB1Liqk7On80Ut0Deoz3CBmj6CCIdswggWNMIIEdaADAgECAhAOmxiO+dAt
# 5+/bUOIIQBhaMA0GCSqGSIb3DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNV
# BAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBa
# Fw0zMTExMDkyMzU5NTlaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lD
# ZXJ0IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoC
# ggIBAL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3E
# MB/zG6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKy
# unWZanMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsF
# xl7sWxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU1
# 5zHL2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJB
# MtfbBHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObUR
# WBf3JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6
# nj3cAORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxB
# YKqxYxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5S
# UUd0viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+x
# q4aLT8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIB
# NjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwP
# TzAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMC
# AYYweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdp
# Y2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0
# aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENB
# LmNybDARBgNVHSAECjAIMAYGBFUdIAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0Nc
# Vec4X6CjdBs9thbX979XB72arKGHLOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnov
# Lbc47/T/gLn4offyct4kvFIDyE7QKt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65Zy
# oUi0mcudT6cGAxN3J0TU53/oWajwvy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFW
# juyk1T3osdz9HNj0d1pcVIxv76FQPfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPF
# mCLBsln1VWvPJ6tsds5vIy30fnFqI2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9z
# twGpn1eqXijiuZQwgga0MIIEnKADAgECAhANx6xXBf8hmS5AQyIMOkmGMA0GCSqG
# SIb3DQEBCwUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMx
# GTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRy
# dXN0ZWQgUm9vdCBHNDAeFw0yNTA1MDcwMDAwMDBaFw0zODAxMTQyMzU5NTlaMGkx
# CzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4
# RGlnaUNlcnQgVHJ1c3RlZCBHNCBUaW1lU3RhbXBpbmcgUlNBNDA5NiBTSEEyNTYg
# MjAyNSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC0eDHTCphB
# cr48RsAcrHXbo0ZodLRRF51NrY0NlLWZloMsVO1DahGPNRcybEKq+RuwOnPhof6p
# vF4uGjwjqNjfEvUi6wuim5bap+0lgloM2zX4kftn5B1IpYzTqpyFQ/4Bt0mAxAHe
# HYNnQxqXmRinvuNgxVBdJkf77S2uPoCj7GH8BLuxBG5AvftBdsOECS1UkxBvMgEd
# gkFiDNYiOTx4OtiFcMSkqTtF2hfQz3zQSku2Ws3IfDReb6e3mmdglTcaarps0wjU
# jsZvkgFkriK9tUKJm/s80FiocSk1VYLZlDwFt+cVFBURJg6zMUjZa/zbCclF83bR
# VFLeGkuAhHiGPMvSGmhgaTzVyhYn4p0+8y9oHRaQT/aofEnS5xLrfxnGpTXiUOeS
# LsJygoLPp66bkDX1ZlAeSpQl92QOMeRxykvq6gbylsXQskBBBnGy3tW/AMOMCZIV
# NSaz7BX8VtYGqLt9MmeOreGPRdtBx3yGOP+rx3rKWDEJlIqLXvJWnY0v5ydPpOjL
# 6s36czwzsucuoKs7Yk/ehb//Wx+5kMqIMRvUBDx6z1ev+7psNOdgJMoiwOrUG2Zd
# SoQbU2rMkpLiQ6bGRinZbI4OLu9BMIFm1UUl9VnePs6BaaeEWvjJSjNm2qA+sdFU
# eEY0qVjPKOWug/G6X5uAiynM7Bu2ayBjUwIDAQABo4IBXTCCAVkwEgYDVR0TAQH/
# BAgwBgEB/wIBADAdBgNVHQ4EFgQU729TSunkBnx6yuKQVvYv1Ensy04wHwYDVR0j
# BBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMGA1Ud
# JQQMMAoGCCsGAQUFBwMIMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0
# cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0
# cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNVHR8E
# PDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVz
# dGVkUm9vdEc0LmNybDAgBgNVHSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEw
# DQYJKoZIhvcNAQELBQADggIBABfO+xaAHP4HPRF2cTC9vgvItTSmf83Qh8WIGjB/
# T8ObXAZz8OjuhUxjaaFdleMM0lBryPTQM2qEJPe36zwbSI/mS83afsl3YTj+IQhQ
# E7jU/kXjjytJgnn0hvrV6hqWGd3rLAUt6vJy9lMDPjTLxLgXf9r5nWMQwr8Myb9r
# EVKChHyfpzee5kH0F8HABBgr0UdqirZ7bowe9Vj2AIMD8liyrukZ2iA/wdG2th9y
# 1IsA0QF8dTXqvcnTmpfeQh35k5zOCPmSNq1UH410ANVko43+Cdmu4y81hjajV/gx
# dEkMx1NKU4uHQcKfZxAvBAKqMVuqte69M9J6A47OvgRaPs+2ykgcGV00TYr2Lr3t
# y9qIijanrUR3anzEwlvzZiiyfTPjLbnFRsjsYg39OlV8cipDoq7+qNNjqFzeGxcy
# tL5TTLL4ZaoBdqbhOhZ3ZRDUphPvSRmMThi0vw9vODRzW6AxnJll38F0cuJG7uEB
# YTptMSbhdhGQDpOXgpIUsWTjd6xpR6oaQf/DJbg3s6KCLPAlZ66RzIg9sC+NJpud
# /v4+7RWsWCiKi9EOLLHfMR2ZyJ/+xhCx9yHbxtl5TPau1j/1MIDpMPx0LckTetiS
# uEtQvLsNz3Qbp7wGWqbIiOWCnb5WqxL3/BAPvIXKUjPSxyZsq8WhbaM2tszWkPZP
# ubdcMIIG7TCCBNWgAwIBAgIQCoDvGEuN8QWC0cR2p5V0aDANBgkqhkiG9w0BAQsF
# ADBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNV
# BAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgVGltZVN0YW1waW5nIFJTQTQwOTYgU0hB
# MjU2IDIwMjUgQ0ExMB4XDTI1MDYwNDAwMDAwMFoXDTM2MDkwMzIzNTk1OVowYzEL
# MAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTswOQYDVQQDEzJE
# aWdpQ2VydCBTSEEyNTYgUlNBNDA5NiBUaW1lc3RhbXAgUmVzcG9uZGVyIDIwMjUg
# MTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBANBGrC0Sxp7Q6q5gVrMr
# V7pvUf+GcAoB38o3zBlCMGMyqJnfFNZx+wvA69HFTBdwbHwBSOeLpvPnZ8ZN+vo8
# dE2/pPvOx/Vj8TchTySA2R4QKpVD7dvNZh6wW2R6kSu9RJt/4QhguSssp3qome7M
# rxVyfQO9sMx6ZAWjFDYOzDi8SOhPUWlLnh00Cll8pjrUcCV3K3E0zz09ldQ//nBZ
# ZREr4h/GI6Dxb2UoyrN0ijtUDVHRXdmncOOMA3CoB/iUSROUINDT98oksouTMYFO
# nHoRh6+86Ltc5zjPKHW5KqCvpSduSwhwUmotuQhcg9tw2YD3w6ySSSu+3qU8DD+n
# igNJFmt6LAHvH3KSuNLoZLc1Hf2JNMVL4Q1OpbybpMe46YceNA0LfNsnqcnpJeIt
# K/DhKbPxTTuGoX7wJNdoRORVbPR1VVnDuSeHVZlc4seAO+6d2sC26/PQPdP51ho1
# zBp+xUIZkpSFA8vWdoUoHLWnqWU3dCCyFG1roSrgHjSHlq8xymLnjCbSLZ49kPmk
# 8iyyizNDIXj//cOgrY7rlRyTlaCCfw7aSUROwnu7zER6EaJ+AliL7ojTdS5PWPsW
# eupWs7NpChUk555K096V1hE0yZIXe+giAwW00aHzrDchIc2bQhpp0IoKRR7YufAk
# prxMiXAJQ1XCmnCfgPf8+3mnAgMBAAGjggGVMIIBkTAMBgNVHRMBAf8EAjAAMB0G
# A1UdDgQWBBTkO/zyMe39/dfzkXFjGVBDz2GM6DAfBgNVHSMEGDAWgBTvb1NK6eQG
# fHrK4pBW9i/USezLTjAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0lAQH/BAwwCgYIKwYB
# BQUHAwgwgZUGCCsGAQUFBwEBBIGIMIGFMCQGCCsGAQUFBzABhhhodHRwOi8vb2Nz
# cC5kaWdpY2VydC5jb20wXQYIKwYBBQUHMAKGUWh0dHA6Ly9jYWNlcnRzLmRpZ2lj
# ZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNFRpbWVTdGFtcGluZ1JTQTQwOTZTSEEy
# NTYyMDI1Q0ExLmNydDBfBgNVHR8EWDBWMFSgUqBQhk5odHRwOi8vY3JsMy5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRUaW1lU3RhbXBpbmdSU0E0MDk2U0hB
# MjU2MjAyNUNBMS5jcmwwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcB
# MA0GCSqGSIb3DQEBCwUAA4ICAQBlKq3xHCcEua5gQezRCESeY0ByIfjk9iJP2zWL
# pQq1b4URGnwWBdEZD9gBq9fNaNmFj6Eh8/YmRDfxT7C0k8FUFqNh+tshgb4O6Lgj
# g8K8elC4+oWCqnU/ML9lFfim8/9yJmZSe2F8AQ/UdKFOtj7YMTmqPO9mzskgiC3Q
# YIUP2S3HQvHG1FDu+WUqW4daIqToXFE/JQ/EABgfZXLWU0ziTN6R3ygQBHMUBaB5
# bdrPbF6MRYs03h4obEMnxYOX8VBRKe1uNnzQVTeLni2nHkX/QqvXnNb+YkDFkxUG
# tMTaiLR9wjxUxu2hECZpqyU1d0IbX6Wq8/gVutDojBIFeRlqAcuEVT0cKsb+zJNE
# suEB7O7/cuvTQasnM9AWcIQfVjnzrvwiCZ85EE8LUkqRhoS3Y50OHgaY7T/lwd6U
# Arb+BOVAkg2oOvol/DJgddJ35XTxfUlQ+8Hggt8l2Yv7roancJIFcbojBcxlRcGG
# 0LIhp6GvReQGgMgYxQbV1S3CrWqZzBt1R9xJgKf47CdxVRd/ndUlQ05oxYy2zRWV
# FjF7mcr4C34Mj3ocCVccAvlKV9jEnstrniLvUxxVZE/rptb7IRE2lskKPIJgbaP5
# t2nGj/ULLi49xTcBZU8atufk+EMF/cWuiC7POGT75qaL6vdCvHlshtjdNXOCIUjs
# arfNZzCCBzMwggUboAMCAQICEGYMmxKaCmwhVQk43VSg7S0wDQYJKoZIhvcNAQEL
# BQAwUzELMAkGA1UEBhMCRVUxKTAnBgNVBAoMIEVVUk9QRUFOIFNZU1RFTSBPRiBD
# RU5UUkFMIEJBTktTMRkwFwYDVQQDDBBFU0NCLVBLSSBST09UIENBMCAYDzIwMTEw
# NzIyMTA0NjM1WhcNMjYwNzIyMTA0NjM1WjBVMQswCQYDVQQGEwJFVTEpMCcGA1UE
# CgwgRVVST1BFQU4gU1lTVEVNIE9GIENFTlRSQUwgQkFOS1MxGzAZBgNVBAMMEkVT
# Q0ItUEtJIE9OTElORSBDQTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
# ANJvy4ZCs0EnziXahaYZ5gP5o987svHmfC7k+FYJjx1dKUor1mggmNCi2F3YSUxe
# 7PaSbxi3GkEyXhiA+Ip7qcHwfz+KWyr3gZdzhAZIxozFzV5X5O+VjGqU4XbRpDwS
# O16SPG7lZa3cjzjBDedT0b4iar+L4+msL+golBskl0/vFHicpzkPw5i3JifDXlWj
# wplJ8wE3Nli7WBoy97ErbsSsxkDcJ1xcBmEhrJqR9vXNxPFHJ+HcbNeYgRHLeCX2
# J1ukx1vKCn1w2EeIxFTGkxDR9RjiUpmDBH5g3C8S7N5PGZZ8E8EBiY+wQvfOSyrM
# 51EYu0JT+V+mFTGnfftv1GSNEYjU4roPXFolozbyCOcQefV6wUrRBW+F/YmYoAto
# TmA/G0XvEz3YT24R6rDeipcK6QqYffLfUYZoLlKE+kUoOOh2GZvmqgan9h6xA75K
# u5O6aefXZnD6zvJJCUu5g9RtAfy1kOtjqqS+gEiwlvlJihIsVHETlf6jxXpm90Cn
# sXQcevGsV3sblKHYaYxuT0pZHgfeZ16IkZXt1OlKXk3reMInzJtkRHUdeDEP0nzL
# lQdDvp7IvklpMv8UnHFRc+YNiK0bvhF0sWfJa99gNR7VscUfJotr/S7KHbH+tD6v
# m6fa3eX1nqam2xANQVbO1Q3xQOaST0RqRAMCF2S73G+5AgMBAAGjggH9MIIB+TAP
# BgNVHRMBAf8EBTADAQH/MA4GA1UdDwEB/wQEAwIBBjAdBgNVHQ4EFgQU5FneRCS2
# pDyDQzcosMikriYtPQMwHwYDVR0jBBgwFoAU1YUdaWOXKMlZ5tFnB81UvNwCfuow
# PAYDVR0gBDUwMzAxBgRVHSAAMCkwJwYIKwYBBQUHAgEWG2h0dHA6Ly9wa2kuZXNj
# Yi5ldS9wb2xpY2llczA/BggrBgEFBQcBAQQzMDEwLwYIKwYBBQUHMAKGI2h0dHA6
# Ly9wa2kuZXNjYi5ldS9jZXJ0cy9yb290Q0EuY3J0MIIBFQYDVR0fBIIBDDCCAQgw
# ggEEoIIBAKCB/YYiaHR0cDovL3BraS5lc2NiLmV1L2NybHMvcm9vdENBLmNybIaB
# jmxkYXA6Ly9sZGFwLXBraS5lc2NiLmV1L0NOPUVTQ0ItUEtJJTIwUm9vdCUyMENB
# LE9VPVBLSSxPVT1FU0NCLVBLSSxPPUVTQ0IsQz1FVT9jZXJ0aWZpY2F0ZVJldm9j
# YXRpb25MaXN0P2Jhc2U/b2JqZWN0Y2xhc3M9Y1JMRGlzdHJpYnV0aW9uUG9pbnSG
# Jmh0dHA6Ly9pYW0tY3JsLmVzY2IuZXUvZXNjYi9yb290Q0EuY3Jshh5odHRwOi8v
# ZXNjYnBraS9jcmxzL3Jvb3RDQS5jcmwwDQYJKoZIhvcNAQELBQADggIBADSo/LBs
# FuaXPoisACq1U0ymgKv/JCaxatOafoZ3BKJAZ4rw9D3Vc/jcnE3Ln6ZGs/zL+z5X
# bX9v+6VEjRQ5VU2rru5189huHOd7h6kmrTTgky8Py/Tce+P7ofYlE2FtzpTjeqpy
# mNKHsj8iA58G6lZX0uVtBi+bAoRFISG7FPBHbk2hLAvWKNyn2iJ++1vUt1MXRe2x
# 9yOhXNNcIdRC6BtnJUWLwxDAB7UTsSgx4Bc/aCGTfDCsM3CKiFoo7KTM3eiWHaSN
# lN1Pt5RaSwcFiT4sRXCJGc6EbpG4FenIBUvNqKnTHucnt+U9+p7IPAWLsWYrxjMH
# 8At+h5KEmp+SsnxZ13KYhaZ3ZsOZEDbu4YKZHKBLsVY05eD01lx3Spk5qZd/vY7C
# ipky+zpe2b9+6gnD5zsr31dsu3DrvpMRmUfnSeFLKO/0v25GUXfjlKPaltn0X90N
# NrVn2dBDuKp+/LKAXuhTEuNJUS16MiA3VbMuFoX990xqCweGC35eTMoxLl0yHvj4
# FqkCpbdSTBsZuD0hdq72rAVxnlUJneV5Z+D49E02DjSRvN9MmwDKl/9VkT9m+hff
# 7EQe/dyKlLV0HMsH/qVNhN+hTMMQmBE9ufXenJuSMme6pB7XNsECCvqkwWypsPFm
# T1Chmcc+IkSM10HAcPioXKGlRHK2ukowt1VcMIIHZjCCBU6gAwIBAgIQbhMu2c4k
# evZlZgU3D+2uzjANBgkqhkiG9w0BAQsFADBVMQswCQYDVQQGEwJFVTEpMCcGA1UE
# CgwgRVVST1BFQU4gU1lTVEVNIE9GIENFTlRSQUwgQkFOS1MxGzAZBgNVBAMMEkVT
# Q0ItUEtJIE9OTElORSBDQTAeFw0yMzExMjgxNTIwMjNaFw0yNjA3MjIxMDQ2MzVa
# MIGAMQswCQYDVQQGEwJCRTEpMCcGA1UECgwgRVVST1BFQU4gU1lTVEVNIE9GIENF
# TlRSQUwgQkFOS1MxJjAkBgNVBAsMHU5hdGlvbmFsIEJhbmsgb2YgQmVsZ2l1bSAo
# QkUpMR4wHAYDVQQDDBVOQkIgRGlnaXRhbCBXb3JrcGxhY2UwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQCzNNNzo6hkEkb7bf8zCXz3j6BIPs+m+ccClnWY
# EwC7SWiVfUO/Fr9rrLdItzZDzYhYk6MNcspqeigEeVvQHIJ31dU5Y5+wa8aClBK3
# KDSw5TaAoAodthPpoAuX6vv0W32ObnP8M9lG1aGfrLINPoFIaYDWs7wBJFbI4gns
# SulNhc6CyyJVDI3pZ2MyUAr0BjZvveZt0UpuAnyLuZN6S/PiT8YaW/ZUBhf6+LkW
# pU0WahZLdQSKaNdBTiZJRJsCTR35gRK2A1FpOCEGN10f45Y9U290Eoxwnqu7AGGN
# c+F3wCAgYFaVmAVpBB69UqwMreSXEnCBZQxe8sfZW1JZxwf1AgMBAAGjggMEMIID
# ADAiBgNVHREEGzAZgRdkaWdpdGFsd29ya3BsYWNlQG5iYi5iZTAOBgNVHQ8BAf8E
# BAMCB4AwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFF3Qet37dk/9
# 0kMEW9Z3ScPpCAcEMB8GA1UdIwQYMBaAFORZ3kQktqQ8g0M3KLDIpK4mLT0DMEEG
# A1UdIAQ6MDgwNgYJBAB/AAoBAgQDMCkwJwYIKwYBBQUHAgEWG2h0dHA6Ly9wa2ku
# ZXNjYi5ldS9wb2xpY2llczCB3AYIKwYBBQUHAQEEgc8wgcwwLwYIKwYBBQUHMAKG
# I2h0dHA6Ly9wa2kuZXNjYi5ldS9jZXJ0cy9yb290Q0EuY3J0MC4GCCsGAQUFBzAC
# hiJodHRwOi8vcGtpLmVzY2IuZXUvY2VydHMvc3ViQ0EuY3J0MB8GCCsGAQUFBzAB
# hhNodHRwOi8vb2NzcC1lc2NicGtpMCMGCCsGAQUFBzABhhdodHRwOi8vb2NzcC1w
# a2kuZXNjYi5ldTAjBggrBgEFBQcwAYYXaHR0cDovL2lhbS1vY3NwLmVzY2IuZXUw
# HAYIBAB/AAoBAwIEEEJBTkNPIERFIEVTUEHDkUEwGwYIBAB/AAoBAwMED1ZBVEVT
# LVEyODAyNDcyRzCCARMGA1UdHwSCAQowggEGMIIBAqCB/6CB/IYdaHR0cDovL2Vz
# Y2Jwa2kvY3Jscy9zdWJDQS5jcmyGIWh0dHA6Ly9wa2kuZXNjYi5ldS9jcmxzL3N1
# YkNBLmNybIaBkGxkYXA6Ly9sZGFwLXBraS5lc2NiLmV1L0NOPUVTQ0ItUEtJJTIw
# T05MSU5FJTIwQ0EsT1U9UEtJLE9VPUVTQ0ItUEtJLE89RVNDQixDPUVVP2NlcnRp
# ZmljYXRlUmV2b2NhdGlvbkxpc3Q/YmFzZT9vYmplY3RjbGFzcz1jUkxEaXN0cmli
# dXRpb25Qb2ludIYlaHR0cDovL2lhbS1jcmwuZXNjYi5ldS9lc2NiL3N1YkNBLmNy
# bDANBgkqhkiG9w0BAQsFAAOCAgEAD9Wh9F5D8tVvk5uW87M3CVcZHCRg9tAlcZ/m
# 4bz8/qBklgFYne89CyeuxyHUPPSY0Y0DMnFDINVViJ7AknJtnt1KGx6mkkey308/
# hmNOhtWamrph3NTaflejcLpMx6RXiwsKl9bswKIpyajSOpQXX58vQBKoXWeJgK74
# Z9r/lflamvP40oLD5xWK7KDk48z2s9UDz38LMKA4uNOygORzAMZ7okD5TbQoKAWg
# Hia0aVb+G4cPyVk3YkUwZbC6bPAs0lVMUpvp+f1U/TjUviZFHB0OsVBM7o1TTmBy
# 4Ua5aNWMsATRvILvpz77A3XIX3VJXRaDZVuiTmtDWCQnYRHkqZpE4xbFeGDxlKO1
# uCbcXpjWQPlgOuBMCGN5xZTeMQMteHPyI2Jo890dTiuhrzuxw2aeSMOJ8d+PKmnn
# 9m7dC0PVZ2H0cvLOhNccN6GoUBagM02kKHk8y63ecMazDXTWho2jUKFyzL3PsEHw
# 7unGEYwP4nTnxj0lxQ4r7+myPn9rBxr7g76tmDT8mXzjnMOumqhgcTMV61znVptc
# yLDbb9xm9evDCan7I1RsiMpnMXS9XAKx1+hvL9xKip9nEhna9WrQLzOFebn5Xy4d
# pXBPDCKAo0w9/qEy6JUlfzKKRpyA+xA50WErfzUV9drguaVbGHsthHPBkyAJkqcH
# jYCP8XsxggVFMIIFQQIBATBpMFUxCzAJBgNVBAYTAkVVMSkwJwYDVQQKDCBFVVJP
# UEVBTiBTWVNURU0gT0YgQ0VOVFJBTCBCQU5LUzEbMBkGA1UEAwwSRVNDQi1QS0kg
# T05MSU5FIENBAhBuEy7ZziR69mVmBTcP7a7OMA0GCWCGSAFlAwQCAQUAoIGEMBgG
# CisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcC
# AQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIE
# IDUrFz71ETizhw89JOf8seI+SSECWhrUY4ZhKNPWZYTjMA0GCSqGSIb3DQEBAQUA
# BIIBAAl8T5Q1oycg9szeui6d6LYPeqO2J/c7uuV9r8SgzTjVd3Jrb70FjANH363m
# fV+G/VFYdXltnzDRP2fk40pARcodFzK0qGjls3P5P1gSAy8j5HTP4Zvou+7mlKAe
# WDc1PaYyrgc59d2mE/+8a+6ln0BzzrYXn2iXGgo9TorClLsW8LLZLCejsZKZxjSo
# yCNd5+u6hAdOZh2zawkvbEOVLnT36XBDtTGKjzsjct6VOtQmaeUNvSfrE7KjHDUM
# agKZrB3owzb/CtrgCb+ItptP8ibPcbaJ3KdFG4ob52rR3YGMJQwbmsRlAip9qk2o
# 7dZjDQvx2aVp/GTB5FIUqRYxKNKhggMmMIIDIgYJKoZIhvcNAQkGMYIDEzCCAw8C
# AQEwfTBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/
# BgNVBAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgVGltZVN0YW1waW5nIFJTQTQwOTYg
# U0hBMjU2IDIwMjUgQ0ExAhAKgO8YS43xBYLRxHanlXRoMA0GCWCGSAFlAwQCAQUA
# oGkwGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjUx
# MTE3MTYxNzQ4WjAvBgkqhkiG9w0BCQQxIgQgjsyw5xgjELCuKI0WfqrbstPue5V+
# f/RDkGCTBXRalkgwDQYJKoZIhvcNAQEBBQAEggIAU07EuPR6tDdwWJU3Ed1UW6IP
# QuXCfpJkUjGRm4l0/XufNm3N5NduThZMhw1/02VNyxZ2UiICT8VEsPlz83tDEJnN
# 0PXPXAhIsGNsEVmqTDb3Ry9+fbpvNczhOJhNWg3WRKDkXOlQrubKbxoEH9hIF37P
# c4riGf4YoekbDbYR3/j0XwDo59IAuTD6rxLHXoYrZmy15EcjeMSmO6CqB38L7QfN
# 6EusizUO68Pf+ObOl4UStwoI3Ka1kDMH3EVC5LKQ0SfxTi7CmxDXnlUcqEvsMO/w
# XPM5NCURaIBSvUMl8PHoMTxNt9H7d/Lvhi3iH5YUvHB5U1q6YutKaYvQ53M+6M+s
# loXXKUO8/2R0fl0p4/8qnfdrlJ4enwIEm0LWxYcXXRlSqEtzXRxB7syY+R/5lLaa
# F3+UmKdbHPFeXH/lt3d33Cyt2+Qws/x6QRVPx7ru8TQmLK4xYqYf8EYkSTLFrCC2
# Ogv0HpekF/TH5LLvwUJ/1Lcw+vMA3t4cw5hF7Ngcb9lT0Pi4jPPqkhT+l0EhaKdW
# HGIrSpJrnXhXf6QM1/HRnZn4Jhoz3NNXHaqsJkLbt3exT1ByvmJdBPlAdrQSY9Yt
# 1o+fUIlxEqarGTG8FvO9ssEYT47pgFbgQCP2vKv5jne6nBTeAJz/Y/JUv9PnfQfm
# YTKIwjmeDEMWpjPo1hQ=
# SIG # End signature block
