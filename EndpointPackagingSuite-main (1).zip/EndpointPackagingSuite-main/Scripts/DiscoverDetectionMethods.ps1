[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$ComputerName,

    [Parameter(Mandatory=$true)]
    [string]$AppName,

    [Parameter(Mandatory=$false)]
    [string]$AppVersion = "",

    [Parameter(Mandatory=$false)]
    [string]$SourceInstallerPath = ""
)

$ErrorActionPreference = 'SilentlyContinue'

Write-Output "DEBUG:Searching for app: $AppName (Version: $AppVersion) on $ComputerName"

# Extract metadata from source installer if provided
$sourceMetadata = $null
if ($SourceInstallerPath -and (Test-Path $SourceInstallerPath)) {
    Write-Output "DEBUG:Extracting metadata from source installer: $SourceInstallerPath"

    try {
        $sourceFile = Get-Item $SourceInstallerPath
        $versionInfo = $sourceFile.VersionInfo

        $sourceMetadata = @{
            ProductName = $versionInfo.ProductName
            CompanyName = $versionInfo.CompanyName
            FileVersion = $versionInfo.FileVersion
            ProductVersion = $versionInfo.ProductVersion
            InternalName = $versionInfo.InternalName
            OriginalFilename = $versionInfo.OriginalFilename
        }

        Write-Output "DEBUG:Source metadata - Product: $($sourceMetadata.ProductName), Company: $($sourceMetadata.CompanyName), Version: $($sourceMetadata.FileVersion)"
    }
    catch {
        Write-Output "DEBUG:Could not extract metadata from source: $_"
    }
}

try {
    # Use WMI to access remote registry (doesn't require Remote Registry service)
    Write-Output "DEBUG:Connecting to $ComputerName via WMI"

    # Registry paths to search
    $uninstallPaths = @(
        @{Hive=[uint32]2147483650; Path='SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'; View=64},
        @{Hive=[uint32]2147483650; Path='SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'; View=64}
    )

    $installedApps = @()

    # Connect to WMI StdRegProv
    try {
        $reg = Get-WmiObject -List -Namespace root\default -ComputerName $ComputerName | Where-Object {$_.Name -eq "StdRegProv"}

        if (-not $reg) {
            Write-Output "ERROR:Cannot connect to WMI on $ComputerName"
            exit 1
        }

        Write-Output "DEBUG:Connected to WMI successfully"

        foreach ($pathInfo in $uninstallPaths) {
            $hive = $pathInfo.Hive  # HKLM = 2147483650
            $path = $pathInfo.Path

            Write-Output "DEBUG:Enumerating registry path: $path"

            # Enumerate subkeys
            $subKeys = $reg.EnumKey($hive, $path)

            if ($subKeys.ReturnValue -eq 0 -and $subKeys.sNames) {
                Write-Output "DEBUG:Found $($subKeys.sNames.Count) entries in $path"

                foreach ($subKeyName in $subKeys.sNames) {
                    $subKeyPath = "$path\$subKeyName"

                    # Get DisplayName
                    $displayName = $reg.GetStringValue($hive, $subKeyPath, 'DisplayName')

                    if ($displayName.ReturnValue -eq 0 -and $displayName.sValue) {
                        # Get other values
                        $displayVersion = $reg.GetStringValue($hive, $subKeyPath, 'DisplayVersion')
                        $publisher = $reg.GetStringValue($hive, $subKeyPath, 'Publisher')
                        $installLocation = $reg.GetStringValue($hive, $subKeyPath, 'InstallLocation')

                        $app = [PSCustomObject]@{
                            DisplayName = $displayName.sValue
                            DisplayVersion = if ($displayVersion.ReturnValue -eq 0) { $displayVersion.sValue } else { $null }
                            Publisher = if ($publisher.ReturnValue -eq 0) { $publisher.sValue } else { $null }
                            InstallLocation = if ($installLocation.ReturnValue -eq 0) { $installLocation.sValue } else { $null }
                            RegistryPath = $subKeyPath
                            ProductCode = $subKeyName
                        }
                        $installedApps += $app
                    }
                }
            }
            else {
                Write-Output "DEBUG:Could not enumerate $path (Return code: $($subKeys.ReturnValue))"
            }
        }
    }
    catch {
        Write-Output "DEBUG:Error connecting via WMI: $_"
        Write-Output "ERROR:Cannot connect to $ComputerName. Ensure WMI access is available."
        exit 1
    }

    Write-Output "DEBUG:Found $($installedApps.Count) installed applications in registry"

    # Find matching application
    $matchedApp = $null

    # Try exact match first
    $matchedApp = $installedApps | Where-Object {
        $_.DisplayName -eq $AppName
    } | Select-Object -First 1

    # Try with underscores replaced with spaces (common in package naming)
    if (-not $matchedApp -and $AppName) {
        $appNameWithSpaces = $AppName -replace '_', ' '
        $matchedApp = $installedApps | Where-Object {
            $_.DisplayName -eq $appNameWithSpaces
        } | Select-Object -First 1
    }

    # If no exact match, try wildcard
    if (-not $matchedApp -and $AppName) {
        $matchedApp = $installedApps | Where-Object {
            $_.DisplayName -like "*$AppName*"
        } | Select-Object -First 1
    }

    # Try wildcard with spaces instead of underscores
    if (-not $matchedApp -and $AppName) {
        $appNameWithSpaces = $AppName -replace '_', ' '
        $matchedApp = $installedApps | Where-Object {
            $_.DisplayName -like "*$appNameWithSpaces*"
        } | Select-Object -First 1
    }

    # If version specified, try to find version match
    if (-not $matchedApp -and $AppVersion) {
        $appNameWithSpaces = $AppName -replace '_', ' '
        $matchedApp = $installedApps | Where-Object {
            (($_.DisplayName -like "*$AppName*") -or ($_.DisplayName -like "*$appNameWithSpaces*")) -and
            ($_.DisplayVersion -like "*$AppVersion*")
        } | Select-Object -First 1
    }

    if ($matchedApp) {
        Write-Output "DEBUG:Match found: $($matchedApp.DisplayName)"

        # Output discovered information
        Write-Output "APP_NAME:$($matchedApp.DisplayName)"
        Write-Output "APP_VERSION:$($matchedApp.DisplayVersion)"
        Write-Output "PUBLISHER:$($matchedApp.Publisher)"
        Write-Output "INSTALL_LOCATION:$($matchedApp.InstallLocation)"

        # Detection Method 1: MSI Product Code (if available)
        $productCode = $matchedApp.ProductCode

        if ($productCode -match '^\{[A-F0-9]{8}-[A-F0-9]{4}-[A-F0-9]{4}-[A-F0-9]{4}-[A-F0-9]{12}\}$') {
            Write-Output "MSI_PRODUCTCODE:$productCode"
        }

        # Detection Method 2: Registry Key (always available)
        $cleanRegPath = "HKLM:\$($matchedApp.RegistryPath)"
        Write-Output "REGISTRY_KEY:$cleanRegPath"

        # Detection Method 3: Registry Value (DisplayVersion)
        if ($matchedApp.DisplayVersion) {
            Write-Output "REGISTRY_VALUE:$cleanRegPath|DisplayVersion"
        }

        # Detection Method 4: File-based detection
        $foundExe = $null
        $foundPath = $null

        # Try InstallLocation from registry first
        if ($matchedApp.InstallLocation) {
            $installLocationUNC = "\\$ComputerName\" + ($matchedApp.InstallLocation -replace ':', '$')
            Write-Output "DEBUG:Checking registry InstallLocation: $installLocationUNC"

            if (Test-Path $installLocationUNC) {
                $exeFiles = Get-ChildItem -Path $installLocationUNC -Filter "*.exe" -File -ErrorAction SilentlyContinue |
                            Where-Object { $_.Name -notmatch 'unins|uninstall|uninst' } |
                            Select-Object -First 1

                if ($exeFiles) {
                    $foundExe = $exeFiles
                    $foundPath = $installLocationUNC
                    Write-Output "DEBUG:Found executable in InstallLocation: $($exeFiles.Name)"
                }
            }
        }

        # If not found via InstallLocation, search Program Files directories
        if (-not $foundExe) {
            Write-Output "DEBUG:Searching Program Files directories for application folder"

            # Extract search terms from app name
            $appNameClean = $matchedApp.DisplayName -replace '[^\w\s]', ''
            $searchTerms = @($appNameClean -split '\s+' | Where-Object { $_.Length -gt 2 })

            # Add source metadata terms if available
            if ($sourceMetadata) {
                if ($sourceMetadata.ProductName) {
                    $productTerms = $sourceMetadata.ProductName -replace '[^\w\s]', '' -split '\s+' | Where-Object { $_.Length -gt 2 }
                    $searchTerms += $productTerms
                }
                if ($sourceMetadata.CompanyName) {
                    $companyTerms = $sourceMetadata.CompanyName -replace '[^\w\s]', '' -split '\s+' | Where-Object { $_.Length -gt 2 }
                    $searchTerms += $companyTerms
                }
            }

            # Remove duplicates and sort by length (longer terms are more specific)
            $searchTerms = $searchTerms | Select-Object -Unique | Sort-Object Length -Descending

            Write-Output "DEBUG:Search terms: $($searchTerms -join ', ')"

            # Program Files paths to search
            $programFilesPaths = @(
                "\\$ComputerName\C$\Program Files",
                "\\$ComputerName\C$\Program Files (x86)"
            )

            # Collect ALL directories from BOTH locations first
            $allScoredDirs = @()
            $maxPossibleScore = $searchTerms.Count

            foreach ($pfPath in $programFilesPaths) {
                if (-not (Test-Path $pfPath)) { continue }

                Write-Output "DEBUG:Searching in $pfPath"

                # Get all directories (including subdirectories to handle nested structures like VMware\VMware Remote Console)
                $directories = Get-ChildItem -Path $pfPath -Directory -Recurse -Depth 1 -ErrorAction SilentlyContinue

                # Score all directories
                foreach ($dir in $directories) {
                    $matchScore = 0
                    foreach ($term in $searchTerms) {
                        if ($dir.Name -like "*$term*") {
                            $matchScore++
                        }
                    }

                    # Require at least 1 match to be considered
                    if ($matchScore -ge 1) {
                        $allScoredDirs += [PSCustomObject]@{
                            Directory = $dir
                            Score = $matchScore
                            SearchPath = $pfPath
                        }
                    }
                }
            }

            # Sort ALL directories by score (highest first) to check best matches first
            $allScoredDirs = $allScoredDirs | Sort-Object Score -Descending

            Write-Output "DEBUG:Found $($allScoredDirs.Count) potential directories across all Program Files locations"

            # Filter out very low scores if we have high-scoring matches (optimization)
            if ($allScoredDirs.Count -gt 0) {
                $bestScore = ($allScoredDirs | Select-Object -First 1).Score
                # If best score is 3+, skip folders with score 1 to save time
                if ($bestScore -ge 3) {
                    $allScoredDirs = $allScoredDirs | Where-Object { $_.Score -ge 2 }
                    Write-Output "DEBUG:Filtering to high-scoring folders only (score >= 2)"
                }
            }

            # Check directories in order of best match
            foreach ($scoredDir in $allScoredDirs) {
                    $dir = $scoredDir.Directory
                    $matchScore = $scoredDir.Score
                    $pfPath = $scoredDir.SearchPath

                    $relativePath = $dir.FullName.Replace("$pfPath\", "")
                    Write-Output "DEBUG:Found potential folder: $relativePath (score: $matchScore)"

                    # Look for executables in this folder (reduced depth for speed)
                    $exeFiles = Get-ChildItem -Path $dir.FullName -Filter "*.exe" -File -Recurse -Depth 1 -ErrorAction SilentlyContinue |
                                Where-Object { $_.Name -notmatch 'unins|uninstall|uninst|setup|helper' }

                    # If we have source metadata, try to find matching executable
                    if ($sourceMetadata -and $exeFiles) {
                        $bestMatch = $null
                        $bestScore = 0

                        foreach ($exe in $exeFiles) {
                            $exeVersion = $exe.VersionInfo
                            $score = 0

                            # Check product name match
                            if ($sourceMetadata.ProductName -and $exeVersion.ProductName -eq $sourceMetadata.ProductName) {
                                $score += 10
                            }

                            # Check company name match
                            if ($sourceMetadata.CompanyName -and $exeVersion.CompanyName -eq $sourceMetadata.CompanyName) {
                                $score += 5
                            }

                            # Check version match
                            if ($sourceMetadata.FileVersion -and $exeVersion.FileVersion -eq $sourceMetadata.FileVersion) {
                                $score += 3
                            }

                            # Check internal name or original filename
                            if ($sourceMetadata.InternalName -and $exeVersion.InternalName -eq $sourceMetadata.InternalName) {
                                $score += 2
                            }

                            if ($score -gt $bestScore) {
                                $bestScore = $score
                                $bestMatch = $exe
                            }
                        }

                        if ($bestMatch) {
                            $foundExe = $bestMatch
                            Write-Output "DEBUG:Found matching executable: $($bestMatch.Name) (match score: $bestScore)"
                        }
                        else {
                            # Use first non-installer exe if no metadata match
                            $foundExe = $exeFiles | Sort-Object Length -Descending | Select-Object -First 1
                            Write-Output "DEBUG:Found executable (no metadata match): $($foundExe.Name)"
                        }
                    }
                    else {
                        # No source metadata, use first non-installer exe
                        $foundExe = $exeFiles | Sort-Object Length -Descending | Select-Object -First 1
                        Write-Output "DEBUG:Found executable: $($foundExe.Name)"
                    }

                    if ($foundExe) {
                        $foundPath = $dir.FullName
                        Write-Output "DEBUG:Selected executable in $($dir.Name)"

                        # Early exit if this is a perfect match (all search terms matched)
                        if ($matchScore -eq $maxPossibleScore) {
                            Write-Output "DEBUG:Perfect match found (score $matchScore/$maxPossibleScore), stopping search"
                        }
                        break
                    }
                }
        }

        # Output file-based detection if we found an executable
        if ($foundExe) {
            # Convert UNC path back to local path
            $localPath = $foundExe.FullName -replace "\\\\$ComputerName\\(.)\$", '$1:'
            $fileDirectory = Split-Path $localPath -Parent
            $fileName = Split-Path $localPath -Leaf

            Write-Output "FILE_PATH:$localPath"

            # Get file version info
            $fileVersion = $foundExe.VersionInfo.FileVersion
            $productVersion = $foundExe.VersionInfo.ProductVersion

            if ($fileVersion) {
                Write-Output "FILE_WITH_VERSION:$localPath|$fileVersion"
                Write-Output "DEBUG:File version: $fileVersion, Product version: $productVersion"
            }
        }
        else {
            Write-Output "DEBUG:No executable file found for file-based detection"
        }
    }
    else {
        Write-Output "DEBUG:No exact match found"
        Write-Output "ERROR:Application '$AppName' not found in registry"

        # Show similar apps for troubleshooting
        $appNameWithSpaces = $AppName -replace '_', ' '
        $similarApps = $installedApps | Where-Object {
            $_.DisplayName -like "*$($AppName.Split('_')[0])*" -or
            $_.DisplayName -like "*$($appNameWithSpaces.Split(' ')[0])*"
        } | Select-Object -First 5 DisplayName

        if ($similarApps) {
            Write-Output "DEBUG:Similar apps found: $($similarApps.DisplayName -join '; ')"
        }
    }
}
catch {
    Write-Output "ERROR:Failed to discover detection methods: $_"
    Write-Output "DEBUG:Exception details: $($_.Exception.Message)"
}
# SIG # Begin signature block
# MIInygYJKoZIhvcNAQcCoIInuzCCJ7cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBRqGv7PuZLzdjP
# MX4TA6HlvbYPXofBD5IkEsPXbJSmE6CCIdswggWNMIIEdaADAgECAhAOmxiO+dAt
# 5+/bUOIIQBhaMA0GCSqGSIb3DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNV
# BAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBa
# Fw0zMTExMDkyMzU5NTlaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lD
# ZXJ0IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoC
# ggIBAL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3E
# MB/zG6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKy
# unWZanMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsF
# xl7sWxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU1
# 5zHL2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJB
# MtfbBHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObUR
# WBf3JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6
# nj3cAORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxB
# YKqxYxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5S
# UUd0viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+x
# q4aLT8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIB
# NjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwP
# TzAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMC
# AYYweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdp
# Y2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0
# aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENB
# LmNybDARBgNVHSAECjAIMAYGBFUdIAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0Nc
# Vec4X6CjdBs9thbX979XB72arKGHLOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnov
# Lbc47/T/gLn4offyct4kvFIDyE7QKt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65Zy
# oUi0mcudT6cGAxN3J0TU53/oWajwvy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFW
# juyk1T3osdz9HNj0d1pcVIxv76FQPfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPF
# mCLBsln1VWvPJ6tsds5vIy30fnFqI2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9z
# twGpn1eqXijiuZQwgga0MIIEnKADAgECAhANx6xXBf8hmS5AQyIMOkmGMA0GCSqG
# SIb3DQEBCwUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMx
# GTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRy
# dXN0ZWQgUm9vdCBHNDAeFw0yNTA1MDcwMDAwMDBaFw0zODAxMTQyMzU5NTlaMGkx
# CzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4
# RGlnaUNlcnQgVHJ1c3RlZCBHNCBUaW1lU3RhbXBpbmcgUlNBNDA5NiBTSEEyNTYg
# MjAyNSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC0eDHTCphB
# cr48RsAcrHXbo0ZodLRRF51NrY0NlLWZloMsVO1DahGPNRcybEKq+RuwOnPhof6p
# vF4uGjwjqNjfEvUi6wuim5bap+0lgloM2zX4kftn5B1IpYzTqpyFQ/4Bt0mAxAHe
# HYNnQxqXmRinvuNgxVBdJkf77S2uPoCj7GH8BLuxBG5AvftBdsOECS1UkxBvMgEd
# gkFiDNYiOTx4OtiFcMSkqTtF2hfQz3zQSku2Ws3IfDReb6e3mmdglTcaarps0wjU
# jsZvkgFkriK9tUKJm/s80FiocSk1VYLZlDwFt+cVFBURJg6zMUjZa/zbCclF83bR
# VFLeGkuAhHiGPMvSGmhgaTzVyhYn4p0+8y9oHRaQT/aofEnS5xLrfxnGpTXiUOeS
# LsJygoLPp66bkDX1ZlAeSpQl92QOMeRxykvq6gbylsXQskBBBnGy3tW/AMOMCZIV
# NSaz7BX8VtYGqLt9MmeOreGPRdtBx3yGOP+rx3rKWDEJlIqLXvJWnY0v5ydPpOjL
# 6s36czwzsucuoKs7Yk/ehb//Wx+5kMqIMRvUBDx6z1ev+7psNOdgJMoiwOrUG2Zd
# SoQbU2rMkpLiQ6bGRinZbI4OLu9BMIFm1UUl9VnePs6BaaeEWvjJSjNm2qA+sdFU
# eEY0qVjPKOWug/G6X5uAiynM7Bu2ayBjUwIDAQABo4IBXTCCAVkwEgYDVR0TAQH/
# BAgwBgEB/wIBADAdBgNVHQ4EFgQU729TSunkBnx6yuKQVvYv1Ensy04wHwYDVR0j
# BBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMGA1Ud
# JQQMMAoGCCsGAQUFBwMIMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0
# cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0
# cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNVHR8E
# PDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVz
# dGVkUm9vdEc0LmNybDAgBgNVHSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEw
# DQYJKoZIhvcNAQELBQADggIBABfO+xaAHP4HPRF2cTC9vgvItTSmf83Qh8WIGjB/
# T8ObXAZz8OjuhUxjaaFdleMM0lBryPTQM2qEJPe36zwbSI/mS83afsl3YTj+IQhQ
# E7jU/kXjjytJgnn0hvrV6hqWGd3rLAUt6vJy9lMDPjTLxLgXf9r5nWMQwr8Myb9r
# EVKChHyfpzee5kH0F8HABBgr0UdqirZ7bowe9Vj2AIMD8liyrukZ2iA/wdG2th9y
# 1IsA0QF8dTXqvcnTmpfeQh35k5zOCPmSNq1UH410ANVko43+Cdmu4y81hjajV/gx
# dEkMx1NKU4uHQcKfZxAvBAKqMVuqte69M9J6A47OvgRaPs+2ykgcGV00TYr2Lr3t
# y9qIijanrUR3anzEwlvzZiiyfTPjLbnFRsjsYg39OlV8cipDoq7+qNNjqFzeGxcy
# tL5TTLL4ZaoBdqbhOhZ3ZRDUphPvSRmMThi0vw9vODRzW6AxnJll38F0cuJG7uEB
# YTptMSbhdhGQDpOXgpIUsWTjd6xpR6oaQf/DJbg3s6KCLPAlZ66RzIg9sC+NJpud
# /v4+7RWsWCiKi9EOLLHfMR2ZyJ/+xhCx9yHbxtl5TPau1j/1MIDpMPx0LckTetiS
# uEtQvLsNz3Qbp7wGWqbIiOWCnb5WqxL3/BAPvIXKUjPSxyZsq8WhbaM2tszWkPZP
# ubdcMIIG7TCCBNWgAwIBAgIQCoDvGEuN8QWC0cR2p5V0aDANBgkqhkiG9w0BAQsF
# ADBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNV
# BAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgVGltZVN0YW1waW5nIFJTQTQwOTYgU0hB
# MjU2IDIwMjUgQ0ExMB4XDTI1MDYwNDAwMDAwMFoXDTM2MDkwMzIzNTk1OVowYzEL
# MAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTswOQYDVQQDEzJE
# aWdpQ2VydCBTSEEyNTYgUlNBNDA5NiBUaW1lc3RhbXAgUmVzcG9uZGVyIDIwMjUg
# MTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBANBGrC0Sxp7Q6q5gVrMr
# V7pvUf+GcAoB38o3zBlCMGMyqJnfFNZx+wvA69HFTBdwbHwBSOeLpvPnZ8ZN+vo8
# dE2/pPvOx/Vj8TchTySA2R4QKpVD7dvNZh6wW2R6kSu9RJt/4QhguSssp3qome7M
# rxVyfQO9sMx6ZAWjFDYOzDi8SOhPUWlLnh00Cll8pjrUcCV3K3E0zz09ldQ//nBZ
# ZREr4h/GI6Dxb2UoyrN0ijtUDVHRXdmncOOMA3CoB/iUSROUINDT98oksouTMYFO
# nHoRh6+86Ltc5zjPKHW5KqCvpSduSwhwUmotuQhcg9tw2YD3w6ySSSu+3qU8DD+n
# igNJFmt6LAHvH3KSuNLoZLc1Hf2JNMVL4Q1OpbybpMe46YceNA0LfNsnqcnpJeIt
# K/DhKbPxTTuGoX7wJNdoRORVbPR1VVnDuSeHVZlc4seAO+6d2sC26/PQPdP51ho1
# zBp+xUIZkpSFA8vWdoUoHLWnqWU3dCCyFG1roSrgHjSHlq8xymLnjCbSLZ49kPmk
# 8iyyizNDIXj//cOgrY7rlRyTlaCCfw7aSUROwnu7zER6EaJ+AliL7ojTdS5PWPsW
# eupWs7NpChUk555K096V1hE0yZIXe+giAwW00aHzrDchIc2bQhpp0IoKRR7YufAk
# prxMiXAJQ1XCmnCfgPf8+3mnAgMBAAGjggGVMIIBkTAMBgNVHRMBAf8EAjAAMB0G
# A1UdDgQWBBTkO/zyMe39/dfzkXFjGVBDz2GM6DAfBgNVHSMEGDAWgBTvb1NK6eQG
# fHrK4pBW9i/USezLTjAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0lAQH/BAwwCgYIKwYB
# BQUHAwgwgZUGCCsGAQUFBwEBBIGIMIGFMCQGCCsGAQUFBzABhhhodHRwOi8vb2Nz
# cC5kaWdpY2VydC5jb20wXQYIKwYBBQUHMAKGUWh0dHA6Ly9jYWNlcnRzLmRpZ2lj
# ZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNFRpbWVTdGFtcGluZ1JTQTQwOTZTSEEy
# NTYyMDI1Q0ExLmNydDBfBgNVHR8EWDBWMFSgUqBQhk5odHRwOi8vY3JsMy5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRUaW1lU3RhbXBpbmdSU0E0MDk2U0hB
# MjU2MjAyNUNBMS5jcmwwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcB
# MA0GCSqGSIb3DQEBCwUAA4ICAQBlKq3xHCcEua5gQezRCESeY0ByIfjk9iJP2zWL
# pQq1b4URGnwWBdEZD9gBq9fNaNmFj6Eh8/YmRDfxT7C0k8FUFqNh+tshgb4O6Lgj
# g8K8elC4+oWCqnU/ML9lFfim8/9yJmZSe2F8AQ/UdKFOtj7YMTmqPO9mzskgiC3Q
# YIUP2S3HQvHG1FDu+WUqW4daIqToXFE/JQ/EABgfZXLWU0ziTN6R3ygQBHMUBaB5
# bdrPbF6MRYs03h4obEMnxYOX8VBRKe1uNnzQVTeLni2nHkX/QqvXnNb+YkDFkxUG
# tMTaiLR9wjxUxu2hECZpqyU1d0IbX6Wq8/gVutDojBIFeRlqAcuEVT0cKsb+zJNE
# suEB7O7/cuvTQasnM9AWcIQfVjnzrvwiCZ85EE8LUkqRhoS3Y50OHgaY7T/lwd6U
# Arb+BOVAkg2oOvol/DJgddJ35XTxfUlQ+8Hggt8l2Yv7roancJIFcbojBcxlRcGG
# 0LIhp6GvReQGgMgYxQbV1S3CrWqZzBt1R9xJgKf47CdxVRd/ndUlQ05oxYy2zRWV
# FjF7mcr4C34Mj3ocCVccAvlKV9jEnstrniLvUxxVZE/rptb7IRE2lskKPIJgbaP5
# t2nGj/ULLi49xTcBZU8atufk+EMF/cWuiC7POGT75qaL6vdCvHlshtjdNXOCIUjs
# arfNZzCCBzMwggUboAMCAQICEGYMmxKaCmwhVQk43VSg7S0wDQYJKoZIhvcNAQEL
# BQAwUzELMAkGA1UEBhMCRVUxKTAnBgNVBAoMIEVVUk9QRUFOIFNZU1RFTSBPRiBD
# RU5UUkFMIEJBTktTMRkwFwYDVQQDDBBFU0NCLVBLSSBST09UIENBMCAYDzIwMTEw
# NzIyMTA0NjM1WhcNMjYwNzIyMTA0NjM1WjBVMQswCQYDVQQGEwJFVTEpMCcGA1UE
# CgwgRVVST1BFQU4gU1lTVEVNIE9GIENFTlRSQUwgQkFOS1MxGzAZBgNVBAMMEkVT
# Q0ItUEtJIE9OTElORSBDQTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
# ANJvy4ZCs0EnziXahaYZ5gP5o987svHmfC7k+FYJjx1dKUor1mggmNCi2F3YSUxe
# 7PaSbxi3GkEyXhiA+Ip7qcHwfz+KWyr3gZdzhAZIxozFzV5X5O+VjGqU4XbRpDwS
# O16SPG7lZa3cjzjBDedT0b4iar+L4+msL+golBskl0/vFHicpzkPw5i3JifDXlWj
# wplJ8wE3Nli7WBoy97ErbsSsxkDcJ1xcBmEhrJqR9vXNxPFHJ+HcbNeYgRHLeCX2
# J1ukx1vKCn1w2EeIxFTGkxDR9RjiUpmDBH5g3C8S7N5PGZZ8E8EBiY+wQvfOSyrM
# 51EYu0JT+V+mFTGnfftv1GSNEYjU4roPXFolozbyCOcQefV6wUrRBW+F/YmYoAto
# TmA/G0XvEz3YT24R6rDeipcK6QqYffLfUYZoLlKE+kUoOOh2GZvmqgan9h6xA75K
# u5O6aefXZnD6zvJJCUu5g9RtAfy1kOtjqqS+gEiwlvlJihIsVHETlf6jxXpm90Cn
# sXQcevGsV3sblKHYaYxuT0pZHgfeZ16IkZXt1OlKXk3reMInzJtkRHUdeDEP0nzL
# lQdDvp7IvklpMv8UnHFRc+YNiK0bvhF0sWfJa99gNR7VscUfJotr/S7KHbH+tD6v
# m6fa3eX1nqam2xANQVbO1Q3xQOaST0RqRAMCF2S73G+5AgMBAAGjggH9MIIB+TAP
# BgNVHRMBAf8EBTADAQH/MA4GA1UdDwEB/wQEAwIBBjAdBgNVHQ4EFgQU5FneRCS2
# pDyDQzcosMikriYtPQMwHwYDVR0jBBgwFoAU1YUdaWOXKMlZ5tFnB81UvNwCfuow
# PAYDVR0gBDUwMzAxBgRVHSAAMCkwJwYIKwYBBQUHAgEWG2h0dHA6Ly9wa2kuZXNj
# Yi5ldS9wb2xpY2llczA/BggrBgEFBQcBAQQzMDEwLwYIKwYBBQUHMAKGI2h0dHA6
# Ly9wa2kuZXNjYi5ldS9jZXJ0cy9yb290Q0EuY3J0MIIBFQYDVR0fBIIBDDCCAQgw
# ggEEoIIBAKCB/YYiaHR0cDovL3BraS5lc2NiLmV1L2NybHMvcm9vdENBLmNybIaB
# jmxkYXA6Ly9sZGFwLXBraS5lc2NiLmV1L0NOPUVTQ0ItUEtJJTIwUm9vdCUyMENB
# LE9VPVBLSSxPVT1FU0NCLVBLSSxPPUVTQ0IsQz1FVT9jZXJ0aWZpY2F0ZVJldm9j
# YXRpb25MaXN0P2Jhc2U/b2JqZWN0Y2xhc3M9Y1JMRGlzdHJpYnV0aW9uUG9pbnSG
# Jmh0dHA6Ly9pYW0tY3JsLmVzY2IuZXUvZXNjYi9yb290Q0EuY3Jshh5odHRwOi8v
# ZXNjYnBraS9jcmxzL3Jvb3RDQS5jcmwwDQYJKoZIhvcNAQELBQADggIBADSo/LBs
# FuaXPoisACq1U0ymgKv/JCaxatOafoZ3BKJAZ4rw9D3Vc/jcnE3Ln6ZGs/zL+z5X
# bX9v+6VEjRQ5VU2rru5189huHOd7h6kmrTTgky8Py/Tce+P7ofYlE2FtzpTjeqpy
# mNKHsj8iA58G6lZX0uVtBi+bAoRFISG7FPBHbk2hLAvWKNyn2iJ++1vUt1MXRe2x
# 9yOhXNNcIdRC6BtnJUWLwxDAB7UTsSgx4Bc/aCGTfDCsM3CKiFoo7KTM3eiWHaSN
# lN1Pt5RaSwcFiT4sRXCJGc6EbpG4FenIBUvNqKnTHucnt+U9+p7IPAWLsWYrxjMH
# 8At+h5KEmp+SsnxZ13KYhaZ3ZsOZEDbu4YKZHKBLsVY05eD01lx3Spk5qZd/vY7C
# ipky+zpe2b9+6gnD5zsr31dsu3DrvpMRmUfnSeFLKO/0v25GUXfjlKPaltn0X90N
# NrVn2dBDuKp+/LKAXuhTEuNJUS16MiA3VbMuFoX990xqCweGC35eTMoxLl0yHvj4
# FqkCpbdSTBsZuD0hdq72rAVxnlUJneV5Z+D49E02DjSRvN9MmwDKl/9VkT9m+hff
# 7EQe/dyKlLV0HMsH/qVNhN+hTMMQmBE9ufXenJuSMme6pB7XNsECCvqkwWypsPFm
# T1Chmcc+IkSM10HAcPioXKGlRHK2ukowt1VcMIIHZjCCBU6gAwIBAgIQbhMu2c4k
# evZlZgU3D+2uzjANBgkqhkiG9w0BAQsFADBVMQswCQYDVQQGEwJFVTEpMCcGA1UE
# CgwgRVVST1BFQU4gU1lTVEVNIE9GIENFTlRSQUwgQkFOS1MxGzAZBgNVBAMMEkVT
# Q0ItUEtJIE9OTElORSBDQTAeFw0yMzExMjgxNTIwMjNaFw0yNjA3MjIxMDQ2MzVa
# MIGAMQswCQYDVQQGEwJCRTEpMCcGA1UECgwgRVVST1BFQU4gU1lTVEVNIE9GIENF
# TlRSQUwgQkFOS1MxJjAkBgNVBAsMHU5hdGlvbmFsIEJhbmsgb2YgQmVsZ2l1bSAo
# QkUpMR4wHAYDVQQDDBVOQkIgRGlnaXRhbCBXb3JrcGxhY2UwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQCzNNNzo6hkEkb7bf8zCXz3j6BIPs+m+ccClnWY
# EwC7SWiVfUO/Fr9rrLdItzZDzYhYk6MNcspqeigEeVvQHIJ31dU5Y5+wa8aClBK3
# KDSw5TaAoAodthPpoAuX6vv0W32ObnP8M9lG1aGfrLINPoFIaYDWs7wBJFbI4gns
# SulNhc6CyyJVDI3pZ2MyUAr0BjZvveZt0UpuAnyLuZN6S/PiT8YaW/ZUBhf6+LkW
# pU0WahZLdQSKaNdBTiZJRJsCTR35gRK2A1FpOCEGN10f45Y9U290Eoxwnqu7AGGN
# c+F3wCAgYFaVmAVpBB69UqwMreSXEnCBZQxe8sfZW1JZxwf1AgMBAAGjggMEMIID
# ADAiBgNVHREEGzAZgRdkaWdpdGFsd29ya3BsYWNlQG5iYi5iZTAOBgNVHQ8BAf8E
# BAMCB4AwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFF3Qet37dk/9
# 0kMEW9Z3ScPpCAcEMB8GA1UdIwQYMBaAFORZ3kQktqQ8g0M3KLDIpK4mLT0DMEEG
# A1UdIAQ6MDgwNgYJBAB/AAoBAgQDMCkwJwYIKwYBBQUHAgEWG2h0dHA6Ly9wa2ku
# ZXNjYi5ldS9wb2xpY2llczCB3AYIKwYBBQUHAQEEgc8wgcwwLwYIKwYBBQUHMAKG
# I2h0dHA6Ly9wa2kuZXNjYi5ldS9jZXJ0cy9yb290Q0EuY3J0MC4GCCsGAQUFBzAC
# hiJodHRwOi8vcGtpLmVzY2IuZXUvY2VydHMvc3ViQ0EuY3J0MB8GCCsGAQUFBzAB
# hhNodHRwOi8vb2NzcC1lc2NicGtpMCMGCCsGAQUFBzABhhdodHRwOi8vb2NzcC1w
# a2kuZXNjYi5ldTAjBggrBgEFBQcwAYYXaHR0cDovL2lhbS1vY3NwLmVzY2IuZXUw
# HAYIBAB/AAoBAwIEEEJBTkNPIERFIEVTUEHDkUEwGwYIBAB/AAoBAwMED1ZBVEVT
# LVEyODAyNDcyRzCCARMGA1UdHwSCAQowggEGMIIBAqCB/6CB/IYdaHR0cDovL2Vz
# Y2Jwa2kvY3Jscy9zdWJDQS5jcmyGIWh0dHA6Ly9wa2kuZXNjYi5ldS9jcmxzL3N1
# YkNBLmNybIaBkGxkYXA6Ly9sZGFwLXBraS5lc2NiLmV1L0NOPUVTQ0ItUEtJJTIw
# T05MSU5FJTIwQ0EsT1U9UEtJLE9VPUVTQ0ItUEtJLE89RVNDQixDPUVVP2NlcnRp
# ZmljYXRlUmV2b2NhdGlvbkxpc3Q/YmFzZT9vYmplY3RjbGFzcz1jUkxEaXN0cmli
# dXRpb25Qb2ludIYlaHR0cDovL2lhbS1jcmwuZXNjYi5ldS9lc2NiL3N1YkNBLmNy
# bDANBgkqhkiG9w0BAQsFAAOCAgEAD9Wh9F5D8tVvk5uW87M3CVcZHCRg9tAlcZ/m
# 4bz8/qBklgFYne89CyeuxyHUPPSY0Y0DMnFDINVViJ7AknJtnt1KGx6mkkey308/
# hmNOhtWamrph3NTaflejcLpMx6RXiwsKl9bswKIpyajSOpQXX58vQBKoXWeJgK74
# Z9r/lflamvP40oLD5xWK7KDk48z2s9UDz38LMKA4uNOygORzAMZ7okD5TbQoKAWg
# Hia0aVb+G4cPyVk3YkUwZbC6bPAs0lVMUpvp+f1U/TjUviZFHB0OsVBM7o1TTmBy
# 4Ua5aNWMsATRvILvpz77A3XIX3VJXRaDZVuiTmtDWCQnYRHkqZpE4xbFeGDxlKO1
# uCbcXpjWQPlgOuBMCGN5xZTeMQMteHPyI2Jo890dTiuhrzuxw2aeSMOJ8d+PKmnn
# 9m7dC0PVZ2H0cvLOhNccN6GoUBagM02kKHk8y63ecMazDXTWho2jUKFyzL3PsEHw
# 7unGEYwP4nTnxj0lxQ4r7+myPn9rBxr7g76tmDT8mXzjnMOumqhgcTMV61znVptc
# yLDbb9xm9evDCan7I1RsiMpnMXS9XAKx1+hvL9xKip9nEhna9WrQLzOFebn5Xy4d
# pXBPDCKAo0w9/qEy6JUlfzKKRpyA+xA50WErfzUV9drguaVbGHsthHPBkyAJkqcH
# jYCP8XsxggVFMIIFQQIBATBpMFUxCzAJBgNVBAYTAkVVMSkwJwYDVQQKDCBFVVJP
# UEVBTiBTWVNURU0gT0YgQ0VOVFJBTCBCQU5LUzEbMBkGA1UEAwwSRVNDQi1QS0kg
# T05MSU5FIENBAhBuEy7ZziR69mVmBTcP7a7OMA0GCWCGSAFlAwQCAQUAoIGEMBgG
# CisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcC
# AQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIE
# IBFZCzOQwhB0ZucbLwLdAybIQqVSX2zb3xnDf3XkoNu2MA0GCSqGSIb3DQEBAQUA
# BIIBAEXJdamg4OYfaomI9rKvNiI5IdRF2DL0yj26FYm43m5+m8yDzaTeERknLMGM
# sZCz9wYNUDc26nReqBumkFGyqpztr83iAYZUPWMNqt2jU+WaJezUEFrpgJhOtBAC
# FEIERVI4pCrr8qK08JAnW3KVdsKVRQL7BUcplKZlbnH+dPCLcJ+iwYxIlDiZ40Wj
# ZGA7Vra1NHEoq7x/foYlHYwWy66nkJrsA0tzD8KqQcD/xru2tNbN2U6cZN5zAhe/
# yJu17TEop6W0OMck3z59eW+Gqz5S4Kx9xfmBrnx1f3c3qTP8fgCW3nJOKfpp0Cmi
# H0UBww7/Sv7zdzDVxv40lO4MquShggMmMIIDIgYJKoZIhvcNAQkGMYIDEzCCAw8C
# AQEwfTBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/
# BgNVBAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgVGltZVN0YW1waW5nIFJTQTQwOTYg
# U0hBMjU2IDIwMjUgQ0ExAhAKgO8YS43xBYLRxHanlXRoMA0GCWCGSAFlAwQCAQUA
# oGkwGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjUx
# MTE3MTYxNzQ3WjAvBgkqhkiG9w0BCQQxIgQgfv2de2NdzG8FKI2zdX+9zDFsLEwv
# jwkwt6/ovthnTaUwDQYJKoZIhvcNAQEBBQAEggIAQENCEllrQarXl7NdNJsFw0Ff
# UJ9Cl5VlTpSliGmXuxTwVaDNS7X37nyruOduhO0cdOxEPizJL2QahpWPhlCfbYmB
# ltdDtcuBaE6KrOx5bQLUtLSaYKXby84o5vn/xg7Oq1ZQ/5iPoHSlji7stPhHeKeG
# +YvLeluIRJwB+EcSqsgrYMjJJ550UfvSZkH+WlhWZ15vcV8YZ2Sjv2mAZ/O280cR
# oslmRLPVjUH04IX7ylN/d/7pLgaaT5YAjjo4bvfi+pfrHoXxyiXwzEbtmUr7Reru
# l6u0fSkytyg3MIZJ7WoycOCWxTWR3sZ3HPPGtdZJzEq7ySXYEBaTxEDPnm1yIxSW
# sd8DL8Y8s/MYkMljkkNYNDj6wweAPmYNVBV4NLiuyM1UO5gbq0WtxF/wROqgru90
# /qYvJmFCwttcFqX3+3Mpdi3OvglffiYICzoZJs6m16k99R7IupKDLkzf5G4obdrn
# IhyCKdtbOS0lAAn9gSKE8F3WVaLqqUrMsCQQQlhZ4JdBrKfgwA65ROVHGNv/SuQG
# GBlp3FUkaCarriD++F5jlER7dX6Hhu4FGbwrkAAwHwjy8A1B8TPnRctluvohl81d
# S6gPVAp3VnMNaI2RMoKqq4f8hfyBUjnllKSvZyPuaRIsG2Uyk4swUuI4ZVdkDGs7
# dJFYf7O8be/U7l58APU=
# SIG # End signature block
