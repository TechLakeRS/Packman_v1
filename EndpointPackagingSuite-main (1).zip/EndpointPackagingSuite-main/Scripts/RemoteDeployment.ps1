
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$TargetComputer,

    [Parameter(Mandatory=$true)]
    [string]$SourcePath,

    [Parameter(Mandatory=$false)]
    [ValidateSet("Install", "Uninstall", "Repair")]
    [string]$DeploymentType = "Install",

    [Parameter(Mandatory=$false)]
    [switch]$CleanupAfterDeploy
)

$ErrorActionPreference = "Continue"
$LocalTempPath = "C:\Temp\AppDeploy"
$PsExecPath = "C:\Windows\System32\PsExec.exe"

"========================================"
"Remote Application Deployment (PSADT v4)"
"========================================"
"Target: $TargetComputer"
"Source: $SourcePath"
"Type: $DeploymentType"
""

try {
    # Check PsExec
    "Checking for PsExec..."
    if (-not (Test-Path $PsExecPath)) {
        "ERROR: PsExec not found at $PsExecPath"
        exit 1
    }
    "[OK] PsExec found"

    # Check connectivity
    "Checking connectivity to $TargetComputer..."
    if (-not (Test-Connection -ComputerName $TargetComputer -Count 1 -Quiet)) {
        "ERROR: $TargetComputer is not reachable"
        exit 1
    }
    "[OK] $TargetComputer is online"

    # Verify source
    "Verifying source path..."
    if (-not (Test-Path $SourcePath)) {
        "ERROR: Source path not found: $SourcePath"
        exit 1
    }

    # Find PSADT v4 script (Invoke-AppDeployToolkit.ps1)
    $deployScript = $null

    $v4ScriptInApp = Join-Path (Join-Path $SourcePath "Application") "Invoke-AppDeployToolkit.ps1"
    $v4ScriptInRoot = Join-Path $SourcePath "Invoke-AppDeployToolkit.ps1"

    if (Test-Path $v4ScriptInApp) {
        $deployScript = $v4ScriptInApp
        "[OK] Found Invoke-AppDeployToolkit.ps1 in Application subfolder"
    }
    elseif (Test-Path $v4ScriptInRoot) {
        $deployScript = $v4ScriptInRoot
        "[OK] Found Invoke-AppDeployToolkit.ps1 in root folder"
    }
    else {
        "ERROR: Invoke-AppDeployToolkit.ps1 not found in package"
        exit 1
    }

    # Create remote temp directory
    "Creating temp directory on target..."
    & $PsExecPath \\$TargetComputer -accepteula -s cmd.exe /c "mkdir `"$LocalTempPath`" 2>nul" 2>&1 | Out-Null
    "[OK] Temp directory ready"

    # Copy files
    "Copying files to \\$TargetComputer\C$\Temp\AppDeploy..."
    $targetUNC = "\\$TargetComputer\C$\Temp\AppDeploy"

    if (-not (Test-Path $targetUNC)) {
        "Creating directory: $targetUNC"
        New-Item -Path $targetUNC -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
    }

    $copyStart = Get-Date
    try {
        Copy-Item -Path "$SourcePath\*" -Destination $targetUNC -Recurse -Force -ErrorAction Stop
        $copyDuration = ((Get-Date) - $copyStart).TotalSeconds

        # Count and measure copied files in a single enumeration
        $copiedFiles = Get-ChildItem -Path $targetUNC -Recurse -File -ErrorAction SilentlyContinue
        $copiedSizeMB = ($copiedFiles | Measure-Object -Property Length -Sum).Sum / 1MB
        "Package size: $([math]::Round($copiedSizeMB, 2)) MB"
        "[OK] Files copied in $([math]::Round($copyDuration, 1)) seconds"
        "Copied $($copiedFiles.Count) files to target"
    }
    catch {
        "ERROR during copy: $_"
        throw
    }

    # Determine remote script path
    $remoteDeployPath = if ($deployScript -like "*Application\Invoke-AppDeployToolkit.ps1") {
        "$LocalTempPath\Application\Invoke-AppDeployToolkit.ps1"
    } else {
        "$LocalTempPath\Invoke-AppDeployToolkit.ps1"
    }

    # Build the PowerShell command
    $psExePath = "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"
    $psCmd = "`"$psExePath`" -ExecutionPolicy Bypass -NoProfile -File `"$remoteDeployPath`" -DeploymentType $DeploymentType"

    # Execute via PsExec
    ""
    "Executing PSADT v4 deployment on target..."
    "Command: $psCmd"
    ""

    $output = & $PsExecPath \\$TargetComputer -accepteula -s cmd.exe /c $psCmd 2>&1

    foreach ($line in $output) {
        if ($line) { $line }
    }

    $exitCode = $LASTEXITCODE
    ""
    "Exit code: $exitCode"

    # Cleanup
    if ($CleanupAfterDeploy) {
        ""
        "Cleaning up..."
        & $PsExecPath \\$TargetComputer -accepteula -s cmd.exe /c "rmdir /s /q `"$LocalTempPath`"" 2>&1 | Out-Null
        "[OK] Cleanup completed"
    }

    # Results
    ""
    "========================================"
    if ($exitCode -eq 0) {
        "[OK] DEPLOYMENT COMPLETED SUCCESSFULLY!"
        "========================================"
        exit 0
    }
    elseif ($exitCode -eq 3010 -or $exitCode -eq 1641) {
        "[OK] DEPLOYMENT COMPLETED - REBOOT REQUIRED"
        "========================================"
        exit 3010
    }
    else {
        "[FAIL] DEPLOYMENT FAILED WITH EXIT CODE: $exitCode"
        "========================================"
        exit $exitCode
    }
}
catch {
    ""
    "[FAIL] ERROR: $_"
    "========================================"
    exit 1
}
