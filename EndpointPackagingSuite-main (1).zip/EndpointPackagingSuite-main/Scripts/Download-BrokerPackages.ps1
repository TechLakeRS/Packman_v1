# Download Azure.Identity.Broker and all dependencies for offline use
# No .NET SDK required - uses NuGet API directly via Invoke-WebRequest
# Run this on an internet-connected machine, then copy the output folder to your air-gapped machine

$OutputFolder = Join-Path $PSScriptRoot "offline-packages"
if (Test-Path $OutputFolder) { Remove-Item $OutputFolder -Recurse -Force }
New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null

$packages = @(
    "Azure.Identity.Broker/1.2.1"
    "Azure.Identity/1.14.2"
    "Azure.Core/1.44.1"
    "Microsoft.Identity.Client/4.83.3"
    "Microsoft.Identity.Client.Broker/4.83.3"
    "Microsoft.Identity.Client.NativeInterop/0.16.2"
    "Microsoft.Identity.Client.Extensions.Msal/4.83.3"
    "Microsoft.IdentityModel.Abstractions/8.3.0"
    "System.Memory.Data/1.0.2"
    "System.ClientModel/1.1.0"
    "System.Diagnostics.DiagnosticSource/9.0.0"
    "Microsoft.Bcl.AsyncInterfaces/9.0.0"
)

$baseUrl = "https://api.nuget.org/v3-flatcontainer"

foreach ($pkg in $packages) {
    $parts = $pkg -split "/"
    $id = $parts[0].ToLower()
    $version = $parts[1]
    $fileName = "$id.$version.nupkg"
    $url = "$baseUrl/$id/$version/$fileName"
    $outPath = Join-Path $OutputFolder $fileName

    Write-Host "Downloading $($parts[0]) $version..." -ForegroundColor Cyan -NoNewline
    try {
        Invoke-WebRequest -Uri $url -OutFile $outPath -UseBasicParsing
        Write-Host " OK" -ForegroundColor Green
    }
    catch {
        Write-Host " FAILED: $($_.Exception.Message)" -ForegroundColor Red
    }
}

$count = (Get-ChildItem $OutputFolder -Filter "*.nupkg").Count
Write-Host "`nDone! $count packages saved to: $OutputFolder" -ForegroundColor Yellow
Write-Host "Copy this folder to your air-gapped machine's LocalPackages directory." -ForegroundColor Yellow
