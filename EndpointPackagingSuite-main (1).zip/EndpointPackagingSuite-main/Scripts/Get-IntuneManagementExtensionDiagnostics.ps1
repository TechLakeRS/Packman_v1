[CmdletBinding()]
Param(
    [Parameter(Mandatory=$false)]
    [String]$LogFilesFolder = "C:\ProgramData\Microsoft\IntuneManagementExtension\Logs"
)
function Show-IntuneLogViewer {
    param(
        [string]$LogPath
    )
    
    Write-Host "Processing log file: $LogPath" -ForegroundColor Green
    
    # Create list for log entries
    $LogEntryList = [System.Collections.Generic.List[PSObject]]@()
    
    # Read log file
    $Log = Get-Content -Path $LogPath
    $LineNumber = 1
    
    # Regex patterns for log parsing
    $SingleLineRegex = '^\<\!\[LOG\[(.*)]LOG\].*\<time="([0-9]{1,2}):([0-9]{1,2}):([0-9]{1,2}).([0-9]{1,})".*date="([0-9]{1,2})-([0-9]{1,2})-([0-9]{4})" component="(.*?)" context="(.*?)" type="(.*?)" thread="(.*?)" file="(.*?)">$'
    
    foreach ($CurrentLogEntry in $Log) {
        if($CurrentLogEntry -Match $SingleLineRegex) {
            $LogMessage = $Matches[1].Trim()
            $Hour = $Matches[2]
            $Minute = $Matches[3]
            $Second = $Matches[4]
            $Month = $Matches[6]
            $Day = $Matches[7]
            $Year = $Matches[8]
            $Component = $Matches[9]
            $Type = $Matches[11]
            $Thread = $Matches[12]
            
            # Format DateTime for display
            if($Month -like "?") { $Month = "0$Month" }
            if($Day -like "?") { $Day = "0$Day" }
            $DateTime = "$Year-$Month-$Day $($Hour):$($Minute):$($Second)"
            
            $LogEntryList.add([PSCustomObject]@{
                'Line' = $LineNumber
                'DateTime' = $DateTime
                'Component' = $Component
                'Type' = $Type
                'Thread' = $Thread
                'Message' = $LogMessage
            })
        }
        else {
            # Handle non-standard log entries
            $LogEntryList.add([PSCustomObject]@{
                'Line' = $LineNumber
                'DateTime' = ''
                'Component' = ''
                'Type' = ''
                'Thread' = ''
                'Message' = $CurrentLogEntry
            })
        }
        $LineNumber++
    }
    
    # Show in GridView
    $LogEntryList | Out-GridView -Title "Log Viewer: $(Split-Path $LogPath -Leaf)" -OutputMode Multiple
}
# Main script
Write-Host "Intune Log File Viewer" -ForegroundColor Cyan
Write-Host "========================" -ForegroundColor Cyan
# Get log files
$LogFiles = Get-ChildItem -Path $LogFilesFolder -Filter *.log -ErrorAction SilentlyContinue | 
    Where-Object { 
        $_.Name -match '(IntuneManagementExtension|AgentExecutor|AppWorkload|AppActionProcessor|ClientHealth|DeviceHealthMonitoring|HealthScripts|Sensor|Win32App|Reset-Appx)'
    } |
    Select-Object @{Name='FileName';Expression={$_.Name}},
                  @{Name='Size';Expression={"{0:N2} MB" -f ($_.Length / 1MB)}},
                  @{Name='LastModified';Expression={$_.LastWriteTime}},
                  @{Name='FullPath';Expression={$_.FullName}}
if (-not $LogFiles) {
    Write-Host "No log files found in: $LogFilesFolder" -ForegroundColor Yellow
    exit
}
# Show file selection dialog
$SelectedFile = $LogFiles | Out-GridView -Title "Select a log file to view" -OutputMode Single
if ($SelectedFile) {
    Show-IntuneLogViewer -LogPath $SelectedFile.FullPath
} else {
    Write-Host "No file selected" -ForegroundColor Yellow
}
# SIG # Begin signature block
# MIInygYJKoZIhvcNAQcCoIInuzCCJ7cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCqd70kD+l40g9j
# td6jjDyX1N3gJA1mdO6S7ACc+MadO6CCIdswggWNMIIEdaADAgECAhAOmxiO+dAt
# 5+/bUOIIQBhaMA0GCSqGSIb3DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNV
# BAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBa
# Fw0zMTExMDkyMzU5NTlaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lD
# ZXJ0IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoC
# ggIBAL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3E
# MB/zG6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKy
# unWZanMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsF
# xl7sWxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU1
# 5zHL2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJB
# MtfbBHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObUR
# WBf3JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6
# nj3cAORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxB
# YKqxYxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5S
# UUd0viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+x
# q4aLT8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIB
# NjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwP
# TzAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMC
# AYYweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdp
# Y2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0
# aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENB
# LmNybDARBgNVHSAECjAIMAYGBFUdIAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0Nc
# Vec4X6CjdBs9thbX979XB72arKGHLOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnov
# Lbc47/T/gLn4offyct4kvFIDyE7QKt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65Zy
# oUi0mcudT6cGAxN3J0TU53/oWajwvy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFW
# juyk1T3osdz9HNj0d1pcVIxv76FQPfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPF
# mCLBsln1VWvPJ6tsds5vIy30fnFqI2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9z
# twGpn1eqXijiuZQwgga0MIIEnKADAgECAhANx6xXBf8hmS5AQyIMOkmGMA0GCSqG
# SIb3DQEBCwUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMx
# GTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRy
# dXN0ZWQgUm9vdCBHNDAeFw0yNTA1MDcwMDAwMDBaFw0zODAxMTQyMzU5NTlaMGkx
# CzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4
# RGlnaUNlcnQgVHJ1c3RlZCBHNCBUaW1lU3RhbXBpbmcgUlNBNDA5NiBTSEEyNTYg
# MjAyNSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC0eDHTCphB
# cr48RsAcrHXbo0ZodLRRF51NrY0NlLWZloMsVO1DahGPNRcybEKq+RuwOnPhof6p
# vF4uGjwjqNjfEvUi6wuim5bap+0lgloM2zX4kftn5B1IpYzTqpyFQ/4Bt0mAxAHe
# HYNnQxqXmRinvuNgxVBdJkf77S2uPoCj7GH8BLuxBG5AvftBdsOECS1UkxBvMgEd
# gkFiDNYiOTx4OtiFcMSkqTtF2hfQz3zQSku2Ws3IfDReb6e3mmdglTcaarps0wjU
# jsZvkgFkriK9tUKJm/s80FiocSk1VYLZlDwFt+cVFBURJg6zMUjZa/zbCclF83bR
# VFLeGkuAhHiGPMvSGmhgaTzVyhYn4p0+8y9oHRaQT/aofEnS5xLrfxnGpTXiUOeS
# LsJygoLPp66bkDX1ZlAeSpQl92QOMeRxykvq6gbylsXQskBBBnGy3tW/AMOMCZIV
# NSaz7BX8VtYGqLt9MmeOreGPRdtBx3yGOP+rx3rKWDEJlIqLXvJWnY0v5ydPpOjL
# 6s36czwzsucuoKs7Yk/ehb//Wx+5kMqIMRvUBDx6z1ev+7psNOdgJMoiwOrUG2Zd
# SoQbU2rMkpLiQ6bGRinZbI4OLu9BMIFm1UUl9VnePs6BaaeEWvjJSjNm2qA+sdFU
# eEY0qVjPKOWug/G6X5uAiynM7Bu2ayBjUwIDAQABo4IBXTCCAVkwEgYDVR0TAQH/
# BAgwBgEB/wIBADAdBgNVHQ4EFgQU729TSunkBnx6yuKQVvYv1Ensy04wHwYDVR0j
# BBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMGA1Ud
# JQQMMAoGCCsGAQUFBwMIMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0
# cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0
# cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNVHR8E
# PDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVz
# dGVkUm9vdEc0LmNybDAgBgNVHSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEw
# DQYJKoZIhvcNAQELBQADggIBABfO+xaAHP4HPRF2cTC9vgvItTSmf83Qh8WIGjB/
# T8ObXAZz8OjuhUxjaaFdleMM0lBryPTQM2qEJPe36zwbSI/mS83afsl3YTj+IQhQ
# E7jU/kXjjytJgnn0hvrV6hqWGd3rLAUt6vJy9lMDPjTLxLgXf9r5nWMQwr8Myb9r
# EVKChHyfpzee5kH0F8HABBgr0UdqirZ7bowe9Vj2AIMD8liyrukZ2iA/wdG2th9y
# 1IsA0QF8dTXqvcnTmpfeQh35k5zOCPmSNq1UH410ANVko43+Cdmu4y81hjajV/gx
# dEkMx1NKU4uHQcKfZxAvBAKqMVuqte69M9J6A47OvgRaPs+2ykgcGV00TYr2Lr3t
# y9qIijanrUR3anzEwlvzZiiyfTPjLbnFRsjsYg39OlV8cipDoq7+qNNjqFzeGxcy
# tL5TTLL4ZaoBdqbhOhZ3ZRDUphPvSRmMThi0vw9vODRzW6AxnJll38F0cuJG7uEB
# YTptMSbhdhGQDpOXgpIUsWTjd6xpR6oaQf/DJbg3s6KCLPAlZ66RzIg9sC+NJpud
# /v4+7RWsWCiKi9EOLLHfMR2ZyJ/+xhCx9yHbxtl5TPau1j/1MIDpMPx0LckTetiS
# uEtQvLsNz3Qbp7wGWqbIiOWCnb5WqxL3/BAPvIXKUjPSxyZsq8WhbaM2tszWkPZP
# ubdcMIIG7TCCBNWgAwIBAgIQCoDvGEuN8QWC0cR2p5V0aDANBgkqhkiG9w0BAQsF
# ADBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNV
# BAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgVGltZVN0YW1waW5nIFJTQTQwOTYgU0hB
# MjU2IDIwMjUgQ0ExMB4XDTI1MDYwNDAwMDAwMFoXDTM2MDkwMzIzNTk1OVowYzEL
# MAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTswOQYDVQQDEzJE
# aWdpQ2VydCBTSEEyNTYgUlNBNDA5NiBUaW1lc3RhbXAgUmVzcG9uZGVyIDIwMjUg
# MTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBANBGrC0Sxp7Q6q5gVrMr
# V7pvUf+GcAoB38o3zBlCMGMyqJnfFNZx+wvA69HFTBdwbHwBSOeLpvPnZ8ZN+vo8
# dE2/pPvOx/Vj8TchTySA2R4QKpVD7dvNZh6wW2R6kSu9RJt/4QhguSssp3qome7M
# rxVyfQO9sMx6ZAWjFDYOzDi8SOhPUWlLnh00Cll8pjrUcCV3K3E0zz09ldQ//nBZ
# ZREr4h/GI6Dxb2UoyrN0ijtUDVHRXdmncOOMA3CoB/iUSROUINDT98oksouTMYFO
# nHoRh6+86Ltc5zjPKHW5KqCvpSduSwhwUmotuQhcg9tw2YD3w6ySSSu+3qU8DD+n
# igNJFmt6LAHvH3KSuNLoZLc1Hf2JNMVL4Q1OpbybpMe46YceNA0LfNsnqcnpJeIt
# K/DhKbPxTTuGoX7wJNdoRORVbPR1VVnDuSeHVZlc4seAO+6d2sC26/PQPdP51ho1
# zBp+xUIZkpSFA8vWdoUoHLWnqWU3dCCyFG1roSrgHjSHlq8xymLnjCbSLZ49kPmk
# 8iyyizNDIXj//cOgrY7rlRyTlaCCfw7aSUROwnu7zER6EaJ+AliL7ojTdS5PWPsW
# eupWs7NpChUk555K096V1hE0yZIXe+giAwW00aHzrDchIc2bQhpp0IoKRR7YufAk
# prxMiXAJQ1XCmnCfgPf8+3mnAgMBAAGjggGVMIIBkTAMBgNVHRMBAf8EAjAAMB0G
# A1UdDgQWBBTkO/zyMe39/dfzkXFjGVBDz2GM6DAfBgNVHSMEGDAWgBTvb1NK6eQG
# fHrK4pBW9i/USezLTjAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0lAQH/BAwwCgYIKwYB
# BQUHAwgwgZUGCCsGAQUFBwEBBIGIMIGFMCQGCCsGAQUFBzABhhhodHRwOi8vb2Nz
# cC5kaWdpY2VydC5jb20wXQYIKwYBBQUHMAKGUWh0dHA6Ly9jYWNlcnRzLmRpZ2lj
# ZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNFRpbWVTdGFtcGluZ1JTQTQwOTZTSEEy
# NTYyMDI1Q0ExLmNydDBfBgNVHR8EWDBWMFSgUqBQhk5odHRwOi8vY3JsMy5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRUaW1lU3RhbXBpbmdSU0E0MDk2U0hB
# MjU2MjAyNUNBMS5jcmwwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcB
# MA0GCSqGSIb3DQEBCwUAA4ICAQBlKq3xHCcEua5gQezRCESeY0ByIfjk9iJP2zWL
# pQq1b4URGnwWBdEZD9gBq9fNaNmFj6Eh8/YmRDfxT7C0k8FUFqNh+tshgb4O6Lgj
# g8K8elC4+oWCqnU/ML9lFfim8/9yJmZSe2F8AQ/UdKFOtj7YMTmqPO9mzskgiC3Q
# YIUP2S3HQvHG1FDu+WUqW4daIqToXFE/JQ/EABgfZXLWU0ziTN6R3ygQBHMUBaB5
# bdrPbF6MRYs03h4obEMnxYOX8VBRKe1uNnzQVTeLni2nHkX/QqvXnNb+YkDFkxUG
# tMTaiLR9wjxUxu2hECZpqyU1d0IbX6Wq8/gVutDojBIFeRlqAcuEVT0cKsb+zJNE
# suEB7O7/cuvTQasnM9AWcIQfVjnzrvwiCZ85EE8LUkqRhoS3Y50OHgaY7T/lwd6U
# Arb+BOVAkg2oOvol/DJgddJ35XTxfUlQ+8Hggt8l2Yv7roancJIFcbojBcxlRcGG
# 0LIhp6GvReQGgMgYxQbV1S3CrWqZzBt1R9xJgKf47CdxVRd/ndUlQ05oxYy2zRWV
# FjF7mcr4C34Mj3ocCVccAvlKV9jEnstrniLvUxxVZE/rptb7IRE2lskKPIJgbaP5
# t2nGj/ULLi49xTcBZU8atufk+EMF/cWuiC7POGT75qaL6vdCvHlshtjdNXOCIUjs
# arfNZzCCBzMwggUboAMCAQICEGYMmxKaCmwhVQk43VSg7S0wDQYJKoZIhvcNAQEL
# BQAwUzELMAkGA1UEBhMCRVUxKTAnBgNVBAoMIEVVUk9QRUFOIFNZU1RFTSBPRiBD
# RU5UUkFMIEJBTktTMRkwFwYDVQQDDBBFU0NCLVBLSSBST09UIENBMCAYDzIwMTEw
# NzIyMTA0NjM1WhcNMjYwNzIyMTA0NjM1WjBVMQswCQYDVQQGEwJFVTEpMCcGA1UE
# CgwgRVVST1BFQU4gU1lTVEVNIE9GIENFTlRSQUwgQkFOS1MxGzAZBgNVBAMMEkVT
# Q0ItUEtJIE9OTElORSBDQTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
# ANJvy4ZCs0EnziXahaYZ5gP5o987svHmfC7k+FYJjx1dKUor1mggmNCi2F3YSUxe
# 7PaSbxi3GkEyXhiA+Ip7qcHwfz+KWyr3gZdzhAZIxozFzV5X5O+VjGqU4XbRpDwS
# O16SPG7lZa3cjzjBDedT0b4iar+L4+msL+golBskl0/vFHicpzkPw5i3JifDXlWj
# wplJ8wE3Nli7WBoy97ErbsSsxkDcJ1xcBmEhrJqR9vXNxPFHJ+HcbNeYgRHLeCX2
# J1ukx1vKCn1w2EeIxFTGkxDR9RjiUpmDBH5g3C8S7N5PGZZ8E8EBiY+wQvfOSyrM
# 51EYu0JT+V+mFTGnfftv1GSNEYjU4roPXFolozbyCOcQefV6wUrRBW+F/YmYoAto
# TmA/G0XvEz3YT24R6rDeipcK6QqYffLfUYZoLlKE+kUoOOh2GZvmqgan9h6xA75K
# u5O6aefXZnD6zvJJCUu5g9RtAfy1kOtjqqS+gEiwlvlJihIsVHETlf6jxXpm90Cn
# sXQcevGsV3sblKHYaYxuT0pZHgfeZ16IkZXt1OlKXk3reMInzJtkRHUdeDEP0nzL
# lQdDvp7IvklpMv8UnHFRc+YNiK0bvhF0sWfJa99gNR7VscUfJotr/S7KHbH+tD6v
# m6fa3eX1nqam2xANQVbO1Q3xQOaST0RqRAMCF2S73G+5AgMBAAGjggH9MIIB+TAP
# BgNVHRMBAf8EBTADAQH/MA4GA1UdDwEB/wQEAwIBBjAdBgNVHQ4EFgQU5FneRCS2
# pDyDQzcosMikriYtPQMwHwYDVR0jBBgwFoAU1YUdaWOXKMlZ5tFnB81UvNwCfuow
# PAYDVR0gBDUwMzAxBgRVHSAAMCkwJwYIKwYBBQUHAgEWG2h0dHA6Ly9wa2kuZXNj
# Yi5ldS9wb2xpY2llczA/BggrBgEFBQcBAQQzMDEwLwYIKwYBBQUHMAKGI2h0dHA6
# Ly9wa2kuZXNjYi5ldS9jZXJ0cy9yb290Q0EuY3J0MIIBFQYDVR0fBIIBDDCCAQgw
# ggEEoIIBAKCB/YYiaHR0cDovL3BraS5lc2NiLmV1L2NybHMvcm9vdENBLmNybIaB
# jmxkYXA6Ly9sZGFwLXBraS5lc2NiLmV1L0NOPUVTQ0ItUEtJJTIwUm9vdCUyMENB
# LE9VPVBLSSxPVT1FU0NCLVBLSSxPPUVTQ0IsQz1FVT9jZXJ0aWZpY2F0ZVJldm9j
# YXRpb25MaXN0P2Jhc2U/b2JqZWN0Y2xhc3M9Y1JMRGlzdHJpYnV0aW9uUG9pbnSG
# Jmh0dHA6Ly9pYW0tY3JsLmVzY2IuZXUvZXNjYi9yb290Q0EuY3Jshh5odHRwOi8v
# ZXNjYnBraS9jcmxzL3Jvb3RDQS5jcmwwDQYJKoZIhvcNAQELBQADggIBADSo/LBs
# FuaXPoisACq1U0ymgKv/JCaxatOafoZ3BKJAZ4rw9D3Vc/jcnE3Ln6ZGs/zL+z5X
# bX9v+6VEjRQ5VU2rru5189huHOd7h6kmrTTgky8Py/Tce+P7ofYlE2FtzpTjeqpy
# mNKHsj8iA58G6lZX0uVtBi+bAoRFISG7FPBHbk2hLAvWKNyn2iJ++1vUt1MXRe2x
# 9yOhXNNcIdRC6BtnJUWLwxDAB7UTsSgx4Bc/aCGTfDCsM3CKiFoo7KTM3eiWHaSN
# lN1Pt5RaSwcFiT4sRXCJGc6EbpG4FenIBUvNqKnTHucnt+U9+p7IPAWLsWYrxjMH
# 8At+h5KEmp+SsnxZ13KYhaZ3ZsOZEDbu4YKZHKBLsVY05eD01lx3Spk5qZd/vY7C
# ipky+zpe2b9+6gnD5zsr31dsu3DrvpMRmUfnSeFLKO/0v25GUXfjlKPaltn0X90N
# NrVn2dBDuKp+/LKAXuhTEuNJUS16MiA3VbMuFoX990xqCweGC35eTMoxLl0yHvj4
# FqkCpbdSTBsZuD0hdq72rAVxnlUJneV5Z+D49E02DjSRvN9MmwDKl/9VkT9m+hff
# 7EQe/dyKlLV0HMsH/qVNhN+hTMMQmBE9ufXenJuSMme6pB7XNsECCvqkwWypsPFm
# T1Chmcc+IkSM10HAcPioXKGlRHK2ukowt1VcMIIHZjCCBU6gAwIBAgIQbhMu2c4k
# evZlZgU3D+2uzjANBgkqhkiG9w0BAQsFADBVMQswCQYDVQQGEwJFVTEpMCcGA1UE
# CgwgRVVST1BFQU4gU1lTVEVNIE9GIENFTlRSQUwgQkFOS1MxGzAZBgNVBAMMEkVT
# Q0ItUEtJIE9OTElORSBDQTAeFw0yMzExMjgxNTIwMjNaFw0yNjA3MjIxMDQ2MzVa
# MIGAMQswCQYDVQQGEwJCRTEpMCcGA1UECgwgRVVST1BFQU4gU1lTVEVNIE9GIENF
# TlRSQUwgQkFOS1MxJjAkBgNVBAsMHU5hdGlvbmFsIEJhbmsgb2YgQmVsZ2l1bSAo
# QkUpMR4wHAYDVQQDDBVOQkIgRGlnaXRhbCBXb3JrcGxhY2UwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQCzNNNzo6hkEkb7bf8zCXz3j6BIPs+m+ccClnWY
# EwC7SWiVfUO/Fr9rrLdItzZDzYhYk6MNcspqeigEeVvQHIJ31dU5Y5+wa8aClBK3
# KDSw5TaAoAodthPpoAuX6vv0W32ObnP8M9lG1aGfrLINPoFIaYDWs7wBJFbI4gns
# SulNhc6CyyJVDI3pZ2MyUAr0BjZvveZt0UpuAnyLuZN6S/PiT8YaW/ZUBhf6+LkW
# pU0WahZLdQSKaNdBTiZJRJsCTR35gRK2A1FpOCEGN10f45Y9U290Eoxwnqu7AGGN
# c+F3wCAgYFaVmAVpBB69UqwMreSXEnCBZQxe8sfZW1JZxwf1AgMBAAGjggMEMIID
# ADAiBgNVHREEGzAZgRdkaWdpdGFsd29ya3BsYWNlQG5iYi5iZTAOBgNVHQ8BAf8E
# BAMCB4AwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFF3Qet37dk/9
# 0kMEW9Z3ScPpCAcEMB8GA1UdIwQYMBaAFORZ3kQktqQ8g0M3KLDIpK4mLT0DMEEG
# A1UdIAQ6MDgwNgYJBAB/AAoBAgQDMCkwJwYIKwYBBQUHAgEWG2h0dHA6Ly9wa2ku
# ZXNjYi5ldS9wb2xpY2llczCB3AYIKwYBBQUHAQEEgc8wgcwwLwYIKwYBBQUHMAKG
# I2h0dHA6Ly9wa2kuZXNjYi5ldS9jZXJ0cy9yb290Q0EuY3J0MC4GCCsGAQUFBzAC
# hiJodHRwOi8vcGtpLmVzY2IuZXUvY2VydHMvc3ViQ0EuY3J0MB8GCCsGAQUFBzAB
# hhNodHRwOi8vb2NzcC1lc2NicGtpMCMGCCsGAQUFBzABhhdodHRwOi8vb2NzcC1w
# a2kuZXNjYi5ldTAjBggrBgEFBQcwAYYXaHR0cDovL2lhbS1vY3NwLmVzY2IuZXUw
# HAYIBAB/AAoBAwIEEEJBTkNPIERFIEVTUEHDkUEwGwYIBAB/AAoBAwMED1ZBVEVT
# LVEyODAyNDcyRzCCARMGA1UdHwSCAQowggEGMIIBAqCB/6CB/IYdaHR0cDovL2Vz
# Y2Jwa2kvY3Jscy9zdWJDQS5jcmyGIWh0dHA6Ly9wa2kuZXNjYi5ldS9jcmxzL3N1
# YkNBLmNybIaBkGxkYXA6Ly9sZGFwLXBraS5lc2NiLmV1L0NOPUVTQ0ItUEtJJTIw
# T05MSU5FJTIwQ0EsT1U9UEtJLE9VPUVTQ0ItUEtJLE89RVNDQixDPUVVP2NlcnRp
# ZmljYXRlUmV2b2NhdGlvbkxpc3Q/YmFzZT9vYmplY3RjbGFzcz1jUkxEaXN0cmli
# dXRpb25Qb2ludIYlaHR0cDovL2lhbS1jcmwuZXNjYi5ldS9lc2NiL3N1YkNBLmNy
# bDANBgkqhkiG9w0BAQsFAAOCAgEAD9Wh9F5D8tVvk5uW87M3CVcZHCRg9tAlcZ/m
# 4bz8/qBklgFYne89CyeuxyHUPPSY0Y0DMnFDINVViJ7AknJtnt1KGx6mkkey308/
# hmNOhtWamrph3NTaflejcLpMx6RXiwsKl9bswKIpyajSOpQXX58vQBKoXWeJgK74
# Z9r/lflamvP40oLD5xWK7KDk48z2s9UDz38LMKA4uNOygORzAMZ7okD5TbQoKAWg
# Hia0aVb+G4cPyVk3YkUwZbC6bPAs0lVMUpvp+f1U/TjUviZFHB0OsVBM7o1TTmBy
# 4Ua5aNWMsATRvILvpz77A3XIX3VJXRaDZVuiTmtDWCQnYRHkqZpE4xbFeGDxlKO1
# uCbcXpjWQPlgOuBMCGN5xZTeMQMteHPyI2Jo890dTiuhrzuxw2aeSMOJ8d+PKmnn
# 9m7dC0PVZ2H0cvLOhNccN6GoUBagM02kKHk8y63ecMazDXTWho2jUKFyzL3PsEHw
# 7unGEYwP4nTnxj0lxQ4r7+myPn9rBxr7g76tmDT8mXzjnMOumqhgcTMV61znVptc
# yLDbb9xm9evDCan7I1RsiMpnMXS9XAKx1+hvL9xKip9nEhna9WrQLzOFebn5Xy4d
# pXBPDCKAo0w9/qEy6JUlfzKKRpyA+xA50WErfzUV9drguaVbGHsthHPBkyAJkqcH
# jYCP8XsxggVFMIIFQQIBATBpMFUxCzAJBgNVBAYTAkVVMSkwJwYDVQQKDCBFVVJP
# UEVBTiBTWVNURU0gT0YgQ0VOVFJBTCBCQU5LUzEbMBkGA1UEAwwSRVNDQi1QS0kg
# T05MSU5FIENBAhBuEy7ZziR69mVmBTcP7a7OMA0GCWCGSAFlAwQCAQUAoIGEMBgG
# CisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcC
# AQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIE
# ICaiqNiflwy7G1OZXaA5M+iS9rHpbnb9sfmjqljDAT2aMA0GCSqGSIb3DQEBAQUA
# BIIBADR/MHiDtILmas3jp56zF11bP1AvWRcNxG9PGRk9ncTV2FifoukjLTgyjX0L
# d7SQCc8Zz4bgLgoTiRwA4tyo2pMV9OD4DHgjj6upbgvFbNOKHMc92RHQMBgDJYAI
# 29tjb6L06nGMW5r+0+RccKo2sXGxgE1NAdytkO0S61KfDe7Rl8QkTT0yeVh/+YQh
# VOcIc9OkKlgWlqwut58wwlI7fSqJc7c+VzVcrQJZGUAvS8hLy27w9UXlSMQodYkb
# p55VKSmvs7LXbkP5DFKFgFLODd1vyr4z11EVn8vHbkNkra48v5BGw8Mynb7JrvLI
# WA/M2tNZ5whlf+JGA7ksTVXJn+ahggMmMIIDIgYJKoZIhvcNAQkGMYIDEzCCAw8C
# AQEwfTBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/
# BgNVBAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgVGltZVN0YW1waW5nIFJTQTQwOTYg
# U0hBMjU2IDIwMjUgQ0ExAhAKgO8YS43xBYLRxHanlXRoMA0GCWCGSAFlAwQCAQUA
# oGkwGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjUx
# MTE3MTYxNzQ3WjAvBgkqhkiG9w0BCQQxIgQgwo6mDKYMW//z5b+Wd6muutVqhyhs
# g0TaqXZhqK9Np/4wDQYJKoZIhvcNAQEBBQAEggIAKwH4BRccwpTsBLUnkVgmcnC9
# muPxRXxS3sZilq3mbYnF7lMGqBpwCPSEya/Ri5RNoPF8PfHsn0wBq+QIrAszo4b0
# C5AO3uKr5aTnuk+plNBhGffH9nfJpeUUrSKquy2BA1mVI0nNGdFwmNlysE1hLkq5
# PbmvlLxrqfyuAITB4vThm5NQfJB3cE0jWu1dyI30xKNtwgWWSyxiT9hM6kTLwZR9
# 9m3nRPRlwBtc4eozuvDyaYSrVHMd2P2yBWcWKjmDNk3D1YK0V8naEJGANpq3IM5T
# /HAWJuivhun6ACDvvXrd//sXT30qiCAPzbOLXJVDQBBtgQQQGp49NR+mYfmJ/x/W
# gfqeo/QPlL2DnKGHIx1mg0RfV8nGP3CxJIRHpg8qFG2325Ba65qhiF7WdcOSQA3+
# f2jaUeJjwr2DZEZpvI6+Bdw3I3WH0y+JRtfs1ldYpYcuDBMyNJYQ8IHix5KbOIOY
# mgqdwXDILIDPxhLw1Cev54poSgItFQB28hv757fvlpsbssXHinAFNH2ZBxkoqekI
# VJZbKgleCpAf/ppW0GRh69Wo4u5j7SLC1OxWABO6DNOaVvMILwlb46O+hfJcWvmL
# qC0KelU2MNcG2En2syB9kgYxfObAtsVxYyguyYBLobKDnVER9MtrHXaUUotS8usP
# 7ZhpD/mGlfBOzDfyq3c=
# SIG # End signature block
