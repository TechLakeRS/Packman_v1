using System.Windows.Controls;
namespace Endpoint_Packaging_Suite.Controls
{
    public partial class SkeletonLoader : UserControl
    {
        public SkeletonLoader()
        {
            InitializeComponent();
        }
    }
}
