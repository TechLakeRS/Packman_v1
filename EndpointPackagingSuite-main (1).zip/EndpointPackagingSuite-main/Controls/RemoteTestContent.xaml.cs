using System.Diagnostics;
using System.IO;
using System.Net.NetworkInformation;
using System.Text.RegularExpressions;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Text.Json;
using System.Collections.ObjectModel;
using Endpoint_Packaging_Suite.Dialogs;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite.Services;
using Endpoint_Packaging_Suite.Helpers;

namespace Endpoint_Packaging_Suite.Controls
{
    public partial class RemoteTestContent : UserControl
    {
        private readonly ILogger<RemoteTestContent> _logger;
        private string _currentPackagePath = "";
        private bool _isComputerOnline = false;
        private ObservableCollection<string> _recentComputers = new ObservableCollection<string>();
        private const int MaxRecentComputers = 10;
        private readonly string _recentComputersFile = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "Endpoint_Packaging_Suite",
            "RecentComputers.json");

        // Service locator used here because WPF code-behind doesn't support constructor injection
        private NotificationService Notifications => App.Services.GetRequiredService<NotificationService>();
        private readonly DetectionMethodDiscoveryService _discoveryService = new DetectionMethodDiscoveryService();
        private string _lastDeployedAppName = "";
        private string _lastDeployedAppVersion = "";
        private bool _isDialogMode = false;
        private string _deploymentType = "Install";

        // Devices shown in the left-hand Test Devices list. Backed by the same
        // RecentComputers.json that _recentComputers loads from.
        public ObservableCollection<DeviceRow> Devices { get; } = new ObservableCollection<DeviceRow>();

        public class DeviceRow : System.ComponentModel.INotifyPropertyChanged
        {
            private string _name = "";
            private string _subtitleLine1 = "";
            private string _subtitleLine2 = "";
            private Brush _statusFill = Brushes.Gray;

            public string Name
            {
                get => _name;
                set { _name = value; OnChanged(nameof(Name)); }
            }
            public string SubtitleLine1
            {
                get => _subtitleLine1;
                set
                {
                    _subtitleLine1 = value;
                    OnChanged(nameof(SubtitleLine1));
                    OnChanged(nameof(SubtitleLine1Visibility));
                }
            }
            public string SubtitleLine2
            {
                get => _subtitleLine2;
                set
                {
                    _subtitleLine2 = value;
                    OnChanged(nameof(SubtitleLine2));
                    OnChanged(nameof(SubtitleLine2Visibility));
                }
            }
            public Brush StatusFill
            {
                get => _statusFill;
                set { _statusFill = value; OnChanged(nameof(StatusFill)); }
            }

            public Visibility SubtitleLine1Visibility =>
                string.IsNullOrWhiteSpace(_subtitleLine1) ? Visibility.Collapsed : Visibility.Visible;
            public Visibility SubtitleLine2Visibility =>
                string.IsNullOrWhiteSpace(_subtitleLine2) ? Visibility.Collapsed : Visibility.Visible;

            public event System.ComponentModel.PropertyChangedEventHandler? PropertyChanged;
            private void OnChanged(string p) =>
                PropertyChanged?.Invoke(this, new System.ComponentModel.PropertyChangedEventArgs(p));
        }

        // Buffered output to avoid O(n) string concatenation on every append
        private readonly StringBuilder _outputBuffer = new StringBuilder();
        private System.Windows.Threading.DispatcherTimer? _outputFlushTimer;

        // Event to notify parent when CanDeploy state changes
        public event EventHandler? CanDeployChanged;

        // Property to check if deployment can be triggered (for external Deploy button)
        public bool CanDeploy => _isComputerOnline && !string.IsNullOrEmpty(_currentPackagePath) && btnDeploy.IsEnabled;

        // Parameterless constructor for XAML
        public RemoteTestContent() : this(null)
        {
        }

        public RemoteTestContent(ILogger<RemoteTestContent>? logger)
        {
            // Use NullLogger if none provided (for XAML compatibility)
            _logger = logger ?? NullLogger<RemoteTestContent>.Instance;
            _logger.LogInformation("RemoteTestContent control initializing");

            InitializeComponent();
            LoadRecentComputers();
            lstDevices.ItemsSource = Devices;
            RefreshDevicesFromRecent();

            // Ensure ComboBox text is empty on initialization
            cmbComputerName.Text = "";

            _logger.LogInformation("RemoteTestContent control initialized successfully");
        }

        // Project _recentComputers into the visible Devices collection. Preserves
        // any per-row status that's already been computed.
        private void RefreshDevicesFromRecent()
        {
            var existingByName = Devices.ToDictionary(d => d.Name, d => d, StringComparer.OrdinalIgnoreCase);
            Devices.Clear();
            foreach (var name in _recentComputers)
            {
                if (existingByName.TryGetValue(name, out var row))
                {
                    Devices.Add(row);
                }
                else
                {
                    Devices.Add(new DeviceRow { Name = name });
                }
            }
            UpdateDevicesHeader();
        }

        private void UpdateDevicesHeader()
        {
            txtDevicesHeader.Text = $"TEST DEVICES ({Devices.Count})";
        }

        // Initialize with package path and mode
        // isDialogMode: true = hide internal Deploy button, show label view (use parent's footer button)
        //               false = show internal Deploy button, show browse view (standalone page)
        public void Initialize(string packagePath = "", bool isDialogMode = false)
        {
            _logger.LogInformation("Initializing RemoteTestContent - PackagePath: {PackagePath}, DialogMode: {DialogMode}",
                string.IsNullOrEmpty(packagePath) ? "(empty)" : packagePath, isDialogMode);

            _isDialogMode = isDialogMode;
            _currentPackagePath = packagePath;

            // Hide internal Deploy button in dialog mode (parent window has footer button)
            actionButtonsSection.Visibility = isDialogMode ? Visibility.Collapsed : Visibility.Visible;

            if (isDialogMode)
            {
                // Dialog mode: Show compact label display (no browse button)
                txtPackagePathDisplay.Text = packagePath;
                packagePathLabel.Visibility = Visibility.Visible;
                packagePathBrowse.Visibility = Visibility.Collapsed;
                _logger.LogInformation("Initialized in dialog mode with label view");
            }
            else
            {
                // Standalone mode: Show TextBox with browse button
                txtPackagePath.Text = packagePath;
                packagePathLabel.Visibility = Visibility.Collapsed;
                packagePathBrowse.Visibility = Visibility.Visible;
                _logger.LogInformation("Initialized in standalone mode with browse view");
            }

            UpdateDeploymentTitleFromPackage();
        }

        // Update the "Install Test — <app> <version>" header from the current package path.
        private void UpdateDeploymentTitleFromPackage()
        {
            if (!string.IsNullOrEmpty(_currentPackagePath))
            {
                ExtractAppInfoFromPath();
            }

            if (!string.IsNullOrEmpty(_lastDeployedAppName))
            {
                var version = string.IsNullOrEmpty(_lastDeployedAppVersion) ? "" : $" v{_lastDeployedAppVersion}";
                txtDeploymentTitle.Text = $"{ActionLabel(_deploymentType)} Test — {_lastDeployedAppName}{version}";
            }
            else
            {
                txtDeploymentTitle.Text = $"{ActionLabel(_deploymentType)} Test";
            }
        }

        private static string ActionLabel(string deploymentType) => deploymentType switch
        {
            "Uninstall" => "Uninstall",
            "Repair" => "Repair",
            _ => "Install"
        };

        // Public method to trigger deployment from external button (e.g., dialog footer)
        public void TriggerDeploy()
        {
            if (CanDeploy)
            {
                btnDeploy_Click(this, new RoutedEventArgs());
            }
        }

        // Load recent computers from file
        private void LoadRecentComputers()
        {
            try
            {
                _logger.LogDebug("Loading recent computers from {FilePath}", _recentComputersFile);

                if (File.Exists(_recentComputersFile))
                {
                    string json = File.ReadAllText(_recentComputersFile);
                    var computers = JsonSerializer.Deserialize<List<string>>(json);
                    if (computers != null)
                    {
                        _recentComputers.Clear();
                        foreach (var computer in computers.Take(MaxRecentComputers))
                        {
                            _recentComputers.Add(computer);
                        }
                        _logger.LogInformation("Loaded {Count} recent computers", _recentComputers.Count);
                    }
                }
                else
                {
                    _logger.LogDebug("Recent computers file does not exist yet");
                }

                cmbComputerName.ItemsSource = _recentComputers;
                RefreshDevicesFromRecent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading recent computers from {FilePath}", _recentComputersFile);
                Debug.WriteLine($"Error loading recent computers: {ex.Message}");
            }
        }

        // Save recent computers to file
        private void SaveRecentComputers()
        {
            try
            {
                _logger.LogDebug("Saving {Count} recent computers to {FilePath}", _recentComputers.Count, _recentComputersFile);
                Directory.CreateDirectory(Path.GetDirectoryName(_recentComputersFile)!);
                string json = JsonSerializer.Serialize(_recentComputers.ToList());
                File.WriteAllText(_recentComputersFile, json);
                _logger.LogInformation("Successfully saved recent computers list");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error saving recent computers to {FilePath}", _recentComputersFile);
                Debug.WriteLine($"Error saving recent computers: {ex.Message}");
            }
        }

        // Event Handler: Clear selection when user types new text
        private void cmbComputerName_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            // When user starts typing, clear any selection so the typed text is used
            if (e.Key != System.Windows.Input.Key.Enter &&
                e.Key != System.Windows.Input.Key.Return &&
                e.Key != System.Windows.Input.Key.Tab &&
                e.Key != System.Windows.Input.Key.Escape &&
                e.Key != System.Windows.Input.Key.Up &&
                e.Key != System.Windows.Input.Key.Down)
            {
                // Clear selection so typed text takes precedence
                cmbComputerName.SelectedItem = null;
            }
        }

        // Event Handler: ComboBox Selection Changed - Auto-check online status
        private async void cmbComputerName_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Only trigger when user selects from dropdown (not programmatic changes)
            if (e.AddedItems.Count == 0)
                return;

            string? selectedComputer = e.AddedItems[0] as string;
            if (string.IsNullOrWhiteSpace(selectedComputer))
                return;

            _logger.LogInformation("Computer selected from dropdown: {ComputerName}, auto-checking online status", selectedComputer);

            // Trigger the online check automatically
            UpdateStatus("Checking...", Colors.Orange);
            btnCheckOnline.IsEnabled = false;

            bool isOnline = await Task.Run(() => IsComputerOnline(selectedComputer));

            if (isOnline)
            {
                _logger.LogInformation("Computer '{ComputerName}' is online (auto-check)", selectedComputer);
                UpdateStatus("Online", Colors.Green);
                _isComputerOnline = true;
                SetControlsEnabled(true);
                AppendOutput($"✓ {selectedComputer} is online and ready for deployment.");
            }
            else
            {
                _logger.LogWarning("Computer '{ComputerName}' is offline or unreachable (auto-check)", selectedComputer);
                UpdateStatus("Offline", Colors.Red);
                _isComputerOnline = false;
                btnDeploy.IsEnabled = false;
                AppendOutput($"✗ {selectedComputer} is not reachable. Please check the computer name and network connection.");
            }

            btnCheckOnline.IsEnabled = true;
        }

        // Add computer to recent list
        private void AddToRecentComputers(string computerName)
        {
            if (string.IsNullOrWhiteSpace(computerName))
            {
                _logger.LogDebug("Skipping adding empty computer name to recent list");
                return;
            }

            _logger.LogDebug("Adding computer '{ComputerName}' to recent list", computerName);

            // Remove if already exists
            if (_recentComputers.Contains(computerName))
            {
                _recentComputers.Remove(computerName);
            }

            // Add to top
            _recentComputers.Insert(0, computerName);

            // Keep only max items
            while (_recentComputers.Count > MaxRecentComputers)
            {
                _recentComputers.RemoveAt(_recentComputers.Count - 1);
            }

            SaveRecentComputers();
            RefreshDevicesFromRecent();
        }

        // Event Handler: Check Online Button Click
        private async void btnCheckOnline_Click(object sender, RoutedEventArgs e)
        {
            string computerName = cmbComputerName.Text.Trim();

            _logger.LogInformation("Check online button clicked for computer: {ComputerName}", computerName);

            if (string.IsNullOrEmpty(computerName))
            {
                _logger.LogWarning("Check online attempted with empty computer name");
                ModernMessageBox.Show("Please enter a computer name.", "Input Required",
                    MessageBoxButton.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validate computer name to prevent command injection
            if (!IsValidComputerName(computerName))
            {
                _logger.LogWarning("Invalid computer name format: {ComputerName}", computerName);
                ModernMessageBox.Show("Invalid computer name. Only letters, numbers, hyphens, and dots are allowed.",
                    "Invalid Input", MessageBoxButton.OK, MessageBoxIcon.Warning);
                return;
            }

            UpdateStatus("Checking...", Colors.Orange);
            btnCheckOnline.IsEnabled = false;

            _logger.LogInformation("Checking if computer '{ComputerName}' is online", computerName);
            bool isOnline = await Task.Run(() => IsComputerOnline(computerName));

            if (isOnline)
            {
                _logger.LogInformation("Computer '{ComputerName}' is online", computerName);
                UpdateStatus("Online", Colors.Green);
                _isComputerOnline = true;
                // Deploy button will be enabled by SetControlsEnabled if package path is also set
                SetControlsEnabled(true);
                AppendOutput($"✓ {computerName} is online and ready for deployment.");

                // Add to recent computers
                AddToRecentComputers(computerName);

                // Restore computer name in ComboBox after collection update
                // Using BeginInvoke to ensure text is restored after ItemsSource binding completes
#pragma warning disable CS4014
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    cmbComputerName.Text = computerName;
                }), System.Windows.Threading.DispatcherPriority.Background);
#pragma warning restore CS4014
            }
            else
            {
                _logger.LogWarning("Computer '{ComputerName}' is offline or unreachable", computerName);
                UpdateStatus("Offline", Colors.Red);
                _isComputerOnline = false;
                btnDeploy.IsEnabled = false;
                AppendOutput($"✗ {computerName} is not reachable. Please check the computer name and network connection.");
            }

            btnCheckOnline.IsEnabled = true;
        }

        private bool IsValidComputerName(string computerName)
        {
            // Valid computer names: alphanumeric, hyphens, dots (no special chars like &, |, ;, etc.)
            return Regex.IsMatch(computerName, @"^[a-zA-Z0-9\-\.]+$");
        }

        // Event Handler: Deploy Button Click
        private async void btnDeploy_Click(object sender, RoutedEventArgs e)
        {
            // Clear output terminal and buffer
            lock (_outputBuffer) { _outputBuffer.Clear(); }
            ClearOutputDocument();

            string computerName = cmbComputerName.Text.Trim();
            string deploymentType = GetDeploymentType();
            bool cleanup = true; // Always clean up after deployment
            bool interactive = chkInteractive.IsChecked == true;

            _logger.LogInformation("Deploy button clicked - Computer: {ComputerName}, Type: {DeploymentType}, Cleanup: {Cleanup}, Interactive: {Interactive}",
                computerName, deploymentType, cleanup, interactive);

            // Validate package path
            if (string.IsNullOrEmpty(_currentPackagePath))
            {
                _logger.LogWarning("Deployment attempted with empty package path");
                ModernMessageBox.Show("Package path is not set. Please select a package or use the workflow to set the path.",
                    "Package Path Required", MessageBoxButton.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!Directory.Exists(_currentPackagePath))
            {
                _logger.LogError("Package path does not exist: {PackagePath}", _currentPackagePath);
                ModernMessageBox.Show($"Package path does not exist: {_currentPackagePath}",
                    "Invalid Package Path", MessageBoxButton.OK, MessageBoxIcon.Error);
                return;
            }

            // Disable controls during deployment
            SetControlsEnabled(false);
            progressBar.Visibility = Visibility.Visible;
            progressBar.IsIndeterminate = true;

            AppendOutput($"Starting remote deployment to {computerName}...");
            AppendOutput($"Package: {_currentPackagePath}");
            AppendOutput($"Deployment Type: {deploymentType}");
            AppendOutput($"Interactive Mode: {(interactive ? "Yes" : "No (Silent)")}");
            AppendOutput("----------------------------------------");

            _logger.LogInformation("Starting remote deployment - Package: {PackagePath}, Interactive: {Interactive}", _currentPackagePath, interactive);

            try
            {
                bool success = await ExecuteRemoteDeployment(
                    computerName, _currentPackagePath, deploymentType, cleanup, interactive);

                if (success)
                {
                    _logger.LogInformation("Remote deployment completed successfully to {ComputerName}", computerName);
                    AppendOutput("========================================");
                    AppendOutput("✓ DEPLOYMENT COMPLETED SUCCESSFULLY!");
                    AppendOutput("========================================");

                    // Show non-blocking success notification
                    Notifications.ShowSuccess(
                        "Deployment Successful",
                        $"Deployment to {computerName} completed successfully!");

                    // Auto-discover detection methods after successful installation
                    if (deploymentType == "Install")
                    {
                        _logger.LogInformation("Waiting 3 seconds for registry to update before discovering detection methods");
                        AppendOutput("Waiting for registry to update...");
                        await Task.Delay(3000); // Wait 3 seconds for registry to be fully written
                        await DiscoverDetectionMethodsAsync(computerName);
                    }
                }
                else
                {
                    _logger.LogError("Remote deployment failed to {ComputerName}", computerName);
                    AppendOutput("========================================");
                    AppendOutput("✗ DEPLOYMENT FAILED!");
                    AppendOutput("========================================");

                    // Show error notification (doesn't auto-close)
                    Notifications.ShowError(
                        "Deployment Failed",
                        $"Deployment to {computerName} failed. Check the output for details.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Exception during remote deployment to {ComputerName}", computerName);
                AppendOutput($"ERROR: {ex.Message}");
                ModernMessageBox.Show($"An error occurred: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxIcon.Error);
            }
            finally
            {
                // Flush any remaining buffered output
                FlushOutput();

                progressBar.Visibility = Visibility.Collapsed;
                progressBar.IsIndeterminate = false;
                SetControlsEnabled(true);
                _logger.LogDebug("Deployment operation completed, controls re-enabled");
            }
        }

        // Execute the existing PowerShell script file
        private async Task<bool> ExecuteRemoteDeployment(string computerName,
            string sourcePath, string deploymentType, bool cleanup, bool interactive = false)
        {
            return await Task.Run(() =>
            {
                try
                {
                    _logger.LogInformation("Executing remote deployment - Computer: {ComputerName}, Source: {SourcePath}, Type: {DeploymentType}, Cleanup: {Cleanup}",
                        computerName, sourcePath, deploymentType, cleanup);

                    // Path to your PowerShell script
                    string scriptPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory,
                        "Scripts", "RemoteDeployment.ps1");

                    // Alternative paths to check
                    if (!File.Exists(scriptPath))
                    {
                        _logger.LogDebug("Script not found at {ScriptPath}, trying alternative location", scriptPath);
                        // Try embedded resource location
                        scriptPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory,
                            "RemoteDeployment.ps1");
                    }

                    if (!File.Exists(scriptPath))
                    {
                        _logger.LogError("PowerShell script not found at any expected location. Last tried: {ScriptPath}", scriptPath);
                        AppendOutput($"ERROR: PowerShell script not found at {scriptPath}");
                        return false;
                    }

                    _logger.LogDebug("Using PowerShell script at: {ScriptPath}", scriptPath);

                    // Build PowerShell arguments
                    string arguments = $@"-ExecutionPolicy Bypass -NoProfile -File ""{scriptPath}"" " +
                                     $@"-TargetComputer ""{computerName}"" " +
                                     $@"-SourcePath ""{sourcePath}"" " +
                                     $@"-DeploymentType ""{deploymentType}""";

                    if (cleanup)
                    {
                        arguments += " -CleanupAfterDeploy";
                    }

                    // Execute PowerShell
                    _logger.LogDebug("Starting PowerShell process with arguments: {Arguments}", arguments);
                    ProcessStartInfo psi = new ProcessStartInfo
                    {
                        FileName = "powershell.exe",
                        Arguments = arguments,
                        UseShellExecute = false,
                        RedirectStandardOutput = true,
                        RedirectStandardError = true,
                        CreateNoWindow = true,
                        WorkingDirectory = Path.GetDirectoryName(scriptPath)
                    };

                    using (Process? process = Process.Start(psi))
                    {
                        if (process == null)
                        {
                            _logger.LogError("Failed to start PowerShell process");
                            AppendOutput("ERROR: Failed to start PowerShell process");
                            return false;
                        }

                        _logger.LogDebug("PowerShell process started successfully");

                        // Read both streams simultaneously to avoid deadlock
                        var outputTask = Task.Run(() =>
                        {
                            string? line;
                            var lines = new List<string>();
                            while ((line = process.StandardOutput.ReadLine()) != null)
                            {
                                lines.Add(line);
                                AppendOutput(line);
                            }
                            return lines;
                        });

                        var errorTask = Task.Run(() =>
                        {
                            string? line;
                            var lines = new List<string>();
                            while ((line = process.StandardError.ReadLine()) != null)
                            {
                                lines.Add(line);
                                AppendOutput($"ERROR: {line}");
                            }
                            return lines;
                        });

                        // Wait for both streams to complete
                        Task.WaitAll(outputTask, errorTask);
                        process.WaitForExit();

                        var outputLines = outputTask.Result;
                        var errorLines = errorTask.Result;
                        bool hasOutput = outputLines.Count > 0 || errorLines.Count > 0;

                        int exitCode = process.ExitCode;
                        _logger.LogInformation("PowerShell process exited with code: {ExitCode}", exitCode);
                        AppendOutput("");
                        AppendOutput($"PowerShell process exited with code: {exitCode}");

                        // Check for no output scenario
                        if (!hasOutput)
                        {
                            _logger.LogWarning("No output received from PowerShell script - possible configuration issue");
                            AppendOutput("");
                            AppendOutput("WARNING: No output received from PowerShell script.");
                            AppendOutput("This usually means:");
                            AppendOutput("  1. PsExec.exe is missing from C:\\Windows\\System32\\");
                            AppendOutput("  2. Execution policy prevented the script from running");
                            AppendOutput("  3. Insufficient permissions to execute the script");
                            AppendOutput("  4. The script path or parameters are incorrect");
                            AppendOutput("");
                            AppendOutput("Try running this command manually in PowerShell:");
                            AppendOutput($"  {arguments}");
                            return false;
                        }

                        bool success = exitCode == 0 || exitCode == 3010;
                        _logger.LogInformation("Remote deployment execution completed - Success: {Success}, ExitCode: {ExitCode}",
                            success, exitCode);
                        return success;
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Exception during remote deployment execution");
                    AppendOutput($"Execution error: {ex.Message}");
                    AppendOutput($"Stack trace: {ex.StackTrace}");
                    return false;
                }
            });
        }

        // Check if computer is online. Side-effect: if reachable, record the
        // IP address on the matching DeviceRow so the devices list shows it
        // as a subtitle.
        private bool IsComputerOnline(string computerName)
        {
            try
            {
                _logger.LogDebug("Pinging computer: {ComputerName}", computerName);
                using (Ping ping = new Ping())
                {
                    PingReply reply = ping.Send(computerName, 2000);
                    bool isOnline = reply.Status == IPStatus.Success;
                    _logger.LogDebug("Ping result for {ComputerName}: {Status}", computerName, reply.Status);
                    if (isOnline && reply.Address != null)
                    {
                        var ip = reply.Address.ToString();
                        Dispatcher.Invoke(() =>
                        {
                            var row = Devices.FirstOrDefault(d =>
                                string.Equals(d.Name, computerName, StringComparison.OrdinalIgnoreCase));
                            if (row != null) row.SubtitleLine1 = ip;
                        });
                    }
                    return isOnline;
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Error pinging computer {ComputerName}", computerName);
                return false;
            }
        }

        // Pill colors — keyed off the app's semantic palette (Primary, Success,
        // Warning, Error text colours + Surface for the idle background).
        private static readonly Brush PillGoodBg   = new SolidColorBrush(Color.FromArgb(0x22, 0x2E, 0x7D, 0x32));
        private static readonly Brush PillGood     = new SolidColorBrush(Color.FromRgb(0x81, 0xC7, 0x84));
        private static readonly Brush PillWarnBg   = new SolidColorBrush(Color.FromArgb(0x22, 0xFF, 0xA0, 0x00));
        private static readonly Brush PillWarn     = new SolidColorBrush(Color.FromRgb(0xFF, 0xD5, 0x4F));
        private static readonly Brush PillBadBg    = new SolidColorBrush(Color.FromArgb(0x22, 0xC6, 0x28, 0x28));
        private static readonly Brush PillBad      = new SolidColorBrush(Color.FromRgb(0xEF, 0x9A, 0x9A));
        private static readonly Brush PillIdleBg   = new SolidColorBrush(Color.FromRgb(0x27, 0x27, 0x27));
        private static readonly Brush PillIdle     = new SolidColorBrush(Color.FromRgb(0xA8, 0xA8, 0xA8));
        private static readonly Brush PillIdleDot  = new SolidColorBrush(Color.FromRgb(0x7A, 0x7A, 0x7A));

        // Helper method to update status indicator (legacy hidden elements + new pill UI)
        private void UpdateStatus(string status, Color color)
        {
            Dispatcher.Invoke(() =>
            {
                txtStatus.Text = status;
                var brush = new SolidColorBrush(color);
                statusIndicator.Fill = brush;

                string computer = cmbComputerName.Text.Trim();
                bool online = status.Equals("Online", StringComparison.OrdinalIgnoreCase);
                bool checking = status.Equals("Checking...", StringComparison.OrdinalIgnoreCase);

                if (string.IsNullOrEmpty(computer))
                {
                    pillStatusDot.Fill = PillIdleDot;
                    pillStatusText.Text = "Not connected";
                    pillStatusText.Foreground = PillIdle;
                    connectionPill.Background = PillIdleBg;
                }
                else if (online)
                {
                    pillStatusDot.Fill = PillGood;
                    pillStatusText.Text = $"Connected to {computer}";
                    pillStatusText.Foreground = PillGood;
                    connectionPill.Background = PillGoodBg;
                }
                else if (checking)
                {
                    pillStatusDot.Fill = PillWarn;
                    pillStatusText.Text = $"Connecting to {computer}…";
                    pillStatusText.Foreground = PillWarn;
                    connectionPill.Background = PillWarnBg;
                }
                else
                {
                    pillStatusDot.Fill = PillBad;
                    pillStatusText.Text = $"{computer} — {status}";
                    pillStatusText.Foreground = PillBad;
                    connectionPill.Background = PillBadBg;
                }

                btnReconnect.IsEnabled = !string.IsNullOrEmpty(computer);
                btnDisconnect.IsEnabled = online;

                // Reflect status on the matching device row
                if (!string.IsNullOrEmpty(computer))
                {
                    var row = Devices.FirstOrDefault(d =>
                        string.Equals(d.Name, computer, StringComparison.OrdinalIgnoreCase));
                    if (row != null)
                    {
                        row.StatusFill = online ? PillGood : checking ? PillWarn : PillBad;
                    }
                }
            });
        }

        // Helper method to append output to the console (buffered to avoid O(n) UI updates)
        private void AppendOutput(string text)
        {
            var ts = DateTime.Now.ToString("HH:mm:ss");
            lock (_outputBuffer)
            {
                _outputBuffer.Append($"[{ts}] {text}\n");
            }
            lock (_pendingLines)
            {
                _pendingLines.Add((ts, text));
            }

            // Start the flush timer if not already running (must be done on UI thread)
            Dispatcher.BeginInvoke(new Action(() =>
            {
                if (_outputFlushTimer == null)
                {
                    _outputFlushTimer = new System.Windows.Threading.DispatcherTimer
                    {
                        Interval = TimeSpan.FromMilliseconds(200)
                    };
                    _outputFlushTimer.Tick += (s, e) => FlushOutput();
                }

                if (!_outputFlushTimer.IsEnabled)
                {
                    _outputFlushTimer.Start();
                }
            }));
        }

        // Lines that have been buffered but not yet rendered into the RichTextBox.
        private readonly List<(string timestamp, string message)> _pendingLines = new();
        private bool _hasRenderedRealOutput = false;

        // Terminal line colors — sampled from the app's existing dark theme
        // (PrimaryColor, SuccessColor, WarningColor, ErrorColor, TextSecondary/Muted).
        private static readonly Brush TermTimestamp = new SolidColorBrush(Color.FromRgb(0x7A, 0x7A, 0x7A));
        private static readonly Brush TermAccent    = new SolidColorBrush(Color.FromRgb(0x4F, 0xC3, 0xF7));
        private static readonly Brush TermGood      = new SolidColorBrush(Color.FromRgb(0x81, 0xC7, 0x84));
        private static readonly Brush TermWarn      = new SolidColorBrush(Color.FromRgb(0xFF, 0xD5, 0x4F));
        private static readonly Brush TermBad       = new SolidColorBrush(Color.FromRgb(0xEF, 0x9A, 0x9A));
        private static readonly Brush TermInfo      = new SolidColorBrush(Color.FromRgb(0x4F, 0xC3, 0xF7));
        private static readonly Brush TermDim       = new SolidColorBrush(Color.FromRgb(0xA8, 0xA8, 0xA8));

        private static Brush ClassifyLine(string message)
        {
            if (string.IsNullOrEmpty(message)) return TermDim;
            var head = message.TrimStart();
            if (head.StartsWith("PS>", StringComparison.Ordinal)) return TermAccent;
            if (head.StartsWith("→") || head.StartsWith("->")) return TermInfo;        // arrow
            if (head.StartsWith("✓") || head.StartsWith("[OK]")) return TermGood;      // check
            if (head.StartsWith("✗") || head.StartsWith("[FAIL]")) return TermBad;     // cross
            if (head.StartsWith("⚠") || head.StartsWith("WARNING")) return TermWarn;   // warn
            if (head.StartsWith("ERROR", StringComparison.OrdinalIgnoreCase)) return TermBad;
            if (head.Contains("Return code: 3010", StringComparison.Ordinal)) return TermWarn;
            return TermDim;
        }

        // Clear the terminal document and all buffered output state.
        private void ClearOutputDocument()
        {
            lock (_pendingLines) { _pendingLines.Clear(); }
            _hasRenderedRealOutput = false;
            if (Dispatcher.CheckAccess())
            {
                txtOutput.Document.Blocks.Clear();
            }
            else
            {
                Dispatcher.Invoke(() => txtOutput.Document.Blocks.Clear());
            }
        }

        // Flush pending lines into the RichTextBox as colored paragraphs.
        private void FlushOutput()
        {
            try
            {
                List<(string ts, string msg)> toRender;
                lock (_pendingLines)
                {
                    if (_pendingLines.Count == 0)
                    {
                        _outputFlushTimer?.Stop();
                        return;
                    }
                    toRender = new List<(string, string)>(_pendingLines);
                    _pendingLines.Clear();
                }

                Dispatcher.Invoke(() =>
                {
                    if (!_hasRenderedRealOutput)
                    {
                        txtOutput.Document.Blocks.Clear();
                        _hasRenderedRealOutput = true;
                    }

                    foreach (var (ts, msg) in toRender)
                    {
                        var para = new Paragraph { Margin = new Thickness(0) };
                        para.Inlines.Add(new Run($"[{ts}] ") { Foreground = TermTimestamp });
                        para.Inlines.Add(new Run(msg) { Foreground = ClassifyLine(msg) });
                        txtOutput.Document.Blocks.Add(para);
                    }

                    // Auto-scroll to bottom
                    txtOutput.ScrollToEnd();
                });
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error flushing output: {ex.Message}");
            }
        }

        // Get selected deployment type
        private string GetDeploymentType() => _deploymentType;

        // Enable/disable controls
        private void SetControlsEnabled(bool enabled)
        {
            bool canRunRemoteAction = enabled && _isComputerOnline && !string.IsNullOrEmpty(_currentPackagePath);

            // Hidden Deploy button still drives CanDeploy for the dialog footer
            btnDeploy.IsEnabled = canRunRemoteAction;

            btnCheckOnline.IsEnabled = enabled;
            cmbComputerName.IsEnabled = enabled;
            chkInteractive.IsEnabled = enabled;

            // Action buttons in the new layout
            btnInstall.IsEnabled = canRunRemoteAction;
            btnUninstall.IsEnabled = canRunRemoteAction;
            btnRepair.IsEnabled = canRunRemoteAction;
            // Detect doesn't require a package path; only an online host
            btnDetect.IsEnabled = enabled && _isComputerOnline;

            // Notify parent of CanDeploy state change (for external Deploy button in dialog)
            CanDeployChanged?.Invoke(this, EventArgs.Empty);
        }

        // ====== New action button handlers ======

        private void btnInstall_Click(object sender, RoutedEventArgs e)
        {
            _deploymentType = "Install";
            UpdateDeploymentTitleFromPackage();
            btnDeploy_Click(sender, e);
        }

        private void btnUninstall_Click(object sender, RoutedEventArgs e)
        {
            _deploymentType = "Uninstall";
            UpdateDeploymentTitleFromPackage();
            btnDeploy_Click(sender, e);
        }

        private void btnRepair_Click(object sender, RoutedEventArgs e)
        {
            _deploymentType = "Repair";
            UpdateDeploymentTitleFromPackage();
            btnDeploy_Click(sender, e);
        }

        private async void btnDetect_Click(object sender, RoutedEventArgs e)
        {
            string computerName = cmbComputerName.Text.Trim();
            if (string.IsNullOrEmpty(computerName))
            {
                ModernMessageBox.Show("Select a device first.", "Detect",
                    MessageBoxButton.OK, MessageBoxIcon.Information);
                return;
            }

            _logger.LogInformation("Detect button clicked for {ComputerName}", computerName);
            btnDetect.IsEnabled = false;
            try
            {
                await DiscoverDetectionMethodsAsync(computerName);
            }
            finally
            {
                // Re-evaluate based on current state
                SetControlsEnabled(true);
            }
        }

        private void btnPullLogs_Click(object sender, RoutedEventArgs e)
        {
            // TODO: wire to LogsView log retrieval.
            ModernMessageBox.Show(
                "Pulling PSADT logs from a remote machine isn't wired yet — use the Logs page to fetch them.",
                "Pull logs",
                MessageBoxButton.OK,
                MessageBoxIcon.Information);
        }

        private void btnReconnect_Click(object sender, RoutedEventArgs e) =>
            btnCheckOnline_Click(sender, e);

        private void btnDisconnect_Click(object sender, RoutedEventArgs e)
        {
            _logger.LogInformation("Disconnect clicked for {ComputerName}", cmbComputerName.Text);
            _isComputerOnline = false;
            UpdateStatus("Disconnected", Colors.Gray);
            SetControlsEnabled(true);
            AppendOutput($"Disconnected from {cmbComputerName.Text.Trim()}.");
        }

        // ====== Devices list selection → triggers existing connectivity check ======

        private void lstDevices_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lstDevices.SelectedItem is not DeviceRow row || string.IsNullOrWhiteSpace(row.Name))
                return;

            cmbComputerName.Text = row.Name;
            btnCheckOnline_Click(this, new RoutedEventArgs());
        }

        // Event Handler: Browse Package Button Click (only visible in standalone mode)
        private void BrowsePackage_Click(object sender, RoutedEventArgs e)
        {
            _logger.LogInformation("Browse package button clicked");

            // Use modern folder browser for better UX
            var selectedPath = FolderBrowserHelper.ShowPackageFolderBrowser(
                validatePackageStructure: FolderBrowserHelper.ValidatePackageStructure);

            if (string.IsNullOrEmpty(selectedPath))
            {
                _logger.LogDebug("User cancelled package selection dialog");
                return;
            }

            _logger.LogDebug("User selected folder: {SelectedPath}", selectedPath);

            // Get the actual package root (in case user selected Application folder)
            var packagePath = FolderBrowserHelper.GetPackageRootPath(selectedPath);
            _logger.LogDebug("Resolved package root path: {PackagePath}", packagePath);

            if (!string.IsNullOrEmpty(packagePath))
            {
                _currentPackagePath = packagePath;
                txtPackagePath.Text = packagePath;
                _logger.LogInformation("Package path set to: {PackagePath}", packagePath);
                AppendOutput($"Package path selected: {packagePath}");

                UpdateDeploymentTitleFromPackage();

                // Update Deploy button state now that we have a package path
                SetControlsEnabled(true);
            }
        }

        // Event Handler: Export Log Button Click
        private void btnExportLog_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _logger.LogInformation("Export log button clicked");

                // Flush any buffered output before exporting
                FlushOutput();

                string outputText;
                lock (_outputBuffer) { outputText = _outputBuffer.ToString(); }

                if (string.IsNullOrWhiteSpace(outputText))
                {
                    _logger.LogDebug("No log data available to export");
                    ModernMessageBox.Show("No log data to export.", "Export Log",
                        MessageBoxButton.OK, MessageBoxIcon.Information);
                    return;
                }

                var saveFileDialog = new Microsoft.Win32.SaveFileDialog
                {
                    Title = "Export Deployment Log",
                    Filter = "Text Files (*.txt)|*.txt|Log Files (*.log)|*.log|All Files (*.*)|*.*",
                    FilterIndex = 1,
                    FileName = $"RemoteDeployment_{DateTime.Now:yyyyMMdd_HHmmss}.txt",
                    DefaultExt = "txt"
                };

                if (saveFileDialog.ShowDialog() == true)
                {
                    File.WriteAllText(saveFileDialog.FileName, outputText);
                    _logger.LogInformation("Log exported to: {FilePath}", saveFileDialog.FileName);

                    AppendOutput($"✓ Log exported to: {saveFileDialog.FileName}");

                    Notifications.ShowSuccess(
                        "Log Exported",
                        $"Deployment log saved successfully!");
                }
                else
                {
                    _logger.LogDebug("User cancelled log export dialog");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error exporting deployment log");
                ModernMessageBox.Show($"Error exporting log: {ex.Message}", "Export Error",
                    MessageBoxButton.OK, MessageBoxIcon.Error);
            }
        }

        // Event Handler: Clear Log Button Click
        private void btnClearLog_Click(object sender, RoutedEventArgs e)
        {
            _logger.LogInformation("Clear log button clicked");

            var result = ModernMessageBox.Show(
                "Are you sure you want to clear the deployment log?",
                "Clear Log",
                MessageBoxButton.YesNo,
                MessageBoxIcon.Question);

            if (result == MessageBoxResult.Yes)
            {
                _logger.LogInformation("User confirmed log clear");
                lock (_outputBuffer) { _outputBuffer.Clear(); }
                ClearOutputDocument();
            }
            else
            {
                _logger.LogDebug("User cancelled log clear");
            }
        }

        // Discover detection methods after successful deployment
        private async Task DiscoverDetectionMethodsAsync(string computerName)
        {
            try
            {
                _logger.LogInformation("Starting detection method discovery for computer: {ComputerName}", computerName);

                AppendOutput("");
                AppendOutput("========================================");
                AppendOutput("Discovering detection methods...");
                AppendOutput("========================================");

                // Extract app name and version from package path
                ExtractAppInfoFromPath();

                if (string.IsNullOrEmpty(_lastDeployedAppName))
                {
                    _logger.LogWarning("Unable to determine app name from package path: {PackagePath}", _currentPackagePath);
                    AppendOutput("⚠ Unable to determine app name from package path");
                    return;
                }

                _logger.LogInformation("Searching for detection methods - App: {AppName}, Version: {AppVersion}",
                    _lastDeployedAppName, _lastDeployedAppVersion);
                AppendOutput($"Searching for application: '{_lastDeployedAppName}' Version: '{_lastDeployedAppVersion}'");
                AppendOutput($"Package path used: {_currentPackagePath}");

                // Try to find source installer file in package directory
                string sourceInstallerPath = "";
                if (!string.IsNullOrEmpty(_currentPackagePath) && Directory.Exists(_currentPackagePath))
                {
                    var filesFolder = Path.Combine(_currentPackagePath, "Files");
                    if (Directory.Exists(filesFolder))
                    {
                        // Look for exe or msi files
                        var installerFiles = Directory.GetFiles(filesFolder, "*.exe", SearchOption.TopDirectoryOnly)
                            .Concat(Directory.GetFiles(filesFolder, "*.msi", SearchOption.TopDirectoryOnly))
                            .Where(f => !Path.GetFileName(f).Contains("unins", StringComparison.OrdinalIgnoreCase))
                            .ToList();

                        if (installerFiles.Any())
                        {
                            sourceInstallerPath = installerFiles.First();
                            _logger.LogInformation("Found source installer: {SourcePath}", sourceInstallerPath);
                            AppendOutput($"Using source installer metadata from: {Path.GetFileName(sourceInstallerPath)}");
                        }
                    }
                }

                var result = await _discoveryService.DiscoverDetectionMethodsAsync(
                    computerName,
                    _lastDeployedAppName,
                    _lastDeployedAppVersion,
                    sourceInstallerPath);

                // Show debug messages if any
                if (result.DebugMessages.Count > 0)
                {
                    foreach (var debugMsg in result.DebugMessages)
                    {
                        AppendOutput($"  [DEBUG] {debugMsg}");
                    }
                }

                if (result.Success && result.SuggestedRules.Count > 0)
                {
                    _logger.LogInformation("Found {Count} detection method(s)", result.SuggestedRules.Count);
                    AppendOutput($"✓ Found {result.SuggestedRules.Count} detection method(s)");

                    // Save discovered rules to package metadata (nbb_info folder)
                    if (!string.IsNullOrEmpty(_currentPackagePath))
                    {
                        DetectionRulesCache.SetDiscoveredRules(result.SuggestedRules, _currentPackagePath, computerName);
                        _logger.LogInformation("Saved {Count} detection rules to package metadata at {PackagePath}/nbb_info/", result.SuggestedRules.Count, _currentPackagePath);
                        AppendOutput($"✓ Detection rules saved to package metadata (nbb_info/detection_rules.json)");
                    }

                    // Update UI with detection methods
                    Dispatcher.Invoke(() =>
                    {
                        detectionRulesList.ItemsSource = result.SuggestedRules;

                        if (!string.IsNullOrEmpty(result.AppName))
                        {
                            txtDetectionAppName.Text = $"Application: {result.AppName}";
                            txtDetectionPublisher.Text = $"Publisher: {result.Publisher}";
                            txtDetectionVersion.Text = $"Version: {result.AppVersion}";
                            detectionAppInfo.Visibility = Visibility.Visible;
                        }

                        detectionMethodsSection.Visibility = Visibility.Visible;
                    });

                    AppendOutput("Detection methods displayed below.");
                    AppendOutput("💡 TIP: These detection methods will be auto-populated when you upload to Intune!");
                }
                else
                {
                    _logger.LogWarning("No detection methods discovered: {ErrorMessage}", result.ErrorMessage);
                    AppendOutput($"⚠ No detection methods discovered");
                    if (!string.IsNullOrEmpty(result.ErrorMessage))
                    {
                        AppendOutput($"   Error: {result.ErrorMessage}");
                    }
                    AppendOutput($"   TIP: Verify the application is installed and its DisplayName in the registry matches '{_lastDeployedAppName}'");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error discovering detection methods for computer: {ComputerName}", computerName);
                AppendOutput($"✗ Error discovering detection methods: {ex.Message}");
                Debug.WriteLine($"Discovery error: {ex}");
            }
        }

        // Extract app name and version from package path
        private void ExtractAppInfoFromPath()
        {
            try
            {
                _logger.LogDebug("Extracting app info from package path: {PackagePath}", _currentPackagePath);

                // Package path format: ...\Manufacturer_AppName\Version\
                var pathParts = _currentPackagePath.Split(new[] { '\\', '/' }, StringSplitOptions.RemoveEmptyEntries);

                if (pathParts.Length >= 2)
                {
                    // Version is the last folder
                    _lastDeployedAppVersion = pathParts[pathParts.Length - 1];

                    // App name is the second to last (Manufacturer_AppName)
                    var manufacturerAppName = pathParts[pathParts.Length - 2];

                    // Split by underscore to get app name (remove manufacturer prefix)
                    var parts = manufacturerAppName.Split('_');
                    if (parts.Length >= 2)
                    {
                        // Join all parts after the first (manufacturer) back together
                        _lastDeployedAppName = string.Join("_", parts.Skip(1));
                    }
                    else
                    {
                        _lastDeployedAppName = manufacturerAppName;
                    }

                    _logger.LogInformation("Extracted app info - AppName: {AppName}, Version: {AppVersion}",
                        _lastDeployedAppName, _lastDeployedAppVersion);
                    Debug.WriteLine($"Extracted - AppName: {_lastDeployedAppName}, Version: {_lastDeployedAppVersion}");
                }
                else
                {
                    _logger.LogWarning("Package path does not have expected format (expected at least 2 parts): {PackagePath}", _currentPackagePath);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error extracting app info from path: {PackagePath}", _currentPackagePath);
                Debug.WriteLine($"Error extracting app info from path: {ex.Message}");
                _lastDeployedAppName = "";
                _lastDeployedAppVersion = "";
            }
        }

        // Event Handler: Copy Detection Rules Button Click
        private void btnCopyDetectionRules_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _logger.LogInformation("Copy detection rules button clicked");

                var rules = detectionRulesList.ItemsSource as List<DetectionRule>;
                if (rules == null || rules.Count == 0)
                {
                    _logger.LogDebug("No detection rules available to copy");
                    ModernMessageBox.Show("No detection rules to copy.", "Copy Rules",
                        MessageBoxButton.OK, MessageBoxIcon.Information);
                    return;
                }

                var sb = new StringBuilder();
                sb.AppendLine("=== Intune Detection Method Recommendations ===");
                sb.AppendLine();

                if (!string.IsNullOrEmpty(txtDetectionAppName.Text))
                {
                    sb.AppendLine(txtDetectionAppName.Text);
                    sb.AppendLine(txtDetectionPublisher.Text);
                    sb.AppendLine(txtDetectionVersion.Text);
                    sb.AppendLine();
                }

                int count = 1;
                foreach (var rule in rules)
                {
                    sb.AppendLine($"{count}. {rule.Title}");
                    sb.AppendLine($"   {rule.Description}");
                    sb.AppendLine();
                    count++;
                }

                Clipboard.SetText(sb.ToString());
                _logger.LogInformation("Copied {Count} detection rules to clipboard", rules.Count);

                AppendOutput("✓ Detection rules copied to clipboard");

                Notifications.ShowSuccess(
                    "Copied to Clipboard",
                    "Detection method recommendations copied successfully!");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error copying detection rules to clipboard");
                ModernMessageBox.Show($"Error copying rules: {ex.Message}", "Copy Error",
                    MessageBoxButton.OK, MessageBoxIcon.Error);
            }
        }
    }
}