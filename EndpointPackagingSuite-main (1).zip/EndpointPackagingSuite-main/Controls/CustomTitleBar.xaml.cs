using System;
using System.Windows;
using System.Windows.Controls;

namespace Endpoint_Packaging_Suite.Controls
{
    public partial class CustomTitleBar : UserControl
    {
        private Window? _host;

        public CustomTitleBar()
        {
            InitializeComponent();
            Loaded += OnLoaded;
            Unloaded += OnUnloaded;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            _host = Window.GetWindow(this);
            if (_host == null) return;

            _host.StateChanged += OnHostStateChanged;
            MinimizeButton.IsEnabled = _host.ResizeMode != ResizeMode.NoResize;
            MaxRestoreButton.IsEnabled = _host.ResizeMode == ResizeMode.CanResize
                                         || _host.ResizeMode == ResizeMode.CanResizeWithGrip;
            UpdateMaxRestoreGlyph();
        }

        private void OnUnloaded(object sender, RoutedEventArgs e)
        {
            if (_host != null)
            {
                _host.StateChanged -= OnHostStateChanged;
                _host = null;
            }
        }

        private void OnHostStateChanged(object? sender, EventArgs e)
        {
            UpdateMaxRestoreGlyph();
            // WindowChrome + WindowStyle="None" overflows the work area by ~8px on each side
            // when maximized. Push the content inward so it doesn't get clipped behind the
            // taskbar / screen edge.
            if (_host?.Content is FrameworkElement root)
            {
                root.Margin = _host.WindowState == WindowState.Maximized
                    ? new Thickness(8)
                    : new Thickness(0);
            }
        }

        private void UpdateMaxRestoreGlyph()
        {
            if (_host == null) return;
            if (_host.WindowState == WindowState.Maximized)
            {
                MaxRestoreButton.Content = "";
                MaxRestoreButton.ToolTip = "Restore";
            }
            else
            {
                MaxRestoreButton.Content = "";
                MaxRestoreButton.ToolTip = "Maximize";
            }
        }

        private void MinimizeButton_Click(object sender, RoutedEventArgs e)
        {
            if (_host != null) _host.WindowState = WindowState.Minimized;
        }

        private void MaxRestoreButton_Click(object sender, RoutedEventArgs e)
        {
            if (_host == null) return;
            _host.WindowState = _host.WindowState == WindowState.Maximized
                ? WindowState.Normal
                : WindowState.Maximized;
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            _host?.Close();
        }
    }
}
