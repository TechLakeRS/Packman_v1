using Endpoint_Packaging_Suite.Services;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Serilog;
using System;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography.X509Certificates;
using MsLogger = Microsoft.Extensions.Logging.ILogger;

namespace Endpoint_Packaging_Suite.Infrastructure
{
    /// <summary>
    /// Extension methods for configuring dependency injection
    /// </summary>
    public static class ServiceCollectionExtensions
    {
        /// <summary>
        /// Configure all application services
        /// </summary>
        public static IServiceCollection AddApplicationServices(this IServiceCollection services)
        {
            // Configuration
            var configuration = BuildConfiguration();
            services.AddSingleton<IConfiguration>(configuration);

            // Logging
            ConfigureLogging();
            services.AddLogging(builder =>
            {
                builder.ClearProviders();
                builder.AddSerilog(dispose: true);
            });

            // Memory Cache
            services.AddMemoryCache(options =>
            {
                options.SizeLimit = 100; // Limit cache to 100 entries
                options.CompactionPercentage = 0.25; // Compact 25% when full
            });

            // Settings Service (Singleton - loaded once)
            services.AddSingleton<SettingsService>();

            // User Settings Service (Singleton - per-user settings in AppData)
            services.AddSingleton<UserSettingsService>();

            // Notification Service (Singleton - manages toast notifications)
            services.AddSingleton<NotificationService>();

            // Application List Cache Service (Singleton - disk cache for the app list)
            services.AddSingleton<ApplicationCacheService>();

            // KeyVault Service (Singleton - loaded at startup, kept for session lifetime)
            services.AddSingleton<KeyVaultService>(sp =>
            {
                var settings = sp.GetRequiredService<SettingsService>();
                var cache = sp.GetRequiredService<IMemoryCache>();
                var logger = Log.Logger;

                var keyVaultName = settings.Settings.KeyVaultName;
                var tenantId = settings.Settings.Authentication?.TenantId;
                var cacheDuration = settings.Settings.KeyVault?.CacheDurationHours ?? 24;

                return new KeyVaultService(keyVaultName, tenantId, cache, logger, cacheDuration);
            });

            // Native Authenticode signer (Singleton - in-process, no PowerShell, no temp PFX)
            // Used by: the Sign tab, IntuneUploadService (PSADT script signing on
            // upload/update) and HyperVCatalogService (.cat signing). Reads the
            // code-signing cert from KeyVaultService and calls SignerSignEx2 via P/Invoke.
            services.AddSingleton<NativeCodeSigner>(sp =>
            {
                var keyVault = sp.GetRequiredService<KeyVaultService>();
                var settings = sp.GetRequiredService<SettingsService>();
                return new NativeCodeSigner(keyVault, settings);
            });

            // Intune Service (Scoped - per operation)
            services.AddScoped<IntuneService>(sp =>
            {
                var settings = sp.GetRequiredService<SettingsService>();
                var cache = sp.GetRequiredService<IMemoryCache>();
                var appListCache = sp.GetRequiredService<ApplicationCacheService>();
                var logger = sp.GetRequiredService<ILogger<IntuneService>>();
                var keyVault = sp.GetRequiredService<KeyVaultService>();

                return new IntuneService(
                    settings.Settings.Authentication.TenantId,
                    settings.Settings.Authentication.ClientId,
                    keyVault,
                    cache,
                    appListCache,
                    logger);
            });

            // Intune Upload Service (Scoped - per operation)
            services.AddScoped<IntuneUploadService>();

            // GitLab Service (Singleton - version control integration)
            services.AddSingleton<GitLabService>();

            // HttpClient with Polly for Intune API
            services.AddHttpClient("IntuneAPI")
                .ConfigureHttpClient(client =>
                {
                    client.Timeout = TimeSpan.FromMinutes(2);
                });

            // HttpClient for Intune Upload (longer timeout)
            services.AddHttpClient("IntuneUpload")
                .ConfigureHttpClient(client =>
                {
                    client.Timeout = TimeSpan.FromMinutes(30);
                });

            // HttpClient for GitLab API
            services.AddHttpClient("GitLab")
                .ConfigureHttpClient(client =>
                {
                    client.Timeout = TimeSpan.FromSeconds(30);
                });

            // HttpClient Factory
            services.AddHttpClient();

            // ViewModels (Transient - new instance for each use)
            services.AddTransient<Endpoint_Packaging_Suite.ViewModels.MainViewModel>();
            services.AddTransient<Endpoint_Packaging_Suite.ViewModels.CreatePackageViewModel>();
            services.AddTransient<Endpoint_Packaging_Suite.ViewModels.ApplicationListViewModel>();
            services.AddTransient<Endpoint_Packaging_Suite.ViewModels.UploadPackageViewModel>();
            services.AddTransient<Endpoint_Packaging_Suite.ViewModels.UpgradePackageViewModel>();

            return services;
        }

        /// <summary>
        /// Build configuration from appsettings.json
        /// </summary>
        private static IConfiguration BuildConfiguration()
        {
            var basePath = AppDomain.CurrentDomain.BaseDirectory;

            return new ConfigurationBuilder()
                .SetBasePath(basePath)
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .Build();
        }

        /// <summary>
        /// Configure Serilog logging
        /// </summary>
        private static void ConfigureLogging()
        {
            var logPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Endpoint_Packaging_Suite",
                "Logs",
                "app-.log"
            );

            // Ensure logs directory exists
            var logDir = Path.GetDirectoryName(logPath);
            if (!string.IsNullOrEmpty(logDir) && !Directory.Exists(logDir))
            {
                Directory.CreateDirectory(logDir);
            }

            Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Debug()
                .WriteTo.File(
                    logPath,
                    rollingInterval: RollingInterval.Day,
                    retainedFileCountLimit: 7,
                    outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff} [{Level:u3}] {SourceContext} {Message:lj}{NewLine}{Exception}"
                )
                .CreateLogger();

            Log.Information("=== Endpoint Packaging Suite Started ===");
        }
    }
}