using Endpoint_Packaging_Suite.Constants;
using Endpoint_Packaging_Suite.Helpers;
using Endpoint_Packaging_Suite.Managers;
using Endpoint_Packaging_Suite.Models;
using Endpoint_Packaging_Suite.Services;
using Endpoint_Packaging_Suite.Dialogs;
using Endpoint_Packaging_Suite.ViewModels;
using Endpoint_Packaging_Suite.Views;
using Microsoft.Extensions.DependencyInjection;
using Serilog;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Endpoint_Packaging_Suite
{
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        #region Private Fields

        // Timer and Search
        private System.Windows.Threading.DispatcherTimer? _searchTimer;

        // Services
        private IntuneService? _intuneService;
        private PSADTGenerator? _psadtGenerator;
        private IntuneUploadService? _uploadService;
        private SettingsService? _settingsService;
        private NotificationService? _notificationService;
        private MsiInfoService.MsiInfo? _currentMsiInfo = null;
        private CancellationTokenSource? _initCancellation;

        // Managers
        private NavigationManager? _navigationManager;

        // ViewModels
        private CreatePackageViewModel? _createPackageViewModel;
        private UploadPackageViewModel? _uploadPackageViewModel;
        private UpgradePackageViewModel? _upgradePackageViewModel;
        private ApplicationListViewModel? _applicationListViewModel;

        // Package Management (Upload Existing)
        private string _detectedPackageType = "";
        private string _msiProductCode = "";
        private string _msiProductVersion = "";

        // Icon extraction (Create Mode)
        private string _extractedIconPath = "";
        #endregion

        #region Properties
        public IntuneService? GetIntuneService()
        {
            return _intuneService;
        }

        public string DetectedPackageType
        {
            get
            {
                if (DetectedPackageTypeText.Text.StartsWith("MSI Package")) return "MSI";
                if (DetectedPackageTypeText.Text.StartsWith("EXE Installer")) return "EXE";
                return "Unknown";
            }
            private set
            {
                // Store the value if needed
                _detectedPackageType = value;
            }
        }

        #endregion

        public MainWindow()
        {
            InitializeComponent();

            InitializeTimer();
            InitializeUI();
            InitializeNotificationService();

            // Initialize services asynchronously (loads from Key Vault if configured)
            Loaded += async (sender, e) => await InitializeServicesAsync();
        }

        protected override void OnSourceInitialized(System.EventArgs e)
        {
            base.OnSourceInitialized(e);

            // Clamp the window to the current monitor's work area so a 1400x900
            // default doesn't overhang on smaller displays (1366x768, laptops, etc.).
            var work = SystemParameters.WorkArea;
            if (Width > work.Width) Width = work.Width;
            if (Height > work.Height) Height = work.Height;
            Left = work.Left + (work.Width - Width) / 2;
            Top = work.Top + (work.Height - Height) / 2;
        }

        #region INotifyPropertyChanged Implementation

        public event PropertyChangedEventHandler? PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }
}
