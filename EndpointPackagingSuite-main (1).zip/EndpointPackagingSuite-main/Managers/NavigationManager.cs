using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Endpoint_Packaging_Suite.Views;
using Endpoint_Packaging_Suite.Constants;
using Endpoint_Packaging_Suite;

namespace Endpoint_Packaging_Suite.Managers
{
    /// <summary>
    /// Manages page navigation and UI visibility for the main window
    /// </summary>
    public class NavigationManager
    {
        // Page name constants from AppConstants
        public const string PageNameCreateApplication = AppConstants.Navigation.PageNameCreateApplication;
        public const string PageNameUploadExisting = AppConstants.Navigation.PageNameUploadExisting;
        public const string PageNameViewApplications = AppConstants.Navigation.PageNameViewApplications;
        public const string PageNameSettings = AppConstants.Navigation.PageNameSettings;
        public const string PageNameLogs = AppConstants.Navigation.PageNameLogs;
        public const string PageNameWDACTools = AppConstants.Navigation.PageNameWDACTools;
        public const string PageNameRemoteTest = AppConstants.Navigation.PageNameRemoteTest;
        public const string PageNameSign = AppConstants.Navigation.PageNameSign;
        public const string PageNameAdvanced = AppConstants.Navigation.PageNameAdvanced;

        // UI Elements (passed from MainWindow)
        private readonly UIElement _createApplicationPage;
        private readonly UIElement _uploadExistingPage;
        private readonly UIElement _viewApplicationsPage;
        private readonly UIElement? _settingsPage; // Nullable - Settings page removed
        private readonly UIElement _paginationPanel;
        private readonly Grid _mainContentGrid;
        private readonly TextBlock _pageTitle;
        private readonly TextBlock _pageSubtitle;
        private readonly TextBox _searchTextBox;
        private readonly UIElement _pageHeader;
        private readonly UIElement _applicationsListPanel;
        private readonly UIElement _applicationDetailView;

        // Navigation buttons
        private readonly Button _createAppNavButton;
        private readonly Button _uploadExistingNavButton;
        private readonly Button _viewAppsNavButton;
        private readonly Button? _settingsNavButton; // Nullable - Settings button removed
        private readonly Button _logsNavButton;
        private readonly Button _wdacToolsNavButton;
        private readonly Button _remoteTestNavButton;
        private readonly Button? _signNavButton;
        private readonly Button? _advancedNavButton;

        // Navigation button icons (for active state highlighting)
        private readonly TextBlock _createAppNavIconText;
        private readonly TextBlock _uploadNavIconText;
        private readonly TextBlock _viewAppsNavIconText;
        private readonly TextBlock _remoteTestNavIconText;
        private readonly TextBlock _logsNavIconText;
        private readonly TextBlock _wdacNavIconText;
        private readonly TextBlock? _signNavIconText;
        private readonly TextBlock? _advancedNavIconText;

        // Dynamic pages
        private WDACToolsPage? _wdacToolsPage;
        private LogsView? _logsView;
        private RemoteTestPage? _remoteTestPage;
        private SignView? _signView;
        private AdvancedView? _advancedView;

        public NavigationManager(
            UIElement createApplicationPage,
            UIElement uploadExistingPage,
            UIElement viewApplicationsPage,
            UIElement? settingsPage,
            UIElement paginationPanel,
            Grid mainContentGrid,
            TextBlock pageTitle,
            TextBlock pageSubtitle,
            TextBox searchTextBox,
            UIElement pageHeader,
            UIElement applicationsListPanel,
            UIElement applicationDetailView,
            Button createAppNavButton,
            Button uploadExistingNavButton,
            Button viewAppsNavButton,
            Button? settingsNavButton,
            Button logsNavButton,
            Button wdacToolsNavButton,
            Button remoteTestNavButton,
            TextBlock createAppNavIconText,
            TextBlock uploadNavIconText,
            TextBlock viewAppsNavIconText,
            TextBlock remoteTestNavIconText,
            TextBlock logsNavIconText,
            TextBlock wdacNavIconText,
            Button? signNavButton = null,
            TextBlock? signNavIconText = null,
            Button? advancedNavButton = null,
            TextBlock? advancedNavIconText = null)
        {
            _createApplicationPage = createApplicationPage;
            _uploadExistingPage = uploadExistingPage;
            _viewApplicationsPage = viewApplicationsPage;
            _settingsPage = settingsPage;
            _paginationPanel = paginationPanel;
            _mainContentGrid = mainContentGrid;
            _pageTitle = pageTitle;
            _pageSubtitle = pageSubtitle;
            _searchTextBox = searchTextBox;
            _pageHeader = pageHeader;
            _applicationsListPanel = applicationsListPanel;
            _applicationDetailView = applicationDetailView;

            _createAppNavButton = createAppNavButton;
            _uploadExistingNavButton = uploadExistingNavButton;
            _viewAppsNavButton = viewAppsNavButton;
            _settingsNavButton = settingsNavButton;
            _logsNavButton = logsNavButton;
            _wdacToolsNavButton = wdacToolsNavButton;
            _remoteTestNavButton = remoteTestNavButton;

            _createAppNavIconText = createAppNavIconText;
            _uploadNavIconText = uploadNavIconText;
            _viewAppsNavIconText = viewAppsNavIconText;
            _remoteTestNavIconText = remoteTestNavIconText;
            _logsNavIconText = logsNavIconText;
            _wdacNavIconText = wdacNavIconText;

            _signNavButton = signNavButton;
            _signNavIconText = signNavIconText;

            _advancedNavButton = advancedNavButton;
            _advancedNavIconText = advancedNavIconText;
        }

        /// <summary>
        /// Shows the specified page and updates the header
        /// </summary>
        public void ShowPage(string pageName)
        {
            // Hide all existing pages
            HideAllPages();

            // Always show the shared page header; every page including Remote
            // Test uses it so the title/subtitle style stays consistent.
            _pageHeader.Visibility = Visibility.Visible;

            // Show requested page and update header
            switch (pageName)
            {
                case PageNameCreateApplication:
                    _createApplicationPage.Visibility = Visibility.Visible;
                    _pageTitle.Text = "Create Package";
                    _pageSubtitle.Text = "Build new application packages for Intune deployment";
                    break;

                case PageNameUploadExisting:
                    _uploadExistingPage.Visibility = Visibility.Visible;
                    _pageTitle.Text = "Upload Package";
                    _pageSubtitle.Text = "Upload an existing package to Intune";
                    break;

                case PageNameViewApplications:
                    _viewApplicationsPage.Visibility = Visibility.Visible;
                    _paginationPanel.Visibility = Visibility.Visible;
                    // Reset ApplicationDetailView state when navigating to ViewApplications
                    _applicationDetailView.Visibility = Visibility.Collapsed;
                    _applicationsListPanel.Visibility = Visibility.Visible;
                    _pageTitle.Text = "Applications";
                    _pageSubtitle.Text = "Browse and manage Microsoft Intune applications";
                    _searchTextBox.Focus();
                    break;

                case PageNameLogs:
                    if (_logsView == null)
                    {
                        _logsView = new LogsView();
                        _mainContentGrid.Children.Add(_logsView);
                    }

                    _logsView.Visibility = Visibility.Visible;
                    _pageTitle.Text = "Intune Logs & Diagnostics";
                    _pageSubtitle.Text = "View and troubleshoot Intune Management Extension logs";
                    break;

                case PageNameSettings:
                    // Settings page has been removed - configuration is in appsettings.json
                    if (_settingsPage != null)
                    {
                        _settingsPage.Visibility = Visibility.Visible;
                        _pageTitle.Text = "Settings";
                        _pageSubtitle.Text = "Configure application settings and preferences";
                    }
                    break;

                case PageNameWDACTools:
                    // Ensure the UserControl is added to the main content area if not already
                    if (_wdacToolsPage == null)
                    {
                        _wdacToolsPage = new WDACToolsPage();
                    }

                    // Add to MainContentGrid if not already a child
                    if (!_mainContentGrid.Children.Contains(_wdacToolsPage))
                    {
                        _mainContentGrid.Children.Add(_wdacToolsPage);
                    }

                    _wdacToolsPage.Visibility = Visibility.Visible;
                    _pageTitle.Text = "WDAC Security Tools";
                    _pageSubtitle.Text = "Generate and manage Windows Defender Application Control catalogs";
                    break;

                case PageNameRemoteTest:
                    // Ensure the UserControl is added to the main content area if not already
                    if (_remoteTestPage == null)
                    {
                        _remoteTestPage = new RemoteTestPage();
                    }

                    // Add to MainContentGrid if not already a child
                    if (!_mainContentGrid.Children.Contains(_remoteTestPage))
                    {
                        _mainContentGrid.Children.Add(_remoteTestPage);
                    }

                    _remoteTestPage.Visibility = Visibility.Visible;
                    _pageTitle.Text = "Remote Test Deployment";
                    _pageSubtitle.Text = "Test packages on remote machines using PsExec";
                    break;

                case PageNameSign:
                    if (_signView == null)
                    {
                        _signView = new SignView();
                    }

                    if (!_mainContentGrid.Children.Contains(_signView))
                    {
                        _mainContentGrid.Children.Add(_signView);
                    }

                    _signView.Visibility = Visibility.Visible;
                    _pageTitle.Text = "Sign Files";
                    _pageSubtitle.Text = "Authenticode-sign files using the Key Vault code-signing certificate";
                    break;

                case PageNameAdvanced:
                    if (_advancedView == null)
                    {
                        _advancedView = new AdvancedView();
                    }

                    if (!_mainContentGrid.Children.Contains(_advancedView))
                    {
                        _mainContentGrid.Children.Add(_advancedView);
                    }

                    _advancedView.Visibility = Visibility.Visible;
                    _pageTitle.Text = "Advanced";
                    _pageSubtitle.Text = "Maintenance actions and tools for package management";
                    break;
            }
        }

        /// <summary>
        /// Sets the active navigation button style
        /// </summary>
        public void SetActiveNavButton(Button activeButton)
        {
            // Reset all buttons to inactive style
            var inactiveStyle = (Style)Application.Current.FindResource("SidebarNavButton");
            var activeStyle = (Style)Application.Current.FindResource("ActiveSidebarNavButton");

            _createAppNavButton.Style = inactiveStyle;
            _uploadExistingNavButton.Style = inactiveStyle;
            _viewAppsNavButton.Style = inactiveStyle;
            if (_settingsNavButton != null) _settingsNavButton.Style = inactiveStyle;
            _logsNavButton.Style = inactiveStyle;
            _wdacToolsNavButton.Style = inactiveStyle;
            _remoteTestNavButton.Style = inactiveStyle;
            if (_signNavButton != null) _signNavButton.Style = inactiveStyle;
            if (_advancedNavButton != null) _advancedNavButton.Style = inactiveStyle;

            // Reset all icons to inactive state (white)
            // Note: Opacity is controlled by the style's ContentPresenter (0.6 inactive, 0.87 hover, 1.0 active)
            _createAppNavIconText.Foreground = Brushes.White;
            _uploadNavIconText.Foreground = Brushes.White;
            _viewAppsNavIconText.Foreground = Brushes.White;
            _remoteTestNavIconText.Foreground = Brushes.White;
            _logsNavIconText.Foreground = Brushes.White;
            _wdacNavIconText.Foreground = Brushes.White;
            if (_signNavIconText != null) _signNavIconText.Foreground = Brushes.White;
            if (_advancedNavIconText != null) _advancedNavIconText.Foreground = Brushes.White;

            // Set active button style
            activeButton.Style = activeStyle;

            // Set active icon to accent color (matches the left border accent)
            var accentBrush = (SolidColorBrush)Application.Current.FindResource("AccentBrush");
            TextBlock? activeIcon = GetIconForButton(activeButton);
            if (activeIcon != null)
            {
                activeIcon.Foreground = accentBrush;
            }
        }

        /// <summary>
        /// Gets the icon TextBlock associated with a navigation button
        /// </summary>
        private TextBlock? GetIconForButton(Button button)
        {
            if (button == _createAppNavButton) return _createAppNavIconText;
            if (button == _uploadExistingNavButton) return _uploadNavIconText;
            if (button == _viewAppsNavButton) return _viewAppsNavIconText;
            if (button == _remoteTestNavButton) return _remoteTestNavIconText;
            if (button == _logsNavButton) return _logsNavIconText;
            if (button == _wdacToolsNavButton) return _wdacNavIconText;
            if (_signNavButton != null && button == _signNavButton) return _signNavIconText;
            if (_advancedNavButton != null && button == _advancedNavButton) return _advancedNavIconText;
            return null;
        }

        /// <summary>
        /// Hides all pages
        /// </summary>
        private void HideAllPages()
        {
            _createApplicationPage.Visibility = Visibility.Collapsed;
            _uploadExistingPage.Visibility = Visibility.Collapsed;
            _viewApplicationsPage.Visibility = Visibility.Collapsed;
            if (_settingsPage != null) _settingsPage.Visibility = Visibility.Collapsed;
            _paginationPanel.Visibility = Visibility.Collapsed;

            if (_wdacToolsPage != null)
            {
                _wdacToolsPage.Visibility = Visibility.Collapsed;
            }

            if (_logsView != null)
            {
                _logsView.Visibility = Visibility.Collapsed;
            }

            if (_remoteTestPage != null)
            {
                _remoteTestPage.Visibility = Visibility.Collapsed;
            }

            if (_signView != null)
            {
                _signView.Visibility = Visibility.Collapsed;
            }

            if (_advancedView != null)
            {
                _advancedView.Visibility = Visibility.Collapsed;
            }
        }
    }
}